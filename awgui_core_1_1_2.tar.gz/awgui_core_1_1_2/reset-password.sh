#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Запустите: sudo $0 [НОВЫЙ_ПАРОЛЬ]" >&2; exit 1; }

TARGET="/opt/awgui"
ENV_FILE="/etc/awgui.env"
[[ -f "$ENV_FILE" ]] || { echo "Не найден $ENV_FILE" >&2; exit 1; }
[[ -x "$TARGET/.venv/bin/python" ]] || { echo "AWGUI не установлена в $TARGET" >&2; exit 1; }

PASSWORD="${1:-$(openssl rand -hex 10)}"
if [[ ${#PASSWORD} -lt 12 || ${#PASSWORD} -gt 128 || "$PASSWORD" =~ [[:space:]\\\"\'] ]]; then
  echo "Пароль должен содержать 12–128 символов без пробелов, кавычек и обратного слеша." >&2
  exit 1
fi

python3 - "$ENV_FILE" "$PASSWORD" <<'PY'
import os
import sys
import tempfile
from pathlib import Path

path = Path(sys.argv[1])
password = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines()
out = []
updated = False
for line in lines:
    if line.startswith("AWGUI_ADMIN_PASSWORD="):
        out.append(f"AWGUI_ADMIN_PASSWORD={password}")
        updated = True
    else:
        out.append(line)
if not updated:
    out.append(f"AWGUI_ADMIN_PASSWORD={password}")
fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
try:
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(out) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
finally:
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
PY

systemctl restart awgui.service
systemctl is-active --quiet awgui.service
"$TARGET/.venv/bin/python" -m panel.runtime_check "$ENV_FILE"
USER_NAME="$(awk -F= '$1=="AWGUI_ADMIN_USER"{print substr($0,index($0,"=")+1); exit}' "$ENV_FILE")"
echo "Логин: ${USER_NAME:-admin}"
echo "Новый пароль: $PASSWORD"
