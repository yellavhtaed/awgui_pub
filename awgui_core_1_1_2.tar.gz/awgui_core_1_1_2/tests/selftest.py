from __future__ import annotations

import json
import multiprocessing
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui-test-"))
STATE = TMP / "state"
AWG = TMP / "awg"
CONF = TMP / "awg0.conf"
MANAGE = TMP / "manage.sh"
MANAGE.write_bytes((ROOT / "tests/fake_manage.sh").read_bytes())
MANAGE.chmod(0o700)
AWG.mkdir()
CONF.write_text("[Interface]\nAddress = 172.16.17.1/24\n", encoding="utf-8")

os.environ.update({
    "AWGUI_BASE_DIR": str(ROOT),
    "AWGUI_VENDOR_DIR": str(ROOT / "vendor" / "bivlked"),
    "AWGUI_STATE_DIR": str(STATE),
    "AWGUI_STATE_FILE": str(STATE / "state.json"),
    "AWGUI_STATE_LOCK_FILE": str(STATE / "state.lock"),
    "AWGUI_ADMIN_USER": "admin",
    "AWGUI_ADMIN_PASSWORD": "testpass",
    "AWGUI_SECRET_KEY": "test-secret",
    "AWGUI_SSH_BIN": str(ROOT / "tests/fake_ssh.sh"),
})

from panel import state, telegram
from panel.cascade import _render_upstream_routing_script, patch_awg1_config, transfer_link_config
from panel.manager import AWGManager, make_ssh_server
from panel.web import create_app
from panel.runtime_check import read_env

LOCAL = {
    "id": "local", "name": "Local", "mode": "local", "host": "127.0.0.1", "port": 22,
    "user": "root", "key_path": "", "manage_path": str(MANAGE), "awg_dir": str(AWG),
    "server_conf": str(CONF),
}
state.save({
    "servers": [LOCAL],
    "telegram": {"enabled": False, "token": "", "admin_ids": [], "dangerous": False},
    "telegram_server": {},
})

# Direct delegation to the installed manage_amneziawg.sh surface.
mgr = AWGManager(state.get_server("local"))
assert mgr.installed()
assert mgr.add(["phone"], expires="1d", psk=True).ok
assert mgr.list_clients().ok and mgr.list_clients().data[0]["name"] == "phone"
assert mgr.stats().ok
assert mgr.client_file("phone", "conf")
assert mgr.client_bundle("phone")
assert mgr.run_manage("backup").ok
assert mgr.backup_list()
assert mgr.modify("phone", "DNS", "1.1.1.1").ok
assert mgr.regen(["phone"]).ok
assert not mgr.run_manage("not-a-command").ok

# Server inventory stays agentless and stores no installer fields.
remote = make_ssh_server("remote", "fake", key_path="/tmp/key", manage_path=str(MANAGE), awg_dir=str(AWG), server_conf=str(CONF))
assert "installer_dir" not in remote
state.upsert_server(remote)
assert state.get_server("remote")["manage_path"] == str(MANAGE)

# State update is process-safe: independent writers cannot overwrite each other.
def add_server(index: int) -> None:
    from panel import state as child_state
    child_state.upsert_server(make_ssh_server(f"s{index}", "fake", manage_path=str(MANAGE), awg_dir=str(AWG), server_conf=str(CONF)))

processes = [multiprocessing.Process(target=add_server, args=(i,)) for i in range(6)]
for process in processes: process.start()
for process in processes: process.join(10); assert process.exitcode == 0
ids = {item["id"] for item in state.list_servers()}
assert {f"s{i}" for i in range(6)} <= ids

# CASCADE.md contract: only DNS removal and Table=off; AllowedIPs is untouched.
source_conf = "[Interface]\nDNS = 1.1.1.1\nPrivateKey = x\n[Peer]\nEndpoint = 1.2.3.4:39743\nAllowedIPs = 0.0.0.0/0\n"
patched = patch_awg1_config(source_conf)
assert "DNS" not in patched and "Table = off" in patched and "AllowedIPs = 0.0.0.0/0" in patched
rendered = _render_upstream_routing_script("172.16.17.0/24", "1.2.3.4").decode()
assert 'CLIENT_SUBNET="172.16.17.0/24"' in rendered
assert 'AWG1_ENDPOINT="1.2.3.4"' in rendered
assert 'RU_ZONE_FALLBACK_URL="https://raw.githubusercontent.com/bivlked/amneziawg-installer/main/cascade/ru.zone"' in rendered

# Non-full-tunnel link config is rejected rather than silently rewritten.
EXIT_AWG = TMP / "exit-awg"
EXIT_AWG.mkdir()
(EXIT_AWG / "link.conf").write_text("[Interface]\nPrivateKey=x\n[Peer]\nEndpoint=1.2.3.4:39743\nAllowedIPs=10.0.0.0/8\n")
exit_spec = {**LOCAL, "id": "exit", "name": "Exit", "awg_dir": str(EXIT_AWG)}
result = transfer_link_config(mgr, AWGManager(exit_spec), "link")
assert not result.ok and "AllowedIPs" in result.stderr
assert not (Path("/etc/amnezia/amneziawg/awg1.conf")).exists()

# Environment parser used by install/reset checks reads the exact credentials.
env_file = TMP / "awgui.env"
env_file.write_text("AWGUI_ADMIN_USER=admin\nAWGUI_ADMIN_PASSWORD=testpass\n", encoding="utf-8")
assert read_env(env_file)["AWGUI_ADMIN_PASSWORD"] == "testpass"

# Web auth, CSRF, safe redirects and core routes.
app = create_app(); app.testing = True
client = app.test_client()
assert client.get("/health").status_code == 200
response = client.post("/login?next=//evil.example", data={"username": "admin", "password": "testpass"})
assert response.status_code == 302 and "evil.example" not in response.headers["Location"]
response = client.post("/login", data={"username": "admin", "password": "testpass"}, follow_redirects=True)
assert response.status_code == 200
with client.session_transaction() as sess:
    csrf = sess["csrf_token"]
assert client.post("/clients", data={"action": "add", "names": "bad"}).status_code == 400
for url in ["/", "/clients", "/servers", "/cascade", "/settings"]:
    response = client.get(url)
    assert response.status_code == 200, (url, response.status_code)
response = client.post("/clients", data={"csrf_token": csrf, "action": "add", "names": "tablet", "expires": "", "apply_mode": "syncconf"})
assert response.status_code == 200 and (AWG / "tablet.conf").is_file()

# Telegram parity and the single-client removal callback regression.
state.set_telegram({"enabled": True, "token": "test", "admin_ids": ["1"], "dangerous": True})
messages: list[tuple] = []
telegram.send = lambda chat_id, text, kb=None: messages.append((chat_id, text, kb))
telegram.answer = lambda callback_id, text="": None
telegram.handle_command("1", "/add phone2 --expires=1d --psk")
assert (AWG / "phone2.conf").is_file()
telegram.handle_command("1", "/remove phone2")
callback = messages[-1][2]["inline_keyboard"][0][0]["callback_data"]
assert callback.startswith("remove:") and callback != "remove:phone2"
telegram.handle_callback({"id": "1", "data": callback, "message": {"chat": {"id": "1"}}})
assert not (AWG / "phone2.conf").exists()
for marker in ["/cascade", "/clients", "/backupfile", "/uploadbackup", "/addserver"]:
    assert marker in telegram.HELP, marker
for forbidden in ["/install", "/deploy", "/uninstall", "installer"]:
    assert forbidden not in telegram.HELP

print("AWGUI Core selftest OK")
