from __future__ import annotations

import argparse
import http.client
import json
import time
import urllib.parse
from pathlib import Path


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key.strip()] = value
    return values


def _connect(host: str, port: int, timeout: float) -> http.client.HTTPConnection:
    host = host.strip()
    if host in {"0.0.0.0", "::", "[::]"}:
        host = "127.0.0.1" if host == "0.0.0.0" else "::1"
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    return http.client.HTTPConnection(host, port, timeout=timeout)


def check(env_file: Path, deadline_seconds: int = 30) -> dict[str, object]:
    settings = read_env(env_file)
    host = settings.get("AWGUI_HOST", "127.0.0.1")
    port = int(settings.get("AWGUI_PORT", "8080"))
    username = settings.get("AWGUI_ADMIN_USER", "admin")
    password = settings.get("AWGUI_ADMIN_PASSWORD", "")
    if not password:
        raise RuntimeError("AWGUI_ADMIN_PASSWORD отсутствует или пуст")

    deadline = time.monotonic() + deadline_seconds
    last_error = "нет ответа"
    while time.monotonic() < deadline:
        connection = None
        try:
            connection = _connect(host, port, 3)
            connection.request("GET", "/health")
            response = connection.getresponse()
            body = response.read()
            if response.status != 200:
                raise RuntimeError(f"GET /health: HTTP {response.status}")
            data = json.loads(body.decode("utf-8"))
            if data.get("panel") != "ok":
                raise RuntimeError(f"GET /health: неожиданный ответ {data!r}")

            connection.close()
            connection = _connect(host, port, 3)
            payload = urllib.parse.urlencode({"username": username, "password": password})
            connection.request(
                "POST",
                "/login",
                body=payload,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response = connection.getresponse()
            response.read()
            location = response.getheader("Location", "")
            if response.status != 302 or location.endswith("/login"):
                raise RuntimeError(
                    f"POST /login: ожидался HTTP 302, получен HTTP {response.status}"
                )
            return {
                "panel": "ok",
                "login": "ok",
                "username": username,
                "host": host,
                "port": port,
            }
        except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
            last_error = str(exc)
            time.sleep(1)
        finally:
            if connection is not None:
                connection.close()
    raise RuntimeError(f"runtime-check не пройден: {last_error}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("env_file", type=Path)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = check(args.env_file)
    print(json.dumps(result, ensure_ascii=False) if args.json else "AWGUI runtime-check OK")


if __name__ == "__main__":
    main()
