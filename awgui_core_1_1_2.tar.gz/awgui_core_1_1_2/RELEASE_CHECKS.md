# Release checks 1.1.2

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/python tests/verify_release.py
```

После установки:

```bash
systemctl is-enabled awgui.service awgui-bot.service
systemctl is-active awgui.service awgui-bot.service
/opt/awgui/.venv/bin/python -m panel.runtime_check /etc/awgui.env
```

Сброс и проверка пароля:

```bash
sudo /opt/awgui/reset-password.sh
```

Перед выпуском на реальных серверах дополнительно проверить:

1. настоящий reboot и автоматический запуск обеих служб;
2. существующую установку bivlked до и после установки панели;
3. local и SSH server status;
4. полный цикл add/list/stats/modify/regen/remove;
5. backup/download/upload/restore;
6. restart и repair-module с подтверждением;
7. Telegram parity;
8. две VPS для AWG0 → AWG1 по `CASCADE.md`;
9. реальный клиентский трафик RU и non-RU;
10. reboot AWG0, reboot AWG1 и восстановление каскада;
11. несколько независимых каскадных пар.

Не отмечать DKMS/reboot/сетевой путь как пройденные без физического стенда.
