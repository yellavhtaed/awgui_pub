# AWGUI Core 1.1.2 — test report

Дата проверки: 2026-07-10.

## Исправленный сценарий установки и входа

Фактически выполнен полный smoke-test с реальными процессами Gunicorn и Telegram bot и изолированным макетом systemd:

1. чистая установка без `/root/awg` и `manage_amneziawg.sh`;
2. создание `/etc/awgui.env`;
3. запуск Web и Telegram процессов командами из systemd units;
4. HTTP `/health`;
5. реальный POST `/login` с логином и паролем из `/etc/awgui.env`;
6. проверка вывода тех же фактических логина и пароля установщиком;
7. проверка `active` и `enabled` для `awgui.service` и `awgui-bot.service`;
8. остановка и повторный запуск обеих служб как имитация загрузочного цикла;
9. повторный успешный вход;
10. сброс пароля через `/opt/awgui/reset-password.sh`;
11. подтверждение, что старый пароль заменён, а новый проходит реальный вход.

Также `systemd-analyze verify` успешно проверил синтаксис обеих unit-конфигураций. В units присутствует `WantedBy=multi-user.target`, а installer выполняет и проверяет `systemctl enable --now`.

## Остальные пройденные проверки

- компиляция всех Python-модулей;
- `bash -n` для install, uninstall, reset-password, тестовых shell-скриптов и upstream routing script;
- Flask 3.1.3 и Gunicorn 26.0.0 в чистом venv;
- `pip check` без конфликтов;
- вызовы поверхности `manage_amneziawg.sh` через fake manager;
- add/list/stats/modify/regen/remove;
- client conf/QR/vpnuri bundle;
- backup list/download/upload/restore paths;
- local и fake-SSH inventory;
- одновременная запись state шестью процессами без lost update;
- Web login, неверный пароль, CSRF и основные маршруты;
- блокировка внешнего `next` redirect;
- Telegram add и подтверждённое удаление одного клиента;
- Telegram-процесс остаётся активным без token и ожидает включения в Settings;
- отсутствие installer/deploy функций в Web, Telegram и manager wrapper;
- byte-for-byte совпадение `vendor/bivlked/awg-routing.sh` с bash-блоком `CASCADE.md`;
- byte-for-byte совпадение cascade systemd unit с ini-блоком `CASCADE.md`;
- каскадная правка только `DNS` и `Table = off`;
- сохранение `AllowedIPs` без самовольной модификации;
- отказ от non-full-tunnel конфига;
- отказ от перезаписи существующих отличающихся `awg1.conf` и `awg-routing.sh`;
- release gate после повторной распаковки итогового архива.

## Что не заявляется как физически проверенное

- настоящий reboot ОС с systemd как PID 1;
- сборка и загрузка DKMS-модуля;
- `CAP_NET_ADMIN`, iptables/ipset и реальный AWG-туннель;
- сетевой путь реального клиента AWG0 → AWG1 между двумя VPS;
- несколько реальных независимых каскадных пар.

Автозапуск после reboot обеспечивается стандартным `systemctl enable` и `WantedBy=multi-user.target`; синтаксис и повторный старт процессов проверены. Окончательное подтверждение настоящего reboot требует VPS или VM с systemd как PID 1.
