# AWGUI v8.9.1

AWGUI is an autonomous web/Telegram/SSH control-plane for personal AmneziaWG servers.

It ships a vendored AWG engine based on `bivlked/amneziawg-installer v5.18.4` and uses it as a full offline runtime base: installer, manager, common library, cascade snapshot and cascade routing template are bundled inside the AWGUI archive. Python remains the control-plane; bundled shell scripts remain responsible for low-level work: DKMS, apt, firewall, sysctl, UFW, Fail2Ban, kernel headers, routing and parent-script logic.

## Philosophy

- KISS / Unix-way.
- No Docker, no agents, no frontend framework, no Paramiko, no sshpass.
- Web and Telegram are two interfaces to the same action layer.
- Runtime bootstrap/apply does not download core scripts from GitHub.
- Destructive operations require explicit confirmation and audit.
- Fake apply buttons are forbidden: unsupported features are shown as read-only/unavailable.

## What v8.9.1 changes

- Fixes upgrade/removal commands for root-owned `.venv`: use `sudo rm -rf ~/awgui` when replacing or deleting an installed panel.
- Adds explicit Cascade notes: installing `awg-routing.sh` does not run it; run `sudo bash /root/awg/awg-routing.sh` only after checking parameters.
- Removes the unnecessary per-client obfuscation dropdown from client creation. Clients always use current server AWG params; server profile changes belong to `/obfuscation`.
- Keeps v8.9.0 cascade console and provisioner cascade setup, with clearer UI and less surface area.
- Adds bundled `awg-routing.sh` extracted from upstream `CASCADE.md` and patched for AWGUI offline `cascade/ru.zone` usage.
- Reworks `/cascade` into an interactive console:
  - diagnose;
  - install bundled `ru.zone`;
  - generate/install configured `/root/awg/awg-routing.sh`;
  - explicit run of `awg-routing.sh` only after confirmation.
- Adds cascade setup options to `/provisioner` so a freshly bootstrapped server can be marked as cascade entry AWG0 and receive the configured routing script immediately after install.
- Adds client creation obfuscation guard: clients use current server AWG parameters. Per-client obfuscation profiles are intentionally blocked because AWG parameters are server-wide and must match byte-for-byte.
- Keeps `/obfuscation` read-only, but uses it as the source of truth for detected J/S/H/I values, profile hints and future safe apply flow.
- Adds full uninstall instructions for AWGUI panel and AmneziaWG server.

## Install / upgrade

```bash
cd ~

sudo systemctl stop awgui awgui-bot 2>/dev/null || true

# AWGUI creates .venv under sudo/root, so plain rm can fail with Permission denied.
sudo rm -rf ~/awgui
mkdir -p ~/awgui

tar -xzf ~/Downloads/awgui_v8_9_1.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui

sudo ./upgrade.sh
```

Check:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected:

```json
{"app":"AWGUI","engine":"5.18.4-awgui1","ok":true,"version":"8.9.1"}
```

Open:

```text
http://127.0.0.1:8080
```

Default login:

```text
admin / devpass
```

## SSH servers

AWGUI does not store SSH passwords. It uses OpenSSH keys, ssh-agent or `~/.ssh/config`.

Recommended dedicated key:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
chmod 700 ~/.ssh
chmod 600 ~/.ssh/awgui_ed25519
chmod 644 ~/.ssh/awgui_ed25519.pub
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP \
  'bash /root/awg/manage_amneziawg.sh --no-color --json list'
```

Private key stays on the AWGUI host. Public key goes to the remote server. Revoke access by removing the key line from `/root/.ssh/authorized_keys` on the remote server.

## Cascade workflow

`/cascade` is intentionally interactive but conservative:

1. Run diagnostics.
2. Install bundled `ru.zone` if local snapshot is missing/stale.
3. Install configured `awg-routing.sh` with:
   - `CLIENT_SUBNET`, for example `172.16.17.0/24`;
   - `AWG1 endpoint`, public IP/host of the exit server;
   - `AWG1 interface`, usually `awg1`.
4. Run `awg-routing.sh` explicitly only after checking values.

Installing `ru.zone` or `awg-routing.sh` does not mutate routes. Running `awg-routing.sh` does mutate ipset/ip rule/iptables/routes and requires explicit `RUN` confirmation.

## Obfuscation note for client creation

AWG obfuscation parameters are not per-client. Server and client configs must match exactly. Therefore `/clients` only allows adding clients with the current server parameters. Profile/rand apply belongs to the server-level `/obfuscation` workflow: backup → diff → apply → regenerate clients → verify.

## Key pages

- `/clients` — clients, QR, conf, vpnuri, bundle, regen/remove/modify.
- `/servers` — local/SSH server registry.
- `/engine` — bundled engine verify/deploy/apply.
- `/provisioner` — Ubuntu 24.04 LTS bootstrap through bundled engine; optional cascade entry setup.
- `/cascade` — cascade diagnostics, bundled `ru.zone`, configured `awg-routing.sh`, explicit route apply.
- `/obfuscation` — read-only AWG 2.0 parameter inspection and apply-readiness.
- `/traffic` — SQLite traffic snapshots.
- `/backups` — backup list/preview/download/restore through parent manager.
- `/bot` — Telegram token/chat_id settings.

## Cascade routing note

Installing bundled `awg-routing.sh` only writes the configured file to `/root/awg/awg-routing.sh` and backs up the old file. It does **not** run automatically. After checking `CLIENT_SUBNET`, `AWG1 endpoint` and `AWG1 interface`, start it explicitly:

```bash
sudo bash /root/awg/awg-routing.sh
```

The explicit run changes ipset/ip rule/iptables/routes, so AWGUI keeps it separated from file installation.

## Full removal

### Remove AWGUI panel only

```bash
sudo systemctl stop awgui awgui-bot 2>/dev/null || true
sudo systemctl disable awgui awgui-bot 2>/dev/null || true
sudo rm -f /etc/systemd/system/awgui.service /etc/systemd/system/awgui-bot.service
sudo systemctl daemon-reload

# .venv/site-packages may be root-owned after sudo ./upgrade.sh.
sudo rm -rf ~/awgui
sudo rm -rf /var/lib/awgui
sudo rm -f /etc/awgui.env
```

This removes the panel, bot, AWGUI state DB, audit/traffic history and Telegram settings. It does not remove AmneziaWG itself.

### Remove AmneziaWG from a server

If AWGUI engine was deployed:

```bash
sudo bash /root/awg/.awgui-engine/5.18.4-awgui1/install_amneziawg.sh --uninstall
```

If using the installed upstream script directly:

```bash
sudo bash /root/awg/install_amneziawg.sh --uninstall
```

After uninstall, optional cleanup:

```bash
sudo rm -rf /root/awg
sudo rm -rf /etc/amnezia/amneziawg
sudo systemctl daemon-reload
```

Before removing a real server, download/keep backups from `/backups` if you may need clients/configs later.

## Limitations

- Real clean VPS bootstrap was not performed in this sandbox.
- `/obfuscation` is intentionally read-only in v8.9.1.
- Cascade route apply exists only as explicit `RUN` of the configured upstream script; no hidden auto-repair or blind route mutation is performed.
