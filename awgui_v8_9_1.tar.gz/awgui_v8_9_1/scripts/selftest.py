#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui_v8_9_1_selftest_"))
FAKE = ROOT / "scripts" / "fake_manage_amneziawg.sh"
os.environ["AWGUI_MANAGE"] = str(FAKE)
os.environ["AWGUI_AWG_DIR"] = str(TMP / "awg")
os.environ["AWGUI_SERVER_CONF"] = str(TMP / "etc" / "awg0.conf")
os.environ["AWGUI_STATE_DIR"] = str(TMP / "state")
os.environ["AWGUI_ENV_FILE"] = str(TMP / "awgui.env")
os.environ["AWGUI_SECRET"] = "test-secret"
os.environ["AWGUI_SERVER_ID"] = "local_test"
os.environ["AWGUI_SERVER_NAME"] = "Local Test"
os.environ["AWGUI_SSH_BIN"] = str(ROOT / "scripts" / "fake_ssh.sh")
os.environ["AWGUI_FAKE_MANAGE"] = str(FAKE)

import config  # noqa: E402
import i18n  # noqa: E402
import manage_adapter  # noqa: E402
import parse  # noqa: E402
import engine  # noqa: E402
import cascade  # noqa: E402
import provisioner  # noqa: E402
import actions  # noqa: E402
import obfuscation  # noqa: E402
import store  # noqa: E402
import telegram_bot  # noqa: E402

assert config.APP_VERSION == "8.9.1"
assert config.ENGINE_MODE == "full-offline-engine"
assert set(i18n.SUPPORTED_LANGS) == {"en", "ru", "uk", "be"}
eng = engine.verify_bundled_engine()
assert eng["ok"], eng
assert eng["engine_version"] == "5.18.4-awgui1"
assert eng["mode"] == "full-offline-engine"
cas = cascade.diagnose(manage_adapter.ManageAdapter(config.MANAGE, config.AWG_DIR, config.SERVER_CONF))
assert cas["raw"]["ok"], cas
assert any(c["name"] == "Cascade boot viability" for c in cas["checks"]), cas
ru_install = cascade.install_bundled_ru_zone(manage_adapter.ManageAdapter(config.MANAGE, config.AWG_DIR, config.SERVER_CONF))
assert ru_install["ok"], ru_install
routing_status = cascade.bundled_routing_script_status()
assert routing_status["ok"] and routing_status["offline_ru_zone"], routing_status
routing_install = cascade.install_bundled_routing_script(manage_adapter.ManageAdapter(config.MANAGE, config.AWG_DIR, config.SERVER_CONF), client_subnet="172.16.17.0/24", awg1_endpoint="203.0.113.10")
assert routing_install["ok"], routing_install
assert (config.AWG_DIR / "awg-routing.sh").is_file()
store.init_db()
servers = store.list_servers()
assert servers and servers[0]["id"] == "local_test", servers
ssh = store.save_server({
    "id": "remote_test",
    "name": "Remote Test",
    "mode": "ssh",
    "host": "127.0.0.1",
    "port": 22,
    "user": "root",
    "key_path": "",
    "manage_path": "/root/awg/manage_amneziawg.sh",
    "awg_dir": "/root/awg",
    "server_conf": "/etc/amnezia/amneziawg/awg0.conf",
})
assert ssh["mode"] == "ssh"
assert isinstance(manage_adapter.adapter_for_server(store.get_server("remote_test")), manage_adapter.SSHManageAdapter)
pr = provisioner.provisioner_for_server("remote_test")
pre = pr.preflight()
assert pre["ok"] and pre["ready_to_bootstrap"], pre
boot = pr.bootstrap({"route_mode": "amnezia"})
assert boot["ok"], boot
assert provisioner.read_last("remote_test")
deploy = actions.action_engine_deploy("remote_test", confirm=True)
assert deploy["ok"], deploy
deploy_result = deploy["data"]["result"]
assert deploy_result.get("payload_bytes", 0) > 1000, deploy_result
assert "AWGUI_ENGINE_B64" not in deploy_result.get("cmd", ""), deploy_result
assert "fake streaming deploy" in deploy_result.get("stdout", ""), deploy_result
probe = actions.action_engine_probe("remote_test")
assert probe["ok"], probe
apply = actions.action_engine_apply("remote_test", confirm=True)
assert apply["ok"], apply
cas_remote = actions.action_cascade_diagnostics("remote_test")
assert cas_remote["ok"] or cas_remote["data"], cas_remote
cas_install = actions.action_install_bundled_ru_zone("remote_test", confirm=True)
assert cas_install["ok"], cas_install
routing_remote = actions.action_install_cascade_routing_script("remote_test", "172.16.17.0/24", "203.0.113.10", confirm=True)
assert routing_remote["ok"], routing_remote
run_remote = actions.action_run_cascade_routing("remote_test", confirm=True)
assert run_remote["ok"], run_remote
store.delete_server("remote_test")
assert store.get_server("remote_test") is None

ad = manage_adapter.ManageAdapter(config.MANAGE, config.AWG_DIR, config.SERVER_CONF)
scan = ad.scan()
assert scan["ok"], scan
assert scan["commands"]["add"] and scan["commands"]["backup"] and scan["options"]["--json"], scan
lst = ad.list_clients()
clients = parse.clients_from(lst["json"])
assert lst["ok"] and clients[0]["name"] == "phone", lst
add = ad.add_client("test_phone", expires="7d", psk=True)
assert add["ok"], add
act_add = actions.action_add_client("local_test", "action_phone", expires="1d")
assert act_add["ok"], act_add
assert ad.find_client_file("test_phone", "conf")
fn, data = ad.read_client_bytes("test_phone", "conf")
assert fn and data and b"[Interface]" in data
bundle = ad.create_client_bundle("test_phone")
assert bundle.exists(), bundle
b = ad.backup()
assert b["ok"], b
backups = ad.list_backups()
assert backups, backups
preview = ad.backup_preview(backups[0]["path"])
assert preview["ok"], preview
bn, bd = ad.backup_bytes(backups[0]["name"])
assert bn and bd, (bn, bd)
store.audit("selftest", "tester", "backup", "", b, server_id="local_test")
assert store.list_audit(1, server_id="local_test")[0]["server_id"] == "local_test"
st = ad.stats()
stat_clients = parse.clients_from(st["json"])
assert store.record_stats_snapshot(stat_clients, server_id="local_test") == 1
assert store.traffic_overview(server_id="local_test")[0]["client"] == "phone"
obf = obfuscation.inspect(ad)
assert obf["mode"] == "read-only groundwork"
kb = telegram_bot.main_keyboard()["inline_keyboard"]
assert any(any(button["callback_data"] == "m:add" for button in row) for row in kb)
assert any(any(button["callback_data"] == "m:addtemp" for button in row) for row in kb)
assert any(any(button["callback_data"] == "m:servers" for button in row) for row in kb)
assert any(any(button["callback_data"] == "m:cascade" for button in row) for row in kb)
assert any(any(button["callback_data"] == "m:engine" for button in row) for row in kb)
assert any(any(button["callback_data"] == "m:obfuscation" for button in row) for row in kb)
assert telegram_bot.servers_keyboard("123")["inline_keyboard"]
assert telegram_bot.add_keyboard()["inline_keyboard"]
assert telegram_bot.backup_keyboard()["inline_keyboard"]
assert telegram_bot.cascade_keyboard()["inline_keyboard"]
assert telegram_bot.engine_keyboard()["inline_keyboard"]

import app  # noqa: E402

routes = {rule.rule for rule in app.app.url_map.iter_rules()}
for route in ("/health", "/", "/clients", "/servers", "/engine", "/cascade", "/obfuscation", "/provisioner", "/traffic", "/expiry", "/backups", "/diagnostics", "/audit", "/bot", "/logs", "/api/version", "/api/cascade", "/api/summary", "/api/clients", "/api/stats", "/api/doctor", "/api/audit", "/api/bot"):
    assert route in routes, route
client = app.app.test_client()
assert client.get("/health").status_code == 200
with client.session_transaction() as sess:
    sess["auth"] = True
    sess["user"] = config.USER
for route in ("/", "/clients", "/servers", "/engine", "/cascade", "/obfuscation", "/provisioner", "/traffic", "/expiry", "/backups", "/diagnostics", "/audit", "/bot", "/logs", "/api/version", "/api/cascade", "/api/summary", "/api/clients", "/api/stats", "/api/doctor", "/api/audit", "/api/bot"):
    resp = client.get(route)
    assert resp.status_code < 500, (route, resp.status_code, resp.get_data(as_text=True)[:500])
print("AWGUI v8.9.1 selftest OK")
