#!/usr/bin/env bash
set -euo pipefail
JSON=0; AWG_DIR="${AWGUI_FAKE_AWG_DIR:-/tmp/awgui_fake_awg}"; SERVER_CONF="${AWGUI_FAKE_SERVER_CONF:-/tmp/awgui_fake_awg/awg0.conf}"; EXPIRES=""; PSK=0; YES=0; CARRIER=""
ARGS=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --json) JSON=1; shift;;
    --no-color) shift;;
    --conf-dir=*) AWG_DIR="${1#*=}"; shift;;
    --server-conf=*) SERVER_CONF="${1#*=}"; shift;;
    --expires=*) EXPIRES="${1#*=}"; shift;;
    --psk) PSK=1; shift;;
    --yes) YES=1; shift;;
    --carrier=*) CARRIER="${1#*=}"; shift;;
    -h|--help|help) CMD=help; shift; break;;
    *) ARGS+=("$1"); shift;;
  esac
done
CMD="${CMD:-${ARGS[0]:-help}}"
if [[ "${#ARGS[@]}" -gt 0 ]]; then ARGS=("${ARGS[@]:1}"); fi
mkdir -p "$AWG_DIR/backups" "$AWG_DIR/keys" "$(dirname "$SERVER_CONF")"
if [ ! -s "$SERVER_CONF" ]; then
  cat > "$SERVER_CONF" <<'EOFAWGCONF'
[Interface]
Address = 172.16.17.1/24
Jc = 3
Jmin = 40
Jmax = 120
S1 = 0
S2 = 0
S3 = 0
S4 = 0
H1 = 1
H2 = 2
H3 = 3
H4 = 4
I1 = <r 64>
EOFAWGCONF
fi
if [ ! -s "$AWG_DIR/awgsetup_cfg.init" ]; then
  cat > "$AWG_DIR/awgsetup_cfg.init" <<'EOFAWGINIT'
AWG_PRESET=mobile
AWG_Jc=3
AWG_Jmin=40
AWG_Jmax=120
EOFAWGINIT
fi
touch "$AWG_DIR/awg_common.sh"
case "$CMD" in
  help)
    cat <<'EOF'
SCRIPT_VERSION="5.18.1"
Скрипт управления AmneziaWG 2.0 (v5.18.1)
Опции: --json --expires=ВРЕМЯ --conf-dir=ПУТЬ --server-conf=ПУТЬ --apply-mode=РЕЖИМ --psk --yes --carrier=NAME
Доступные: beeline_msk yota_msk tele2_msk tele2_krasnoyarsk tattelecom megafon_regions tmobile_us
Команды:
 add <имя> [имя2 ...]
 remove <имя> [имя2 ...]
 list [-v] [--json]
 stats [--json]
 regen [имя ...]
 modify <имя> <пар> <зн>
 backup
 restore [файл]
 check | status
 diagnose [--carrier=N]
 show
 restart
 repair-module
 help
EOF
    ;;
  list)
    if [[ "$JSON" == 1 ]]; then echo '[{"name":"phone","client_ip":"10.8.0.2","client_ipv6":"fd42::2","latest_handshake":"2 minutes ago","status":"active"}]'; else echo 'phone 10.8.0.2 active'; fi;;
  stats)
    if [[ "$JSON" == 1 ]]; then echo '[{"name":"phone","rx":1024,"tx":2048,"latest_handshake":"2 minutes ago","status":"active"}]'; else echo 'phone rx 1024 tx 2048'; fi;;
  status|check) echo 'awg-quick@awg0 active';;
  show) echo 'interface: awg0'; echo 'peer: fake';;
  diagnose) echo "diagnose OK carrier=${CARRIER:-default}";;
  add) name="${ARGS[0]:-client}"; echo "[Interface]" > "$AWG_DIR/$name.conf"; echo "vpn://$name" > "$AWG_DIR/$name.vpnuri"; echo "fakepng" > "$AWG_DIR/$name.png"; echo "added $name expires=$EXPIRES psk=$PSK";;
  remove) echo "removed ${ARGS[*]}";;
  regen) echo "regenerated ${ARGS[*]}";;
  modify) echo "modified ${ARGS[*]}";;
  backup) f="$AWG_DIR/backups/awg_backup_$(date +%F_%H-%M-%S).tar.gz"; tar -czf "$f" -C "$AWG_DIR" awgsetup_cfg.init >/dev/null 2>&1; echo "Бэкап создан: $f";;
  restore) echo "restored ${ARGS[0]:-latest}";;
  restart) echo 'service restarted';;
  repair-module|repair) echo 'module repaired';;
  *) echo "unknown $CMD" >&2; exit 1;;
esac
