#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui_v8_9_gate_"))
os.environ["AWGUI_MANAGE"] = str(ROOT / "scripts" / "fake_manage_amneziawg.sh")
os.environ["AWGUI_AWG_DIR"] = str(TMP / "awg")
os.environ["AWGUI_SERVER_CONF"] = str(TMP / "etc" / "awg0.conf")
os.environ["AWGUI_STATE_DIR"] = str(TMP / "state")
os.environ["AWGUI_ENV_FILE"] = str(TMP / "awgui.env")
os.environ["AWGUI_SECRET"] = "test-secret"
os.environ["AWGUI_SSH_BIN"] = str(ROOT / "scripts" / "fake_ssh.sh")

selftest = subprocess.run([sys.executable, str(ROOT / "scripts" / "selftest.py")], text=True, capture_output=True, timeout=180)
if selftest.returncode != 0:
    raise SystemExit("selftest failed:\n" + (selftest.stdout or "") + (selftest.stderr or ""))

import config  # noqa: E402
import engine  # noqa: E402
import telegram_bot  # noqa: E402
import app  # noqa: E402

assert config.APP_VERSION == "8.9.1", config.APP_VERSION
assert config.ENGINE_VERSION == "5.18.4-awgui1"
assert config.ENGINE_MODE == "full-offline-engine"

vendor = ROOT / "engine" / "vendor" / "bivlked_5_18_4"
manifest = json.loads((vendor / "MANIFEST.json").read_text(encoding="utf-8"))
assert manifest["mode"] == "full-offline-engine", manifest
assert manifest["upstream_version"] == "5.18.4", manifest
assert manifest["awgui_engine_version"] == "5.18.4-awgui1", manifest

required = {
    "install_amneziawg.sh",
    "manage_amneziawg.sh",
    "awg_common.sh",
    "awgui_engine_apply.sh",
    "awg-routing.sh",
    "cascade/README.md",
    "cascade/ru.zone",
    "CASCADE.md",
    "ADVANCED.md",
    "README.upstream.md",
    "LICENSE.upstream",
}
manifest_files = {item["path"]: item for item in manifest["files"]}
missing = sorted(required - set(manifest_files))
if missing:
    raise SystemExit(f"manifest missing files: {missing}")
for rel, item in manifest_files.items():
    path = vendor / rel
    if not path.is_file():
        raise SystemExit(f"missing vendor file: {rel}")
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != item["sha256"]:
        raise SystemExit(f"manifest sha mismatch: {rel}")
    if len(data) != int(item["bytes"]):
        raise SystemExit(f"manifest byte mismatch: {rel}")
sha_lines = (vendor / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines()
if len(sha_lines) != len(manifest_files):
    raise SystemExit("MANIFEST.sha256 line count mismatch")
assert engine.verify_bundled_engine()["ok"], engine.verify_bundled_engine()
routing_text = (vendor / "awg-routing.sh").read_text(encoding="utf-8", errors="replace")
if 'RU_ZONE="$AWG_DIR/cascade/ru.zone"' not in routing_text or "onlink" not in routing_text:
    raise SystemExit("bundled awg-routing.sh is not offline/onlink ready")

runtime_paths = ["engine.py", "provisioner.py", "actions.py", "app.py", "cascade.py", "engine/vendor/bivlked_5_18_4/install_amneziawg.sh", "engine/vendor/bivlked_5_18_4/awgui_engine_apply.sh"]
for rel in runtime_paths:
    text = (ROOT / rel).read_text(encoding="utf-8", errors="replace")
    if "raw.githubusercontent.com" in text:
        raise SystemExit(f"runtime raw.githubusercontent.com reference in {rel}")
engine_text = (ROOT / "engine.py").read_text(encoding="utf-8", errors="replace")
if "AWGUI_ENGINE_B64" in engine_text or "base64.b64encode" in engine_text:
    raise SystemExit("ssh deploy still uses base64/heredoc payload")
if "stream_stdin" not in engine_text or "tar -xzf -" not in engine_text:
    raise SystemExit("ssh deploy streaming transport missing")
env_text = (ROOT / ".env.example").read_text(encoding="utf-8", errors="replace")
if "raw.githubusercontent.com" in env_text or "AWGUI_PROVISIONER_INSTALL_URL" in env_text:
    raise SystemExit(".env.example contains normal workflow GitHub/provisioner URL")

routes = {rule.rule for rule in app.app.url_map.iter_rules()}
for route in ("/engine", "/cascade", "/obfuscation", "/provisioner"):
    if route not in routes:
        raise SystemExit(f"missing route: {route}")
for endpoint in ("/cascade/install-routing-script", "/cascade/run-routing"):
    if endpoint not in routes:
        raise SystemExit(f"missing route: {endpoint}")

obf_tpl = (ROOT / "templates" / "obfuscation.html").read_text(encoding="utf-8")
if "Apply bundled" in obf_tpl or "action=" in obf_tpl:
    raise SystemExit("/obfuscation must remain read-only in v8.9.1")

clients_tpl = (ROOT / "templates" / "clients.html").read_text(encoding="utf-8")
if 'name="obf_mode"' in clients_tpl or "change profile before add" in clients_tpl:
    raise SystemExit("per-client obfuscation selector must not be present in client creation")
cascade_tpl = (ROOT / "templates" / "cascade.html").read_text(encoding="utf-8")
provisioner_tpl = (ROOT / "templates" / "provisioner.html").read_text(encoding="utf-8")
if "sudo bash /root/awg/awg-routing.sh" not in cascade_tpl or "not auto-run" not in cascade_tpl.lower():
    raise SystemExit("cascade page must clearly state awg-routing.sh is not auto-run and show command")
if "sudo bash /root/awg/awg-routing.sh" not in provisioner_tpl or "not run" not in provisioner_tpl.lower():
    raise SystemExit("provisioner cascade note must show explicit awg-routing.sh run command")
readme_text = (ROOT / "README.md").read_text(encoding="utf-8")
if "sudo rm -rf ~/awgui" not in readme_text:
    raise SystemExit("README must use sudo rm -rf ~/awgui for root-owned .venv cleanup")

kb = telegram_bot.main_keyboard()["inline_keyboard"]
for callback in ("m:servers", "m:cascade", "m:engine"):
    if not any(any(button.get("callback_data") == callback for button in row) for row in kb):
        raise SystemExit(f"Telegram menu lacks {callback}")

legacy_needles = ["v8.5 provisions", "offline-cascade-payload+pinned-core-launcher", "pinned-core launcher", "v5.0.0", "v6.0.0"]
for path in list((ROOT / "templates").glob("*.html")) + [ROOT / "README.md", ROOT / "CHANGELOG.md", ROOT / "RELEASE_CHECKS.md"]:
    if not path.exists():
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    for needle in legacy_needles:
        if needle in text:
            raise SystemExit(f"legacy text in {path.relative_to(ROOT)}: {needle}")

text_suffixes = {".py", ".sh", ".md", ".json"}
for path in list(ROOT.rglob("*")):
    if not path.is_file():
        continue
    if ".testvenv" in path.parts or "__pycache__" in path.parts:
        continue
    if path.suffix not in text_suffixes and path.name != ".env.example":
        continue
    data = path.read_bytes()
    rel = path.relative_to(ROOT)
    if data.startswith(b"\xef\xbb\xbf"):
        raise SystemExit(f"UTF-8 BOM found in {rel}")
    if path.suffix == ".sh" and b"\r\n" in data:
        raise SystemExit(f"CRLF shell script: {rel}")

print("AWGUI v8.9.1 release gate OK")
