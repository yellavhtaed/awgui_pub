#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ -f /etc/awgui.env ]]; then set -a; source /etc/awgui.env; set +a; fi
if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -q -r requirements.txt
exec .venv/bin/python telegram_bot.py
