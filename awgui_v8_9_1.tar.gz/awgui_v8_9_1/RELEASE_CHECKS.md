# AWGUI v8.9.1 release checks

Required checks:

```bash
python3 -m py_compile \
  app.py config.py manage_adapter.py parse.py store.py i18n.py \
  engine.py cascade.py telegram_bot.py telegram_client.py web_support.py \
  provisioner.py actions.py obfuscation.py \
  scripts/selftest.py scripts/verify_release.py

bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh \
  scripts/fake_manage_amneziawg.sh scripts/fake_ssh.sh \
  engine/vendor/bivlked_5_18_4/*.sh

python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
```

Runtime smoke:

- `/health`
- `/`
- `/clients`
- `/servers`
- `/engine`
- `/cascade`
- `/obfuscation`
- `/provisioner`
- `/traffic`
- `/expiry`
- `/backups`
- `/diagnostics`
- `/audit`
- `/bot`
- `/logs`
- `/api/version`
- `/api/cascade`
- `/api/summary`
- `/api/clients`
- `/api/stats`
- `/api/doctor`
- `/api/audit`
- `/api/bot`

Release gate must fail on missing `awg-routing.sh`, manifest mismatch, old version text, runtime GitHub core fetch in normal path, or base64-in-argv SSH deploy.

- Client creation form has no per-client obfuscation selector.
- README install/removal uses sudo rm -rf for root-owned .venv cleanup.
- Cascade UI states that awg-routing.sh is not auto-run and shows sudo bash /root/awg/awg-routing.sh.
