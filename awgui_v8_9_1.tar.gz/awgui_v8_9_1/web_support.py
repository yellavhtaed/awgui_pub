from __future__ import annotations

import json
import shutil
import subprocess
import urllib.request
from typing import Any, Dict

import config
import manage_adapter


def systemctl(*args: str, timeout: int = 12) -> Dict[str, Any]:
    cmd = ["systemctl", *args]
    if not shutil.which("systemctl"):
        return manage_adapter.make_result(cmd, 127, "", "systemctl not found")
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return manage_adapter.make_result(cmd, p.returncode, p.stdout.strip(), p.stderr.strip())
    except Exception as exc:
        return manage_adapter.make_result(cmd, 1, "", f"{type(exc).__name__}: {exc}")


def control_bot_service(enabled: bool) -> Dict[str, Any]:
    if enabled:
        return {"enable": systemctl("enable", "awgui-bot.service"), "restart": systemctl("restart", "awgui-bot.service")}
    return {"stop": systemctl("stop", "awgui-bot.service"), "disable": systemctl("disable", "awgui-bot.service")}


def bot_service_status() -> Dict[str, Any]:
    return manage_adapter.default_adapter().systemctl_state("awgui-bot.service")


def telegram_get_me(token_value: str) -> Dict[str, Any]:
    token_value = config.validate_bot_token(token_value, required=True)
    url = f"https://api.telegram.org/bot{token_value}/getMe"
    try:
        with urllib.request.urlopen(url, timeout=12) as r:
            payload = json.loads(r.read().decode("utf-8"))
        if not payload.get("ok"):
            return {"ok": False, "error": payload.get("description") or "Telegram returned ok=false"}
        return {"ok": True, "bot": payload.get("result") or {}}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
