from __future__ import annotations

import re
import shlex
from pathlib import Path
from typing import Any, Dict, List, Tuple

import config
import manage_adapter

PARAMS = ["Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4", "H1", "H2", "H3", "H4", "I1", "I2", "I3", "I4", "I5"]
REQUIRED = ["Jc", "Jmin", "Jmax", "S1", "S2", "S3", "S4", "H1", "H2", "H3", "H4"]
OPTIONAL = ["I1", "I2", "I3", "I4", "I5"]
PROFILE_HINTS = {
    "default": "upstream default: Jc 3-6, Jmin 40-89, Jmax = Jmin + 50..250",
    "mobile": "upstream mobile: Jc=3, Jmin 30-50, Jmax = Jmin + 20..80",
    "beeline_msk": "diagnose carrier profile: Jc 3-6, Jmin 40-89, Jmax offset 50-250, I1 random",
    "yota_msk": "diagnose carrier profile: Jc=3, Jmin 30-50, Jmax offset 20-80, I1 random",
    "tele2_msk": "diagnose carrier profile: Jc=3, Jmin 30-50, Jmax offset 20-80, I1 random",
    "tele2_krasnoyarsk": "diagnose carrier profile: Jc=3, Jmin 30-50, Jmax offset 20-80, I1 absent",
    "tattelecom": "diagnose carrier profile: Jc=3, Jmin 30-50, Jmax offset 20-80, I1 random",
    "megafon_regions": "diagnose carrier profile: Jc=3, Jmin 30-50, Jmax offset 20-80, I1 absent",
    "tmobile_us": "diagnose carrier profile: Jc=6, Jmin=10, Jmax offset 40, I1 binary",
}


def _plain_key(key: str) -> str:
    return key[4:] if key.startswith("AWG_") else key


def _parse_values(text: str, source: str) -> Dict[str, Dict[str, str]]:
    found: Dict[str, Dict[str, str]] = {}
    patterns = []
    for key in PARAMS:
        patterns.append((key, rf"^\s*{re.escape(key)}\s*=\s*([^#\n\r]+)"))
        patterns.append((key, rf"^\s*(?:export\s+)?AWG_{re.escape(key)}\s*=\s*([^#\n\r]+)"))
    patterns.append(("AWG_PRESET", r"^\s*(?:export\s+)?AWG_PRESET\s*=\s*([^#\n\r]+)"))
    for canonical, pattern in patterns:
        matches = re.findall(pattern, text or "", re.MULTILINE)
        if matches:
            value = str(matches[-1]).strip().strip("'\"")
            if value:
                found[canonical] = {"value": value, "source": source}
    return found


def _merge_sources(chunks: List[Dict[str, str]]) -> Dict[str, Dict[str, str]]:
    # Live server config is intentionally first: upstream treats it as source of truth.
    out: Dict[str, Dict[str, str]] = {}
    for chunk in reversed(chunks):
        out.update(_parse_values(chunk.get("text") or "", chunk.get("path") or "unknown"))
    return out


def _read_local(adapter: manage_adapter.ManageAdapter) -> Dict[str, Any]:
    paths = [Path(adapter.server_conf), Path(adapter.awg_dir) / "awgsetup_cfg.init"]
    chunks: List[Dict[str, str]] = []
    for p in paths:
        try:
            if p.is_file():
                chunks.append({"path": str(p), "text": p.read_text(encoding="utf-8", errors="replace")})
        except Exception:
            continue
    return {"ok": bool(chunks), "chunks": chunks, "files": [c["path"] for c in chunks]}


def _read_ssh(adapter: manage_adapter.SSHManageAdapter) -> Dict[str, Any]:
    paths = [str(adapter.server_conf), str(adapter.awg_dir / "awgsetup_cfg.init")]
    script = "\n".join([
        "set -u",
        "for p in " + " ".join(shlex.quote(p) for p in paths) + "; do",
        "  [ -r \"$p\" ] || continue",
        "  printf '\\n###AWGUI_FILE=%s###\\n' \"$p\"",
        "  sed -n '1,260p' \"$p\"",
        "done",
    ])
    raw = adapter.shell(script, timeout=20, save_last=False)
    chunks: List[Dict[str, str]] = []
    cur_path = ""
    cur_lines: List[str] = []
    for line in str(raw.get("stdout") or "").splitlines():
        if line.startswith("###AWGUI_FILE=") and line.endswith("###"):
            if cur_path:
                chunks.append({"path": cur_path, "text": "\n".join(cur_lines)})
            cur_path = line[len("###AWGUI_FILE="):-3]
            cur_lines = []
        else:
            cur_lines.append(line)
    if cur_path:
        chunks.append({"path": cur_path, "text": "\n".join(cur_lines)})
    return {"ok": bool(raw.get("ok")) and bool(chunks), "chunks": chunks, "files": [c["path"] for c in chunks], "raw": raw}


def _vendor_docs() -> List[str]:
    out = []
    for rel in ("ADVANCED.md", "CASCADE.md", "README.upstream.md"):
        p = config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME / rel
        if p.is_file():
            out.append(str(p))
    return out


def _profile_info(values: Dict[str, Dict[str, str]]) -> Dict[str, Any]:
    preset = (values.get("AWG_PRESET") or {}).get("value") or "unknown"
    profiles = [{"name": k, "detail": v, "current": k == preset} for k, v in PROFILE_HINTS.items()]
    return {"last_known_profile": preset, "profiles": profiles}


def _compatibility(values: Dict[str, Dict[str, str]]) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    missing_required = [k for k in REQUIRED if k not in values]
    if missing_required:
        out.append({"level": "fail", "name": "Required AWG 2.0 params", "detail": "missing: " + ", ".join(missing_required)})
    else:
        out.append({"level": "ok", "name": "Required AWG 2.0 params", "detail": "Jc/Jmin/Jmax/S1-S4/H1-H4 detected"})
    missing_optional = [k for k in OPTIONAL if k not in values]
    out.append({"level": "info", "name": "Optional I params", "detail": "missing/unused: " + ", ".join(missing_optional) if missing_optional else "I1-I5 detected"})
    try:
        jc = int(values.get("Jc", {}).get("value", "0"))
        jmin = int(values.get("Jmin", {}).get("value", "0"))
        jmax = int(values.get("Jmax", {}).get("value", "0"))
        if not 1 <= jc <= 128:
            out.append({"level": "fail", "name": "Jc range", "detail": f"Jc={jc} outside 1..128"})
        elif jmax < jmin:
            out.append({"level": "fail", "name": "J range", "detail": f"Jmax={jmax} is lower than Jmin={jmin}"})
        else:
            out.append({"level": "ok", "name": "J ranges", "detail": f"Jc={jc}, Jmin={jmin}, Jmax={jmax}"})
    except Exception:
        out.append({"level": "warn", "name": "J ranges", "detail": "numeric validation unavailable"})
    out.append({"level": "warn", "name": "Client compatibility", "detail": "AmneziaWG 2.x clients must receive configs regenerated with exactly the same server params; classic WireGuard clients are not compatible with AWG 2.0 obfuscation params."})
    return out


def safe_apply_plan() -> List[Dict[str, str]]:
    return [
        {"step": "1", "name": "backup", "detail": "create parent-script backup before any parameter mutation"},
        {"step": "2", "name": "diff", "detail": "show old/new J/S/H/I values and affected client count"},
        {"step": "3", "name": "apply", "detail": "write params through validated offline engine path only"},
        {"step": "4", "name": "regen", "detail": "regenerate client configs because params must match byte-for-byte"},
        {"step": "5", "name": "verify", "detail": "restart/sync, run diagnostics, record audit/profile history"},
    ]


def inspect(adapter: manage_adapter.ManageAdapter) -> Dict[str, Any]:
    raw = _read_ssh(adapter) if isinstance(adapter, manage_adapter.SSHManageAdapter) else _read_local(adapter)
    values = _merge_sources(raw.get("chunks") or [])
    profile = _profile_info(values)
    params = []
    for key in PARAMS:
        item = values.get(key)
        params.append({
            "name": key,
            "value": item.get("value") if item else "unknown/not detected",
            "source": item.get("source") if item else "-",
            "found": bool(item),
            "required": key in REQUIRED,
        })
    return {
        "ok": bool(raw.get("ok")),
        "mode": "read-only groundwork",
        "apply_supported": False,
        "message": "read-only: safe apply flow is designed but disabled until profile mutation is validated end-to-end",
        "params": params,
        "files": raw.get("files") or [],
        "vendor_docs": _vendor_docs(),
        "last_known_profile": profile["last_known_profile"],
        "profiles": profile["profiles"],
        "compatibility": _compatibility(values),
        "safe_apply_plan": safe_apply_plan(),
        "raw": raw,
    }
