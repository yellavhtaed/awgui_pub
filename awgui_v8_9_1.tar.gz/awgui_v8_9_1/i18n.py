from __future__ import annotations

SUPPORTED_LANGS = {
    "en": "English",
    "ru": "Русский",
    "uk": "Українська",
    "be": "Беларуская",
}

DEFAULT_LANG = "ru"

_TEXT = {
    "en": {
        "dashboard": "Dashboard", "clients": "Clients", "traffic": "Traffic", "expiry": "Expiry", "backups": "Backups",
        "diagnostics": "Diagnostics", "audit": "Audit", "telegram": "Telegram", "logs": "Logs", "logout": "Logout",
        "theme": "Theme", "language": "Language", "system": "System", "light": "Light", "dark": "Dark",
        "local_cockpit": "Local AWG cockpit", "thin_layer": "Thin control layer over parent manage_amneziawg.sh: clients, traffic, backups, diagnostics and Telegram. No own VPN logic.",
        "check": "Check", "restart_awg": "Restart AWG", "clients_total": "Clients", "online": "online", "parent_status": "Parent status", "compatibility": "Compatibility",
        "server_status": "Server status", "last_actions": "Last actions", "time": "Time", "action": "Action", "target": "Target", "result": "Result",
        "add_client": "Add client", "name": "Name", "expires": "Expires", "permanent": "permanent", "open": "Open", "status": "Status", "handshake": "Handshake",
        "temporary_clients": "Temporary clients", "traffic_history": "Traffic history", "latest_snapshots": "Latest snapshots", "client": "Client", "received": "Received", "sent": "Sent", "delta": "Delta", "snapshot": "Snapshot",
        "create_backup": "Create backup", "download": "Download", "preview": "Preview", "restore": "Restore", "settings": "Settings", "save_apply": "Save & apply",
        "bot_enabled": "Bot enabled", "admin_chat_id": "Admin chat_id", "send_backups_tg": "Send backup files to Telegram", "allow_dangerous_tg": "Allow restart / repair / remove / restore from Telegram",
        "service": "Service", "env": "Env", "run_diagnose": "Run diagnose", "repair_module": "Repair module", "login": "Login", "password": "Password", "enter": "Enter",
        "no_rows": "No rows", "no_clients": "No clients or upstream list --json returned no data.", "no_logs": "no logs", "no_output": "no output",
    },
    "ru": {
        "dashboard": "Панель", "clients": "Клиенты", "traffic": "Трафик", "expiry": "Сроки", "backups": "Бэкапы",
        "diagnostics": "Диагностика", "audit": "Аудит", "telegram": "Telegram", "logs": "Логи", "logout": "Выйти",
        "theme": "Тема", "language": "Язык", "system": "Системная", "light": "Светлая", "dark": "Тёмная",
        "local_cockpit": "Локальный AWG cockpit", "thin_layer": "Тонкий слой над родительским manage_amneziawg.sh: клиенты, трафик, бэкапы, диагностика и Telegram. Без собственной VPN-логики.",
        "check": "Проверить", "restart_awg": "Перезапустить AWG", "clients_total": "Клиенты", "online": "online", "parent_status": "Parent status", "compatibility": "Совместимость",
        "server_status": "Статус сервера", "last_actions": "Последние действия", "time": "Время", "action": "Действие", "target": "Цель", "result": "Результат",
        "add_client": "Добавить клиента", "name": "Имя", "expires": "Срок", "permanent": "постоянный", "open": "Открыть", "status": "Статус", "handshake": "Handshake",
        "temporary_clients": "Временные клиенты", "traffic_history": "История трафика", "latest_snapshots": "Последние снимки", "client": "Клиент", "received": "Принято", "sent": "Отправлено", "delta": "Дельта", "snapshot": "Снимок",
        "create_backup": "Создать backup", "download": "Скачать", "preview": "Просмотр", "restore": "Восстановить", "settings": "Настройки", "save_apply": "Сохранить и применить",
        "bot_enabled": "Бот включён", "admin_chat_id": "Admin chat_id", "send_backups_tg": "Отправлять backup-файлы в Telegram", "allow_dangerous_tg": "Разрешить restart / repair / remove / restore из Telegram",
        "service": "Сервис", "env": "Env", "run_diagnose": "Запустить diagnose", "repair_module": "Repair module", "login": "Логин", "password": "Пароль", "enter": "Войти",
        "no_rows": "Нет записей", "no_clients": "Клиентов нет или upstream list --json не вернул данные.", "no_logs": "логов нет", "no_output": "нет вывода",
    },
    "uk": {
        "dashboard": "Панель", "clients": "Клієнти", "traffic": "Трафік", "expiry": "Строки", "backups": "Бекапи",
        "diagnostics": "Діагностика", "audit": "Аудит", "telegram": "Telegram", "logs": "Логи", "logout": "Вийти",
        "theme": "Тема", "language": "Мова", "system": "Системна", "light": "Світла", "dark": "Темна",
        "local_cockpit": "Локальний AWG cockpit", "thin_layer": "Тонкий шар над батьківським manage_amneziawg.sh: клієнти, трафік, бекапи, діагностика і Telegram. Без власної VPN-логіки.",
        "check": "Перевірити", "restart_awg": "Перезапустити AWG", "clients_total": "Клієнти", "online": "online", "parent_status": "Parent status", "compatibility": "Сумісність",
        "server_status": "Статус сервера", "last_actions": "Останні дії", "time": "Час", "action": "Дія", "target": "Ціль", "result": "Результат",
        "add_client": "Додати клієнта", "name": "Імʼя", "expires": "Строк", "permanent": "постійний", "open": "Відкрити", "status": "Статус", "handshake": "Handshake",
        "temporary_clients": "Тимчасові клієнти", "traffic_history": "Історія трафіку", "latest_snapshots": "Останні знімки", "client": "Клієнт", "received": "Отримано", "sent": "Надіслано", "delta": "Дельта", "snapshot": "Знімок",
        "create_backup": "Створити backup", "download": "Завантажити", "preview": "Перегляд", "restore": "Відновити", "settings": "Налаштування", "save_apply": "Зберегти і застосувати",
        "bot_enabled": "Бот увімкнено", "admin_chat_id": "Admin chat_id", "send_backups_tg": "Надсилати backup-файли в Telegram", "allow_dangerous_tg": "Дозволити restart / repair / remove / restore з Telegram",
        "service": "Сервіс", "env": "Env", "run_diagnose": "Запустити diagnose", "repair_module": "Repair module", "login": "Логін", "password": "Пароль", "enter": "Увійти",
        "no_rows": "Немає записів", "no_clients": "Клієнтів немає або upstream list --json не повернув дані.", "no_logs": "логів немає", "no_output": "немає виводу",
    },
    "be": {
        "dashboard": "Панэль", "clients": "Кліенты", "traffic": "Трафік", "expiry": "Тэрміны", "backups": "Бэкапы",
        "diagnostics": "Дыягностыка", "audit": "Аўдыт", "telegram": "Telegram", "logs": "Логі", "logout": "Выйсці",
        "theme": "Тэма", "language": "Мова", "system": "Сістэмная", "light": "Светлая", "dark": "Цёмная",
        "local_cockpit": "Лакальны AWG cockpit", "thin_layer": "Тонкі слой над бацькоўскім manage_amneziawg.sh: кліенты, трафік, бэкапы, дыягностыка і Telegram. Без уласнай VPN-логікі.",
        "check": "Праверыць", "restart_awg": "Перазапусціць AWG", "clients_total": "Кліенты", "online": "online", "parent_status": "Parent status", "compatibility": "Сумяшчальнасць",
        "server_status": "Статус сервера", "last_actions": "Апошнія дзеянні", "time": "Час", "action": "Дзеянне", "target": "Мэта", "result": "Вынік",
        "add_client": "Дадаць кліента", "name": "Імя", "expires": "Тэрмін", "permanent": "пастаянны", "open": "Адкрыць", "status": "Статус", "handshake": "Handshake",
        "temporary_clients": "Часовыя кліенты", "traffic_history": "Гісторыя трафіку", "latest_snapshots": "Апошнія здымкі", "client": "Кліент", "received": "Атрымана", "sent": "Адпраўлена", "delta": "Дэльта", "snapshot": "Здымак",
        "create_backup": "Стварыць backup", "download": "Спампаваць", "preview": "Прагляд", "restore": "Аднавіць", "settings": "Налады", "save_apply": "Захаваць і прымяніць",
        "bot_enabled": "Бот уключаны", "admin_chat_id": "Admin chat_id", "send_backups_tg": "Адпраўляць backup-файлы ў Telegram", "allow_dangerous_tg": "Дазволіць restart / repair / remove / restore з Telegram",
        "service": "Сэрвіс", "env": "Env", "run_diagnose": "Запусціць diagnose", "repair_module": "Repair module", "login": "Лагін", "password": "Пароль", "enter": "Увайсці",
        "no_rows": "Няма запісаў", "no_clients": "Кліентаў няма або upstream list --json не вярнуў даныя.", "no_logs": "логаў няма", "no_output": "няма вываду",
    },
}


def normalize_lang(lang: str | None) -> str:
    lang = (lang or "").strip().lower()
    return lang if lang in SUPPORTED_LANGS else DEFAULT_LANG


def tr(lang: str | None, key: str) -> str:
    lang = normalize_lang(lang)
    return _TEXT.get(lang, {}).get(key) or _TEXT["en"].get(key) or key
