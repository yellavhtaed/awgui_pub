from __future__ import annotations

import ipaddress
import json
import re
import shlex
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
import manage_adapter

CHECK_SCRIPT = r'''
set -u
AWG_DIR="${AWG_DIR:-/root/awg}"
SERVER_CONF="${SERVER_CONF:-/etc/amnezia/amneziawg/awg0.conf}"
ENGINE_DIR="${ENGINE_DIR:-/root/awg/.awgui-engine/5.18.4-awgui1}"
kv(){ printf '%s=%s\n' "$1" "$2"; }
exists(){ [ -e "$1" ] && printf 1 || printf 0; }
size(){ [ -f "$1" ] && wc -c < "$1" 2>/dev/null || printf 0; }
lines(){ [ -f "$1" ] && wc -l < "$1" 2>/dev/null || printf 0; }
first(){ [ -f "$1" ] && head -n 1 "$1" 2>/dev/null || true; }
kv awg_dir "$AWG_DIR"
kv server_conf "$SERVER_CONF"
kv server_conf_present "$(exists "$SERVER_CONF")"
kv engine_dir "$ENGINE_DIR"
kv engine_ru_zone_present "$(exists "$ENGINE_DIR/cascade/ru.zone")"
kv engine_ru_zone_size "$(size "$ENGINE_DIR/cascade/ru.zone")"
kv engine_ru_zone_lines "$(lines "$ENGINE_DIR/cascade/ru.zone")"
kv engine_ru_zone_first "$(first "$ENGINE_DIR/cascade/ru.zone")"
kv awg_ru_zone_present "$(exists "$AWG_DIR/cascade/ru.zone")"
kv awg_ru_zone_size "$(size "$AWG_DIR/cascade/ru.zone")"
kv awg_ru_zone_lines "$(lines "$AWG_DIR/cascade/ru.zone")"
kv awg_ru_zone_first "$(first "$AWG_DIR/cascade/ru.zone")"
for p in "$AWG_DIR/awg-routing.sh" "$AWG_DIR/cascade/awg-routing.sh" "/usr/local/sbin/awg-routing.sh" "/usr/local/bin/awg-routing.sh"; do
  if [ -f "$p" ]; then kv routing_script "$p"; grep -q 'onlink' "$p" 2>/dev/null && kv routing_onlink_code 1 || kv routing_onlink_code 0; break; fi
done
kv default_route "$(ip -4 route show default 2>/dev/null | head -n1)"
dev="$(ip -4 route show default 2>/dev/null | awk 'NR==1{for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}')"
gw="$(ip -4 route show default 2>/dev/null | awk 'NR==1{for(i=1;i<=NF;i++) if($i=="via") print $(i+1)}')"
cidr=""
[ -n "$dev" ] && cidr="$(ip -o -4 addr show dev "$dev" scope global 2>/dev/null | awk 'NR==1{print $4}')"
kv default_dev "$dev"
kv default_gw "$gw"
kv default_cidr "$cidr"
if command -v python3 >/dev/null 2>&1 && [ -n "$gw" ] && [ -n "$cidr" ]; then
  python3 - "$gw" "$cidr" <<'PYIP'
import ipaddress, sys
try:
    gw=ipaddress.ip_address(sys.argv[1]); net=ipaddress.ip_network(sys.argv[2], strict=False)
    print('gateway_in_subnet=' + ('1' if gw in net else '0'))
    print('onlink_needed=' + ('0' if gw in net else '1'))
except Exception as e:
    print('gateway_in_subnet=unknown')
    print('onlink_needed=unknown')
PYIP
else
  kv gateway_in_subnet unknown
  kv onlink_needed unknown
fi
if command -v curl >/dev/null 2>&1; then
  curl -fsI --max-time 4 https://www.ipdeny.com/ipblocks/data/countries/ru.zone >/dev/null 2>&1 && kv ipdeny_reachable 1 || kv ipdeny_reachable 0
else
  kv ipdeny_reachable unknown
fi
if [ -f "$SERVER_CONF" ]; then
  addr_line="$(grep -E '^[[:space:]]*Address[[:space:]]*=' "$SERVER_CONF" 2>/dev/null | head -n1 | sed 's/^[^=]*=//; s/#.*//; s/[[:space:]]//g')"
  kv server_address "$addr_line"
  if command -v python3 >/dev/null 2>&1 && [ -n "$addr_line" ]; then
    python3 - "$addr_line" <<'PYSUBNET'
import ipaddress, sys
for part in sys.argv[1].split(','):
    part=part.strip()
    if not part or ':' in part:
        continue
    try:
        iface=ipaddress.ip_interface(part)
        print('client_subnet_guess=' + str(iface.network))
        break
    except Exception:
        pass
PYSUBNET
  fi
  grep -E '^[[:space:]]*(Jc|Jmin|Jmax|I[1-9]|H[1-4]|S[1-4])[[:space:]]*=' "$SERVER_CONF" 2>/dev/null | sed 's/^/awg_param=/' | head -50
fi
'''


def _parse_kv(text: str) -> Dict[str, Any]:
    data: Dict[str, Any] = {}
    params: List[str] = []
    for raw in (text or "").splitlines():
        if "=" not in raw:
            continue
        k, v = raw.split("=", 1)
        if k == "awg_param":
            params.append(v.strip())
        else:
            data[k.strip()] = v.strip()
    if params:
        data["awg_params"] = params
    return data


def local_bundle_status() -> Dict[str, Any]:
    vendor = config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME
    ru = vendor / "cascade" / "ru.zone"
    routing = bundled_routing_script_status()
    return {
        "vendor_root": str(vendor),
        "ru_zone_present": ru.exists(),
        "ru_zone_size": ru.stat().st_size if ru.exists() else 0,
        "ru_zone_lines": len(ru.read_text(encoding="utf-8", errors="replace").splitlines()) if ru.exists() else 0,
        "ru_zone_path": str(ru),
        "routing_script": routing,
    }


def diagnose(adapter: manage_adapter.ManageAdapter, timeout: int = 45) -> Dict[str, Any]:
    started = time.time()
    env = f"AWG_DIR={shlex.quote(str(adapter.awg_dir))} SERVER_CONF={shlex.quote(str(adapter.server_conf))} ENGINE_DIR={shlex.quote('/root/awg/.awgui-engine/' + config.ENGINE_VERSION)}"
    script = f"{env}\n{CHECK_SCRIPT}"
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        raw = adapter.shell(script, timeout=timeout, save_last=False)
    else:
        import os, subprocess
        proc = subprocess.run(["bash", "-lc", script], text=True, capture_output=True, timeout=timeout, env=os.environ.copy())
        raw = manage_adapter.make_result(["bash", "-lc", "cascade-check"], proc.returncode, proc.stdout.strip(), proc.stderr.strip(), started)
    data = _parse_kv(raw.get("stdout") or "")
    checks = build_checks(data, raw)
    return {
        "ok": bool(raw.get("ok")) and not any(c["level"] == "FAIL" for c in checks),
        "raw": raw,
        "data": data,
        "checks": checks,
        "bundle": local_bundle_status(),
    }


def _yes(v: Any) -> bool:
    return str(v) == "1"


def build_checks(data: Dict[str, Any], raw: Dict[str, Any]) -> List[Dict[str, str]]:
    checks: List[Dict[str, str]] = []
    def add(name: str, level: str, detail: str, action: str = ""):
        checks.append({"name": name, "level": level, "detail": detail, "action": action})
    if not raw.get("ok"):
        add("Cascade probe", "FAIL", (raw.get("stderr") or raw.get("text") or "probe failed")[:240], "Check SSH/local shell access")
    local_present = _yes(data.get("awg_ru_zone_present")) or _yes(data.get("engine_ru_zone_present"))
    ipdeny = data.get("ipdeny_reachable", "unknown")
    if local_present:
        add("Local cascade snapshot", "OK", f"awg={data.get('awg_ru_zone_lines','0')} lines, engine={data.get('engine_ru_zone_lines','0')} lines")
    else:
        add("Local cascade snapshot", "WARN", "ru.zone is not present in /root/awg/cascade or deployed engine slot", "Deploy/apply AWGUI engine or refresh cascade assets")
    if ipdeny == "1":
        add("ipdeny source", "OK", "www.ipdeny.com is reachable")
    elif ipdeny == "0":
        add("ipdeny source", "WARN", "ipdeny is not reachable from selected server", "Fallback must use bundled/local ru.zone")
    else:
        add("ipdeny source", "WARN", "curl is missing or source was not checked")
    if not local_present and ipdeny == "0":
        add("Cascade boot viability", "FAIL", "all route-list sources are unavailable", "Install bundled ru.zone before enabling cascade")
    else:
        add("Cascade boot viability", "OK", "at least one route-list source is available")
    onlink = data.get("onlink_needed", "unknown")
    if onlink == "1":
        add("/32 gateway topology", "WARN", f"gateway {data.get('default_gw')} is outside {data.get('default_cidr')}; onlink fallback is needed", "Use v5.18.4+ routing script")
    elif onlink == "0":
        add("/32 gateway topology", "OK", "default gateway is inside interface subnet")
    else:
        add("/32 gateway topology", "WARN", "unable to determine gateway/subnet relation")
    if data.get("routing_script"):
        lvl = "OK" if _yes(data.get("routing_onlink_code")) else "WARN"
        add("Routing script", lvl, f"{data.get('routing_script')} · onlink_code={data.get('routing_onlink_code','?')}")
    else:
        add("Routing script", "WARN", "awg-routing.sh not found in common locations")
    return checks




def bundled_routing_script_path() -> Path:
    return config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME / "awg-routing.sh"


def bundled_routing_script_status() -> Dict[str, Any]:
    p = bundled_routing_script_path()
    if not p.is_file():
        return {"ok": False, "path": str(p), "error": "bundled awg-routing.sh missing"}
    data = p.read_text(encoding="utf-8", errors="replace")
    return {
        "ok": "AWG1_ENDPOINT" in data and "onlink" in data and "ipset" in data,
        "path": str(p),
        "bytes": p.stat().st_size,
        "has_onlink": "onlink" in data,
        "has_ipset": "ipset" in data,
        "offline_ru_zone": 'RU_ZONE="$AWG_DIR/cascade/ru.zone"' in data,
    }


def _validate_client_subnet(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        raise ValueError("client subnet is required")
    net = ipaddress.ip_network(raw, strict=False)
    if net.version != 4:
        raise ValueError("only IPv4 client subnet is supported by current cascade routing script")
    return str(net)


def _validate_endpoint(value: str) -> str:
    raw = str(value or "").strip()
    if not raw or raw == "CHANGE_ME":
        raise ValueError("AWG1 endpoint is required")
    if not re.match(r"^[A-Za-z0-9_.:-]{1,255}$", raw):
        raise ValueError("bad AWG1 endpoint")
    return raw


def _validate_ifname(value: str, default: str = "awg1") -> str:
    raw = str(value or default).strip()
    if not re.match(r"^[A-Za-z0-9_.:-]{1,32}$", raw):
        raise ValueError("bad interface name")
    return raw


def render_routing_script(*, client_subnet: str, awg1_endpoint: str, awg1_if: str = "awg1") -> str:
    p = bundled_routing_script_path()
    if not p.is_file():
        raise FileNotFoundError("bundled awg-routing.sh missing")
    text = p.read_text(encoding="utf-8", errors="replace")
    client_subnet = _validate_client_subnet(client_subnet)
    awg1_endpoint = _validate_endpoint(awg1_endpoint)
    awg1_if = _validate_ifname(awg1_if)
    text = re.sub(r'^CLIENT_SUBNET="[^"]*"', f'CLIENT_SUBNET="{client_subnet}"', text, count=1, flags=re.M)
    text = re.sub(r'^AWG1_ENDPOINT="[^"]*"', f'AWG1_ENDPOINT="{awg1_endpoint}"', text, count=1, flags=re.M)
    text = re.sub(r'^AWG1_IF="[^"]*"', f'AWG1_IF="{awg1_if}"', text, count=1, flags=re.M)
    return text


def install_bundled_routing_script(adapter: manage_adapter.ManageAdapter, *, client_subnet: str, awg1_endpoint: str, awg1_if: str = "awg1", timeout: int = 60) -> Dict[str, Any]:
    """Install configured AWGUI-bundled awg-routing.sh safely.

    Safe scope: writes /root/awg/awg-routing.sh and ensures bundled ru.zone is
    present. It does not run the routing script and does not mutate routes.
    """
    started = time.time()
    try:
        content = render_routing_script(client_subnet=client_subnet, awg1_endpoint=awg1_endpoint, awg1_if=awg1_if).encode("utf-8")
    except Exception as exc:
        return manage_adapter.make_result(["cascade", "install-routing-script"], 2, "", f"{type(exc).__name__}: {exc}", started)
    ru = install_bundled_ru_zone(adapter, timeout=timeout)
    if not ru.get("ok"):
        return ru
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        script = f"""
set -Eeuo pipefail
AWG_DIR={shlex.quote(str(adapter.awg_dir))}
install -d -m 700 "$AWG_DIR"
if [ -f "$AWG_DIR/awg-routing.sh" ]; then
  cp -a "$AWG_DIR/awg-routing.sh" "$AWG_DIR/awg-routing.sh.bak.$(date +%Y%m%d-%H%M%S)"
fi
cat > "$AWG_DIR/awg-routing.sh.tmp"
chmod 700 "$AWG_DIR/awg-routing.sh.tmp"
bash -n "$AWG_DIR/awg-routing.sh.tmp"
mv -f "$AWG_DIR/awg-routing.sh.tmp" "$AWG_DIR/awg-routing.sh"
printf 'Installed configured awg-routing.sh: %s bytes\\n' "$(wc -c < "$AWG_DIR/awg-routing.sh")"
""".strip()
        return adapter.stream_stdin(script, content, timeout=timeout, label="awg-routing.sh", save_last=False)
    try:
        target_dir = Path(adapter.awg_dir)
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / "awg-routing.sh"
        if target.exists():
            import shutil
            backup = target_dir / ("awg-routing.sh.bak." + time.strftime("%Y%m%d-%H%M%S"))
            shutil.copy2(target, backup)
        tmp = target_dir / "awg-routing.sh.awgui-new"
        tmp.write_bytes(content)
        tmp.chmod(0o700)
        import subprocess
        check = subprocess.run(["bash", "-n", str(tmp)], text=True, capture_output=True, timeout=15)
        if check.returncode != 0:
            return manage_adapter.make_result(["bash", "-n", str(tmp)], check.returncode, check.stdout, check.stderr, started)
        tmp.replace(target)
        return manage_adapter.make_result(["cascade", "install-routing-script", str(target)], 0, f"Installed configured awg-routing.sh: {len(content)} bytes", "", started)
    except Exception as exc:
        return manage_adapter.make_result(["cascade", "install-routing-script"], 1, "", f"{type(exc).__name__}: {exc}", started)


def run_routing_script(adapter: manage_adapter.ManageAdapter, timeout: int = 60) -> Dict[str, Any]:
    """Run existing awg-routing.sh. This is intentionally explicit/destructive."""
    script = f"set -Eeuo pipefail\nAWG_DIR={shlex.quote(str(adapter.awg_dir))}\ntest -x \"$AWG_DIR/awg-routing.sh\"\nbash \"$AWG_DIR/awg-routing.sh\""
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        return adapter.shell(script, timeout=timeout, save_last=False)
    import subprocess, os
    started = time.time()
    proc = subprocess.run(["bash", "-lc", script], text=True, capture_output=True, timeout=timeout, env=os.environ.copy())
    return manage_adapter.make_result(["bash", "-lc", "run-awg-routing"], proc.returncode, proc.stdout.strip(), proc.stderr.strip(), started)

def report_text(diag: Dict[str, Any]) -> str:
    lines = [f"AWGUI Cascade diagnostics · {config.APP_VERSION}", f"Engine: {config.ENGINE_VERSION}", ""]
    for c in diag.get("checks", []):
        lines.append(f"[{c['level']}] {c['name']}: {c['detail']}")
        if c.get("action"):
            lines.append(f"  action: {c['action']}")
    lines.append("")
    lines.append("Raw data:")
    for k, v in sorted((diag.get("data") or {}).items()):
        if k == "awg_params":
            lines.append("awg_params:")
            for p in v:
                lines.append(f"  {p}")
        else:
            lines.append(f"{k}={v}")
    return "\n".join(lines)



def install_bundled_ru_zone(adapter: manage_adapter.ManageAdapter, timeout: int = 60) -> Dict[str, Any]:
    """Install AWGUI-bundled cascade/ru.zone on selected server.

    Safe scope: this only places the route-list snapshot under
    <AWG_DIR>/cascade/ru.zone. It does not rewrite routing rules, does not
    restart AWG, and does not touch client/server keys.
    """
    import shutil
    ru_path = config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME / "cascade" / "ru.zone"
    if not ru_path.is_file():
        return manage_adapter.make_result(["cascade", "install-ru-zone"], 2, "", "bundled cascade/ru.zone missing")
    content = ru_path.read_bytes()
    lines = len(content.decode("utf-8", errors="replace").splitlines())
    if lines < 1000 or len(content) < 10000:
        return manage_adapter.make_result(["cascade", "install-ru-zone"], 2, "", f"bundled ru.zone looks incomplete: {lines} lines, {len(content)} bytes")
    started = time.time()
    awg_dir_q = shlex.quote(str(adapter.awg_dir))
    # SSH path: deploy the engine slot once, then copy ru.zone from the remote slot.
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        import engine
        dep = engine.deploy_bundled_engine(adapter, timeout=timeout)
        if not dep.get("ok"):
            return dep
        remote_ru = shlex.quote(engine.REMOTE_DIR + "/cascade/ru.zone")
        script = f"""
set -Eeuo pipefail
AWG_DIR={awg_dir_q}
SRC={remote_ru}
test -f "$SRC"
install -d -m 700 "$AWG_DIR/cascade"
if [ -f "$AWG_DIR/cascade/ru.zone" ]; then
  cp -a "$AWG_DIR/cascade/ru.zone" "$AWG_DIR/cascade/ru.zone.bak.$(date +%Y%m%d-%H%M%S)"
fi
lines=$(wc -l < "$SRC")
bytes=$(wc -c < "$SRC")
if [ "$lines" -lt 1000 ] || [ "$bytes" -lt 10000 ]; then
  echo "bundled ru.zone validation failed: $lines lines, $bytes bytes" >&2
  exit 2
fi
install -m 600 "$SRC" "$AWG_DIR/cascade/ru.zone"
printf '%s\n' '{config.ENGINE_VERSION}' > "$AWG_DIR/cascade/.awgui-ru-zone-version"
printf 'Installed bundled ru.zone: %s lines, %s bytes\n' "$lines" "$bytes"
""".strip()
        return adapter.shell(script, timeout=timeout, save_last=False)
    # Local path: copy directly to avoid huge command-line arguments.
    try:
        target_dir = adapter.awg_dir / "cascade"
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / "ru.zone"
        if target.exists():
            backup = target_dir / ("ru.zone.bak." + time.strftime("%Y%m%d-%H%M%S"))
            shutil.copy2(target, backup)
        tmp = target_dir / "ru.zone.awgui-new"
        tmp.write_bytes(content)
        tmp.chmod(0o600)
        tmp.replace(target)
        (target_dir / ".awgui-ru-zone-version").write_text(config.ENGINE_VERSION + "\n", encoding="utf-8")
        return manage_adapter.make_result(["cascade", "install-ru-zone", str(target)], 0, f"Installed bundled ru.zone: {lines} lines, {len(content)} bytes", "", started)
    except Exception as exc:
        return manage_adapter.make_result(["cascade", "install-ru-zone"], 1, "", f"{type(exc).__name__}: {exc}", started)
