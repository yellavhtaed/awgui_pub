#!/usr/bin/env python3
from __future__ import annotations

import html
import json
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional

import config

MAX_MSG = 3900
DOC_THRESHOLD = 3000

class TelegramError(RuntimeError):
    def __init__(self, method: str, status: int, description: str, raw: str = "") -> None:
        super().__init__(f"Telegram {method} failed: {status} {description}")
        self.method = method
        self.status = status
        self.description = description
        self.raw = raw


def log(msg: str) -> None:
    print(f"[awgui-bot] {msg}", flush=True)


def settings() -> Dict[str, Any]:
    return config.load_telegram_settings()


def token() -> str:
    return str(settings().get("token") or "")


def esc(x: Any) -> str:
    return html.escape(str(x or ""), quote=False)


def clip(text: Any, limit: int = MAX_MSG) -> str:
    s = str(text or "")
    return s if len(s) <= limit else s[:limit] + "\n\n--- cut ---"


def _http_error_text(exc: urllib.error.HTTPError) -> str:
    try:
        raw = exc.read().decode("utf-8", errors="replace")
    except Exception:
        raw = ""
    if raw:
        try:
            payload = json.loads(raw)
            return str(payload.get("description") or raw)
        except Exception:
            return raw
    return str(exc.reason or exc)


def api(method: str, payload: Optional[Dict[str, Any]] = None, timeout: int = 60) -> Dict[str, Any]:
    url = f"https://api.telegram.org/bot{token()}/{method}"
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", errors="replace")
        out = json.loads(body or "{}")
        if not out.get("ok", True):
            raise TelegramError(method, 200, str(out.get("description") or "ok=false"), body)
        return out
    except urllib.error.HTTPError as exc:
        desc = _http_error_text(exc)
        raise TelegramError(method, int(exc.code or 0), desc) from exc


def multipart_api(method: str, fields: Dict[str, Any], file_field: str, path: Path, mime: str, timeout: int = 90) -> Dict[str, Any]:
    boundary = "----awgui" + str(int(time.time() * 1000))
    body = bytearray()

    def add(s: str) -> None:
        body.extend(s.encode("utf-8"))

    for k, v in fields.items():
        add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n")
    add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; filename=\"{path.name}\"\r\nContent-Type: {mime}\r\n\r\n")
    body.extend(path.read_bytes())
    add(f"\r\n--{boundary}--\r\n")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token()}/{method}",
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        desc = _http_error_text(exc)
        raise TelegramError(method, int(exc.code or 0), desc) from exc


def _text_payload(chat_id: int | str, text: str, keyboard: Optional[Dict[str, Any]], html_mode: bool) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "text": clip(text),
        "disable_web_page_preview": True,
    }
    if html_mode:
        payload["parse_mode"] = "HTML"
    if keyboard:
        payload["reply_markup"] = keyboard
    return payload


def send(chat_id: int | str, text: str, keyboard: Optional[Dict[str, Any]] = None, html_mode: bool = True) -> bool:
    try:
        api("sendMessage", _text_payload(chat_id, text, keyboard, html_mode))
        return True
    except TelegramError as exc:
        log(f"sendMessage failed: {exc.status} {exc.description}")
        if html_mode:
            try:
                api("sendMessage", _text_payload(chat_id, _strip_html_for_fallback(text), keyboard, False))
                return True
            except TelegramError as retry_exc:
                log(f"sendMessage plain fallback failed: {retry_exc.status} {retry_exc.description}")
        return False


def edit(chat_id: int | str, message_id: int, text: str, keyboard: Optional[Dict[str, Any]] = None, html_mode: bool = True) -> bool:
    payload = _text_payload(chat_id, text, keyboard, html_mode)
    payload["message_id"] = message_id
    try:
        api("editMessageText", payload)
        return True
    except TelegramError as exc:
        desc = exc.description.lower()
        if "message is not modified" in desc:
            return True
        log(f"editMessageText failed: {exc.status} {exc.description}; falling back to sendMessage")
        return send(chat_id, text, keyboard, html_mode=html_mode)


def answer_callback(callback_id: str, text: str = "") -> bool:
    try:
        api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180]}, timeout=15)
        return True
    except TelegramError as exc:
        log(f"answerCallbackQuery failed: {exc.status} {exc.description}")
        return False


def send_doc(chat_id: int | str, path: Path, caption: str = "") -> bool:
    try:
        multipart_api("sendDocument", {"chat_id": chat_id, "caption": caption[:900]}, "document", path, "application/octet-stream")
        return True
    except Exception as exc:
        log(f"sendDocument failed for {path}: {type(exc).__name__}: {exc}")
        return False


def send_photo(chat_id: int | str, path: Path, caption: str = "") -> bool:
    try:
        multipart_api("sendPhoto", {"chat_id": chat_id, "caption": caption[:900]}, "photo", path, "image/png")
        return True
    except Exception as exc:
        log(f"sendPhoto failed for {path}: {type(exc).__name__}: {exc}")
        return False


def _strip_html_for_fallback(text: str) -> str:
    return str(text or "").replace("<b>", "").replace("</b>", "").replace("<code>", "").replace("</code>", "").replace("<pre>", "").replace("</pre>", "")


def send_output(chat_id: Any, title: str, result_or_text: Any, keyboard: Optional[Dict[str, Any]] = None, *, force_doc: bool = False) -> None:
    if isinstance(result_or_text, dict):
        ok = bool(result_or_text.get("ok"))
        text = str(result_or_text.get("text") or result_or_text.get("stdout") or result_or_text.get("stderr") or "")
        icon = "✅" if ok else "⚠️"
        header = f"{icon} {title}"
    else:
        text = str(result_or_text or "")
        header = title
    if force_doc or len(text) > DOC_THRESHOLD:
        tmp_path: Optional[Path] = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", prefix="awgui_", delete=False) as f:
                f.write(text)
                tmp_path = Path(f.name)
            if send_doc(chat_id, tmp_path, header):
                send(chat_id, f"<b>{esc(header)}</b>\nВывод отправлен файлом: <code>{esc(tmp_path.name)}</code>", keyboard)
                return
        finally:
            if tmp_path:
                try:
                    tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass
    send(chat_id, f"<b>{esc(header)}</b>\n<pre>{esc(text)}</pre>", keyboard)

