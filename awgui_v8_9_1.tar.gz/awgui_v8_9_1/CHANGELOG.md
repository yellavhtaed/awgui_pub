# AWGUI v8.9.1 — Cascade Console & Obfuscation Wiring

## Added

- Bundled `awg-routing.sh` from upstream cascade documentation, patched to use AWGUI offline `/root/awg/cascade/ru.zone`.
- Interactive `/cascade` console:
  - diagnostics;
  - bundled `ru.zone` install;
  - configured `awg-routing.sh` install;
  - explicit routing script run with `RUN` confirmation.
- Provisioner cascade options for new servers that will act as AWG0 cascade entry.
- Client creation obfuscation guard: clients use current server params; unsafe per-client profile selection is blocked.
- README full removal instructions for AWGUI panel and AmneziaWG server.

## Changed

- Engine manifest now includes `awg-routing.sh`.
- Cascade diagnostics expose server Address/client subnet guess and bundled routing script status.
- Telegram Cascade menu now explains routing-script setup and keeps route mutation web-only for safer structured input.

## Not added intentionally

- No fake per-client obfuscation profile.
- No blind cascade route auto-repair.
- No password SSH / sshpass.
- No new frontend framework or extra heavy dependencies.
