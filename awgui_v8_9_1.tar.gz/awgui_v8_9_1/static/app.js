(function () {
  function applyTheme(value) {
    var theme = value || 'system';
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('awgui_theme', theme); } catch (e) {}
  }
  var initial = 'system';
  try { initial = localStorage.getItem('awgui_theme') || 'system'; } catch (e) {}
  applyTheme(initial);
  document.addEventListener('DOMContentLoaded', function () {
    var select = document.getElementById('themeSelect');
    if (select) {
      select.value = initial;
      select.addEventListener('change', function () { applyTheme(select.value); });
    }
  });
  document.addEventListener('submit', function (e) {
    var form = e.target;
    var msg = form && form.getAttribute && form.getAttribute('data-confirm');
    if (msg && !confirm(msg)) e.preventDefault();
  });
})();
