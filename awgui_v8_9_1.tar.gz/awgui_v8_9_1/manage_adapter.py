from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import tarfile
import tempfile
import time
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import config
import parse

CLIENT_RE = re.compile(r"^[A-Za-z0-9_-]{1,63}$")
PARAM_RE = re.compile(r"^(DNS|Endpoint|AllowedIPs|PersistentKeepalive)$")
DURATION_RE = re.compile(r"^[0-9]+[hdwm]$|^[0-9]+d$|^[0-9]+h$|^[0-9]+m$|^[0-9]+w$")
CARRIER_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def parse_json_tolerant(text: str) -> Any:
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass
    for left, right in (("[", "]"), ("{", "}")):
        a, b = text.find(left), text.rfind(right)
        if a >= 0 and b > a:
            try:
                return json.loads(text[a:b + 1])
            except Exception:
                pass
    return None


def make_result(cmd: Iterable[str], rc: int, stdout: str = "", stderr: str = "", started: Optional[float] = None, parsed: Any = None) -> Dict[str, Any]:
    stdout = stdout or ""
    stderr = stderr or ""
    text = (stdout + ("\n" if stdout and stderr else "") + stderr).strip()
    return {
        "time": now_iso(),
        "ok": rc == 0,
        "rc": int(rc),
        "cmd": shlex.join([str(x) for x in cmd]),
        "stdout": stdout,
        "stderr": stderr,
        "text": text,
        "json": parsed,
        "duration": round(time.time() - started, 3) if started else 0,
    }


def valid_client(name: str) -> str:
    name = (name or "").strip()
    if not CLIENT_RE.match(name):
        raise ValueError("bad client name: use A-Z a-z 0-9 _ - up to 63 chars")
    return name


def valid_duration(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    value = value.strip()
    if not DURATION_RE.match(value):
        raise ValueError("bad duration: use 1h / 12h / 1d / 7d / 30d / 4w")
    return value


class ManageAdapter:
    """Single gateway to bivlked/amneziawg-installer's manage_amneziawg.sh.

    Everything in AWGUI that touches AmneziaWG must go through this class.
    The parent shell script remains the source of truth.
    """

    def __init__(self, manage: Path | str = config.MANAGE, awg_dir: Path | str = config.AWG_DIR, server_conf: Path | str = config.SERVER_CONF):
        self.manage = Path(manage)
        self.awg_dir = Path(awg_dir)
        self.server_conf = Path(server_conf)

    def exists(self) -> bool:
        return self.manage.exists() and self.manage.is_file()

    def _base_cmd(self) -> List[str]:
        return ["bash", str(self.manage), "--no-color", f"--conf-dir={self.awg_dir}", f"--server-conf={self.server_conf}"]

    def run(self, *args: str, json_mode: bool = False, timeout: Optional[int] = None, save_last: bool = True, extra_env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        timeout = timeout or config.DEFAULT_TIMEOUT
        started = time.time()
        cmd = self._base_cmd()
        if json_mode:
            cmd.append("--json")
        cmd.extend(str(x) for x in args if x is not None and str(x) != "")
        if not self.exists():
            return make_result(cmd, 127, "", f"manage script not found: {self.manage}", started)
        env = os.environ.copy()
        env.update(extra_env or {})
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        cwd = str(self.awg_dir if self.awg_dir.exists() else Path("/tmp"))
        try:
            proc = subprocess.run(cmd, cwd=cwd, env=env, text=True, capture_output=True, timeout=timeout)
            parsed = parse_json_tolerant(proc.stdout) if json_mode else None
            result = make_result(cmd, proc.returncode, proc.stdout.strip(), proc.stderr.strip(), started, parsed)
        except subprocess.TimeoutExpired as exc:
            result = make_result(cmd, 124, (exc.stdout or "") if isinstance(exc.stdout, str) else "", (exc.stderr or "Timeout") if isinstance(exc.stderr, str) else "Timeout", started)
        except Exception as exc:
            result = make_result(cmd, 1, "", f"{type(exc).__name__}: {exc}", started)
        if save_last:
            self.save_last(result)
        return result

    def save_last(self, result: Dict[str, Any]) -> None:
        try:
            config.LAST_FILE.parent.mkdir(parents=True, exist_ok=True)
            config.LAST_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def read_last(self) -> Optional[Dict[str, Any]]:
        try:
            return json.loads(config.LAST_FILE.read_text(encoding="utf-8"))
        except Exception:
            return None

    def tail_log(self, lines: int = 500) -> str:
        candidates = [self.awg_dir / "manage_amneziawg.log", config.LOG_FILE]
        for p in candidates:
            try:
                data = p.read_text(encoding="utf-8", errors="replace").splitlines()
                return "\n".join(data[-lines:])
            except Exception:
                continue
        return ""

    # Capabilities / upstream compatibility
    def help(self) -> Dict[str, Any]:
        if not self.exists():
            return make_result(["bash", str(self.manage), "help"], 127, "", f"manage script not found: {self.manage}")
        return self.run("help", timeout=12, save_last=False)

    def scan(self) -> Dict[str, Any]:
        text = ""
        version = "unknown"
        if self.exists():
            try:
                raw = self.manage.read_text(encoding="utf-8", errors="replace")[:50000]
                m = re.search(r'SCRIPT_VERSION="([^"]+)"', raw) or re.search(r"Версия:\s*([0-9.]+)", raw)
                if m:
                    version = m.group(1)
            except Exception:
                pass
        h = self.help()
        text = h.get("text") or ""
        commands = {}
        for command in ("add", "remove", "list", "stats", "regen", "modify", "backup", "restore", "check", "status", "diagnose", "show", "restart", "repair-module"):
            commands[command] = bool(re.search(rf"(^|\s){re.escape(command)}(\s|\||$)", text)) or command in text
        options = {opt: opt in text for opt in ("--json", "--expires", "--psk", "--carrier", "--apply-mode", "--yes", "--conf-dir", "--server-conf")}
        carriers = [c for c in config.CARRIERS if c in text]
        return {
            "ok": self.exists(),
            "script_version": version,
            "manage": str(self.manage),
            "awg_dir": str(self.awg_dir),
            "server_conf": str(self.server_conf),
            "help_ok": h.get("ok", False),
            "commands": commands,
            "options": options,
            "carriers": carriers or config.CARRIERS,
            "raw_help": text[:12000],
        }

    # Read API
    def list_clients(self) -> Dict[str, Any]:
        return self.run("list", json_mode=True, save_last=False)

    def stats(self) -> Dict[str, Any]:
        return self.run("stats", json_mode=True, save_last=False)

    def status(self) -> Dict[str, Any]:
        return self.run("status", save_last=False)

    def check(self) -> Dict[str, Any]:
        return self.run("check", timeout=60)

    def show(self, save_last: bool = False) -> Dict[str, Any]:
        return self.run("show", save_last=save_last)

    def diagnose(self, carrier: Optional[str] = None) -> Dict[str, Any]:
        args: List[str] = []
        if carrier:
            carrier = carrier.strip()
            if not CARRIER_RE.match(carrier):
                raise ValueError("bad carrier name")
            args.append(f"--carrier={carrier}")
        args.append("diagnose")
        return self.run(*args, timeout=180)

    # Mutations
    def add_client(self, name: str, expires: Optional[str] = None, psk: bool = False) -> Dict[str, Any]:
        name = valid_client(name)
        args: List[str] = ["--yes"]
        expires = valid_duration(expires)
        if expires:
            args.append(f"--expires={expires}")
        if psk:
            args.append("--psk")
        args += ["add", name]
        return self.run(*args, timeout=300)

    def remove_client(self, name: str) -> Dict[str, Any]:
        return self.run("--yes", "remove", valid_client(name), timeout=300)

    def regen_client(self, name: str) -> Dict[str, Any]:
        return self.run("regen", valid_client(name), timeout=300)

    def modify_client(self, name: str, param: str, value: str) -> Dict[str, Any]:
        name = valid_client(name)
        param = (param or "").strip()
        value = (value or "").strip()
        if not PARAM_RE.match(param):
            raise ValueError("unsupported parameter")
        if not value:
            raise ValueError("empty value")
        return self.run("modify", name, param, value, timeout=300)

    def backup(self) -> Dict[str, Any]:
        return self.run("backup", timeout=300)

    def restore(self, backup_path: str) -> Dict[str, Any]:
        p = Path(backup_path or "")
        if not p.exists() or not p.is_file():
            raise FileNotFoundError("backup file not found")
        return self.run("--yes", "restore", str(p), timeout=900)

    def restart(self) -> Dict[str, Any]:
        return self.run("--yes", "restart", timeout=180)

    def repair_module(self) -> Dict[str, Any]:
        return self.run("repair-module", timeout=900)

    # Files produced by parent script
    def find_client_file(self, name: str, suffix: str) -> Optional[Path]:
        try:
            name = valid_client(name)
        except Exception:
            return None
        suffix = suffix.lstrip(".")
        candidates = [
            self.awg_dir / f"{name}.{suffix}",
            self.awg_dir / "clients" / f"{name}.{suffix}",
            self.awg_dir / "configs" / f"{name}.{suffix}",
            self.awg_dir / "client_configs" / f"{name}.{suffix}",
            self.awg_dir / "peer_configs" / f"{name}.{suffix}",
            self.awg_dir / "output" / f"{name}.{suffix}",
        ]
        for p in candidates:
            if p.exists() and p.is_file():
                return p
        try:
            for p in self.awg_dir.rglob(f"{name}.{suffix}"):
                if p.is_file():
                    return p
        except Exception:
            pass
        return None

    def read_client_text(self, name: str, suffix: str, limit: int = 100000) -> str:
        p = self.find_client_file(name, suffix)
        if not p:
            return ""
        return p.read_text(encoding="utf-8", errors="replace")[:limit]

    def file_inventory(self, name: str) -> Dict[str, str]:
        return {s: str(self.find_client_file(name, s) or "") for s in ("conf", "vpnuri", "png")}

    def read_client_bytes(self, name: str, suffix: str, limit: int = 20 * 1024 * 1024) -> Tuple[Optional[str], Optional[bytes]]:
        p = self.find_client_file(name, suffix)
        if not p:
            return None, None
        data = p.read_bytes()[:limit]
        return p.name, data

    def qr_payload(self, name: str, preferred: str = "vpnuri") -> Tuple[Optional[str], Optional[str]]:
        order = [preferred if preferred in {"vpnuri", "conf"} else "vpnuri"]
        order.append("conf" if order[0] == "vpnuri" else "vpnuri")
        for suffix in order:
            text = self.read_client_text(name, suffix)
            if text:
                return suffix, text.strip()
        return None, None

    def create_client_bundle(self, name: str) -> Path:
        name = valid_client(name)
        out = Path(tempfile.gettempdir()) / f"awgui_{name}_bundle.zip"
        files: List[Tuple[Path, str]] = []
        for suffix in ("conf", "vpnuri", "png"):
            p = self.find_client_file(name, suffix)
            if p:
                files.append((p, f"{name}.{suffix}"))
        if not files:
            raise FileNotFoundError("client files not found")
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for p, arc in files:
                z.write(p, arc)
            z.writestr("README.txt", f"AWGUI client bundle\nclient={name}\nversion={config.APP_VERSION}\nsource={self.manage}\n")
        return out

    # Backups
    def backup_roots(self) -> List[Path]:
        return [self.awg_dir / "backups", self.awg_dir / "backup", self.awg_dir]

    @staticmethod
    def human_size(num: int) -> str:
        n = float(num)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if n < 1024 or unit == "TB":
                return f"{n:.1f} {unit}"
            n /= 1024
        return f"{n:.1f} TB"

    def list_backups(self) -> List[Dict[str, Any]]:
        seen = set()
        out: List[Dict[str, Any]] = []
        for root in self.backup_roots():
            if not root.exists() or not root.is_dir():
                continue
            for pat in ("awg_backup_*.tar.gz", "*.tar.gz", "*.tgz", "*.zip"):
                for p in root.glob(pat):
                    try:
                        r = p.resolve()
                        if r in seen or not r.is_file():
                            continue
                        seen.add(r)
                        st = r.stat()
                        out.append({"name": r.name, "path": str(r), "size": st.st_size, "size_h": self.human_size(st.st_size), "mtime": st.st_mtime, "mtime_h": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")})
                    except Exception:
                        pass
        out.sort(key=lambda x: x["mtime"], reverse=True)
        return out

    def find_backup(self, name: str) -> Optional[Path]:
        name = (name or "").strip()
        if not name or "/" in name or "\\" in name or name.startswith("."):
            return None
        for item in self.list_backups():
            if item["name"] == name:
                return Path(item["path"])
        return None

    def backup_bytes(self, name: str, limit: int = 1024 * 1024 * 1024) -> Tuple[Optional[str], Optional[bytes]]:
        p = self.find_backup(name)
        if not p:
            return None, None
        return p.name, p.read_bytes()[:limit]

    def backup_preview(self, path: Path | str, limit: int = 300) -> Dict[str, Any]:
        p = Path(path or "")
        if not p.exists() or not p.is_file():
            return {"ok": False, "error": "backup not found", "items": []}
        items: List[Dict[str, Any]] = []
        try:
            if tarfile.is_tarfile(p):
                with tarfile.open(p) as t:
                    for m in t.getmembers()[:limit]:
                        items.append({"name": m.name, "size": m.size, "size_h": self.human_size(m.size), "type": "dir" if m.isdir() else "file"})
                return {"ok": True, "name": p.name, "path": str(p), "format": "tar", "items": items, "truncated": len(items) >= limit, "sha256": self.sha256(p)}
            if zipfile.is_zipfile(p):
                with zipfile.ZipFile(p) as z:
                    for i in z.infolist()[:limit]:
                        items.append({"name": i.filename, "size": i.file_size, "size_h": self.human_size(i.file_size), "type": "dir" if i.is_dir() else "file"})
                return {"ok": True, "name": p.name, "path": str(p), "format": "zip", "items": items, "truncated": len(items) >= limit, "sha256": self.sha256(p)}
            return {"ok": False, "name": p.name, "error": "unknown archive format", "items": [], "sha256": self.sha256(p)}
        except Exception as exc:
            return {"ok": False, "name": p.name, "error": f"{type(exc).__name__}: {exc}", "items": items}

    @staticmethod
    def sha256(path: Path) -> str:
        h = hashlib.sha256()
        with Path(path).open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    # Diagnostics
    def systemctl_state(self, service: str) -> Dict[str, Any]:
        if not shutil.which("systemctl"):
            return {"service": service, "available": False, "active": "systemctl not found", "enabled": "unknown"}
        def run(*args):
            try:
                p = subprocess.run(["systemctl", *args, service], text=True, capture_output=True, timeout=6)
                return {"rc": p.returncode, "text": (p.stdout or p.stderr or "").strip()}
            except Exception as exc:
                return {"rc": 1, "text": f"{type(exc).__name__}: {exc}"}
        a, e = run("is-active"), run("is-enabled")
        return {"service": service, "available": True, "active": a["text"] or "unknown", "enabled": e["text"] or "unknown", "active_ok": a["rc"] == 0, "enabled_ok": e["rc"] == 0}

    def systemd_execstart(self, service: str = "awgui.service") -> str:
        if not shutil.which("systemctl"):
            return ""
        try:
            p = subprocess.run(["systemctl", "show", service, "-p", "ExecStart", "--value"], text=True, capture_output=True, timeout=6)
            return (p.stdout or p.stderr or "").strip()
        except Exception:
            return ""

    def doctor(self) -> Dict[str, Any]:
        scan = self.scan()
        status = self.status()
        checks = [
            {"name": "AWGUI version", "ok": bool(config.APP_VERSION), "detail": config.APP_VERSION},
            {"name": "manage_amneziawg.sh", "ok": self.exists(), "detail": str(self.manage)},
            {"name": "parent script version", "ok": scan.get("script_version") != "unknown", "detail": scan.get("script_version")},
            {"name": "AWG directory", "ok": self.awg_dir.exists(), "detail": str(self.awg_dir)},
            {"name": "server config", "ok": self.server_conf.exists(), "detail": str(self.server_conf)},
            {"name": "json contract", "ok": bool(scan["options"].get("--json")), "detail": "list/stats --json"},
            {"name": "temporary clients", "ok": bool(scan["options"].get("--expires")), "detail": "--expires"},
            {"name": "PSK support", "ok": bool(scan["options"].get("--psk")), "detail": "--psk"},
            {"name": "carrier diagnose", "ok": bool(scan["options"].get("--carrier")), "detail": ", ".join(scan.get("carriers") or [])},
            {"name": "awg service status", "ok": status.get("ok"), "detail": (status.get("text") or "")[:260]},
        ]
        return {
            "ok": all(c["ok"] for c in checks[:2]),
            "checks": checks,
            "scan": scan,
            "status": status,
            "services": [self.systemctl_state("awgui.service"), self.systemctl_state("awgui-bot.service"), self.systemctl_state("awg-quick@awg0.service")],
            "execstart": self.systemd_execstart("awgui.service"),
        }

    def summary(self) -> Dict[str, Any]:
        list_result = self.list_clients()
        stats_result = self.stats()
        clients = parse.clients_from(list_result.get("json"))
        online = sum(1 for c in clients if parse.online_state(c, config.ONLINE_WINDOW_SECONDS) == "ONLINE")
        return {
            "version": config.APP_VERSION,
            "server": {"id": config.SERVER_ID, "name": config.SERVER_NAME},
            "clients_total": len(clients),
            "clients_online": online,
            "list": list_result,
            "stats": stats_result,
            "clients": clients,
        }




class SSHManageAdapter(ManageAdapter):
    """No-agent SSH adapter. It runs the same parent manage script on a remote server.

    This is intentionally plain OpenSSH + remote bash: no Paramiko, no agent daemon,
    no RPC layer. Remote servers remain ordinary Ubuntu AWG boxes.
    """

    def __init__(self, spec: Dict[str, Any]):
        super().__init__(spec.get("manage_path") or "/root/awg/manage_amneziawg.sh", spec.get("awg_dir") or "/root/awg", spec.get("server_conf") or "/etc/amnezia/amneziawg/awg0.conf")
        self.spec = spec
        self.host = str(spec.get("host") or "")
        self.user = str(spec.get("user") or "root")
        self.port = int(spec.get("port") or 22)
        self.key_path = str(spec.get("key_path") or "")

    def _ssh(self) -> List[str]:
        cmd = [
            config.SSH_BIN,
            "-p", str(self.port),
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=8",
            "-o", "ServerAliveInterval=10",
            "-o", "ServerAliveCountMax=2",
            "-o", "StrictHostKeyChecking=accept-new",
        ]
        if self.key_path:
            cmd += ["-i", self.key_path]
        cmd.append(f"{self.user}@{self.host}")
        return cmd

    def exists(self) -> bool:
        r = self.shell(f"test -f {shlex.quote(str(self.manage))} && test -r {shlex.quote(str(self.manage))}", timeout=12, save_last=False)
        return bool(r.get("ok"))

    def _remote_manage_command(self, args: Iterable[str], json_mode: bool = False) -> str:
        parts = ["bash", str(self.manage), "--no-color", f"--conf-dir={self.awg_dir}", f"--server-conf={self.server_conf}"]
        if json_mode:
            parts.append("--json")
        parts.extend(str(x) for x in args if x is not None and str(x) != "")
        return " ".join(shlex.quote(x) for x in parts)

    def shell(self, script: str, timeout: Optional[int] = None, save_last: bool = True) -> Dict[str, Any]:
        timeout = timeout or config.DEFAULT_TIMEOUT
        started = time.time()
        cmd = self._ssh() + [script]
        if not self.host:
            return make_result(cmd, 2, "", "ssh host is empty", started)
        if not shutil.which(config.SSH_BIN) and not Path(config.SSH_BIN).exists():
            return make_result(cmd, 127, "", f"ssh client not found: {config.SSH_BIN}", started)
        env = os.environ.copy()
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        try:
            proc = subprocess.run(cmd, env=env, text=True, capture_output=True, timeout=timeout)
            result = make_result(cmd, proc.returncode, proc.stdout.strip(), proc.stderr.strip(), started)
        except subprocess.TimeoutExpired as exc:
            result = make_result(cmd, 124, (exc.stdout or "") if isinstance(exc.stdout, str) else "", (exc.stderr or "Timeout") if isinstance(exc.stderr, str) else "Timeout", started)
        except Exception as exc:
            result = make_result(cmd, 1, "", f"{type(exc).__name__}: {exc}", started)
        if save_last:
            self.save_last(result)
        return result

    def stream_stdin(self, remote_script: str, payload: bytes, *, timeout: Optional[int] = None, label: str = "stdin-stream", save_last: bool = True) -> Dict[str, Any]:
        timeout = timeout or config.DEFAULT_TIMEOUT
        started = time.time()
        cmd = self._ssh() + [remote_script]
        display_cmd = [
            config.SSH_BIN,
            "-p", str(self.port),
            f"{self.user}@{self.host}",
            f"<{label}: {len(payload)} bytes>",
        ]
        if not self.host:
            return make_result(display_cmd, 2, "", "ssh host is empty", started)
        if not shutil.which(config.SSH_BIN) and not Path(config.SSH_BIN).exists():
            return make_result(display_cmd, 127, "", f"ssh client not found: {config.SSH_BIN}", started)
        env = os.environ.copy()
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        try:
            proc = subprocess.run(cmd, input=payload, env=env, capture_output=True, timeout=timeout)
            stdout = proc.stdout.decode("utf-8", errors="replace").strip()
            stderr = proc.stderr.decode("utf-8", errors="replace").strip()
            result = make_result(display_cmd, proc.returncode, stdout, stderr, started)
            result["payload_bytes"] = len(payload)
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            stderr = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "Timeout")
            result = make_result(display_cmd, 124, stdout, stderr, started)
            result["payload_bytes"] = len(payload)
        except Exception as exc:
            result = make_result(display_cmd, 1, "", f"{type(exc).__name__}: {exc}", started)
            result["payload_bytes"] = len(payload)
        if save_last:
            self.save_last(result)
        return result

    def run(self, *args: str, json_mode: bool = False, timeout: Optional[int] = None, save_last: bool = True, extra_env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
        timeout = timeout or config.DEFAULT_TIMEOUT
        started = time.time()
        remote = self._remote_manage_command(args, json_mode=json_mode)
        cmd = self._ssh() + [remote]
        if not self.host:
            return make_result(cmd, 2, "", "ssh host is empty", started)
        if not shutil.which(config.SSH_BIN) and not Path(config.SSH_BIN).exists():
            return make_result(cmd, 127, "", f"ssh client not found: {config.SSH_BIN}", started)
        env = os.environ.copy()
        env.update(extra_env or {})
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        try:
            proc = subprocess.run(cmd, env=env, text=True, capture_output=True, timeout=timeout)
            parsed = parse_json_tolerant(proc.stdout) if json_mode else None
            result = make_result(cmd, proc.returncode, proc.stdout.strip(), proc.stderr.strip(), started, parsed)
        except subprocess.TimeoutExpired as exc:
            result = make_result(cmd, 124, (exc.stdout or "") if isinstance(exc.stdout, str) else "", (exc.stderr or "Timeout") if isinstance(exc.stderr, str) else "Timeout", started)
        except Exception as exc:
            result = make_result(cmd, 1, "", f"{type(exc).__name__}: {exc}", started)
        if save_last:
            self.save_last(result)
        return result

    def save_last(self, result: Dict[str, Any]) -> None:
        try:
            sid = str(self.spec.get("id") or "ssh")
            p = config.LAST_FILE.with_name(f"last_action_{sid}.json")
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def read_last(self) -> Optional[Dict[str, Any]]:
        try:
            sid = str(self.spec.get("id") or "ssh")
            return json.loads(config.LAST_FILE.with_name(f"last_action_{sid}.json").read_text(encoding="utf-8"))
        except Exception:
            return None

    def _remote_find_client_file(self, name: str, suffix: str) -> Optional[str]:
        try:
            name = valid_client(name)
        except Exception:
            return None
        suffix = suffix.lstrip(".")
        roots = [str(self.awg_dir), f"{self.awg_dir}/clients", f"{self.awg_dir}/configs", f"{self.awg_dir}/client_configs", f"{self.awg_dir}/peer_configs", f"{self.awg_dir}/output"]
        tests = "\n".join([f"p={shlex.quote(root + '/' + name + '.' + suffix)}; [ -f \"$p\" ] && printf '%s\\n' \"$p\" && exit 0" for root in roots])
        script = f"set -efu\n{tests}\nfind {shlex.quote(str(self.awg_dir))} -type f -name {shlex.quote(name + '.' + suffix)} -print -quit 2>/dev/null || true"
        r = self.shell(script, timeout=20, save_last=False)
        if not r.get("ok"):
            return None
        line = (r.get("stdout") or "").splitlines()
        return line[0].strip() if line else None

    def read_client_text(self, name: str, suffix: str, limit: int = 100000) -> str:
        path = self._remote_find_client_file(name, suffix)
        if not path:
            return ""
        r = self.shell(f"head -c {int(limit)} {shlex.quote(path)}", timeout=30, save_last=False)
        return str(r.get("stdout") or "") if r.get("ok") else ""

    def read_client_bytes(self, name: str, suffix: str, limit: int = 20 * 1024 * 1024) -> Tuple[Optional[str], Optional[bytes]]:
        path = self._remote_find_client_file(name, suffix)
        if not path:
            return None, None
        cmd = self._ssh() + [f"head -c {int(limit)} {shlex.quote(path)}"]
        try:
            proc = subprocess.run(cmd, capture_output=True, timeout=45)
            if proc.returncode != 0:
                return None, None
            return Path(path).name, proc.stdout
        except Exception:
            return None, None

    def find_client_file(self, name: str, suffix: str) -> Optional[Path]:
        return None

    def file_inventory(self, name: str) -> Dict[str, str]:
        return {s: self._remote_find_client_file(name, s) or "" for s in ("conf", "vpnuri", "png")}

    def create_client_bundle(self, name: str) -> Path:
        name = valid_client(name)
        out = Path(tempfile.gettempdir()) / f"awgui_{self.spec.get('id','ssh')}_{name}_bundle.zip"
        found = 0
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
            for suffix in ("conf", "vpnuri", "png"):
                filename, data = self.read_client_bytes(name, suffix)
                if filename and data:
                    z.writestr(f"{name}.{suffix}", data)
                    found += 1
            z.writestr("README.txt", f"AWGUI remote client bundle\nserver={self.spec.get('id')}\nclient={name}\nversion={config.APP_VERSION}\nsource={self.user}@{self.host}:{self.manage}\n")
        if not found:
            raise FileNotFoundError("client files not found on remote server")
        return out

    def tail_log(self, lines: int = 500) -> str:
        script = f"for p in {shlex.quote(str(self.awg_dir) + '/manage_amneziawg.log')} {shlex.quote(str(config.LOG_FILE))}; do [ -f \"$p\" ] && tail -n {int(lines)} \"$p\" && exit 0; done"
        r = self.shell(script, timeout=20, save_last=False)
        return str(r.get("stdout") or r.get("stderr") or "")

    def list_backups(self) -> List[Dict[str, Any]]:
        roots = [f"{self.awg_dir}/backups", f"{self.awg_dir}/backup", str(self.awg_dir)]
        root_args = " ".join(shlex.quote(x) for x in roots)
        script = r"""
for d in __ROOTS__; do
  [ -d "$d" ] || continue
  find "$d" -maxdepth 1 -type f \( -name 'awg_backup_*.tar.gz' -o -name '*.tar.gz' -o -name '*.tgz' -o -name '*.zip' \) -printf '%f\t%p\t%s\t%T@\n' 2>/dev/null
 done
""".replace("__ROOTS__", root_args)
        r = self.shell(script, timeout=30, save_last=False)
        out: List[Dict[str, Any]] = []
        seen = set()
        for line in str(r.get("stdout") or "").splitlines():
            parts = line.split("\t")
            if len(parts) != 4:
                continue
            name, path, size, mtime = parts
            if path in seen:
                continue
            seen.add(path)
            try:
                size_i = int(size); mtime_f = float(mtime)
            except Exception:
                continue
            out.append({"name": name, "path": path, "size": size_i, "size_h": self.human_size(size_i), "mtime": mtime_f, "mtime_h": datetime.fromtimestamp(mtime_f).strftime("%Y-%m-%d %H:%M:%S")})
        out.sort(key=lambda x: x["mtime"], reverse=True)
        return out

    def find_backup(self, name: str) -> Optional[str]:
        name = (name or "").strip()
        if not name or "/" in name or "\\" in name or name.startswith("."):
            return None
        for item in self.list_backups():
            if item["name"] == name:
                return str(item["path"])
        return None

    def backup_preview(self, path: Path | str, limit: int = 300) -> Dict[str, Any]:
        p = str(path or "")
        if not p:
            return {"ok": False, "error": "backup not found", "items": []}
        script = f"set -efu\nsha=$(sha256sum {shlex.quote(p)} 2>/dev/null | awk '{{print $1}}' || true)\nif tar -tzf {shlex.quote(p)} >/tmp/awgui_tarlist.$$ 2>/dev/null; then head -n {int(limit)} /tmp/awgui_tarlist.$$; rm -f /tmp/awgui_tarlist.$$; echo __SHA256__$sha; exit 0; fi\nif command -v unzip >/dev/null 2>&1 && unzip -Z1 {shlex.quote(p)} >/tmp/awgui_ziplist.$$ 2>/dev/null; then head -n {int(limit)} /tmp/awgui_ziplist.$$; rm -f /tmp/awgui_ziplist.$$; echo __SHA256__$sha; exit 0; fi\necho __SHA256__$sha; exit 2"
        r = self.shell(script, timeout=45, save_last=False)
        lines = str(r.get("stdout") or "").splitlines()
        sha = ""
        items = []
        for line in lines:
            if line.startswith("__SHA256__"):
                sha = line.replace("__SHA256__", "", 1).strip()
            elif line.strip():
                items.append({"name": line.strip(), "size": 0, "size_h": "", "type": "file"})
        return {"ok": bool(items) or bool(sha), "name": Path(p).name, "path": p, "format": "remote", "items": items, "truncated": len(items) >= limit, "sha256": sha, "error": "" if r.get("ok") else str(r.get("stderr") or "")[:300]}

    def backup_bytes(self, name: str, limit: int = 1024 * 1024 * 1024) -> Tuple[Optional[str], Optional[bytes]]:
        path = self.find_backup(name)
        if not path:
            return None, None
        cmd = self._ssh() + [f"head -c {int(limit)} {shlex.quote(path)}"]
        try:
            proc = subprocess.run(cmd, capture_output=True, timeout=120)
            if proc.returncode != 0:
                return None, None
            return Path(path).name, proc.stdout
        except Exception:
            return None, None

    def systemctl_state(self, service: str) -> Dict[str, Any]:
        script = f"systemctl is-active {shlex.quote(service)} 2>/dev/null; systemctl is-enabled {shlex.quote(service)} 2>/dev/null || true"
        r = self.shell(script, timeout=12, save_last=False)
        lines = str(r.get("stdout") or "").splitlines()
        return {"service": service, "available": True, "active": lines[0] if lines else "unknown", "enabled": lines[1] if len(lines)>1 else "unknown", "active_ok": bool(lines and lines[0] == "active"), "enabled_ok": bool(len(lines)>1 and lines[1] == "enabled")}

    def systemd_execstart(self, service: str = "awgui.service") -> str:
        return "remote ssh adapter: no AWGUI systemd on managed node"

    def doctor(self) -> Dict[str, Any]:
        d = super().doctor()
        d["remote"] = {"host": self.host, "user": self.user, "port": self.port, "mode": "ssh"}
        d["checks"].insert(1, {"name": "SSH transport", "ok": bool(self.host) and (shutil.which(config.SSH_BIN) is not None or Path(config.SSH_BIN).exists()), "detail": f"{self.user}@{self.host}:{self.port}"})
        return d


def default_adapter() -> ManageAdapter:
    return ManageAdapter()


def adapter_for_server(server: Optional[Dict[str, Any]]) -> ManageAdapter:
    if not server or server.get("mode") == "local":
        return ManageAdapter(server.get("manage_path", config.MANAGE) if server else config.MANAGE, server.get("awg_dir", config.AWG_DIR) if server else config.AWG_DIR, server.get("server_conf", config.SERVER_CONF) if server else config.SERVER_CONF)
    if server.get("mode") == "ssh":
        return SSHManageAdapter(server)
    raise ValueError("unsupported server mode")

def error_svg(title: str, subtitle: str = "") -> str:
    def esc(x: str) -> str:
        return str(x or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="360" height="360" viewBox="0 0 360 360">
  <rect width="360" height="360" rx="26" fill="#f7f7f2"/>
  <rect x="28" y="28" width="304" height="304" rx="20" fill="#ffffff" stroke="#d9d7cc"/>
  <text x="180" y="158" text-anchor="middle" font-family="Arial" font-size="19" font-weight="700" fill="#9f1239">{esc(title)}</text>
  <text x="180" y="192" text-anchor="middle" font-family="Arial" font-size="13" fill="#57534e">{esc(subtitle)[:120]}</text>
  <text x="180" y="236" text-anchor="middle" font-family="Arial" font-size="12" fill="#78716c">AWGUI v8.8.0</text>
</svg>'''
