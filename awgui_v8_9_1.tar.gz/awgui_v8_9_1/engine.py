from __future__ import annotations

import io
import json
import os
import shlex
import shutil
import stat
import tarfile
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import config
import manage_adapter

VENDOR_ROOT = config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME
MANIFEST = VENDOR_ROOT / "MANIFEST.json"
MANIFEST_SHA256 = VENDOR_ROOT / "MANIFEST.sha256"
REMOTE_ROOT = config.ENGINE_REMOTE_ROOT
REMOTE_DIR = f"{REMOTE_ROOT}/{config.ENGINE_VERSION}"

REQUIRED_FILES = [
    "install_amneziawg.sh",
    "manage_amneziawg.sh",
    "awg_common.sh",
    "awgui_engine_apply.sh",
    "awg-routing.sh",
    "cascade/README.md",
    "cascade/ru.zone",
    "CASCADE.md",
    "ADVANCED.md",
    "README.upstream.md",
    "LICENSE.upstream",
    "MANIFEST.json",
    "MANIFEST.sha256",
]

EXECUTABLE_FILES = {
    "install_amneziawg.sh",
    "manage_amneziawg.sh",
    "awg_common.sh",
    "awgui_engine_apply.sh",
    "awg-routing.sh",
}

MANAGE_MARKERS = [
    "SCRIPT_VERSION=\"5.18.4\"",
    "add)",
    "remove)",
    "list)",
    "stats)",
    "regen)",
    "backup)",
    "restore)",
    "check|status)",
    "diagnose)",
]


def sha256(path: Path) -> str:
    import hashlib

    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _file_mode(path: Path) -> int:
    try:
        return path.stat().st_mode
    except Exception:
        return 0


def _is_executable(path: Path) -> bool:
    if os.name == "nt":
        return path.suffix == ".sh"
    return bool(_file_mode(path) & stat.S_IXUSR)


def load_manifest() -> Dict[str, Any]:
    try:
        data = json.loads(MANIFEST.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {"ok": False, "error": "manifest is not an object"}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def _manifest_files(manifest: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    files = manifest.get("files") or []
    if isinstance(files, list):
        for item in files:
            if isinstance(item, dict) and item.get("path"):
                out[str(item["path"])] = item
    return out


def _read_sha_file() -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        for raw in MANIFEST_SHA256.read_text(encoding="utf-8").splitlines():
            parts = raw.strip().split(None, 1)
            if len(parts) == 2 and len(parts[0]) == 64:
                out[parts[1].lstrip("*")] = parts[0]
    except Exception:
        pass
    return out


def verify_bundled_engine() -> Dict[str, Any]:
    manifest = load_manifest()
    manifest_files = _manifest_files(manifest)
    sha_file = _read_sha_file()
    files: List[Dict[str, Any]] = []
    errors: List[str] = []
    warnings: List[str] = []

    if manifest.get("engine_name") != config.ENGINE_VENDOR_NAME:
        errors.append("manifest engine_name mismatch")
    if manifest.get("upstream_version") != config.ENGINE_UPSTREAM_VERSION:
        errors.append("manifest upstream_version mismatch")
    if manifest.get("awgui_engine_version") != config.ENGINE_VERSION:
        errors.append("manifest awgui_engine_version mismatch")
    if manifest.get("mode") != config.ENGINE_MODE:
        errors.append("manifest mode is not full-offline-engine")

    for rel in REQUIRED_FILES:
        p = VENDOR_ROOT / rel
        present = p.is_file()
        actual_sha = sha256(p) if present else ""
        size = p.stat().st_size if present else 0
        expected = manifest_files.get(rel, {})
        expected_sha = str(expected.get("sha256") or "")
        expected_bytes = int(expected.get("bytes") or 0)
        item = {
            "path": rel,
            "present": present,
            "size": size,
            "bytes": size,
            "sha256": actual_sha,
            "expected_sha256": expected_sha,
            "manifest": bool(expected),
            "executable": _is_executable(p) if present and rel in EXECUTABLE_FILES else None,
        }
        if not present:
            errors.append(f"missing required file: {rel}")
        elif expected_sha and expected_sha != actual_sha:
            errors.append(f"sha256 mismatch: {rel}")
        elif rel in sha_file and sha_file[rel] != actual_sha:
            errors.append(f"MANIFEST.sha256 mismatch: {rel}")
        if present and expected_bytes and expected_bytes != size:
            errors.append(f"byte size mismatch: {rel}")
        if present and rel in EXECUTABLE_FILES and not _is_executable(p):
            errors.append(f"not executable: {rel}")
        files.append(item)

    ru = VENDOR_ROOT / "cascade" / "ru.zone"
    ru_lines = 0
    if ru.is_file():
        ru_lines = len(ru.read_text(encoding="utf-8", errors="replace").splitlines())
        if ru.stat().st_size == 0 or ru_lines == 0:
            errors.append("cascade/ru.zone is empty")

    manage = VENDOR_ROOT / "manage_amneziawg.sh"
    missing_markers: List[str] = []
    if manage.is_file():
        text = manage.read_text(encoding="utf-8", errors="replace")
        missing_markers = [m for m in MANAGE_MARKERS if m not in text]
        if missing_markers:
            errors.append("manage_amneziawg.sh markers missing")

    declared = set(manifest_files)
    required_payload = set(REQUIRED_FILES) - {"MANIFEST.json", "MANIFEST.sha256"}
    extra_declared = sorted(declared - required_payload)
    if extra_declared:
        warnings.append("manifest declares extra files: " + ", ".join(extra_declared[:8]))

    ok = not errors
    return {
        "ok": ok,
        "offline_ready": ok,
        "core_offline_ready": ok and all((VENDOR_ROOT / rel).is_file() for rel in ("install_amneziawg.sh", "manage_amneziawg.sh", "awg_common.sh")),
        "cascade_offline_ready": ok and ru.is_file(),
        "cascade_ru_zone_lines": ru_lines,
        "mode": config.ENGINE_MODE,
        "engine_version": config.ENGINE_VERSION,
        "upstream_version": config.ENGINE_UPSTREAM_VERSION,
        "vendor_name": config.ENGINE_VENDOR_NAME,
        "vendor_root": str(VENDOR_ROOT),
        "remote_dir": REMOTE_DIR,
        "manifest": manifest,
        "files": files,
        "errors": errors,
        "warnings": warnings,
        "missing_markers": missing_markers,
        "note": "Full offline engine: install/manage/common/cascade are bundled and normal deploy/apply/provisioner paths do not download upstream scripts from GitHub.",
    }


def _tar_vendor_bytes() -> bytes:
    bio = io.BytesIO()
    with tarfile.open(fileobj=bio, mode="w:gz") as t:
        for p in VENDOR_ROOT.rglob("*"):
            if p.is_file():
                info = t.gettarinfo(str(p), arcname=str(Path(config.ENGINE_VERSION) / p.relative_to(VENDOR_ROOT)))
                if p.name.endswith(".sh"):
                    info.mode = 0o700
                elif p.name in {"MANIFEST.json", "MANIFEST.sha256"}:
                    info.mode = 0o600
                else:
                    info.mode = 0o600
                with p.open("rb") as f:
                    t.addfile(info, f)
    return bio.getvalue()


def _server_id_for_adapter(adapter: manage_adapter.ManageAdapter) -> str:
    return getattr(adapter, "server_id", "") or ("ssh" if isinstance(adapter, manage_adapter.SSHManageAdapter) else config.SERVER_ID)


def _adapter_for(server_or_adapter: Any) -> manage_adapter.ManageAdapter:
    if isinstance(server_or_adapter, manage_adapter.ManageAdapter):
        return server_or_adapter
    import store

    srv = store.get_server(str(server_or_adapter))
    if not srv:
        raise ValueError("server not found")
    return manage_adapter.adapter_for_server(srv)


def deploy_engine(server_or_adapter: Any, timeout: int = 120) -> Dict[str, Any]:
    adapter = _adapter_for(server_or_adapter)
    ver = verify_bundled_engine()
    if not ver.get("ok"):
        return manage_adapter.make_result(["awgui-engine", "verify"], 2, "", "bundled engine incomplete: " + "; ".join(ver.get("errors") or []))
    started = time.time()
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        tar_bytes = _tar_vendor_bytes()
        script = f"""
set -Eeuo pipefail
install -d -m 700 {shlex.quote(REMOTE_ROOT)} /root/awg
tar -xzf - -C {shlex.quote(REMOTE_ROOT)}
find {shlex.quote(REMOTE_DIR)} -type f -name '*.sh' -exec chmod 700 {{}} +
find {shlex.quote(REMOTE_DIR)} -type f ! -name '*.sh' -exec chmod 600 {{}} +
printf '%s\\n' {shlex.quote(config.ENGINE_VERSION)} > /root/awg/.awgui-engine-version
printf 'AWGUI engine deployed: %s\\n' {shlex.quote(config.ENGINE_VERSION)}
""".strip()
        result = adapter.stream_stdin(script, tar_bytes, timeout=timeout, label="awgui-engine-deploy")
        result["manifest_sha256"] = sha256(MANIFEST)
        return result
    try:
        target = Path(REMOTE_DIR)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(VENDOR_ROOT, target)
        for sh in target.rglob("*.sh"):
            sh.chmod(0o700)
        Path("/root/awg").mkdir(parents=True, exist_ok=True)
        Path("/root/awg/.awgui-engine-version").write_text(config.ENGINE_VERSION + "\n", encoding="utf-8")
        return manage_adapter.make_result(["awgui-engine", "deploy", str(target)], 0, f"AWGUI engine deployed: {config.ENGINE_VERSION}", "", started)
    except Exception as exc:
        return manage_adapter.make_result(["awgui-engine", "deploy", REMOTE_DIR], 1, "", f"{type(exc).__name__}: {exc}", started)


def _parse_kv(stdout: str) -> Dict[str, str]:
    data: Dict[str, str] = {}
    for line in str(stdout or "").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            data[k.strip()] = v.strip()
    return data


def probe_installed_engine(server_or_adapter: Any) -> Dict[str, Any]:
    adapter = _adapter_for(server_or_adapter)
    bundled = verify_bundled_engine()
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        script = f"""
set -u
printf 'installed_marker=%s\\n' "$(cat /root/awg/.awgui-engine-version 2>/dev/null || true)"
printf 'current_json=%s\\n' "$(cat /root/awg/.awgui-engine/current.json 2>/dev/null | tr '\\n' ' ' || true)"
printf 'engine_dir=%s\\n' "{REMOTE_DIR}"
[ -d {shlex.quote(REMOTE_DIR)} ] && printf 'engine_deployed=1\\n' || printf 'engine_deployed=0\\n'
[ -f /root/awg/manage_amneziawg.sh ] && printf 'manage_present=1\\n' || printf 'manage_present=0\\n'
[ -f /root/awg/awg_common.sh ] && printf 'common_present=1\\n' || printf 'common_present=0\\n'
[ -f /root/awg/manage_amneziawg.sh ] && printf 'manage_sha256=%s\\n' "$(sha256sum /root/awg/manage_amneziawg.sh 2>/dev/null | awk '{{print $1}}')" || true
[ -f /root/awg/awg_common.sh ] && printf 'common_sha256=%s\\n' "$(sha256sum /root/awg/awg_common.sh 2>/dev/null | awk '{{print $1}}')" || true
""".strip()
        raw = adapter.shell(script, timeout=30, save_last=False)
        data = _parse_kv(raw.get("stdout") or "")
    else:
        data = {
            "installed_marker": "",
            "current_json": "",
            "engine_dir": REMOTE_DIR,
            "engine_deployed": "1" if Path(REMOTE_DIR).is_dir() else "0",
            "manage_present": "1" if Path(adapter.manage).is_file() else "0",
            "common_present": "1" if (Path(adapter.awg_dir) / "awg_common.sh").is_file() else "0",
        }
        for key, path in (("manage_sha256", Path(adapter.manage)), ("common_sha256", Path(adapter.awg_dir) / "awg_common.sh")):
            try:
                data[key] = sha256(path)
            except Exception:
                data[key] = ""
        raw = manage_adapter.make_result(["awgui-engine", "probe"], 0, "\n".join(f"{k}={v}" for k, v in data.items()))
    manifest = _manifest_files(bundled.get("manifest") or {})
    expected_manage = str((manifest.get("manage_amneziawg.sh") or {}).get("sha256") or "")
    expected_common = str((manifest.get("awg_common.sh") or {}).get("sha256") or "")
    if data.get("manage_present") != "1":
        status = "missing"
    elif data.get("manage_sha256") == expected_manage and data.get("common_sha256") == expected_common:
        status = "matching"
    elif data.get("installed_marker") == config.ENGINE_VERSION:
        status = "drift"
    elif data.get("installed_marker"):
        status = "upgrade_available"
    else:
        status = "unknown"
    return {"ok": bool(raw.get("ok")), "status": status, "data": data, "raw": raw, "bundled": bundled}


def apply_engine(server_or_adapter: Any, timeout: int = 300) -> Dict[str, Any]:
    adapter = _adapter_for(server_or_adapter)
    deployed = deploy_engine(adapter)
    if not deployed.get("ok"):
        return deployed
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        return adapter.shell(f"bash {shlex.quote(REMOTE_DIR + '/awgui_engine_apply.sh')}", timeout=timeout)
    try:
        p = Path(REMOTE_DIR) / "awgui_engine_apply.sh"
        if not p.exists():
            return manage_adapter.make_result(["bash", str(p)], 127, "", "engine apply script not found")
        import subprocess

        proc = subprocess.run(["bash", str(p)], text=True, capture_output=True, timeout=timeout)
        return manage_adapter.make_result(["bash", str(p)], proc.returncode, proc.stdout.strip(), proc.stderr.strip())
    except Exception as exc:
        return manage_adapter.make_result(["awgui-engine", "apply"], 1, "", f"{type(exc).__name__}: {exc}")


def server_engine_status(adapter: manage_adapter.ManageAdapter) -> Dict[str, Any]:
    probe = probe_installed_engine(adapter)
    return {
        "ok": probe.get("ok"),
        "server": "ssh" if isinstance(adapter, manage_adapter.SSHManageAdapter) else "local",
        "status": probe.get("status"),
        "data": probe.get("data", {}),
        "raw": probe.get("raw", {}),
        "bundled": probe.get("bundled", verify_bundled_engine()),
    }


def deploy_bundled_engine(adapter: manage_adapter.ManageAdapter, timeout: int = 120) -> Dict[str, Any]:
    return deploy_engine(adapter, timeout=timeout)


def apply_bundled_engine(adapter: manage_adapter.ManageAdapter, timeout: int = 300) -> Dict[str, Any]:
    return apply_engine(adapter, timeout=timeout)
