#!/usr/bin/env bash
set -Eeuo pipefail
# Fallback only. Preferred path: AWGUI /bot page.
read -rp "Telegram bot token: " TOKEN
read -rp "Admin chat_id: " ADMIN
sudo install -d -m 700 /etc
sudo tee /etc/awgui.env >/dev/null <<EOF
AWGUI_TG_BOT_TOKEN="${TOKEN}"
AWGUI_TG_ADMIN_IDS="${ADMIN}"
AWGUI_TG_SEND_BACKUP="1"
AWGUI_TG_ALLOW_DANGEROUS="0"
EOF
sudo chmod 600 /etc/awgui.env
sudo systemctl restart awgui awgui-bot
