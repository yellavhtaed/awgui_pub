# Changelog

## v8.1.0

- Added light/dark/system theme switcher with proper dark palette, not inverted colors.
- Added UI language selector: English, Russian, Ukrainian, Belarusian.
- Added `i18n.py` with compact dictionary-based translation layer.
- Added Traffic page backed by local SQLite snapshots from upstream `stats --json`.
- Added RX/TX delta view between latest traffic snapshots.
- Added Expiry page for temporary-client workflow through upstream `--expires`.
- Added `server_id` to audit and traffic storage as a future multi-server foundation.
- Added DB migration helpers for existing v8 SQLite databases.
- Removed “Update center” from roadmap/scope; diagnostics keeps only the narrow drift checks needed for real deployment mistakes.
- Updated README with v8.1 install, feature list, multi-server direction and obfuscation direction.
- Strengthened selftest and release gate for dark theme, i18n, traffic and expiry pages.

## v8.0.0

- Rebuilt the project around `manage_adapter.py` as the only path to `manage_amneziawg.sh`.
- Added upstream compatibility scanner for commands/options/carrier support.
- Added lifecycle-first client UI with temporary clients and PSK support.
- Added client bundle zip.
- Added backup center with archive preview and SHA256.
- Added focused diagnostics page.
- Added SQLite audit log for web and Telegram actions.
- Reworked Telegram into inline cockpit with guarded destructive actions.
- Reworked visual design: calmer palette, compact cards, less neon.
- Added release gate to prevent old `/bot` CLI-first text and old version labels from shipping again.
- Added upgrade health check that verifies the actually running app reports v8.0.0.
