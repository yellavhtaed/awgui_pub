# AWGUI v8.1.0 Operator Core

Personal web + Telegram control layer for AmneziaWG installed by `bivlked/amneziawg-installer`.

AWGUI is not a replacement for the parent installer. The parent script `/root/awg/manage_amneziawg.sh` remains the source of truth. AWGUI calls it through one adapter and adds only the operational layer: clients, temporary clients, QR/config delivery, traffic snapshots, backups, diagnostics, audit, Telegram cockpit, theme/language UI.

## Philosophy

```text
Flask UI / Telegram bot
        ↓
manage_adapter.py
        ↓
/root/awg/manage_amneziawg.sh
        ↓
AmneziaWG config, clients, backup, restore, diagnose
```

Rules:

- no own key generation;
- no own restore engine;
- no arbitrary full `awg0.conf` editor;
- no Prometheus/Grafana/Docker/React stack;
- no multi-server agent yet;
- SQLite only stores AWGUI audit/history, not private VPN state.

## Default access

Open locally:

```text
http://127.0.0.1:8080
```

Default login:

```text
admin
```

Default password:

```text
devpass
```

Change credentials in `/etc/awgui.env`:

```bash
sudo tee /etc/awgui.env >/dev/null <<'ENV'
AWGUI_USER="admin"
AWGUI_PASSWORD="your-strong-password"
AWGUI_SECRET="replace-with-random-long-secret"

AWGUI_SERVER_ID="local"
AWGUI_SERVER_NAME="Local AWG"

AWGUI_MANAGE="/root/awg/manage_amneziawg.sh"
AWGUI_AWG_DIR="/root/awg"
AWGUI_SERVER_CONF="/etc/amnezia/amneziawg/awg0.conf"
ENV
sudo chmod 600 /etc/awgui.env
sudo systemctl restart awgui
```

## Install / upgrade

Copy the archive to the server, then run from the directory where the archive really exists:

```bash
cd ~
sudo systemctl stop awgui awgui-bot 2>/dev/null || true
rm -rf ~/awgui
mkdir -p ~/awgui
tar -xzf ./awgui_v8_1_0.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui
sudo ./upgrade.sh
```

If the archive is in `~/Downloads`:

```bash
tar -xzf ~/Downloads/awgui_v8_1_0.tar.gz -C ~/awgui --strip-components=1
```

Check:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected:

```json
{"app":"AWGUI","ok":true,"version":"8.1.0"}
```

## Telegram

Open:

```text
http://127.0.0.1:8080/bot
```

Paste token and admin chat_id, enable bot, then press **Save & apply**.

Bot commands:

```text
/id
/menu
/status
/clients
/client NAME
/add NAME [7d] [psk]
/backup
/diagnose [carrier]
```

Dangerous Telegram actions are disabled by default. Enable them only for a private bot and trusted chat_id.

## v8.1 functionality

Implemented:

- one `ManageAdapter` gateway to the parent script;
- upstream compatibility scanner;
- lifecycle-first clients page;
- temporary client creation through upstream `--expires`;
- PSK through upstream `--psk`;
- dedicated Expiry page for temporary-client workflow;
- client QR/conf/vpnuri/bundle delivery;
- traffic snapshots via local SQLite using upstream `stats --json`;
- Traffic page with latest RX/TX values and deltas between snapshots;
- backup center with preview/checksum/restore;
- focused diagnostics page tied to real parent capabilities;
- SQLite audit log with `server_id` foundation for future multi-server;
- Telegram inline cockpit with guarded destructive actions;
- light/dark/system UI theme;
- language selector: English, Russian, Ukrainian, Belarusian;
- release gate against old v5/v6 UI regression and missing v8.1 features;
- systemd upgrade that verifies `/health` reports the installed version.

## Multi-server direction

v8.1 is still local-only by design. It already stores `server_id` in audit and traffic history so the model can evolve without rewriting the database.

The intended future multi-server model is SSH-based:

```text
AWGUI panel
  local adapter
  ssh adapter
    server_id
    host
    user
    key
    manage_path
```

No agents, no Docker, no cluster layer.

## Obfuscation direction

Carrier/profile diagnostics should remain controlled and explicit:

```text
backup → show current Jc/Jmin/Jmax/I* → proposed diff → apply → restart → diagnose again
```

Randomization of `Jc`, `Jmin`, `Jmax`, `I1...` must not be blind. It belongs after multi-server foundation and after a safe diff/rollback path is in place.
