#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui_v8_1_gate_"))
os.environ["AWGUI_MANAGE"] = str(ROOT / "scripts" / "fake_manage_amneziawg.sh")
os.environ["AWGUI_AWG_DIR"] = str(TMP / "awg")
os.environ["AWGUI_SERVER_CONF"] = str(TMP / "etc" / "awg0.conf")
os.environ["AWGUI_STATE_DIR"] = str(TMP / "state")
os.environ["AWGUI_ENV_FILE"] = str(TMP / "awgui.env")
os.environ["AWGUI_SECRET"] = "test-secret"

import config  # noqa: E402
assert config.APP_VERSION == "8.1.0", config.APP_VERSION
for rel in (ROOT / "templates").glob("*.html"):
    text = rel.read_text(encoding="utf-8")
    forbidden = [
        "На сервере запусти cd ~/awgui",
        "AmneziaWG Control · v5.0.0",
        "v5.0.0",
        "Mode\nlocalhost only",
        "Update center",
    ]
    for bad in forbidden:
        if bad in text:
            raise SystemExit(f"forbidden legacy text in {rel.name}: {bad}")
required = [
    "manage_adapter.py", "store.py", "i18n.py", "telegram_bot.py",
    "templates/bot.html", "templates/diagnostics.html", "templates/traffic.html", "templates/expiry.html",
]
for item in required:
    if not (ROOT / item).exists():
        raise SystemExit(f"missing {item}")
css = (ROOT / "static" / "style.css").read_text(encoding="utf-8")
for needle in ('data-theme="dark"', 'prefers-color-scheme: dark'):
    if needle not in css:
        raise SystemExit(f"missing dark theme marker: {needle}")
i18n_text = (ROOT / "i18n.py").read_text(encoding="utf-8")
for lang in ('"en"', '"ru"', '"uk"', '"be"'):
    if lang not in i18n_text:
        raise SystemExit(f"missing language {lang}")
print("AWGUI v8.1 release gate OK")
