# AWGUI v8.1.0 release checks

Executed on fresh unpacked package:

```bash
python3 -m py_compile app.py config.py manage_adapter.py parse.py store.py i18n.py telegram_bot.py scripts/selftest.py scripts/verify_release.py
bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh scripts/fake_manage_amneziawg.sh
python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
```

Runtime smoke with fake `manage_amneziawg.sh`:

```text
/health       200, version 8.1.0
/login        302
/             200
/clients      200
/traffic      200
/expiry       200
/backups      200
/diagnostics  200
/audit        200
/bot          200
/logs         200
/api/version  200
/api/summary  200
```

Release gate blocks:

- old `/bot` CLI-first text;
- old `v5.0.0` UI label;
- accidental “Update center” scope creep;
- missing `manage_adapter.py`;
- missing `i18n.py`;
- missing Traffic/Expiry pages;
- missing dark theme markers;
- missing language set: en/ru/uk/be.
