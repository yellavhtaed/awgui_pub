from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

import config


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def conn() -> sqlite3.Connection:
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def _has_column(c: sqlite3.Connection, table: str, column: str) -> bool:
    rows = c.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r["name"] == column for r in rows)


def _ensure_column(c: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    if not _has_column(c, table, column):
        c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def init_db() -> None:
    with conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS audit (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              server_id TEXT NOT NULL DEFAULT 'local',
              source TEXT NOT NULL,
              actor TEXT NOT NULL,
              action TEXT NOT NULL,
              target TEXT NOT NULL DEFAULT '',
              ok INTEGER NOT NULL,
              rc INTEGER NOT NULL DEFAULT 0,
              duration REAL NOT NULL DEFAULT 0,
              cmd TEXT NOT NULL DEFAULT '',
              text TEXT NOT NULL DEFAULT ''
            )
            """
        )
        _ensure_column(c, "audit", "server_id", "TEXT NOT NULL DEFAULT 'local'")
        c.execute("CREATE INDEX IF NOT EXISTS idx_audit_server_ts ON audit(server_id, ts DESC)")
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS traffic_snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              server_id TEXT NOT NULL DEFAULT 'local',
              client TEXT NOT NULL,
              rx INTEGER,
              tx INTEGER,
              handshake TEXT,
              status TEXT,
              raw TEXT NOT NULL DEFAULT ''
            )
            """
        )
        _ensure_column(c, "traffic_snapshots", "server_id", "TEXT NOT NULL DEFAULT 'local'")
        c.execute("CREATE INDEX IF NOT EXISTS idx_traffic_server_client_ts ON traffic_snapshots(server_id, client, ts DESC)")
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )


def audit(source: str, actor: str, action: str, target: str, result: Dict[str, Any], server_id: Optional[str] = None) -> None:
    init_db()
    text = (result.get("text") or result.get("stderr") or result.get("stdout") or "")
    if len(text) > 6000:
        text = text[:6000] + "\n--- cut ---"
    with conn() as c:
        c.execute(
            """
            INSERT INTO audit(ts, server_id, source, actor, action, target, ok, rc, duration, cmd, text)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                now(), server_id or config.SERVER_ID, source or "web", actor or "admin", action or "unknown", target or "",
                1 if result.get("ok") else 0, int(result.get("rc") or 0), float(result.get("duration") or 0),
                str(result.get("cmd") or ""), str(text or ""),
            ),
        )


def list_audit(limit: int = 120, server_id: Optional[str] = None) -> List[Dict[str, Any]]:
    init_db()
    limit = max(1, min(int(limit or 120), 500))
    sid = server_id or config.SERVER_ID
    with conn() as c:
        rows = c.execute("SELECT * FROM audit WHERE server_id=? ORDER BY id DESC LIMIT ?", (sid, limit)).fetchall()
    return [dict(r) for r in rows]


def set_setting(key: str, value: Any) -> None:
    init_db()
    with conn() as c:
        c.execute(
            "INSERT INTO settings(key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, json.dumps(value, ensure_ascii=False), now()),
        )


def get_setting(key: str, default: Any = None) -> Any:
    init_db()
    with conn() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["value"])
    except Exception:
        return row["value"]


def _to_int(value: Any) -> Optional[int]:
    if value in (None, "", "-"):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip().lower().replace(",", ".")
    parts = text.split()
    try:
        n = float(parts[0])
    except Exception:
        digits = "".join(ch for ch in text if ch.isdigit())
        return int(digits) if digits else None
    unit = parts[1] if len(parts) > 1 else "b"
    mult = 1
    if unit.startswith("k"):
        mult = 1024
    elif unit.startswith("m"):
        mult = 1024 ** 2
    elif unit.startswith("g"):
        mult = 1024 ** 3
    elif unit.startswith("t"):
        mult = 1024 ** 4
    return int(n * mult)


def record_stats_snapshot(clients: Iterable[Dict[str, Any]], server_id: Optional[str] = None) -> int:
    init_db()
    ts = now()
    sid = server_id or config.SERVER_ID
    count = 0
    with conn() as c:
        for item in clients:
            if not isinstance(item, dict):
                continue
            name = item.get("name") or item.get("client") or item.get("client_name") or item.get("Name")
            if not name:
                continue
            rx = _to_int(item.get("rx") or item.get("received") or item.get("transfer_rx"))
            tx = _to_int(item.get("tx") or item.get("sent") or item.get("transfer_tx"))
            handshake = str(item.get("latest_handshake") or item.get("last_handshake") or item.get("handshake") or "")
            status = str(item.get("status") or item.get("state") or "")
            c.execute(
                "INSERT INTO traffic_snapshots(ts, server_id, client, rx, tx, handshake, status, raw) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (ts, sid, str(name), rx, tx, handshake, status, json.dumps(item, ensure_ascii=False)),
            )
            count += 1
    return count


def latest_traffic(limit: int = 80, client: Optional[str] = None, server_id: Optional[str] = None) -> List[Dict[str, Any]]:
    init_db()
    sid = server_id or config.SERVER_ID
    limit = max(1, min(int(limit or 80), 500))
    with conn() as c:
        if client:
            rows = c.execute("SELECT * FROM traffic_snapshots WHERE server_id=? AND client=? ORDER BY id DESC LIMIT ?", (sid, client, limit)).fetchall()
        else:
            rows = c.execute("SELECT * FROM traffic_snapshots WHERE server_id=? ORDER BY id DESC LIMIT ?", (sid, limit)).fetchall()
    return [dict(r) for r in rows]


def traffic_overview(server_id: Optional[str] = None, limit_clients: int = 200) -> List[Dict[str, Any]]:
    """Latest + previous snapshot per client, with simple byte deltas."""
    init_db()
    sid = server_id or config.SERVER_ID
    with conn() as c:
        rows = c.execute(
            "SELECT * FROM traffic_snapshots WHERE server_id=? ORDER BY client ASC, id DESC LIMIT ?",
            (sid, max(20, min(limit_clients * 3, 1000))),
        ).fetchall()
    by_client: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        item = dict(r)
        by_client.setdefault(item["client"], []).append(item)
    out: List[Dict[str, Any]] = []
    for client, items in by_client.items():
        latest = items[0]
        prev = items[1] if len(items) > 1 else None
        rx_delta = None if prev is None or latest.get("rx") is None or prev.get("rx") is None else max(0, int(latest["rx"]) - int(prev["rx"]))
        tx_delta = None if prev is None or latest.get("tx") is None or prev.get("tx") is None else max(0, int(latest["tx"]) - int(prev["tx"]))
        out.append({"client": client, "latest": latest, "previous": prev, "rx_delta": rx_delta, "tx_delta": tx_delta})
    out.sort(key=lambda x: ((x.get("rx_delta") or 0) + (x.get("tx_delta") or 0)), reverse=True)
    return out[:limit_clients]
