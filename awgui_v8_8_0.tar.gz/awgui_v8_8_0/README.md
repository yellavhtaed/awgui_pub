# AWGUI v8.8.0

AWGUI is an autonomous web/Telegram/SSH control-plane for personal AmneziaWG servers.

The project ships a vendored AWG engine based on `bivlked/amneziawg-installer v5.18.4` and uses it as a pinned offline runtime base. Python is the control-plane; bundled shell scripts remain responsible for low-level installer/manager work: DKMS, apt, firewall, sysctl, UFW, Fail2Ban, kernel headers, routing and parent-script logic.

## Philosophy

- KISS / Unix-way.
- No Docker, no agents, no frontend framework, no Paramiko, no sshpass.
- Web and Telegram are two interfaces to the same action layer.
- Runtime bootstrap/apply does not download core scripts from GitHub.
- Destructive operations require explicit confirmation and audit.
- Fake apply buttons are forbidden: unsupported features are shown as read-only/unavailable.

## What v8.8.0 changes

- Extends `actions.py` as the shared web/Telegram action core.
- Moves Telegram transport helpers into `telegram_client.py`.
- Moves web service/systemd helpers into `web_support.py`.
- Converts more web and bot operations to the shared action layer.
- Cleans vendored installer patch: the duplicate runtime-download `step5_download_scripts()` is removed; the offline bundled step remains.
- Improves `/obfuscation` from a placeholder into a real read-only inspection page:
  - reads `Jc/Jmin/Jmax`, `S1-S4`, `H1-H4`, `I1-I5`;
  - shows each parameter source;
  - shows last known `AWG_PRESET` if present;
  - shows upstream profile hints;
  - shows compatibility guard;
  - shows the future safe apply plan without enabling destructive mutation.

## Install / upgrade

```bash
cd ~

sudo systemctl stop awgui awgui-bot 2>/dev/null || true

rm -rf ~/awgui
mkdir -p ~/awgui

tar -xzf ~/Downloads/awgui_v8_8_0.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui

sudo ./upgrade.sh
```

Check:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected:

```json
{"app":"AWGUI","engine":"5.18.4-awgui1","ok":true,"version":"8.8.0"}
```

Open:

```text
http://127.0.0.1:8080
```

Default login:

```text
admin / devpass
```

## SSH servers

AWGUI does not store SSH passwords. It uses OpenSSH keys, ssh-agent or `~/.ssh/config`.

Recommended dedicated key:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
chmod 700 ~/.ssh
chmod 600 ~/.ssh/awgui_ed25519
chmod 644 ~/.ssh/awgui_ed25519.pub
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP \
  'bash /root/awg/manage_amneziawg.sh --no-color --json list'
```

## Key pages

- `/clients` — clients, QR, conf, vpnuri, bundle, regen/remove/modify.
- `/servers` — local/SSH server registry.
- `/engine` — bundled engine verify/deploy/apply.
- `/provisioner` — Ubuntu 24.04 LTS bootstrap through bundled engine.
- `/cascade` — cascade diagnostics and safe bundled `ru.zone` install.
- `/obfuscation` — read-only AWG 2.0 parameter inspection and apply-readiness.
- `/traffic` — SQLite traffic snapshots.
- `/backups` — backup list/preview/download/restore through parent manager.
- `/bot` — Telegram token/chat_id settings.

## Limitations

- Real clean VPS bootstrap was not performed in this sandbox.
- `/obfuscation` is intentionally read-only in v8.8.0.
- Cascade route mutation is intentionally not implemented without a full safe apply workflow.
