#!/usr/bin/env python3
from __future__ import annotations

import tempfile
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import config
import actions
import engine
import manage_adapter
import parse
import store

MAX_MSG = 3900
DOC_THRESHOLD = 3000
ADD_DURATIONS = ["1h", "12h", "1d", "7d", "30d", "4w"]



def tg_server_id(chat_id: Any = None) -> str:
    if chat_id is not None:
        sid = store.get_setting(f"telegram_server:{chat_id}", config.SERVER_ID)
        if store.get_server(str(sid)):
            return str(sid)
    return config.SERVER_ID


def tg_server(chat_id: Any = None) -> Dict[str, Any]:
    return store.get_server(tg_server_id(chat_id)) or store.get_server(config.SERVER_ID) or {"id": config.SERVER_ID, "name": config.SERVER_NAME, "mode": "local"}


def tg_adapter(chat_id: Any = None) -> manage_adapter.ManageAdapter:
    return manage_adapter.adapter_for_server(tg_server(chat_id))


class AdapterProxy:
    def __getattr__(self, name: str):
        # Fallback for legacy command paths before chat_id is known.
        return getattr(tg_adapter(None), name)


adapter = AdapterProxy()
_pending_add: Dict[str, Dict[str, Any]] = {}


from telegram_client import (DOC_THRESHOLD, TelegramError, answer_callback, clip, edit, esc, log, send, send_doc, send_output, send_photo, token)

def is_admin(chat_id: Any) -> bool:
    return str(chat_id) in set(settings().get("admin_ids") or [])


def require_admin(chat_id: Any) -> bool:
    tg = settings()
    if not tg.get("admin_ids"):
        send(chat_id, f"Бот ещё не привязан. Твой chat_id: <code>{esc(chat_id)}</code>\nВставь его в AWGUI → Telegram → Save & apply.")
        return False
    if not is_admin(chat_id):
        send(chat_id, f"Access denied. Твой chat_id: <code>{esc(chat_id)}</code>")
        return False
    return True


def allow_dangerous() -> bool:
    return bool(settings().get("allow_dangerous"))


# Keyboards

def main_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "🟢 Status", "callback_data": "m:status"}, {"text": "👥 Clients", "callback_data": "m:clients:0"}],
        [{"text": "➕ Add client", "callback_data": "m:add"}, {"text": "⏳ Temporary", "callback_data": "m:addtemp"}],
        [{"text": "💾 Backup", "callback_data": "m:backupmenu"}, {"text": "🩺 Diagnostics", "callback_data": "m:diag"}],
        [{"text": "🌐 Servers", "callback_data": "m:servers"}, {"text": "🧭 Cascade", "callback_data": "m:cascade"}],
        [{"text": "Engine", "callback_data": "m:engine"}, {"text": "Obfuscation", "callback_data": "m:obfuscation"}],
        [{"text": "🖥 Server actions", "callback_data": "m:server"}, {"text": "❔ Help", "callback_data": "m:help"}],
    ]}


def add_keyboard(temporary_only: bool = False) -> Dict[str, Any]:
    rows: List[List[Dict[str, str]]] = []
    if not temporary_only:
        rows.append([{"text": "♾ Permanent", "callback_data": "add:perm"}])
    rows += [
        [{"text": "1h", "callback_data": "add:exp:1h"}, {"text": "12h", "callback_data": "add:exp:12h"}, {"text": "1d", "callback_data": "add:exp:1d"}],
        [{"text": "7d", "callback_data": "add:exp:7d"}, {"text": "30d", "callback_data": "add:exp:30d"}, {"text": "4w", "callback_data": "add:exp:4w"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]
    return {"inline_keyboard": rows}


def add_psk_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "PSK off", "callback_data": "addpsk:0"}, {"text": "PSK on", "callback_data": "addpsk:1"}],
        [{"text": "Cancel", "callback_data": "m:main"}],
    ]}



def cascade_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "🧭 Run diagnostics", "callback_data": "m:cascade"}],
        [{"text": "📥 Install bundled ru.zone", "callback_data": "confirm:cascade_ruzone"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}


def engine_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "Probe", "callback_data": "m:engine"}],
        [{"text": "Deploy bundled engine", "callback_data": "engine:deploy"}],
        [{"text": "Apply bundled engine", "callback_data": "confirm:engine_apply"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}


def backup_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "💾 Create backup", "callback_data": "backup:create"}],
        [{"text": "📦 Send latest", "callback_data": "backup:latest"}, {"text": "📋 List", "callback_data": "backup:list"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}



def servers_keyboard(chat_id: Any = None) -> Dict[str, Any]:
    rows: List[List[Dict[str, str]]] = []
    active = tg_server_id(chat_id)
    for s in store.list_servers(include_disabled=False)[:12]:
        icon = "✓" if s.get("id") == active else ""
        mode = "ssh" if s.get("mode") == "ssh" else "local"
        rows.append([{"text": f"{icon} {s.get('name') or s.get('id')} · {mode}", "callback_data": f"srv:{s.get('id')}"}])
    rows.append([{"text": "← main", "callback_data": "m:main"}])
    return {"inline_keyboard": rows}


def send_backup_doc(chat_id: Any, backup_name: str = "") -> bool:
    backups = tg_adapter(chat_id).list_backups()
    if not backups:
        send(chat_id, "No backups found.", backup_keyboard())
        return False
    name = backup_name or backups[0]["name"]
    filename, data = tg_adapter(chat_id).backup_bytes(name)
    if not data:
        send(chat_id, "Backup file not readable.", backup_keyboard())
        return False
    tmp_path: Optional[Path] = None
    try:
        with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name), prefix="awgui_backup_", delete=False) as f:
            f.write(data)
            tmp_path = Path(f.name)
        return send_doc(chat_id, tmp_path, f"latest AWG backup · {tg_server_id(chat_id)}")
    finally:
        if tmp_path:
            try:
                tmp_path.unlink(missing_ok=True)
            except Exception:
                pass

def server_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "📋 show", "callback_data": "m:show"}, {"text": "✅ check", "callback_data": "m:check"}],
        [{"text": "🔄 restart", "callback_data": "confirm:restart"}, {"text": "🛠 repair-module", "callback_data": "confirm:repair"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}


def clients(chat_id: Any = None) -> List[Dict[str, Any]]:
    return actions.action_list_clients(tg_server_id(chat_id), actor=str(chat_id)).get("data", {}).get("clients") or []


def client_by_index(i: str, chat_id: Any = None) -> Tuple[Optional[Dict[str, Any]], str]:
    try:
        idx = int(i)
    except Exception:
        return None, ""
    items = clients(chat_id)
    if idx < 0 or idx >= len(items):
        return None, ""
    return items[idx], parse.name(items[idx])


def clients_keyboard(page: int = 0, per_page: int = 7, chat_id: Any = None) -> Dict[str, Any]:
    items = clients(chat_id)
    page = max(0, int(page or 0))
    start = page * per_page
    rows: List[List[Dict[str, str]]] = []
    for idx, c in enumerate(items[start:start + per_page], start=start):
        name = parse.name(c)
        state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
        icon = "🟢" if state == "ONLINE" else "⚪"
        rows.append([{"text": f"{icon} {name[:38]}", "callback_data": f"ci:{idx}"}])
    nav = []
    if page > 0:
        nav.append({"text": "← prev", "callback_data": f"m:clients:{page-1}"})
    if start + per_page < len(items):
        nav.append({"text": "next →", "callback_data": f"m:clients:{page+1}"})
    if nav:
        rows.append(nav)
    rows.append([{"text": "➕ add", "callback_data": "m:add"}, {"text": "← main", "callback_data": "m:main"}])
    return {"inline_keyboard": rows}


def client_keyboard(idx: int) -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "🧾 QR", "callback_data": f"qr:{idx}"}, {"text": "📄 conf", "callback_data": f"conf:{idx}"}, {"text": "🔗 vpnuri", "callback_data": f"vpn:{idx}"}],
        [{"text": "📦 bundle", "callback_data": f"bundle:{idx}"}, {"text": "♻️ regen", "callback_data": f"confirm:regen:{idx}"}, {"text": "🗑 remove", "callback_data": f"confirm:remove:{idx}"}],
        [{"text": "← clients", "callback_data": "m:clients:0"}, {"text": "main", "callback_data": "m:main"}],
    ]}


def confirm_keyboard(action: str, value: str) -> Dict[str, Any]:
    return {"inline_keyboard": [[
        {"text": f"Confirm {action}", "callback_data": f"do:{action}:{value}"},
        {"text": "Cancel", "callback_data": "m:main"},
    ]]}


# Formatting

def format_main(chat_id: Any = None) -> str:
    srv = tg_server(chat_id)
    status_action = actions.action_status(tg_server_id(chat_id), actor=str(chat_id))
    s = status_action.get("data", {}).get("summary") or {"clients_total": 0, "clients_online": 0}
    st = status_action.get("data", {}).get("status") or {}
    state = "online" if st.get("ok") else "attention needed"
    return (
        f"<b>AWGUI cockpit</b> · <code>{esc(tg_server_id(chat_id))}</code>\n"
        f"Server: <b>{esc(srv.get('name') or srv.get('id') or 'unknown')}</b> · <code>{esc(srv.get('mode') or 'local')}</code>\n"
        f"AWG: <b>{esc(state)}</b>\n"
        f"Clients: <b>{s['clients_total']}</b> total / <b>{s['clients_online']}</b> online\n\n"
        "Выбери действие:"
    )


def format_status(chat_id: Any = None) -> str:
    srv = tg_server(chat_id)
    status_action = actions.action_status(tg_server_id(chat_id), actor=str(chat_id))
    s = status_action.get("data", {}).get("summary") or {"clients_total": 0, "clients_online": 0}
    st = status_action.get("data", {}).get("status") or {}
    return (
        f"<b>Status</b> · AWGUI <code>{esc(config.APP_VERSION)}</code>\n"
        f"Server: <code>{esc(tg_server_id(chat_id))}</code> · {esc(srv.get('name') or srv.get('id') or 'unknown')} · {esc(srv.get('mode') or 'local')}\n"
        f"Clients: <b>{s['clients_total']}</b> total / <b>{s['clients_online']}</b> online\n"
        f"Parent: <b>{'OK' if st.get('ok') else 'FAIL'}</b>\n"
        f"<pre>{esc(clip(st.get('text') or '', 1500))}</pre>"
    )


def format_client(c: Dict[str, Any]) -> str:
    state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
    icon = "🟢" if state == "ONLINE" else "⚪"
    return (
        f"{icon} <b>{esc(parse.name(c))}</b>\n"
        f"IPv4: <code>{esc(parse.ipv4(c))}</code>\n"
        f"IPv6: <code>{esc(parse.ipv6(c))}</code>\n"
        f"Handshake: {esc(parse.handshake(c))}\n"
        f"Status: <b>{esc(state)}</b>"
    )


def help_text() -> str:
    return (
        "<b>AWGUI Telegram cockpit</b>\n"
        "Основной режим — кнопки через <code>/menu</code>.\n\n"
        "Команды остаются как быстрый fallback:\n"
        "<code>/id</code> · показать chat_id\n"
        "<code>/status</code> · статус сервера\n"
        "<code>/clients</code> · список клиентов\n"
        "<code>/add NAME [7d] [psk]</code> · быстрый add\n"
        "<code>/backup</code> · создать backup\n"
        "<code>/diagnose [carrier]</code> · диагностика"
    )


def audit(action: str, target: str, result: Dict[str, Any], chat_id: Any) -> None:
    store.audit("telegram", str(chat_id), action, target, result, server_id=tg_server_id(chat_id))


def start_add_flow(chat_id: Any, message_id: int, expires: Optional[str]) -> None:
    _pending_add[str(chat_id)] = {"expires": expires, "psk": False, "step": "psk", "ts": time.time()}
    label = "permanent" if not expires else f"temporary {expires}"
    edit(chat_id, message_id, f"<b>Add {esc(label)} client</b>\nВыбери PSK режим.", add_psk_keyboard())


def set_add_psk(chat_id: Any, message_id: int, psk: bool) -> None:
    state = _pending_add.setdefault(str(chat_id), {"expires": None})
    state["psk"] = psk
    state["step"] = "name"
    state["ts"] = time.time()
    expires = state.get("expires")
    label = "permanent" if not expires else f"temporary {expires}"
    psk_label = "ON" if psk else "OFF"
    edit(chat_id, message_id, f"<b>Add {esc(label)} client</b>\nPSK: <b>{psk_label}</b>\n\nТеперь отправь имя клиента одним сообщением.\nНапример: <code>iphone_lamanper</code>", {"inline_keyboard": [[{"text": "Cancel", "callback_data": "m:main"}]]})


def handle_pending_add(chat_id: Any, text: str) -> bool:
    state = _pending_add.get(str(chat_id))
    if not state or state.get("step") != "name" or text.startswith("/"):
        return False
    name = text.strip().split()[0]
    _pending_add.pop(str(chat_id), None)
    result = actions.action_add_client(tg_server_id(chat_id), name, expires=state.get("expires"), psk=bool(state.get("psk")), actor=str(chat_id))
    audit("client.add", name, result, chat_id)
    send_output(chat_id, f"Add client {name}", result.get("message") or result.get("error") or result, main_keyboard())
    try:
        items = clients(chat_id)
        idx = next((i for i, c in enumerate(items) if parse.name(c) == name), None)
        if idx is not None:
            send(chat_id, format_client(items[idx]), client_keyboard(idx))
    except Exception as exc:
        log(f"post-add client card failed: {exc}")
    return True


def handle_command(chat_id: Any, text: str) -> None:
    if text.startswith("/id"):
        send(chat_id, f"chat_id: <code>{esc(chat_id)}</code>")
        return
    if not require_admin(chat_id):
        return
    if handle_pending_add(chat_id, text):
        return
    parts = text.split()
    cmd = parts[0].lower() if parts else ""
    if cmd in {"/start", "/menu", "/help"}:
        send(chat_id, format_main(chat_id) if cmd != "/help" else help_text(), main_keyboard())
    elif cmd == "/status":
        send(chat_id, format_status(chat_id), main_keyboard())
    elif cmd == "/clients":
        send(chat_id, "<b>Clients</b>", clients_keyboard(0, chat_id=chat_id))
    elif cmd == "/client" and len(parts) > 1:
        name = parts[1]
        c = next((x for x in clients(chat_id) if parse.name(x) == name), None)
        send(chat_id, format_client(c) if c else "client not found", main_keyboard())
    elif cmd == "/add" and len(parts) > 1:
        expires = parts[2] if len(parts) > 2 and parts[2] != "psk" else None
        psk = "psk" in [p.lower() for p in parts[2:]]
        result = actions.action_add_client(tg_server_id(chat_id), parts[1], expires=expires, psk=psk, actor=str(chat_id))
        audit("client.add", parts[1], result, chat_id)
        send_output(chat_id, f"Add client {parts[1]}", result.get("message") or result.get("error") or result, main_keyboard())
    elif cmd == "/backup":
        result = actions.action_create_backup(tg_server_id(chat_id), actor=str(chat_id))
        audit("backup.create", "", result, chat_id)
        send_output(chat_id, "Backup", result.get("message") or result.get("error") or result, main_keyboard())
        if result.get("ok") and settings().get("send_backup"):
            send_backup_doc(chat_id)
    elif cmd == "/diagnose":
        carrier = parts[1] if len(parts) > 1 else None
        result = actions.action_run_diagnostics(tg_server_id(chat_id), actor=str(chat_id))
        audit("diagnose", carrier or "", result, chat_id)
        send_output(chat_id, "Diagnostics", result.get("message") or result.get("error") or result, main_keyboard())
    elif cmd == "/cancel":
        _pending_add.pop(str(chat_id), None)
        send(chat_id, "Cancelled.", main_keyboard())
    else:
        send(chat_id, help_text(), main_keyboard())


def handle_callback(cb: Dict[str, Any]) -> None:
    qid = cb.get("id", "")
    msg = cb.get("message") or {}
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    data = cb.get("data") or ""
    answer_callback(qid)
    if not require_admin(chat_id):
        return
    try:
        if data == "m:main":
            _pending_add.pop(str(chat_id), None)
            edit(chat_id, message_id, format_main(chat_id), main_keyboard())
        elif data == "m:help":
            edit(chat_id, message_id, help_text(), main_keyboard())
        elif data == "m:status":
            edit(chat_id, message_id, format_status(chat_id), main_keyboard())
        elif data == "m:servers":
            edit(chat_id, message_id, "<b>Servers</b>\nВыбери активный сервер для Telegram-действий.", servers_keyboard(chat_id))
        elif data.startswith("srv:"):
            sid = data.split(":", 1)[1]
            if store.get_server(sid):
                store.set_setting(f"telegram_server:{chat_id}", sid)
                edit(chat_id, message_id, format_main(chat_id), main_keyboard())
            else:
                send(chat_id, "server not found", main_keyboard())
        elif data.startswith("m:clients:"):
            edit(chat_id, message_id, "<b>Clients</b>", clients_keyboard(int(data.split(":")[-1]), chat_id=chat_id))
        elif data == "m:add":
            edit(chat_id, message_id, "<b>Add client</b>\nВыбери срок действия.", add_keyboard(False))
        elif data == "m:addtemp":
            edit(chat_id, message_id, "<b>Add temporary client</b>\nВыбери срок действия.", add_keyboard(True))
        elif data == "m:server":
            edit(chat_id, message_id, "<b>Server actions</b>", server_keyboard())
        elif data == "m:backupmenu":
            edit(chat_id, message_id, "<b>Backup center</b>", backup_keyboard())
        elif data == "m:diag":
            result = actions.action_run_diagnostics(tg_server_id(chat_id), actor=str(chat_id))
            audit("diagnose", "", result, chat_id)
            send_output(chat_id, "Diagnostics", result.get("message") or result.get("error") or result, main_keyboard())
        elif data == "m:cascade":
            result = actions.action_cascade_diagnostics(tg_server_id(chat_id), actor=str(chat_id))
            text = result.get("message") or result.get("error") or ""
            audit("cascade.diagnose", tg_server_id(chat_id), result, chat_id)
            send_output(chat_id, "Cascade diagnostics", text, cascade_keyboard(), force_doc=len(text) > DOC_THRESHOLD)
        elif data == "m:engine":
            probe = actions.action_engine_probe(tg_server_id(chat_id), actor=str(chat_id))
            payload = probe.get("data", {}).get("probe") or {}
            bundled = payload.get("bundled") or engine.verify_bundled_engine()
            text = (
                f"Engine status: {probe.get('message') or payload.get('status') or 'unknown'}\n"
                f"AWGUI engine: {bundled.get('engine_version')}\n"
                f"Mode: {bundled.get('mode')}\n"
                f"Bundled verify: {'OK' if bundled.get('ok') else 'FAIL'}\n"
                f"Remote slot: {bundled.get('remote_dir')}\n"
            )
            audit("engine.probe", tg_server_id(chat_id), {"ok": bool(probe.get("ok")), "rc": 0 if probe.get("ok") else 1, "text": text}, chat_id)
            send_output(chat_id, "Engine", text, engine_keyboard())
        elif data == "m:obfuscation":
            result = actions.action_obfuscation_status(tg_server_id(chat_id), actor=str(chat_id))
            obf = result.get("data", {}).get("obfuscation") or {}
            params = obf.get("params") or []
            found = [p for p in params if p.get("found")]
            lines = [
                f"Mode: {obf.get('mode') or 'read-only'}",
                obf.get("message") or "Read-only groundwork. Apply will be enabled after validated offline engine profile support.",
                "",
                f"Detected: {len(found)}/{len(params)}",
            ]
            for p in params[:16]:
                lines.append(f"{p.get('name')}: {p.get('value')}")
            audit("obfuscation.status", tg_server_id(chat_id), result, chat_id)
            send_output(chat_id, "Obfuscation", "\n".join(lines), main_keyboard())
        elif data == "engine:deploy":
            result = actions.action_engine_deploy(tg_server_id(chat_id), actor=str(chat_id), confirm=True)
            audit("engine.deploy", "engine", result, chat_id)
            send_output(chat_id, "Engine deploy", result.get("message") or result.get("error") or result, engine_keyboard())
        elif data == "m:show":
            result = actions.action_server_show(tg_server_id(chat_id), actor=str(chat_id))
            audit("server.show", "awg0", result, chat_id)
            send_output(chat_id, "Server show", result.get("message") or result.get("error") or result, server_keyboard(), force_doc=len(str(result.get("message") or "")) > DOC_THRESHOLD)
        elif data == "m:check":
            result = actions.action_server_check(tg_server_id(chat_id), actor=str(chat_id))
            audit("server.check", "awg0", result, chat_id)
            send_output(chat_id, "Server check", result.get("message") or result.get("error") or result, server_keyboard())
        elif data.startswith("add:perm"):
            start_add_flow(chat_id, message_id, None)
        elif data.startswith("add:exp:"):
            duration = data.split(":", 2)[2]
            if duration not in ADD_DURATIONS:
                send(chat_id, "Unsupported duration.", main_keyboard())
            else:
                start_add_flow(chat_id, message_id, duration)
        elif data.startswith("addpsk:"):
            set_add_psk(chat_id, message_id, data.endswith(":1"))
        elif data == "backup:create":
            result = actions.action_create_backup(tg_server_id(chat_id), actor=str(chat_id))
            audit("backup.create", "", result, chat_id)
            send_output(chat_id, "Backup", result.get("message") or result.get("error") or result, backup_keyboard())
            if result.get("ok") and settings().get("send_backup"):
                send_backup_doc(chat_id)
        elif data == "backup:latest":
            if send_backup_doc(chat_id):
                send(chat_id, "Latest backup sent.", backup_keyboard())
        elif data == "backup:list":
            result = actions.action_list_backups(tg_server_id(chat_id), actor=str(chat_id))
            backups = (result.get("data", {}).get("backups") or [])[:8]
            if not backups:
                send(chat_id, "No backups found.", backup_keyboard())
            else:
                lines = [f"{i+1}. {esc(b['name'])} · {esc(b.get('size_h') or b.get('size') or '')}" for i, b in enumerate(backups)]
                send(chat_id, "<b>Backups</b>\n" + "\n".join(lines), backup_keyboard())
        elif data.startswith("ci:"):
            idx = int(data.split(":", 1)[1])
            c, _name = client_by_index(str(idx), chat_id)
            edit(chat_id, message_id, format_client(c) if c else "client not found", client_keyboard(idx) if c else clients_keyboard(0))
        elif data.startswith("qr:"):
            c, name = client_by_index(data.split(":", 1)[1], chat_id)
            qr_action = actions.action_get_client_qr(tg_server_id(chat_id), name, actor=str(chat_id)) if name else {"data": {}}
            filename, data_bytes = qr_action.get("data", {}).get("filename"), qr_action.get("data", {}).get("bytes")
            if data_bytes:
                tmp_path = None
                try:
                    with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name + ".png"), prefix="awgui_qr_", delete=False) as f:
                        f.write(data_bytes); tmp_path = Path(f.name)
                    send_photo(chat_id, tmp_path, name)
                finally:
                    if tmp_path:
                        tmp_path.unlink(missing_ok=True)
            else:
                send(chat_id, "PNG QR not found. Use web UI for SVG fallback.", main_keyboard())
        elif data.startswith("conf:") or data.startswith("vpn:") or data.startswith("bundle:"):
            action, idx = data.split(":", 1)
            c, name = client_by_index(idx, chat_id)
            if not name:
                send(chat_id, "client not found", main_keyboard())
                return
            if action == "bundle":
                bundle_action = actions.action_get_client_bundle(tg_server_id(chat_id), name, actor=str(chat_id))
                p = bundle_action.get("data", {}).get("path")
            else:
                file_action = actions.action_get_client_conf(tg_server_id(chat_id), name, actor=str(chat_id)) if action == "conf" else actions.action_get_client_vpnuri(tg_server_id(chat_id), name, actor=str(chat_id))
                filename, data_bytes = file_action.get("data", {}).get("filename"), file_action.get("data", {}).get("bytes")
                p = None
                if data_bytes:
                    with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name), prefix="awgui_client_", delete=False) as f:
                        f.write(data_bytes); p = Path(f.name)
            if p:
                try:
                    send_doc(chat_id, Path(p), name)
                finally:
                    if str(p).startswith(tempfile.gettempdir()):
                        Path(p).unlink(missing_ok=True)
            else:
                send(chat_id, "file not found", main_keyboard())
        elif data.startswith("confirm:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled in AWGUI → Telegram.", main_keyboard())
                return
            _, action, *rest = data.split(":")
            value = rest[0] if rest else ""
            edit(chat_id, message_id, f"Confirm <b>{esc(action)}</b> {esc(value)}?", confirm_keyboard(action, value))
        elif data.startswith("do:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled.", main_keyboard())
                return
            _, action, value = data.split(":", 2)
            if action == "restart":
                target = "awg0"; result = actions.action_server_restart(tg_server_id(chat_id), actor=str(chat_id), confirm=True)
            elif action == "repair":
                target = "module"; result = actions.action_repair_module(tg_server_id(chat_id), actor=str(chat_id), confirm=True)
            elif action == "regen":
                _c, target = client_by_index(value, chat_id); result = actions.action_regen_client(tg_server_id(chat_id), target, actor=str(chat_id))
            elif action == "remove":
                _c, target = client_by_index(value, chat_id); result = actions.action_remove_client(tg_server_id(chat_id), target, actor=str(chat_id), confirm=True)
            elif action == "cascade_ruzone":
                target = "cascade/ru.zone"; result = actions.action_install_bundled_ru_zone(tg_server_id(chat_id), actor=str(chat_id), confirm=True)
            elif action == "engine_apply":
                target = "engine"; result = actions.action_engine_apply(tg_server_id(chat_id), actor=str(chat_id), confirm=True)
            else:
                raise ValueError("bad action")
            audit(action, target, result, chat_id)
            send_output(chat_id, action, result.get("message") or result.get("error") or result, main_keyboard())
        else:
            send(chat_id, "Unknown action.", main_keyboard())
    except Exception as exc:
        log(f"callback failed data={data!r}: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        send(chat_id, "⚠️ Telegram action failed. Команда не скрыта: подробности в journalctl -u awgui-bot.", main_keyboard())


def poll() -> None:
    if not token():
        log("disabled: empty token")
        return
    try:
        api("deleteWebhook", {"drop_pending_updates": False}, timeout=20)
    except Exception as exc:
        log(f"deleteWebhook failed: {exc}")
    offset = 0
    log("polling started")
    while True:
        try:
            resp = api("getUpdates", {"timeout": 45, "offset": offset, "allowed_updates": ["message", "callback_query"]}, timeout=60)
            for upd in resp.get("result", []):
                offset = max(offset, int(upd.get("update_id", 0)) + 1)
                if "message" in upd:
                    msg = upd["message"]
                    chat_id = msg.get("chat", {}).get("id")
                    text = msg.get("text") or ""
                    if text:
                        handle_command(chat_id, text.strip())
                elif "callback_query" in upd:
                    handle_callback(upd["callback_query"])
        except KeyboardInterrupt:
            raise
        except Exception:
            traceback.print_exc()
            time.sleep(4)


if __name__ == "__main__":
    poll()

