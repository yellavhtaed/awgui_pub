#!/usr/bin/env bash
# Tiny OpenSSH test double: ignore ssh options and execute/simulate the last argument.
set -u
script="${@: -1}"
if printf '%s' "$script" | grep -q 'AWGUI_PROVISIONER_PREFLIGHT=1'; then
  cat <<'EOF'
AWGUI_PROVISIONER_PREFLIGHT=1
whoami=root
uid=0
os_id=ubuntu
os_version=24.04
os_codename=noble
kernel=6.8.0-test
arch=x86_64
disk_mb=8192
cmd_bash=1
cmd_curl=1
cmd_apt-get=1
cmd_systemctl=1
cmd_ss=1
cmd_awk=1
cmd_grep=1
cmd_sed=1
cmd_tar=1
cmd_chmod=1
cmd_install=1
cmd_sha256sum=1
privilege=root
manage=absent
awg=absent
awg_service=inactive
dkms=absent
headers=unknown
efi=absent
EOF
  exit 0
fi
if printf '%s' "$script" | grep -q 'running pinned engine installer'; then
  cat <<'EOF'
[AWGUI] running pinned engine installer: bash /root/awg/.awgui-engine/5.18.4-awgui1/install_amneziawg.sh --yes --no-color --route-amnezia
[AWGUI engine] installing pinned upstream engine 5.18.4
[INFO] fake pinned install complete
[AWGUI] applying/verifying AWGUI engine
[AWGUI engine] applied and verified: 5.18.4-awgui1
[AWGUI] verifying parent manager
[AWGUI] bootstrap finished
EOF
  exit 0
fi
if printf '%s' "$script" | grep -q 'tar -xzf -'; then
  bytes=$(wc -c | awk '{print $1}')
  printf 'AWGUI fake streaming deploy received %s bytes\n' "$bytes"
  echo 'AWGUI engine deployed: 5.18.4-awgui1'
  exit 0
fi
if printf '%s' "$script" | grep -q 'running bundled offline engine installer'; then
  cat <<'EOF'
[AWGUI] verifying bundled engine manifest
MANIFEST.sha256: OK
[AWGUI] running bundled offline engine installer: bash /root/awg/.awgui-engine/5.18.4-awgui1/install_amneziawg.sh --yes --no-color --route-amnezia
[INFO] fake bundled offline install complete
[AWGUI] applying/verifying AWGUI engine
[AWGUI engine] applied bundled offline engine: 5.18.4-awgui1
[AWGUI] verifying parent manager
[AWGUI] bootstrap finished
EOF
  exit 0
fi
if printf '%s' "$script" | grep -q 'manage_sha256'; then
  cat <<'EOF'
installed_marker=5.18.4-awgui1
current_json={"engine":"5.18.4-awgui1"}
engine_dir=/root/awg/.awgui-engine/5.18.4-awgui1
engine_deployed=1
manage_present=1
common_present=1
manage_sha256=fake
common_sha256=fake
EOF
  exit 0
fi
if printf '%s' "$script" | grep -q '.awgui-ru-zone-version'; then
  echo 'Installed bundled ru.zone: fake'
  exit 0
fi
if printf '%s' "$script" | grep -q 'awgui_engine_apply.sh'; then
  echo '[AWGUI engine] applied bundled offline engine: 5.18.4-awgui1'
  exit 0
fi
if printf '%s' "$script" | grep -q 'install_amneziawg_en.sh'; then
  cat <<'EOF'
[AWGUI] downloading parent installer
[AWGUI] running parent installer: bash /root/awg/install_amneziawg.sh --yes --no-color --route-amnezia
[INFO] fake install complete
[AWGUI] verifying parent manager
[AWGUI] bootstrap finished
EOF
  exit 0
fi
if printf '%s' "$script" | grep -q 'test -f /root/awg/manage_amneziawg.sh'; then
  exit 0
fi
if printf '%s' "$script" | grep -q '/root/awg/manage_amneziawg.sh'; then
  fake="${AWGUI_FAKE_MANAGE:-$(dirname "$0")/fake_manage_amneziawg.sh}"
  # Execute the local fake manager with the remote command arguments after the script path.
  # shellcheck disable=SC2206
  args=( $script )
  out=()
  take=0
  for a in "${args[@]}"; do
    if [ "$take" = 1 ]; then out+=("$a"); fi
    if [ "$a" = "/root/awg/manage_amneziawg.sh" ]; then take=1; fi
  done
  bash "$fake" "${out[@]}"
  exit $?
fi
bash -lc "$script"
