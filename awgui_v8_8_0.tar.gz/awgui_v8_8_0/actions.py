from __future__ import annotations

from typing import Any, Dict, Optional

import cascade
import engine
import manage_adapter
import obfuscation
import parse
import provisioner
import store


def _adapter(server_id: str) -> manage_adapter.ManageAdapter:
    srv = store.get_server(server_id)
    if not srv:
        raise ValueError("server not found")
    return manage_adapter.adapter_for_server(srv)


def _shape(action: str, server_id: str, target: str = "", *, ok: bool = False, message: str = "", data: Optional[Dict[str, Any]] = None, logs: Optional[list] = None, error: Optional[str] = None) -> Dict[str, Any]:
    return {
        "ok": bool(ok),
        "action": action,
        "server_id": server_id,
        "target": target,
        "message": message,
        "data": data or {},
        "logs": logs or [],
        "error": error,
    }


def _from_result(action: str, server_id: str, target: str, result: Dict[str, Any]) -> Dict[str, Any]:
    text = str(result.get("text") or result.get("stdout") or result.get("stderr") or "")
    return _shape(action, server_id, target, ok=bool(result.get("ok")), message=text, data={"result": result}, logs=[text] if text else [], error=None if result.get("ok") else text)


def _run(action: str, server_id: str, target: str, fn) -> Dict[str, Any]:
    try:
        return _from_result(action, server_id, target, fn(_adapter(server_id)))
    except Exception as exc:
        return _shape(action, server_id, target, error=f"{type(exc).__name__}: {exc}")


def action_status(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        ad = _adapter(server_id)
        summary = ad.summary()
        status = ad.status()
        ok = bool(status.get("ok"))
        return _shape("status", server_id, "server", ok=ok, message=status.get("text") or "", data={"summary": summary, "status": status}, error=None if ok else status.get("text") or "status failed")
    except Exception as exc:
        return _shape("status", server_id, "server", error=f"{type(exc).__name__}: {exc}")


def action_list_clients(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        result = _adapter(server_id).list_clients()
        clients = parse.clients_from(result.get("json"))
        return _shape("client.list", server_id, "clients", ok=bool(result.get("ok")), message=result.get("text") or "", data={"result": result, "clients": clients}, error=None if result.get("ok") else result.get("text") or "list failed")
    except Exception as exc:
        return _shape("client.list", server_id, "clients", error=f"{type(exc).__name__}: {exc}")


def action_add_client(server_id: str, name: str, expires=None, psk: bool = False, actor=None) -> Dict[str, Any]:
    return _run("client.add", server_id, name, lambda ad: ad.add_client(name, expires=expires, psk=psk))


def action_remove_client(server_id: str, name: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("client.remove", server_id, name, error="confirmation required")
    return _run("client.remove", server_id, name, lambda ad: ad.remove_client(name))


def action_regen_client(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    return _run("client.regen", server_id, name, lambda ad: ad.regen_client(name))


def action_get_client_conf(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        filename, data = _adapter(server_id).read_client_bytes(name, "conf")
        return _shape("client.conf", server_id, name, ok=bool(data), message=filename or "", data={"filename": filename, "bytes": data})
    except Exception as exc:
        return _shape("client.conf", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_get_client_qr(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        filename, data = _adapter(server_id).read_client_bytes(name, "png")
        return _shape("client.qr", server_id, name, ok=bool(data), message=filename or "", data={"filename": filename, "bytes": data})
    except Exception as exc:
        return _shape("client.qr", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_get_client_vpnuri(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        filename, data = _adapter(server_id).read_client_bytes(name, "vpnuri")
        return _shape("client.vpnuri", server_id, name, ok=bool(data), message=filename or "", data={"filename": filename, "bytes": data})
    except Exception as exc:
        return _shape("client.vpnuri", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_get_client_bundle(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        path = _adapter(server_id).create_client_bundle(name)
        return _shape("client.bundle", server_id, name, ok=bool(path), message=str(path), data={"path": path})
    except Exception as exc:
        return _shape("client.bundle", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_create_backup(server_id: str, reason=None, actor=None) -> Dict[str, Any]:
    return _run("backup.create", server_id, reason or "", lambda ad: ad.backup())


def action_run_diagnostics(server_id: str, actor=None) -> Dict[str, Any]:
    return _run("diagnostics.run", server_id, "", lambda ad: ad.diagnose())


def action_cascade_diagnostics(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        diag = cascade.diagnose(_adapter(server_id))
        text = cascade.report_text(diag)
        return _shape("cascade.diagnostics", server_id, "cascade", ok=bool(diag.get("ok")), message=text, data={"diagnostics": diag}, logs=[text])
    except Exception as exc:
        return _shape("cascade.diagnostics", server_id, "cascade", error=f"{type(exc).__name__}: {exc}")


def action_install_bundled_ru_zone(server_id: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("cascade.install_ru_zone", server_id, "cascade/ru.zone", error="confirmation required")
    return _run("cascade.install_ru_zone", server_id, "cascade/ru.zone", cascade.install_bundled_ru_zone)


def action_engine_probe(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        probe = engine.probe_installed_engine(server_id)
        return _shape("engine.probe", server_id, "engine", ok=bool(probe.get("ok")), message=str(probe.get("status")), data={"probe": probe})
    except Exception as exc:
        return _shape("engine.probe", server_id, "engine", error=f"{type(exc).__name__}: {exc}")


def action_engine_deploy(server_id: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("engine.deploy", server_id, "engine", error="confirmation required")
    return _from_result("engine.deploy", server_id, "engine", engine.deploy_engine(server_id))


def action_engine_apply(server_id: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("engine.apply", server_id, "engine", error="confirmation required")
    return _from_result("engine.apply", server_id, "engine", engine.apply_engine(server_id))


def action_obfuscation_status(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        data = obfuscation.inspect(_adapter(server_id))
        return _shape("obfuscation.status", server_id, "obfuscation", ok=bool(data.get("ok")), message=data.get("message") or "", data={"obfuscation": data})
    except Exception as exc:
        return _shape("obfuscation.status", server_id, "obfuscation", error=f"{type(exc).__name__}: {exc}")


def action_provision_server(server_id: str, options, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("provisioner.bootstrap", server_id, "provisioner", error="confirmation required")
    try:
        result = provisioner.provisioner_for_server(server_id).bootstrap(options or {})
        text = str((result.get("raw") or {}).get("text") or result.get("error") or "")
        return _shape("provisioner.bootstrap", server_id, "provisioner", ok=bool(result.get("ok")), message=text, data={"result": result}, logs=[text] if text else [], error=None if result.get("ok") else text)
    except Exception as exc:
        return _shape("provisioner.bootstrap", server_id, "provisioner", error=f"{type(exc).__name__}: {exc}")


def action_stats(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        result = _adapter(server_id).stats()
        clients = parse.clients_from(result.get("json"))
        return _shape("stats", server_id, "stats", ok=bool(result.get("ok")), message=result.get("text") or "", data={"result": result, "clients": clients}, error=None if result.get("ok") else result.get("text") or "stats failed")
    except Exception as exc:
        return _shape("stats", server_id, "stats", error=f"{type(exc).__name__}: {exc}")


def action_doctor(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        data = _adapter(server_id).doctor()
        ok = all(bool(c.get("ok", True)) for c in data.get("checks", [])) if isinstance(data, dict) else False
        return _shape("doctor", server_id, "doctor", ok=ok, message="doctor ok" if ok else "doctor warnings", data={"doctor": data})
    except Exception as exc:
        return _shape("doctor", server_id, "doctor", error=f"{type(exc).__name__}: {exc}")


def action_client_detail(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        ad = _adapter(server_id)
        list_result = ad.list_clients()
        clients = parse.clients_from(list_result.get("json"))
        client = next((c for c in clients if parse.name(c) == name), None)
        return _shape("client.detail", server_id, name, ok=True, message=name, data={
            "list_result": list_result,
            "client": client,
            "inventory": ad.file_inventory(name),
            "conf_text": ad.read_client_text(name, "conf"),
            "vpnuri_text": ad.read_client_text(name, "vpnuri"),
        })
    except Exception as exc:
        return _shape("client.detail", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_modify_client(server_id: str, name: str, param: str, value: str, actor=None) -> Dict[str, Any]:
    return _run("client.modify", server_id, f"{name}:{param}", lambda ad: ad.modify_client(name, param, value))


def action_qr_payload(server_id: str, name: str, preferred: str = "vpnuri", actor=None) -> Dict[str, Any]:
    try:
        source_name, source = _adapter(server_id).qr_payload(name, preferred)
        return _shape("client.qr_payload", server_id, name, ok=bool(source), message=source_name or "", data={"source_name": source_name, "source": source})
    except Exception as exc:
        return _shape("client.qr_payload", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_list_backups(server_id: str, actor=None) -> Dict[str, Any]:
    try:
        backups = _adapter(server_id).list_backups()
        return _shape("backup.list", server_id, "backups", ok=True, data={"backups": backups})
    except Exception as exc:
        return _shape("backup.list", server_id, "backups", error=f"{type(exc).__name__}: {exc}")


def action_backup_preview(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        ad = _adapter(server_id)
        p = ad.find_backup(name)
        if not p:
            return _shape("backup.preview", server_id, name, error="backup not found")
        preview = ad.backup_preview(p)
        return _shape("backup.preview", server_id, name, ok=bool(preview.get("ok")), data={"preview": preview}, error=None if preview.get("ok") else preview.get("error") or "preview failed")
    except Exception as exc:
        return _shape("backup.preview", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_restore_backup(server_id: str, name: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("backup.restore", server_id, name, error="confirmation required")
    try:
        ad = _adapter(server_id)
        p = ad.find_backup(name)
        if not p:
            return _shape("backup.restore", server_id, name, error="backup not found")
        return _from_result("backup.restore", server_id, name, ad.restore(str(p)))
    except Exception as exc:
        return _shape("backup.restore", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_backup_bytes(server_id: str, name: str, actor=None) -> Dict[str, Any]:
    try:
        filename, data = _adapter(server_id).backup_bytes(name)
        return _shape("backup.download", server_id, name, ok=bool(data), message=filename or "", data={"filename": filename, "bytes": data}, error=None if data else "backup not found")
    except Exception as exc:
        return _shape("backup.download", server_id, name, error=f"{type(exc).__name__}: {exc}")


def action_server_check(server_id: str, actor=None) -> Dict[str, Any]:
    return _run("server.check", server_id, "awg0", lambda ad: ad.check())


def action_server_show(server_id: str, actor=None) -> Dict[str, Any]:
    return _run("server.show", server_id, "awg0", lambda ad: ad.show())


def action_server_restart(server_id: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("server.restart", server_id, "awg0", error="confirmation required")
    return _run("server.restart", server_id, "awg0", lambda ad: ad.restart())


def action_repair_module(server_id: str, actor=None, confirm: bool = False) -> Dict[str, Any]:
    if not confirm:
        return _shape("server.repair_module", server_id, "module", error="confirmation required")
    return _run("server.repair_module", server_id, "module", lambda ad: ad.repair_module())
