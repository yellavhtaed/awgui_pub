#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
from datetime import timedelta
from typing import Any, Dict

from flask import Flask, Response, jsonify, redirect, render_template, request, send_file, session, url_for, has_request_context

import config
import actions
import engine
import web_support
import cascade
import i18n
import manage_adapter
import parse
import provisioner
import store

app = Flask(__name__)
app.secret_key = config.SECRET
app.permanent_session_lifetime = timedelta(hours=12)
store.init_db()


def current_server_id() -> str:
    if has_request_context():
        sid = str(session.get("server_id") or config.SERVER_ID)
    else:
        sid = config.SERVER_ID
    if not store.get_server(sid):
        sid = config.SERVER_ID
        if has_request_context():
            session["server_id"] = sid
    return sid


def current_server() -> Dict[str, Any]:
    return store.get_server(current_server_id()) or store.get_server(config.SERVER_ID) or {
        "id": config.SERVER_ID, "name": config.SERVER_NAME, "mode": "local",
        "manage_path": str(config.MANAGE), "awg_dir": str(config.AWG_DIR), "server_conf": str(config.SERVER_CONF),
    }


def current_adapter() -> manage_adapter.ManageAdapter:
    return manage_adapter.adapter_for_server(current_server())


class AdapterProxy:
    def __getattr__(self, name: str):
        return getattr(current_adapter(), name)


adapter = AdapterProxy()


def current_lang() -> str:
    return i18n.normalize_lang(session.get("lang") or request.cookies.get("awgui_lang") or request.accept_languages.best_match(list(i18n.SUPPORTED_LANGS)) or i18n.DEFAULT_LANG)


@app.context_processor
def globals_for_templates():
    lang = current_lang()
    return {
        "app_name": config.APP_NAME,
        "app_version": config.APP_VERSION,
        "app_tagline": config.APP_TAGLINE,
        "server_id": current_server().get("id", config.SERVER_ID),
        "server_name": current_server().get("name", config.SERVER_NAME),
        "server_mode": current_server().get("mode", "local"),
        "servers": store.list_servers(include_disabled=False),
        "parse": parse,
        "online_window": config.ONLINE_WINDOW_SECONDS,
        "lang": lang,
        "langs": i18n.SUPPORTED_LANGS,
        "t": lambda key: i18n.tr(lang, key),
    }


def logged_in() -> bool:
    return session.get("auth") is True


def wants_json() -> bool:
    return request.path.startswith("/api/") or "application/json" in (request.headers.get("Accept") or "")


@app.before_request
def auth_guard():
    if request.endpoint == "static" or request.path in {"/health", "/login"}:
        return None
    if logged_in():
        return None
    if wants_json():
        return jsonify({"ok": False, "error": "auth required"}), 401
    return redirect(url_for("login", next=request.path))


def actor() -> str:
    return str(session.get("user") or "admin")


def audit(action: str, target: str, result: Dict[str, Any], source: str = "web") -> Dict[str, Any]:
    store.audit(source, actor(), action, target, result, server_id=current_server_id())
    return result


def notice(text: str):
    session["notice"] = text


def error(text: str):
    session["error"] = text


def pop_flash() -> Dict[str, str]:
    return {"notice": session.pop("notice", ""), "error": session.pop("error", "")}






@app.get("/login")
def login():
    if logged_in():
        return redirect(url_for("dashboard"))
    return render_template("login.html", user=config.USER, error="")


@app.post("/login")
def login_post():
    if request.form.get("username", "") == config.USER and request.form.get("password", "") == config.PASSWORD:
        session.clear()
        session.permanent = True
        session["auth"] = True
        session["user"] = config.USER
        return redirect(request.args.get("next") or url_for("dashboard"))
    return render_template("login.html", user=request.form.get("username", ""), error="Неверный логин или пароль"), 401


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.post("/ui/lang")
def ui_lang():
    lang = i18n.normalize_lang(request.form.get("lang"))
    session["lang"] = lang
    resp = redirect(request.referrer or url_for("dashboard"))
    resp.set_cookie("awgui_lang", lang, max_age=60 * 60 * 24 * 365, samesite="Lax")
    return resp




@app.get("/servers")
def servers_page():
    probes: Dict[str, Any] = session.pop("server_probes", {})
    return render_template("servers.html", servers=store.list_servers(), current=current_server_id(), probes=probes, **pop_flash())


@app.post("/servers/select")
def server_select():
    sid = request.form.get("server_id", "").strip()
    if store.get_server(sid):
        session["server_id"] = sid
        notice(f"Server selected: {sid}")
    else:
        error("Server not found")
    return redirect(request.referrer or url_for("dashboard"))


@app.post("/servers/add")
def server_add():
    try:
        data = {
            "id": request.form.get("id", ""),
            "name": request.form.get("name", ""),
            "mode": "ssh",
            "host": request.form.get("host", ""),
            "port": request.form.get("port", "22"),
            "user": request.form.get("user", "root"),
            "key_path": request.form.get("key_path", ""),
            "manage_path": request.form.get("manage_path", "/root/awg/manage_amneziawg.sh"),
            "awg_dir": request.form.get("awg_dir", "/root/awg"),
            "server_conf": request.form.get("server_conf", "/etc/amnezia/amneziawg/awg0.conf"),
            "enabled": bool(request.form.get("enabled", "1")),
        }
        saved = store.save_server(data)
        audit("server.add", saved.get("id", ""), {"ok": True, "rc": 0, "text": "server saved"})
        notice(f"Server saved: {saved.get('id')}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("servers_page"))


@app.post("/servers/<server_id>/delete")
def server_delete(server_id):
    try:
        store.delete_server(server_id)
        if session.get("server_id") == server_id:
            session["server_id"] = config.SERVER_ID
        audit("server.delete", server_id, {"ok": True, "rc": 0, "text": "server deleted"})
        notice(f"Server deleted: {server_id}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("servers_page"))


@app.post("/servers/<server_id>/probe")
def server_probe(server_id):
    try:
        srv = store.get_server(server_id)
        if not srv:
            raise ValueError("server not found")
        ad = manage_adapter.adapter_for_server(srv)
        probe = {"scan": ad.scan(), "status": ad.status(), "clients": ad.list_clients()}
        session["server_probes"] = {server_id: probe}
        audit("server.probe", server_id, {"ok": bool(probe["scan"].get("ok")), "rc": 0 if probe["scan"].get("ok") else 1, "text": str(probe["scan"].get("script_version"))})
        notice(f"Probe done: {server_id}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("servers_page"))



@app.get("/engine")
def engine_page():
    status = engine.server_engine_status(current_adapter())
    return render_template("engine.html", engine_status=status, **pop_flash())


@app.post("/engine/deploy")
def engine_deploy():
    action = actions.action_engine_deploy(current_server_id(), actor=actor(), confirm=True)
    result = action.get("data", {}).get("result") or action
    audit("engine.deploy", config.ENGINE_VERSION, result)
    if action.get("ok"):
        notice("AWGUI engine deployed to selected server")
    else:
        error(action.get("error") or action.get("message") or "engine deploy failed")
    return redirect(url_for("engine_page"))


@app.post("/engine/apply")
def engine_apply():
    confirm = request.form.get("confirm", "").strip()
    if confirm != "ENGINE":
        error("Type ENGINE to apply bundled engine")
        return redirect(url_for("engine_page"))
    action = actions.action_engine_apply(current_server_id(), actor=actor(), confirm=True)
    result = action.get("data", {}).get("result") or action
    audit("engine.apply", config.ENGINE_VERSION, result)
    if action.get("ok"):
        notice("Bundled engine applied and verified")
    else:
        error(action.get("error") or action.get("message") or "engine apply failed")
    return redirect(url_for("engine_page"))


@app.get("/cascade")
def cascade_page():
    diag = cascade.diagnose(current_adapter())
    return render_template("cascade.html", cascade_diag=diag, **pop_flash())


@app.post("/cascade/diagnose")
def cascade_diagnose_post():
    diag = cascade.diagnose(current_adapter())
    audit("cascade.diagnose", current_server_id(), {"ok": bool(diag.get("ok")), "rc": 0 if diag.get("ok") else 1, "text": cascade.report_text(diag)[:4000]})
    notice("Cascade diagnostics completed" if diag.get("raw", {}).get("ok") else "Cascade diagnostics finished with warnings/errors")
    return redirect(url_for("cascade_page"))




@app.post("/cascade/install-ru-zone")
def cascade_install_ru_zone():
    if request.form.get("confirm", "").strip() != "CASCADE":
        error("Type CASCADE to install bundled ru.zone")
        return redirect(url_for("cascade_page"))
    action = actions.action_install_bundled_ru_zone(current_server_id(), actor=actor(), confirm=True)
    result = action.get("data", {}).get("result") or action
    audit("cascade.install_ru_zone", current_server_id(), result)
    if action.get("ok"):
        notice("Bundled ru.zone installed on selected server")
    else:
        error(action.get("error") or action.get("message") or "ru.zone install failed")
    return redirect(url_for("cascade_page"))


@app.get("/api/cascade")
def api_cascade():
    return jsonify(cascade.diagnose(current_adapter()))


@app.get("/obfuscation")
def obfuscation_page():
    action = actions.action_obfuscation_status(current_server_id(), actor=actor())
    return render_template("obfuscation.html", obf=action.get("data", {}).get("obfuscation") or {}, **pop_flash())


@app.get("/provisioner")
def provisioner_page():
    ssh_servers = [s for s in store.list_servers(include_disabled=False) if s.get("mode") == "ssh"]
    sid = request.args.get("server_id") or (ssh_servers[0]["id"] if ssh_servers else "")
    last = provisioner.read_last(sid) if sid else None
    return render_template("provisioner.html", ssh_servers=ssh_servers, selected_server_id=sid, last=last, **pop_flash())


@app.post("/provisioner/preflight")
def provisioner_preflight():
    sid = request.form.get("server_id", "").strip()
    try:
        pr = provisioner.provisioner_for_server(sid)
        result = pr.preflight()
        audit("provisioner.preflight", sid, {"ok": bool(result.get("ok")), "rc": 0 if result.get("ok") else 1, "text": json.dumps(result.get("data", {}), ensure_ascii=False)})
        if result.get("ok"):
            notice(f"Preflight OK: {sid}")
        else:
            error(f"Preflight failed: {sid}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("provisioner_page", server_id=sid))


@app.post("/provisioner/bootstrap")
def provisioner_bootstrap():
    sid = request.form.get("server_id", "").strip()
    try:
        if request.form.get("confirm") != "BOOTSTRAP":
            raise ValueError("type BOOTSTRAP to confirm remote installation")
        pr = provisioner.provisioner_for_server(sid)
        opts = {
            "port": request.form.get("port", ""),
            "ssh_port": request.form.get("ssh_port", ""),
            "endpoint": request.form.get("endpoint", ""),
            "route_mode": request.form.get("route_mode", "amnezia"),
            "preset": request.form.get("preset", ""),
            "no_tweaks": bool(request.form.get("no_tweaks")),
            "force": bool(request.form.get("force")),
        }
        action = actions.action_provision_server(sid, opts, actor=actor(), confirm=True)
        result = action.get("data", {}).get("result") or action
        text = (result.get("raw") or {}).get("text") or result.get("error") or ""
        audit("provisioner.bootstrap", sid, {"ok": bool(result.get("ok")), "rc": 0 if result.get("ok") else 1, "text": text[:4000]})
        if result.get("ok"):
            notice(f"Bootstrap OK: {sid}")
        else:
            error(f"Bootstrap failed: {sid}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("provisioner_page", server_id=sid))


@app.get("/")
def dashboard():
    status_action = actions.action_status(current_server_id(), actor=actor())
    summary = status_action.get("data", {}).get("summary") or adapter.summary()
    status = status_action.get("data", {}).get("status") or adapter.status()
    doctor = (actions.action_doctor(current_server_id(), actor=actor()).get("data", {}).get("doctor") or adapter.doctor())
    return render_template("dashboard.html", summary=summary, status=status, doctor=doctor, last=adapter.read_last(), audit_rows=store.list_audit(8), **pop_flash())


@app.get("/clients")
def clients_page():
    list_action = actions.action_list_clients(current_server_id(), actor=actor())
    list_result = list_action.get("data", {}).get("result") or {}
    stats_action = actions.action_stats(current_server_id(), actor=actor())
    stats_result = stats_action.get("data", {}).get("result") or {}
    clients = list_action.get("data", {}).get("clients") or parse.clients_from(list_result.get("json"))
    return render_template("clients.html", clients=clients, list_result=list_result, stats_result=stats_result, **pop_flash())


@app.post("/clients/add")
def client_add():
    name = request.form.get("name", "").strip()
    try:
        action = actions.action_add_client(current_server_id(), name, expires=request.form.get("expires", "").strip() or None, psk=bool(request.form.get("psk")), actor=actor())
        result = action.get("data", {}).get("result") or action
        audit("client.add", name, result)
        if action.get("ok"):
            notice(f"Клиент {name} создан")
            return redirect(url_for("client_detail", name=name))
        error(action.get("error") or action.get("message") or "add failed")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("clients_page"))


@app.get("/clients/<name>")
def client_detail(name):
    detail = actions.action_client_detail(current_server_id(), name, actor=actor())
    data = detail.get("data", {})
    return render_template(
        "client.html",
        name=name,
        client=data.get("client"),
        inventory=data.get("inventory") or {},
        conf_text=data.get("conf_text") or "",
        vpnuri_text=data.get("vpnuri_text") or "",
        **pop_flash(),
    )


@app.post("/clients/<name>/remove")
def client_remove(name):
    try:
        action = actions.action_remove_client(current_server_id(), name, actor=actor(), confirm=True)
        result = action.get("data", {}).get("result") or action
        audit("client.remove", name, result)
        if action.get("ok"):
            notice(f"Клиент {name} удалён")
            return redirect(url_for("clients_page"))
        error(action.get("error") or action.get("message") or "remove failed")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.post("/clients/<name>/regen")
def client_regen(name):
    try:
        action = actions.action_regen_client(current_server_id(), name, actor=actor())
        result = action.get("data", {}).get("result") or action
        audit("client.regen", name, result)
        notice("Файлы клиента перегенерированы" if result.get("ok") else result.get("text", "regen failed"))
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.post("/clients/<name>/modify")
def client_modify(name):
    try:
        param = request.form.get("param", "")
        action = actions.action_modify_client(current_server_id(), name, param, request.form.get("value", ""), actor=actor())
        result = action.get("data", {}).get("result") or action
        audit("client.modify", f"{name}:{param}", result)
        notice("Параметр изменён" if action.get("ok") else action.get("error") or action.get("message") or "modify failed")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.get("/clients/<name>/download/<kind>")
def client_download(name, kind):
    if kind not in {"conf", "vpnuri"}:
        return Response("bad kind", status=400)
    action = actions.action_get_client_conf(current_server_id(), name, actor=actor()) if kind == "conf" else actions.action_get_client_vpnuri(current_server_id(), name, actor=actor())
    filename, data = action.get("data", {}).get("filename"), action.get("data", {}).get("bytes")
    if not data:
        return Response(f"{kind} not found", status=404)
    return Response(data, mimetype="text/plain", headers={"Content-Disposition": f"attachment; filename={filename or name + '.' + kind}"})


@app.get("/clients/<name>/bundle.zip")
def client_bundle(name):
    try:
        action = actions.action_get_client_bundle(current_server_id(), name, actor=actor())
        if not action.get("ok"):
            raise FileNotFoundError(action.get("error") or "bundle failed")
        p = action.get("data", {}).get("path")
        return send_file(p, mimetype="application/zip", as_attachment=True, download_name=f"{name}_awgui_bundle.zip")
    except Exception as exc:
        return Response(f"{type(exc).__name__}: {exc}", status=404)


@app.get("/clients/<name>/qr")
def client_qr(name):
    qr_action = actions.action_get_client_qr(current_server_id(), name, actor=actor())
    png_name, png_data = qr_action.get("data", {}).get("filename"), qr_action.get("data", {}).get("bytes")
    if png_data:
        return Response(png_data, mimetype="image/png", headers={"Content-Disposition": f"inline; filename={png_name or name + '.png'}"})
    payload_action = actions.action_qr_payload(current_server_id(), name, request.args.get("source", "vpnuri"), actor=actor())
    source_name = payload_action.get("data", {}).get("source_name")
    source = payload_action.get("data", {}).get("source")
    if not source:
        return Response("QR source not found", status=404)
    try:
        p = subprocess.run(["qrencode", "-t", "SVG", "-m", "2"], input=source, text=True, capture_output=True, timeout=30)
    except FileNotFoundError:
        return Response(manage_adapter.error_svg("qrencode not installed", "sudo apt install -y qrencode"), mimetype="image/svg+xml", status=503)
    if p.returncode != 0:
        return Response(manage_adapter.error_svg("QR failed", p.stderr[:160]), mimetype="image/svg+xml", status=500)
    return Response(p.stdout, mimetype="image/svg+xml", headers={"X-QR-Source": source_name or "unknown"})




@app.get("/traffic")
def traffic_page():
    stats_action = actions.action_stats(current_server_id(), actor=actor())
    stats_result = stats_action.get("data", {}).get("result") or {}
    clients = stats_action.get("data", {}).get("clients") or []
    snapshot_count = 0
    if stats_result.get("ok") and clients:
        snapshot_count = store.record_stats_snapshot(clients, server_id=current_server_id())
    return render_template(
        "traffic.html",
        stats_result=stats_result,
        snapshot_count=snapshot_count,
        overview=store.traffic_overview(server_id=current_server_id()),
        snapshots=store.latest_traffic(160, server_id=current_server_id()),
        **pop_flash(),
    )


@app.get("/expiry")
def expiry_page():
    list_result = adapter.list_clients()
    clients = parse.clients_from(list_result.get("json"))
    temporary = [c for c in clients if str(parse.expires(c) or "-") not in {"", "-", "None", "none"}]
    return render_template("expiry.html", clients=clients, temporary=temporary, list_result=list_result, **pop_flash())


@app.get("/backups")
def backups_page():
    selected = request.args.get("preview", "").strip()
    preview = None
    if selected:
        preview = (actions.action_backup_preview(current_server_id(), selected, actor=actor()).get("data", {}).get("preview")
                   or {"ok": False, "error": "backup not found", "items": []})
    backups = actions.action_list_backups(current_server_id(), actor=actor()).get("data", {}).get("backups") or []
    return render_template("backups.html", backups=backups, selected=selected, preview=preview, **pop_flash())


@app.post("/backups/create")
def backup_create():
    action = actions.action_create_backup(current_server_id(), actor=actor())
    result = action.get("data", {}).get("result") or action
    audit("backup.create", "", result)
    notice("Backup создан" if result.get("ok") else result.get("text", "backup failed"))
    return redirect(url_for("backups_page"))


@app.post("/backups/<name>/restore")
def backup_restore(name):
    action = actions.action_restore_backup(current_server_id(), name, actor=actor(), confirm=True)
    result = action.get("data", {}).get("result") or action
    audit("backup.restore", name, result)
    notice("Restore выполнен" if action.get("ok") else action.get("error") or action.get("message") or "restore failed")
    return redirect(url_for("backups_page", preview=name))


@app.get("/backups/<name>/download")
def backup_download(name):
    action = actions.action_backup_bytes(current_server_id(), name, actor=actor())
    filename, data = action.get("data", {}).get("filename"), action.get("data", {}).get("bytes")
    if not data:
        return Response("backup not found", status=404)
    return Response(data, mimetype="application/gzip", headers={"Content-Disposition": f"attachment; filename={filename or name}"})


@app.get("/diagnostics")
def diagnostics_page():
    carrier = request.args.get("carrier", "").strip() or None
    diag_result = None
    if carrier:
        diag_result = adapter.diagnose(carrier)
        audit("diagnose", carrier, diag_result)
    return render_template("diagnostics.html", doctor=adapter.doctor(), engine_status=engine.server_engine_status(current_adapter()), carriers=config.CARRIERS, selected_carrier=carrier or "", diag_result=diag_result, **pop_flash())


@app.post("/server/action")
def server_action():
    req_action = request.form.get("action", "")
    try:
        if req_action == "check":
            action = actions.action_server_check(current_server_id(), actor=actor())
        elif req_action == "restart":
            action = actions.action_server_restart(current_server_id(), actor=actor(), confirm=True)
        elif req_action == "repair-module":
            action = actions.action_repair_module(current_server_id(), actor=actor(), confirm=True)
        else:
            raise ValueError("unknown server action")
        result = action.get("data", {}).get("result") or action
        audit(f"server.{req_action}", "awg0", result)
        notice(f"{req_action}: {'OK' if action.get('ok') else 'FAIL'}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(request.referrer or url_for("dashboard"))


@app.get("/audit")
def audit_page():
    return render_template("audit.html", rows=store.list_audit(160, server_id=current_server_id()), **pop_flash())


@app.get("/logs")
def logs_page():
    return render_template("logs.html", log_text=adapter.tail_log(800), **pop_flash())


@app.get("/bot")
def bot_page():
    return render_template("bot.html", tg=config.load_telegram_settings(), service=web_support.bot_service_status(), token_check=session.pop("token_check", None), service_action=session.pop("service_action", None), **pop_flash())


@app.post("/bot/save")
def bot_save():
    try:
        tg = config.save_telegram_settings(
            enabled=bool(request.form.get("enabled")),
            token_value=request.form.get("token", ""),
            admin_ids_value=request.form.get("admin_ids", ""),
            send_backup=bool(request.form.get("send_backup")),
            allow_dangerous=bool(request.form.get("allow_dangerous")),
        )
        session["service_action"] = web_support.control_bot_service(bool(tg["enabled"]))
        notice("Telegram настройки сохранены")
        if tg["enabled"]:
            session["token_check"] = web_support.telegram_get_me(str(tg["token"]))
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("bot_page"))


@app.post("/bot/test")
def bot_test():
    token = request.form.get("token", "").strip() or str(config.load_telegram_settings().get("token") or "")
    session["token_check"] = web_support.telegram_get_me(token)
    return redirect(url_for("bot_page"))


@app.post("/bot/restart")
def bot_restart():
    session["service_action"] = web_support.control_bot_service(True)
    notice("awgui-bot перезапущен")
    return redirect(url_for("bot_page"))


@app.get("/api/version")
def api_version():
    return jsonify({"app": config.APP_NAME, "version": config.APP_VERSION, "engine": config.ENGINE_VERSION, "server": current_server_id(), "server_name": current_server().get("name", config.SERVER_NAME)})


@app.get("/api/summary")
def api_summary():
    return jsonify(actions.action_status(current_server_id(), actor=actor()).get("data", {}).get("summary") or adapter.summary())


@app.get("/api/clients")
def api_clients():
    action = actions.action_list_clients(current_server_id(), actor=actor())
    return jsonify({"ok": action.get("ok"), "clients": action.get("data", {}).get("clients") or [], "raw": action.get("data", {}).get("result") or action})


@app.get("/api/stats")
def api_stats():
    action = actions.action_stats(current_server_id(), actor=actor())
    clients = action.get("data", {}).get("clients") or []
    if clients:
        store.record_stats_snapshot(clients, server_id=current_server_id())
    return jsonify({"ok": action.get("ok"), "clients": clients, "raw": action.get("data", {}).get("result") or action})


@app.get("/api/doctor")
def api_doctor():
    return jsonify(actions.action_doctor(current_server_id(), actor=actor()).get("data", {}).get("doctor") or adapter.doctor())


@app.get("/api/audit")
def api_audit():
    return jsonify({"ok": True, "rows": store.list_audit(200, server_id=current_server_id())})


@app.get("/api/bot")
def api_bot():
    tg = config.load_telegram_settings()
    return jsonify({"ok": True, "telegram": {k: v for k, v in tg.items() if k != "token"}, "service": web_support.bot_service_status()})


@app.get("/health")
def health():
    return jsonify({"app": config.APP_NAME, "ok": True, "version": config.APP_VERSION, "engine": config.ENGINE_VERSION})


if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT)
