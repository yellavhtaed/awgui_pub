# AWGUI v8.8.0 — Core Cleanup & Obfuscation Readiness

## Изменено
- Версия поднята до `8.8.0`.
- Сохранена автономная база `full-offline-engine` на upstream `bivlked/amneziawg-installer v5.18.4` / `5.18.4-awgui1`.
- Расширен `actions.py`: добавлены общие действия для stats, doctor, client detail, modify, QR payload, backups, restore/download, server check/show/restart/repair.
- Web routes переведены на общий action-layer там, где раньше напрямую дёргали adapter для повседневных операций.
- Telegram bot переведён ближе к action-layer: server show/check, cascade diagnostics, backup list, QR/conf/vpnuri/bundle, restart/repair идут через actions.
- Telegram транспорт вынесен в `telegram_client.py`: API wrappers, safe send/edit, document/photo send, fallback и long-output handling больше не лежат в основном bot state-machine.
- Web service helpers вынесены в `web_support.py`: systemd actions, bot service status и Telegram getMe.
- `telegram_bot.py` уменьшен примерно с 775 до ~580 строк; `app.py` уменьшен примерно с 715 до ~680 строк без потери функционала.

## Obfuscation readiness
- `/obfuscation` стал полезнее, но остался безопасно read-only.
- Детектируются `Jc/Jmin/Jmax`, `S1-S4`, `H1-H4`, `I1-I5` из live server config и `awgsetup_cfg.init`.
- Для каждого параметра показывается источник.
- Показывается `AWG_PRESET` как last known profile, если он найден.
- Добавлены vendored profile hints из upstream-логики: `default`, `mobile`, `beeline_msk`, `yota_msk`, `tele2_msk`, `tele2_krasnoyarsk`, `tattelecom`, `megafon_regions`, `tmobile_us`.
- Добавлен compatibility guard: обязательные AWG 2.0 параметры, optional I params, J-range sanity, предупреждение о необходимости byte-for-byte совпадения server/client params.
- Добавлен non-destructive safe apply plan: backup → diff → apply → regen → verify.
- Destructive obfuscation apply намеренно не включён в v8.8.0.

## Engine/vendor cleanup
- Из vendored `install_amneziawg.sh` удалён дублирующий upstream `step5_download_scripts()` с runtime-download core scripts.
- Оставлен только AWGUI offline step5, который ставит bundled `awg_common.sh` и `manage_amneziawg.sh` из engine slot.
- Обновлены `MANIFEST.json` и `MANIFEST.sha256` после vendor patch cleanup.

## Проверки
- `py_compile` прошёл для core modules.
- `bash -n` прошёл для shell scripts и vendored engine scripts.
- `scripts/selftest.py` прошёл.
- `scripts/verify_release.py` прошёл.
- Runtime smoke прошёл по основным страницам и API.

## Ограничения
- Реальный чистый VPS / DKMS / apt / UFW / kernel headers bootstrap не проверялся в этой среде.
- `/obfuscation` остаётся read-only: apply будет включён только после полной safe apply реализации с backup/diff/apply/regen/verify.
