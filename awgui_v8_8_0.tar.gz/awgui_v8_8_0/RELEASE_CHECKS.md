# AWGUI v8.8.0 Release Checks

Required checks for this package:

```bash
python3 -m py_compile \
  app.py config.py manage_adapter.py parse.py store.py i18n.py \
  engine.py cascade.py telegram_bot.py telegram_client.py web_support.py \
  provisioner.py actions.py obfuscation.py \
  scripts/selftest.py scripts/verify_release.py

bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh \
  scripts/fake_manage_amneziawg.sh scripts/fake_ssh.sh \
  engine/vendor/bivlked_5_18_4/*.sh

python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
```

Expected:

```text
AWGUI v8.8.0 selftest OK
AWGUI v8.8.0 release gate OK
```

Runtime smoke must cover:

```text
/health / /clients /servers /engine /cascade /obfuscation /provisioner
/traffic /expiry /backups /diagnostics /audit /bot /logs
/api/version /api/cascade /api/summary /api/clients /api/stats /api/doctor /api/audit /api/bot
```

Release gate must fail on:
- wrong `APP_VERSION`;
- non-`full-offline-engine` mode;
- missing vendor files or manifest mismatch;
- normal workflow GitHub/runtime core-script download references;
- SSH deploy via base64 heredoc argv;
- BOM in text files or CRLF in shell scripts;
- missing Engine/Cascade/Obfuscation routes;
- Telegram menu without Servers/Cascade/Engine;
- fake destructive obfuscation apply.
