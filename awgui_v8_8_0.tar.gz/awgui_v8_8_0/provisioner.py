from __future__ import annotations

import json
import re
import shlex
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
import engine
import manage_adapter
import store

PORT_RE = re.compile(r"^[0-9]{1,5}$")
ENDPOINT_RE = re.compile(r"^[A-Za-z0-9_.:\[\]-]{0,255}$")
PRESET_RE = re.compile(r"^(|default|mobile)$")
ROUTE_MODES = {"amnezia", "all", "none"}
SUPPORTED_ID = "ubuntu"
SUPPORTED_VERSION = "24.04"


def _last_path(server_id: str) -> Path:
    safe = re.sub(r"[^A-Za-z0-9_-]", "_", server_id or "local")
    return config.DATA_DIR / f"provisioner_last_{safe}.json"


def save_last(server_id: str, result: Dict[str, Any]) -> None:
    try:
        p = _last_path(server_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def read_last(server_id: str) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(_last_path(server_id).read_text(encoding="utf-8"))
    except Exception:
        return None


def _kv(stdout: str) -> Dict[str, str]:
    data: Dict[str, str] = {}
    for line in (stdout or "").splitlines():
        line = line.strip()
        if not line or "=" not in line:
            continue
        k, v = line.split("=", 1)
        data[k.strip()] = v.strip()
    return data


def _check(name: str, ok: bool, detail: str = "", fix: str = "") -> Dict[str, Any]:
    return {"name": name, "ok": bool(ok), "detail": detail, "fix": fix}


class Provisioner:
    """Controlled SSH bootstrap for a clean Ubuntu 24.04 AWG server.

    KISS boundary: no agent, no Docker, no rewritten installer. The parent
    installer performs AWG/DKMS setup; AWGUI only runs preflight, passes a small
    validated option set, verifies manage_amneziawg.sh, and records audit.
    """

    def __init__(self, server: Dict[str, Any]):
        if not server:
            raise ValueError("server not found")
        if server.get("mode") != "ssh":
            raise ValueError("provisioner works only with SSH servers")
        self.server = server
        self.server_id = str(server.get("id") or "ssh")
        self.ssh = manage_adapter.SSHManageAdapter(server)

    def _shell(self, script: str, timeout: int = 45) -> Dict[str, Any]:
        return self.ssh.shell(script, timeout=timeout, save_last=False)

    def preflight(self) -> Dict[str, Any]:
        script = r'''
set -u
printf 'AWGUI_PROVISIONER_PREFLIGHT=1\n'
printf 'whoami=%s\n' "$(id -un 2>/dev/null || true)"
printf 'uid=%s\n' "$(id -u 2>/dev/null || true)"
if [ -r /etc/os-release ]; then
  . /etc/os-release
  printf 'os_id=%s\n' "${ID:-}"
  printf 'os_version=%s\n' "${VERSION_ID:-}"
  printf 'os_codename=%s\n' "${VERSION_CODENAME:-}"
else
  printf 'os_id=unknown\n'; printf 'os_version=unknown\n'; printf 'os_codename=unknown\n'
fi
printf 'kernel=%s\n' "$(uname -r 2>/dev/null || true)"
printf 'arch=%s\n' "$(uname -m 2>/dev/null || true)"
printf 'disk_mb=%s\n' "$(df -Pm / 2>/dev/null | awk 'NR==2{print $4}' || true)"
for c in bash apt-get systemctl ss awk grep sed tar chmod install sha256sum; do
  if command -v "$c" >/dev/null 2>&1; then printf 'cmd_%s=1\n' "$c"; else printf 'cmd_%s=0\n' "$c"; fi
done
if [ "$(id -u 2>/dev/null || echo 9)" = "0" ]; then
  printf 'privilege=root\n'
elif command -v sudo >/dev/null 2>&1 && sudo -n true >/dev/null 2>&1; then
  printf 'privilege=sudo\n'
else
  printf 'privilege=none\n'
fi
if [ -f /root/awg/manage_amneziawg.sh ]; then printf 'manage=present\n'; else printf 'manage=absent\n'; fi
if command -v awg >/dev/null 2>&1; then printf 'awg=present\n'; else printf 'awg=absent\n'; fi
if command -v systemctl >/dev/null 2>&1; then printf 'awg_service=%s\n' "$(systemctl is-active awg-quick@awg0.service 2>/dev/null || true)"; else printf 'awg_service=unknown\n'; fi
if command -v dkms >/dev/null 2>&1; then printf 'dkms=present\n'; else printf 'dkms=absent\n'; fi
if dpkg-query -W -f='${Status}' "linux-headers-$(uname -r)" 2>/dev/null | grep -q 'ok installed'; then printf 'headers=present\n'; else printf 'headers=unknown\n'; fi
if [ -r /sys/firmware/efi/efivars/SecureBoot-* ]; then printf 'efi=present\n'; else printf 'efi=absent\n'; fi
'''
        raw = self._shell(script, timeout=30)
        data = _kv(raw.get("stdout") or "")
        checks: List[Dict[str, Any]] = []
        checks.append(_check("SSH connectivity", raw.get("ok", False), self.server.get("host", ""), "Check host, port, key and BatchMode SSH login."))
        checks.append(_check("Privilege", data.get("privilege") in {"root", "sudo"}, data.get("privilege", "unknown"), "Use root or passwordless sudo for bootstrap."))
        checks.append(_check("OS", data.get("os_id") == SUPPORTED_ID and data.get("os_version") == SUPPORTED_VERSION, f"{data.get('os_id','?')} {data.get('os_version','?')} ({data.get('os_codename','')})", "AWGUI v8.7 bootstrap is intentionally locked to Ubuntu 24.04 LTS."))
        arch_ok = data.get("arch") in {"x86_64", "aarch64", "arm64"}
        checks.append(_check("Architecture", arch_ok, data.get("arch", "unknown"), "Use amd64 or arm64 Ubuntu 24.04 VPS."))
        try:
            disk_ok = int(data.get("disk_mb") or 0) >= 2048
        except Exception:
            disk_ok = False
        checks.append(_check("Free disk", disk_ok, f"{data.get('disk_mb','?')} MB", "Keep at least 2 GB free for apt/DKMS/kernel headers."))
        for c in ("bash", "apt-get", "systemctl", "ss", "tar", "install", "sha256sum"):
            checks.append(_check(f"command: {c}", data.get(f"cmd_{c}") == "1", "present" if data.get(f"cmd_{c}") == "1" else "missing", f"Install {c} or use a clean Ubuntu 24.04 image."))
        manage_present = data.get("manage") == "present"
        awg_present = data.get("awg") == "present"
        checks.append(_check("parent manager", True, data.get("manage", "unknown"), "If absent, bootstrap can install it."))
        checks.append(_check("awg tool", True, data.get("awg", "unknown"), "If absent, bootstrap can install it."))
        hard_ok = all(c["ok"] for c in checks if c["name"] not in {"parent manager", "awg tool"})
        result = {
            "ok": bool(raw.get("ok") and hard_ok),
            "ready_to_bootstrap": bool(raw.get("ok") and hard_ok and not (manage_present and awg_present)),
            "already_installed": bool(manage_present and awg_present),
            "server_id": self.server_id,
            "server": {k: self.server.get(k) for k in ("id", "name", "mode", "host", "port", "user", "manage_path", "awg_dir", "server_conf")},
            "data": data,
            "checks": checks,
            "raw": raw,
        }
        save_last(self.server_id, result)
        return result

    def _sudo_script(self, script: str, privilege: str) -> str:
        quoted = shlex.quote(script)
        if privilege == "root":
            return f"bash -lc {quoted}"
        if privilege == "sudo":
            return f"sudo -n bash -lc {quoted}"
        raise ValueError("no root/passwordless sudo privilege")

    def build_install_args(self, opts: Dict[str, Any]) -> List[str]:
        args = ["--yes", "--no-color"]
        port = str(opts.get("port") or "").strip()
        if port:
            if not PORT_RE.match(port) or not (1 <= int(port) <= 65535):
                raise ValueError("bad UDP port")
            args.append(f"--port={port}")
        ssh_port = str(opts.get("ssh_port") or "").strip()
        if ssh_port:
            if not PORT_RE.match(ssh_port) or not (1 <= int(ssh_port) <= 65535):
                raise ValueError("bad SSH port")
            args.append(f"--ssh-port={ssh_port}")
        endpoint = str(opts.get("endpoint") or "").strip()
        if endpoint:
            if not ENDPOINT_RE.match(endpoint):
                raise ValueError("bad endpoint")
            args.append(f"--endpoint={endpoint}")
        route_mode = str(opts.get("route_mode") or "amnezia").strip()
        if route_mode not in ROUTE_MODES:
            raise ValueError("bad route mode")
        if route_mode == "amnezia":
            args.append("--route-amnezia")
        elif route_mode == "all":
            args.append("--route-all")
        preset = str(opts.get("preset") or "").strip()
        if preset:
            if not PRESET_RE.match(preset):
                raise ValueError("bad preset")
            args.append(f"--preset={preset}")
        if opts.get("no_tweaks"):
            args.append("--no-tweaks")
        if opts.get("force"):
            args.append("--force")
        return args

    def bootstrap(self, opts: Dict[str, Any]) -> Dict[str, Any]:
        pre = self.preflight()
        if not pre.get("ok"):
            result = {"ok": False, "server_id": self.server_id, "stage": "preflight", "error": "preflight failed", "preflight": pre}
            save_last(self.server_id, result)
            return result
        privilege = pre.get("data", {}).get("privilege") or "none"
        install_args = self.build_install_args(opts)
        started = time.time()
        deployed = engine.deploy_bundled_engine(self.ssh, timeout=120)
        if not deployed.get("ok"):
            result = {"ok": False, "server_id": self.server_id, "stage": "engine_deploy", "install_args": install_args, "duration": round(time.time() - started, 3), "raw": deployed, "scan": {}}
            save_last(self.server_id, result)
            return result
        install_cmd = " ".join(["bash", f"{engine.REMOTE_DIR}/install_amneziawg.sh", *[shlex.quote(a) for a in install_args]])
        root_script = f"""
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
install -d -m 700 /root/awg
printf '[AWGUI] verifying bundled engine manifest\n'
cd {shlex.quote(engine.REMOTE_DIR)}
sha256sum -c MANIFEST.sha256
printf '[AWGUI] running bundled offline engine installer: {install_cmd}\n'
{install_cmd}
printf '[AWGUI] applying/verifying AWGUI engine\n'
bash {shlex.quote(engine.REMOTE_DIR + '/awgui_engine_apply.sh')}
printf '[AWGUI] verifying parent manager\n'
test -f /root/awg/manage_amneziawg.sh
bash /root/awg/manage_amneziawg.sh --no-color --json list >/tmp/awgui_manage_list.json
bash /root/awg/manage_amneziawg.sh --no-color status || true
printf '[AWGUI] bootstrap finished\n'
""".strip()
        remote = self._sudo_script(root_script, privilege)
        raw = self._shell(remote, timeout=int(opts.get("timeout") or 1800))
        scan = self.ssh.scan() if raw.get("ok") else {}
        result = {
            "ok": bool(raw.get("ok") and scan.get("ok")),
            "server_id": self.server_id,
            "stage": "bootstrap",
            "engine": config.ENGINE_VERSION,
            "install_args": install_args,
            "duration": round(time.time() - started, 3),
            "engine_deploy": deployed,
            "raw": raw,
            "scan": scan,
        }
        save_last(self.server_id, result)
        return result


def provisioner_for_server(server_id: str) -> Provisioner:
    srv = store.get_server(server_id)
    if not srv:
        raise ValueError("server not found")
    return Provisioner(srv)
