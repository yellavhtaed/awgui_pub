#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/install.sh"
  exit 1
fi
if [[ ! -f /root/awg/manage_amneziawg.sh ]]; then
  echo "ERROR: /root/awg/manage_amneziawg.sh not found"
  exit 1
fi
apt update
apt install -y python3 python3-venv python3-pip qrencode curl
python3 -m venv "$ROOT/.venv"
"$ROOT/.venv/bin/pip" install -q --upgrade pip
"$ROOT/.venv/bin/pip" install -q -r "$ROOT/requirements.txt"
cat > /etc/systemd/system/awgui.service <<EOF
[Unit]
Description=AWGUI local AmneziaWG panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$ROOT
Environment=AWGUI_TOKEN=dev
ExecStart=$ROOT/.venv/bin/python $ROOT/app.py
Restart=on-failure
RestartSec=2

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now awgui.service
echo "OK: http://127.0.0.1:8080/?token=dev"
systemctl status awgui --no-pager || true
