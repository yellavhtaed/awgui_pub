from pathlib import Path
import os

APP_NAME = "AWGUI"
MANAGE = Path(os.getenv("AWGUI_MANAGE", "/root/awg/manage_amneziawg.sh"))
AWG_DIR = Path(os.getenv("AWGUI_AWG_DIR", "/root/awg"))
HOST = os.getenv("AWGUI_HOST", "127.0.0.1")
PORT = int(os.getenv("AWGUI_PORT", "8080"))
TOKEN = os.getenv("AWGUI_TOKEN", "dev")
LOG_FILE = Path(os.getenv("AWGUI_LOG", str(AWG_DIR / "awgui.log")))
LAST_FILE = Path(os.getenv("AWGUI_LAST", str(AWG_DIR / "awgui-last.json")))
DEFAULT_TIMEOUT = int(os.getenv("AWGUI_TIMEOUT", "240"))
CARRIERS = [
    "beeline_msk",
    "yota_msk",
    "tele2_msk",
    "tele2_krasnoyarsk",
    "tattelecom",
    "megafon_regions",
    "tmobile_us",
]
