def clients_from(payload):
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ("clients", "items", "data", "peers"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
    return []


def name(client):
    if not isinstance(client, dict):
        return "?"
    return (
        client.get("name")
        or client.get("client")
        or client.get("client_name")
        or client.get("clientName")
        or client.get("Name")
        or "?"
    )


def ipv4(client):
    if not isinstance(client, dict):
        return "-"
    return client.get("client_ip") or client.get("ipv4") or client.get("ip") or client.get("address") or "-"


def ipv6(client):
    if not isinstance(client, dict):
        return "-"
    return client.get("client_ipv6") or client.get("ipv6") or "-"


def traffic(client):
    if not isinstance(client, dict):
        return "-"
    return client.get("transfer") or client.get("traffic") or client.get("rx_tx") or client.get("usage") or "-"


def handshake(client):
    if not isinstance(client, dict):
        return "-"
    return client.get("latest_handshake") or client.get("last_handshake") or client.get("handshake") or "-"


def service_state(text):
    text = (text or "").lower()
    if any(x in text for x in ("failed", "inactive", "dead", "error", "not running")):
        return "FAIL"
    if any(x in text for x in ("active", "running", "ok", "listening")):
        return "OK"
    return "UNKNOWN"


def short(text, limit=5000):
    text = text or ""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\n--- cut ---"
