#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/run.sh"
  exit 1
fi
if [[ ! -f /root/awg/manage_amneziawg.sh ]]; then
  echo "ERROR: /root/awg/manage_amneziawg.sh not found"
  exit 1
fi
if [[ ! -d .venv ]]; then
  python3 -m venv .venv
fi
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt
export AWGUI_TOKEN="${AWGUI_TOKEN:-dev}"
exec .venv/bin/python app.py
