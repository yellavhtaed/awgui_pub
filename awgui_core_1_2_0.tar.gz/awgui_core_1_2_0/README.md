# AWGUI Core 1.2.0

AWGUI — компактная Web-панель и Telegram-бот для централизованного управления несколькими серверами AmneziaWG, установленными через `bivlked/amneziawg-installer`.

## Принцип работы

AWGUI не устанавливает, не обновляет и не удаляет AmneziaWG. На каждом управляемом сервере должен находиться рабочий:

```text
/root/awg/manage_amneziawg.sh
```

Все операции с клиентами, ключами, конфигурацией, backup/restore и обслуживанием AWG выполняет именно установленный `manage_amneziawg.sh`. Панель только проверяет его возможности, формирует документированные аргументы, запускает команду локально или по SSH и показывает результат.

На удалённые серверы AWGUI не устанавливается. Один центральный экземпляр управляет всеми узлами по SSH-ключам.

## Возможности

### Единый обзор серверов

Главная страница параллельно и только на чтение показывает для каждого сервера:

- доступность SSH или локального запуска;
- наличие и версию `manage_amneziawg.sh`;
- состояние AWG;
- количество клиентов и активных клиентов;
- суммарные RX/TX;
- AWG binary, модуль, `awg0`, systemd, kernel и DKMS.

Панель читает фактический `help` manager-а и показывает его найденные команды и параметры. Кнопки неподдерживаемых операций не выводятся.

### Клиенты

Web и Telegram дублируют штатные команды:

```text
add remove list stats regen modify
backup restore check status diagnose show restart repair-module help
```

Поддерживаются пакетные операции, срок действия, PSK, `syncconf|restart`, JSON list/stats, carrier-диагностика и клиентские артефакты.

Перегенерация никогда не выполняется одним случайным нажатием:

- выбранные клиенты: подтверждение `REGEN`;
- все клиенты: подтверждение `REGEN ALL` в Web или `--confirm=REGEN-ALL` в Telegram.

Страница клиента показывает только реально найденные файлы:

- `.conf` — inline и кнопка копирования;
- `vpn://` — inline и кнопка копирования;
- обычный QR и QR `vpn://` — оригинальный PNG без повторного кодирования;
- отдельные ссылки на скачивание;
- bundle только из существующих файлов.

QR увеличивается в браузере целым коэффициентом с отключённым сглаживанием, чтобы не размывать модули кода. Содержимое QR генерирует upstream manager, AWGUI его не пересобирает.

### Web-настройки

В разделе «Настройки» доступны:

- смена пароля администратора с проверкой текущего пароля;
- немедленное завершение текущей сессии после смены;
- атомарное сохранение нового пароля и нового session secret;
- Telegram token, admin chat IDs и разрешение опасных действий.

Сохранённый Telegram token не возвращается в HTML и не показывается пользователю повторно.

### Telegram

Бот использует те же Python-вызовы manager-а, что и Web. Опасные операции требуют включения соответствующей настройки и отдельного подтверждения. `regen`, `remove`, `restore`, `restart`, `repair-module` и изменяющие шаги каскада не запускаются из главного меню без промежуточного подтверждения.

### Каскад AWG0 → AWG1

Раздел «Каскад» оркестрирует шаги поставленного официального `CASCADE.md`:

1. проверяет разные серверы и подсети;
2. устанавливает документированные prerequisites на AWG0;
3. создаёт link-client на AWG1 через manager;
4. переносит конфигурацию на AWG0;
5. удаляет только точный ключ `DNS` и устанавливает `Table = off`;
6. отклоняет конфиг без `AllowedIPs = 0.0.0.0/0`, не исправляя его самостоятельно;
7. запускает `awg-quick@awg1`;
8. устанавливает upstream `awg-routing.sh`, меняя только документированные `CLIENT_SUBNET` и `AWG1_ENDPOINT`;
9. запускает routing отдельным подтверждаемым шагом;
10. устанавливает upstream systemd unit без перезаписи отличающегося существующего файла;
11. показывает handshake и состояние правил.

AWGUI не добавляет multi-exit, балансировку, автоматический failover или multi-hop, которых нет в поставленной upstream-инструкции.

## Подготовка удалённого сервера

Сначала отдельно установите AmneziaWG через `bivlked/amneziawg-installer`. Затем на сервере панели настройте ключ:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP \
  'test -x /root/awg/manage_amneziawg.sh && echo OK'
```

Пароли удалённых серверов AWGUI не хранит.

## Установка панели

```bash
tar -xzf awgui_core_1_2_0.tar.gz
cd awgui_core_1_2_0
sudo ./install.sh
```

`install.sh` не принимает параметры. Он проверяет SHA-256, Python/venv, systemd units, bind-порт, запускает обе службы и затем выполняет реальный Web-вход с созданными учётными данными.

После успешной установки логин и пароль выводятся в заметном блоке. Они сохраняются в:

```text
/etc/awgui.env
```

Файл имеет права `0600` и доступен root. Если данные не были сохранены:

```bash
sudo grep -E '^AWGUI_ADMIN_(USER|PASSWORD)=' /etc/awgui.env
```

Пароль также можно изменить после входа: **Настройки → Пароль администратора**.

По умолчанию панель слушает только `127.0.0.1:8080`. Доступ с рабочего компьютера:

```bash
ssh -L 8080:127.0.0.1:8080 root@PANEL_SERVER
```

Откройте `http://127.0.0.1:8080`.

## Автозапуск

Установщик выполняет `systemctl enable --now` и проверяет состояние обеих служб:

```bash
systemctl is-enabled awgui.service awgui-bot.service
systemctl is-active awgui.service awgui-bot.service
```

Ожидается `enabled` и `active` для обеих служб. Telegram-служба остаётся активной без token и ожидает настройки.

## Live acceptance на двух VPS

Скрипт по умолчанию ничего не изменяет и проверяет два уже добавленных сервера:

```bash
sudo /opt/awgui/.venv/bin/python \
  /opt/awgui/tools/live_acceptance.py \
  --entry ru-1 --exit de-1
```

Наблюдение реальных счётчиков во время трафика клиента AWG0:

```bash
sudo /opt/awgui/.venv/bin/python \
  /opt/awgui/tools/live_acceptance.py \
  --entry ru-1 --exit de-1 --observe-seconds 60
```

Реальный reboot-цикл запускается только явным подтверждением и только для SSH-серверов:

```bash
sudo /opt/awgui/.venv/bin/python \
  /opt/awgui/tools/live_acceptance.py \
  --entry ru-1 --exit de-1 \
  --reboot both --confirm-reboot=REBOOT
```

Скрипт проверяет manager/capabilities, состояние каскада, policy route, handshake, изменение iptables-счётчиков и восстановление после reboot. Он не заменяет ручную проверку RU/non-RU egress IP с реального клиента.

## Удаление панели

```bash
sudo /opt/awgui/uninstall.sh
```

С сохранением `/etc/awgui.env` и `/var/lib/awgui`:

```bash
sudo /opt/awgui/uninstall.sh --keep-data
```

Удаление панели не трогает `/root/awg` и установленную AmneziaWG.

## Хранение данных и безопасность

- SQL и отдельный агент не используются;
- inventory, Telegram-настройки и каскады хранятся в JSON;
- межпроцессный `flock`, atomic replace и `fsync` защищают состояние;
- изменяющие manager-команды сериализуются для каждого endpoint;
- SSH работает в `BatchMode=yes` по ключам;
- Web использует сессию, CSRF, `SameSite=Strict`, `HttpOnly`, запрет iframe и no-cache для приватных страниц;
- конфиги и QR не кэшируются браузером через ответы AWGUI;
- загрузка backup ограничена штатными именами `awg_backup_*.tar.gz` и не перезаписывает существующий файл.

## Проверка release

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/pip check
.testvenv/bin/python tests/verify_release.py
```

Автоматические тесты не считаются доказательством реальной DKMS-сборки, reboot сервера, Telegram API или сетевого пути между VPS.
