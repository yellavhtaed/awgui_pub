#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import re
import sys
import time
from pathlib import Path
from typing import Any


def load_environment(path: Path) -> None:
    if not path.is_file():
        raise SystemExit(f"EnvironmentFile не найден: {path}")
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


def parser() -> argparse.ArgumentParser:
    out = argparse.ArgumentParser(
        description="Live acceptance AWGUI для официального каскада bivlked AWG0 → AWG1"
    )
    out.add_argument("--env", default="/etc/awgui.env")
    out.add_argument("--entry", required=True, help="ID входного сервера AWG0")
    out.add_argument("--exit", required=True, help="ID выходного сервера AWG1")
    out.add_argument("--link-name", default="ru_host")
    out.add_argument("--handshake-max-age", type=int, default=180)
    out.add_argument(
        "--observe-seconds",
        type=int,
        default=0,
        help="Сравнить счётчики правил; во время ожидания создайте трафик с AWG-клиента",
    )
    out.add_argument(
        "--public-ip-url",
        default="",
        help="Опциональный URL, возвращающий публичный IP, например https://api.ipify.org",
    )
    out.add_argument(
        "--reboot",
        choices=("none", "entry", "exit", "both"),
        default="none",
        help="Опциональный реальный reboot-цикл; только для SSH-серверов",
    )
    out.add_argument("--confirm-reboot", default="")
    out.add_argument("--reboot-timeout", type=int, default=300)
    return out


class Report:
    def __init__(self) -> None:
        self.failures = 0

    def check(self, title: str, ok: bool, detail: str = "") -> None:
        mark = "PASS" if ok else "FAIL"
        print(f"[{mark}] {title}" + (f": {detail}" if detail else ""))
        if not ok:
            self.failures += 1

    def info(self, title: str, detail: str) -> None:
        print(f"[INFO] {title}: {detail}")


def boot_id(manager: Any) -> str:
    result = manager.runner.run(["cat", "/proc/sys/kernel/random/boot_id"], timeout=20)
    return result.stdout.strip() if result.ok else ""


def wait_for_reboot(manager: Any, old_boot: str, timeout: int) -> tuple[bool, str]:
    deadline = time.monotonic() + timeout
    saw_down = False
    while time.monotonic() < deadline:
        probe = manager.runner.run(["true"], timeout=15)
        if not probe.ok:
            saw_down = True
        else:
            current = boot_id(manager)
            if current and current != old_boot:
                return saw_down, current
        time.sleep(5)
    return False, ""


def reboot_server(name: str, manager: Any, report: Report, timeout: int) -> None:
    if not manager.runner.remote:
        report.check(
            f"Reboot {name}",
            False,
            "локальный сервер запрещён для автоматического reboot",
        )
        return
    previous = boot_id(manager)
    report.check(f"Boot ID до reboot {name}", bool(previous), previous or "не прочитан")
    if not previous:
        return
    issued = manager.runner.run(["systemctl", "reboot", "--no-block"], timeout=20)
    report.check(f"Команда reboot {name}", issued.ok, issued.text)
    if not issued.ok:
        return
    saw_down, current = wait_for_reboot(manager, previous, timeout)
    report.check(f"Сервер {name} действительно отключался", saw_down)
    report.check(
        f"Новый boot ID {name}",
        bool(current and current != previous),
        current or "сервер не вернулся",
    )


def rule_counters(manager: Any, subnet: str) -> dict[str, int]:
    commands = {
        "return": [
            "iptables",
            "-t",
            "mangle",
            "-nvx",
            "-L",
            "PREROUTING",
        ],
        "nat": ["iptables", "-t", "nat", "-nvx", "-L", "POSTROUTING"],
    }
    values = {"return": 0, "mark": 0, "nat": 0}
    result = manager.runner.run(commands["return"], timeout=20)
    if result.ok:
        for line in result.stdout.splitlines():
            fields = line.split()
            if len(fields) < 3 or not fields[0].isdigit() or subnet not in line:
                continue
            packets = int(fields[0])
            if "match-set ru dst" in line and "RETURN" in line:
                values["return"] += packets
            if "MARK" in line and ("0x1" in line or "set 0x1" in line):
                values["mark"] += packets
    result = manager.runner.run(commands["nat"], timeout=20)
    if result.ok:
        for line in result.stdout.splitlines():
            fields = line.split()
            if (
                len(fields) >= 3
                and fields[0].isdigit()
                and subnet in line
                and "MASQUERADE" in line
                and "awg1" in line
            ):
                values["nat"] += int(fields[0])
    return values


def public_ip(manager: Any, url: str) -> str:
    if not url:
        return ""
    result = manager.runner.run(["curl", "-4fsS", "--max-time", "15", url], timeout=20)
    return result.stdout.strip() if result.ok else ""


def run_checks(args: argparse.Namespace) -> int:
    from panel import cascade, state
    from panel.manager import AWGManager

    report = Report()
    if args.entry == args.exit:
        raise SystemExit("ENTRY и EXIT должны быть разными")
    entry_spec = state.get_server(args.entry)
    exit_spec = state.get_server(args.exit)
    if not entry_spec or not exit_spec:
        raise SystemExit("Указанные server ID отсутствуют в AWGUI inventory")
    entry = AWGManager(entry_spec)
    exit_server = AWGManager(exit_spec)

    for title, manager in (("AWG0", entry), ("AWG1", exit_server)):
        summary = manager.summary()
        probe = summary["probe"]
        report.check(
            f"SSH/локальный transport {title}",
            probe["ssh_ok"],
            probe.get("connection_error", ""),
        )
        report.check(
            f"manage_amneziawg.sh {title}",
            probe["manager_present"],
            probe["manager_path"],
        )
        report.check(
            f"manager status {title}",
            bool(probe["status"] and probe["status"].ok),
            probe["status"].text if probe["status"] else "нет результата",
        )
        report.info(
            f"manager version {title}", probe["manager_version"] or "не определена"
        )
        commands = probe["capabilities"]["commands"]
        required = (
            "add",
            "remove",
            "list",
            "stats",
            "regen",
            "backup",
            "restore",
            "status",
        )
        missing = [command for command in required if not commands.get(command)]
        report.check(
            f"обязательные capabilities {title}",
            not missing,
            ", ".join(missing) or "OK",
        )
        report.info(
            f"клиенты {title}",
            f"{summary['active_count']} активных/недавно из {summary['client_count']}",
        )

    steps = cascade.status(entry, exit_server, args.link_name)
    for step in steps:
        ok = step.ok
        if step.key == "handshake" and step.ok:
            match = re.search(r"(\d+) сек", step.detail)
            ok = bool(match and int(match.group(1)) <= args.handshake_max_age)
        report.check(step.title, ok, step.detail)

    route = entry.runner.run(
        ["ip", "-4", "route", "get", "1.1.1.1", "mark", "1"], timeout=20
    )
    report.check(
        "Policy route для mark=1 указывает в awg1",
        route.ok and " dev awg1" in f" {route.stdout}",
        route.text,
    )

    if args.public_ip_url:
        entry_ip = public_ip(entry, args.public_ip_url)
        exit_ip = public_ip(exit_server, args.public_ip_url)
        report.check("Публичный IP AWG0 читается", bool(entry_ip), entry_ip)
        report.check("Публичный IP AWG1 читается", bool(exit_ip), exit_ip)
        if entry_ip and exit_ip:
            report.info("Публичные IP", f"AWG0={entry_ip}, AWG1={exit_ip}")

    subnet = entry.server_subnet()
    if args.observe_seconds > 0:
        if not subnet:
            report.check("Наблюдение счётчиков", False, "не определена подсеть AWG0")
        else:
            before = rule_counters(entry, subnet)
            report.info(
                "Наблюдение",
                f"создайте RU и зарубежный трафик с клиента AWG0 в течение {args.observe_seconds} сек.",
            )
            time.sleep(args.observe_seconds)
            after = rule_counters(entry, subnet)
            report.info("Счётчики до", str(before))
            report.info("Счётчики после", str(after))
            report.check("Счётчик MARK вырос", after["mark"] > before["mark"])
            report.check("Счётчик NAT awg1 вырос", after["nat"] > before["nat"])
            report.check("Счётчик RU RETURN вырос", after["return"] > before["return"])

    if args.reboot != "none":
        if args.confirm_reboot != "REBOOT":
            raise SystemExit("Для reboot-цикла требуется --confirm-reboot=REBOOT")
        order = []
        if args.reboot in {"exit", "both"}:
            order.append(("AWG1", exit_server))
        if args.reboot in {"entry", "both"}:
            order.append(("AWG0", entry))
        for name, manager in order:
            reboot_server(name, manager, report, args.reboot_timeout)
            post = manager.run_manage("status", timeout=90)
            report.check(f"manager status после reboot {name}", post.ok, post.text)
            if name == "AWG1":
                deadline = time.monotonic() + args.handshake_max_age
                recovered = False
                detail = ""
                while time.monotonic() < deadline:
                    handshake_step = next(
                        step
                        for step in cascade.status(entry, exit_server, args.link_name)
                        if step.key == "handshake"
                    )
                    detail = handshake_step.detail
                    if handshake_step.ok:
                        recovered = True
                        break
                    time.sleep(5)
                report.check(
                    "Handshake восстановился после reboot AWG1", recovered, detail
                )

    print()
    print(
        f"ИТОГ: {'PASS' if report.failures == 0 else 'FAIL'}; ошибок: {report.failures}"
    )
    return 0 if report.failures == 0 else 1


def main() -> int:
    args = parser().parse_args()
    load_environment(Path(args.env))
    base = os.environ.get("AWGUI_BASE_DIR", "/opt/awgui")
    if base not in sys.path:
        sys.path.insert(0, base)
    return run_checks(args)


if __name__ == "__main__":
    raise SystemExit(main())
