from __future__ import annotations

import fcntl
import hashlib
import io
import json
import re
import shlex
import tarfile
from contextlib import contextmanager
from ipaddress import ip_interface
from pathlib import Path
from typing import Any, Iterable

from . import config
from .runner import Result, Runner

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,63}$")
_SERVER_ID_RE = re.compile(r"^[a-zA-Z0-9_.-]{1,48}$")
_ALLOWED_EXPIRES = {"", "1h", "12h", "1d", "7d", "30d", "4w"}
_ALLOWED_MODIFY = {"DNS", "Endpoint", "AllowedIPs", "PersistentKeepalive"}
_ALLOWED_APPLY = {"syncconf", "restart"}
_MUTATING_MANAGE = {
    "add",
    "remove",
    "regen",
    "modify",
    "backup",
    "restore",
    "restart",
    "repair-module",
}
_ALLOWED_MANAGE = {
    "add",
    "remove",
    "list",
    "stats",
    "regen",
    "modify",
    "backup",
    "restore",
    "check",
    "status",
    "diagnose",
    "show",
    "restart",
    "repair-module",
    "help",
}

_CAPABILITY_COMMANDS = (
    "add",
    "remove",
    "list",
    "stats",
    "regen",
    "modify",
    "backup",
    "restore",
    "check",
    "status",
    "diagnose",
    "show",
    "restart",
    "repair-module",
    "help",
)
_CAPABILITY_OPTIONS = (
    "--json",
    "--verbose",
    "--expires",
    "--psk",
    "--yes",
    "--carrier",
    "--apply-mode",
    "--conf-dir",
    "--server-conf",
)


def valid_server_id(value: str) -> str:
    value = (value or "").strip()
    if not _SERVER_ID_RE.fullmatch(value):
        raise ValueError(
            "ID сервера: только буквы, цифры, точка, дефис и подчёркивание"
        )
    return value


def make_ssh_server(
    server_id: str,
    host: str,
    *,
    port: int = 22,
    user: str = "root",
    key_path: str = "",
    name: str = "",
    manage_path: str = "",
    awg_dir: str = "",
    server_conf: str = "",
) -> dict[str, Any]:
    sid = valid_server_id(server_id)
    if sid == "local":
        raise ValueError("ID local зарезервирован")
    host = host.strip()
    user = user.strip()
    key_path = key_path.strip()
    if any(ord(ch) < 32 for ch in key_path):
        raise ValueError("Некорректный SSH key path")
    if not re.fullmatch(r"[A-Za-z0-9_.:\-\[\]]{1,255}", host):
        raise ValueError("Некорректный host")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,31}", user):
        raise ValueError("Некорректный SSH user")
    if not 1 <= int(port) <= 65535:
        raise ValueError("Некорректный SSH-порт")
    if key_path and not Path(key_path).is_absolute():
        raise ValueError("SSH key path должен быть абсолютным")
    paths = {
        "manage_path": manage_path or config.LOCAL_MANAGE,
        "awg_dir": awg_dir or config.LOCAL_AWG_DIR,
        "server_conf": server_conf or config.LOCAL_SERVER_CONF,
    }
    for label, value in paths.items():
        if not Path(value).is_absolute() or any(ord(ch) < 32 for ch in value):
            raise ValueError(f"Некорректный путь: {label}")
    display_name = (name or sid).strip()
    if (
        not display_name
        or len(display_name) > 80
        or any(ord(ch) < 32 for ch in display_name)
    ):
        raise ValueError("Некорректное имя сервера")
    return {
        "id": sid,
        "name": display_name,
        "mode": "ssh",
        "host": host,
        "port": int(port),
        "user": user,
        "key_path": key_path,
        **paths,
    }


def valid_names(values: Iterable[str], *, required: bool = True) -> list[str]:
    names = [v.strip() for v in values if v and v.strip()]
    if required and not names:
        raise ValueError("Укажите имя клиента")
    bad = [name for name in names if not _NAME_RE.fullmatch(name)]
    if bad:
        raise ValueError("Недопустимые имена: " + ", ".join(bad))
    return names


def parse_json(result: Result) -> Result:
    if not result.stdout.strip():
        result.ok = False
        result.stderr = (result.stderr + "\nПустой JSON-ответ").strip()
        return result
    try:
        result.data = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        result.ok = False
        result.stderr = (result.stderr + f"\nНекорректный JSON: {exc}").strip()
    return result


class AWGManager:
    """Тонкий вызов установленного manage_amneziawg.sh без собственной AWG-логики."""

    def __init__(self, server: dict[str, Any]):
        self.server = server
        self.runner = Runner(server)
        self.manage_path = str(server.get("manage_path") or config.LOCAL_MANAGE)
        self.awg_dir = str(server.get("awg_dir") or config.LOCAL_AWG_DIR)
        self.server_conf = str(server.get("server_conf") or config.LOCAL_SERVER_CONF)
        self._installed_cache: bool | None = None
        self._help_cache: Result | None = None
        self._artifact_cache: dict[str, dict[str, str]] = {}

    @contextmanager
    def _operation_lock(self):
        identity = "|".join(
            str(x)
            for x in (
                self.server.get("mode", "local"),
                self.server.get("user", "root"),
                self.server.get("host", "local"),
                self.server.get("port", 22),
                self.manage_path,
            )
        )
        digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        path = config.STATE_DIR / f"operation-{digest}.lock"
        with path.open("a+") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def exists(self, path: str) -> bool:
        return self.runner.run(["test", "-f", path], timeout=20).ok

    def installed(self, *, refresh: bool = False) -> bool:
        if refresh or self._installed_cache is None:
            self._installed_cache = self.exists(self.manage_path)
        return self._installed_cache

    def run_manage(
        self,
        command: str,
        *args: str,
        json_output: bool = False,
        verbose: bool = False,
        expires: str = "",
        psk: bool = False,
        yes: bool = False,
        carrier: str = "",
        apply_mode: str = "syncconf",
        timeout: int | None = None,
    ) -> Result:
        if command not in _ALLOWED_MANAGE:
            return Result(False, 2, command, "", "Команда не разрешена", 0.0)
        if not self.installed():
            return Result(
                False, 127, self.manage_path, "", f"Не найден {self.manage_path}", 0.0
            )
        if expires not in _ALLOWED_EXPIRES:
            return Result(False, 2, command, "", "Недопустимый срок", 0.0)
        if apply_mode not in _ALLOWED_APPLY:
            return Result(False, 2, command, "", "Недопустимый apply-mode", 0.0)
        argv = [
            "bash",
            self.manage_path,
            "--no-color",
            f"--conf-dir={self.awg_dir}",
            f"--server-conf={self.server_conf}",
        ]
        if json_output:
            argv.append("--json")
        if verbose:
            argv.append("--verbose")
        if expires:
            argv.append(f"--expires={expires}")
        if psk:
            argv.append("--psk")
        if yes:
            argv.append("--yes")
        if carrier:
            if carrier not in config.CARRIERS:
                return Result(
                    False, 2, command, "", "Неизвестный операторский профиль", 0.0
                )
            argv.append(f"--carrier={carrier}")
        if command in {"add", "remove", "regen", "modify"}:
            argv.append(f"--apply-mode={apply_mode}")
        argv.extend([command, *[str(x) for x in args]])
        if command in _MUTATING_MANAGE:
            with self._operation_lock():
                result = self.runner.run(argv, timeout=timeout or config.MANAGE_TIMEOUT)
        else:
            result = self.runner.run(argv, timeout=timeout or config.MANAGE_TIMEOUT)
        return parse_json(result) if json_output else result

    def manager_help(self, *, refresh: bool = False) -> Result | None:
        if not self.installed():
            return None
        if refresh or self._help_cache is None:
            self._help_cache = self.run_manage("help", timeout=30)
        return self._help_cache

    def capabilities(self, help_result: Result | None = None) -> dict[str, Any]:
        help_result = help_result or self.manager_help()
        text = help_result.stdout if help_result and help_result.ok else ""
        version_match = re.search(r"\(v([0-9]+(?:\.[0-9]+)+)\)", text)
        commands = {
            command: bool(
                re.search(
                    rf"(?<![A-Za-z0-9_-]){re.escape(command)}(?![A-Za-z0-9_-])", text
                )
            )
            for command in _CAPABILITY_COMMANDS
        }
        options = {option: option in text for option in _CAPABILITY_OPTIONS}
        return {
            "version": version_match.group(1) if version_match else "",
            "commands": commands,
            "options": options,
            "help_ok": bool(help_result and help_result.ok),
        }

    def probe(self, *, include_stats: bool = False) -> dict[str, Any]:
        quoted_manager = shlex.quote(self.manage_path)
        shell = self.runner.run(
            [
                "bash",
                "-lc",
                f"manager=$([ -f {quoted_manager} ] && echo yes || true); "
                "awg_binary=$(command -v awg 2>/dev/null || true); "
                "module=$(lsmod 2>/dev/null | awk '$1==\"amneziawg\"{print $1; exit}' || true); "
                "interface=$( (ip link show awg0 >/dev/null 2>&1 && echo awg0) || true ); "
                "service=$(systemctl is-active awg-quick@awg0.service 2>/dev/null || true); "
                "kernel=$(uname -r 2>/dev/null || true); "
                "dkms=$(dkms status 2>/dev/null | grep -i amnezia | head -1 || true); "
                "boot_id=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null || true); "
                "printf 'manager=%s\nawg_binary=%s\nmodule=%s\ninterface=%s\nservice=%s\nkernel=%s\ndkms=%s\nboot_id=%s\n' "
                '"$manager" "$awg_binary" "$module" "$interface" "$service" "$kernel" "$dkms" "$boot_id"',
            ],
            timeout=30,
        )
        facts: dict[str, str] = {}
        for line in shell.stdout.splitlines():
            key, sep, value = line.partition("=")
            if sep:
                facts[key] = value.strip()
        manager_present = shell.ok and facts.get("manager") == "yes"
        self._installed_cache = manager_present
        help_result = self.manager_help() if manager_present else None
        capabilities = self.capabilities(help_result)
        status = self.run_manage("status", timeout=60) if manager_present else None
        listing = (
            self.run_manage("list", json_output=True, timeout=60)
            if manager_present and capabilities["commands"].get("list")
            else None
        )
        statistics = (
            self.run_manage("stats", json_output=True, timeout=60)
            if include_stats
            and manager_present
            and capabilities["commands"].get("stats")
            and capabilities["options"].get("--json")
            else None
        )
        return {
            "installed": manager_present,
            "manager_present": manager_present,
            "manager_path": self.manage_path,
            "manager_version": capabilities["version"],
            "capabilities": capabilities,
            "status": status,
            "clients": listing,
            "stats": statistics,
            "help": help_result,
            "facts": facts,
            "ssh_ok": shell.ok,
            "connection_error": shell.text if not shell.ok else "",
        }

    def summary(self) -> dict[str, Any]:
        probe = self.probe(include_stats=True)
        clients = (
            probe["clients"].data
            if probe["clients"]
            and probe["clients"].ok
            and isinstance(probe["clients"].data, list)
            else []
        )
        statistics = (
            probe["stats"].data
            if probe["stats"]
            and probe["stats"].ok
            and isinstance(probe["stats"].data, list)
            else []
        )
        active = sum(
            1
            for item in statistics
            if str(item.get("status_code") or "") in {"active", "recent"}
        )
        total_rx = sum(
            int(item.get("rx") or 0)
            for item in statistics
            if str(item.get("rx") or "0").isdigit()
        )
        total_tx = sum(
            int(item.get("tx") or 0)
            for item in statistics
            if str(item.get("tx") or "0").isdigit()
        )
        return {
            "server": dict(self.server),
            "probe": probe,
            "clients": clients,
            "statistics": statistics,
            "client_count": len(clients),
            "active_count": active,
            "total_rx": total_rx,
            "total_tx": total_tx,
            "ok": bool(
                probe["ssh_ok"]
                and probe["manager_present"]
                and probe["status"]
                and probe["status"].ok
            ),
        }

    def list_clients(self) -> Result:
        return self.run_manage("list", json_output=True)

    def stats(self) -> Result:
        return self.run_manage("stats", json_output=True)

    def add(
        self,
        names: Iterable[str],
        *,
        expires: str = "",
        psk: bool = False,
        apply_mode: str = "syncconf",
    ) -> Result:
        return self.run_manage(
            "add", *valid_names(names), expires=expires, psk=psk, apply_mode=apply_mode
        )

    def remove(self, names: Iterable[str], *, apply_mode: str = "syncconf") -> Result:
        return self.run_manage(
            "remove", *valid_names(names), yes=True, apply_mode=apply_mode
        )

    def regen(self, names: Iterable[str], *, apply_mode: str = "syncconf") -> Result:
        clean = valid_names(names, required=False)
        return self.run_manage("regen", *clean, apply_mode=apply_mode)

    def modify(
        self, name: str, parameter: str, value: str, *, apply_mode: str = "syncconf"
    ) -> Result:
        clean = valid_names([name])[0]
        if parameter not in _ALLOWED_MODIFY:
            return Result(False, 2, "modify", "", "Недопустимый параметр", 0.0)
        value = value.strip()
        if not value or any(ch in value for ch in "\r\n\x00"):
            return Result(False, 2, "modify", "", "Недопустимое значение", 0.0)
        return self.run_manage("modify", clean, parameter, value, apply_mode=apply_mode)

    def client_artifact_paths(
        self, name: str, *, refresh: bool = False
    ) -> dict[str, str]:
        clean = valid_names([name])[0]
        if not refresh and clean in self._artifact_cache:
            return dict(self._artifact_cache[clean])
        candidates = {
            "conf": [f"{clean}.conf", f"awg0-client-{clean}.conf"],
            "png": [f"{clean}.png", f"awg0-client-{clean}.png"],
            "vpnuri": [f"{clean}.vpnuri", f"awg0-client-{clean}.vpnuri"],
            "vpnuri_png": [
                f"{clean}.vpnuri.png",
                f"awg0-client-{clean}.vpnuri.png",
            ],
        }
        ordered: list[tuple[str, str]] = []
        for kind, filenames in candidates.items():
            for filename in filenames:
                ordered.append((kind, f"{self.awg_dir}/{filename}"))
        script = "; ".join(
            f"[ -f {shlex.quote(path)} ] && printf '%s\t%s\n' {shlex.quote(kind)} {shlex.quote(path)} || true"
            for kind, path in ordered
        )
        result = self.runner.run(["bash", "-lc", script], timeout=30)
        found: dict[str, str] = {}
        if result.ok:
            for line in result.stdout.splitlines():
                kind, sep, path = line.partition("\t")
                if sep and kind in candidates and kind not in found:
                    found[kind] = path
        self._artifact_cache[clean] = found
        return dict(found)

    def client_artifacts(self, name: str) -> dict[str, bool]:
        paths = self.client_artifact_paths(name)
        return {kind: kind in paths for kind in ("conf", "png", "vpnuri", "vpnuri_png")}

    def client_text(self, name: str, kind: str) -> str | None:
        if kind not in {"conf", "vpnuri"}:
            return None
        item = self.client_file(name, kind)
        if not item:
            return None
        return item[1].decode("utf-8", errors="replace").strip()

    def client_path(self, name: str, kind: str) -> str | None:
        clean = valid_names([name])[0]
        if kind not in {"conf", "png", "vpnuri", "vpnuri_png"}:
            return None
        return self.client_artifact_paths(clean).get(kind)

    def client_file(self, name: str, kind: str) -> tuple[str, bytes] | None:
        path = self.client_path(name, kind)
        if not path:
            return None
        data = self.runner.read_file(path)
        return (Path(path).name, data) if data is not None else None

    def client_bundle(self, name: str) -> bytes | None:
        files: list[tuple[str, bytes]] = []
        for kind in ("conf", "png", "vpnuri", "vpnuri_png"):
            item = self.client_file(name, kind)
            if item:
                files.append(item)
        if not files:
            return None
        output = io.BytesIO()
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for filename, data in files:
                info = tarfile.TarInfo(filename)
                info.size = len(data)
                info.mode = 0o600
                archive.addfile(info, io.BytesIO(data))
        return output.getvalue()

    def backup_list(self) -> list[dict[str, Any]]:
        backup_dir = f"{self.awg_dir}/backups"
        command = (
            f"[ -d {shlex.quote(backup_dir)} ] || exit 0; "
            f"find {shlex.quote(backup_dir)} -maxdepth 1 -type f "
            "-name 'awg_backup_*.tar.gz' -printf '%p\t%s\t%T@\n'"
        )
        result = self.runner.run(["bash", "-lc", command], timeout=60)
        if not result.ok:
            return []
        found: dict[str, dict[str, Any]] = {}
        for line in result.stdout.splitlines():
            parts = line.split("\t")
            if len(parts) != 3:
                continue
            path, size, mtime = parts
            try:
                item = {
                    "name": Path(path).name,
                    "path": path,
                    "size": int(size),
                    "mtime": float(mtime),
                }
            except ValueError:
                continue
            found[path] = item
        return sorted(found.values(), key=lambda x: x["mtime"], reverse=True)

    def backup_file(self, name: str) -> tuple[str, bytes] | None:
        if Path(name).name != name:
            return None
        item = next((x for x in self.backup_list() if x["name"] == name), None)
        if not item:
            return None
        data = self.runner.read_file(item["path"])
        return (name, data) if data is not None else None

    def upload_backup(self, filename: str, data: bytes) -> Result:
        safe = Path(filename).name
        if safe != filename or not re.fullmatch(
            r"awg_backup_[A-Za-z0-9_.-]+\.tar\.gz", safe
        ):
            return Result(
                False,
                2,
                "upload backup",
                "",
                "Ожидается штатный файл awg_backup_*.tar.gz",
                0.0,
            )
        target = f"{self.awg_dir}/backups/{safe}"
        if self.exists(target):
            return Result(
                False,
                2,
                "upload backup",
                "",
                f"Бэкап {safe} уже существует; файл не перезаписан",
                0.0,
            )
        return self.runner.write_file(target, data, mode=0o600)

    def server_subnet(self) -> str | None:
        data = self.runner.read_file(self.server_conf)
        if not data:
            return None
        text = data.decode("utf-8", errors="replace")
        match = re.search(r"^Address\s*=\s*([0-9.]+/\d+)", text, re.MULTILINE)
        if not match:
            return None
        try:
            return str(ip_interface(match.group(1)).network)
        except ValueError:
            return None
