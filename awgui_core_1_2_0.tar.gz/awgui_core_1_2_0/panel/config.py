from __future__ import annotations

import os
from pathlib import Path

APP_VERSION = "1.2.0"
BASE_DIR = Path(os.environ.get("AWGUI_BASE_DIR", "/opt/awgui"))
VENDOR_DIR = Path(
    os.environ.get("AWGUI_VENDOR_DIR", str(BASE_DIR / "vendor" / "bivlked"))
)
STATE_DIR = Path(os.environ.get("AWGUI_STATE_DIR", "/var/lib/awgui"))
STATE_FILE = Path(os.environ.get("AWGUI_STATE_FILE", str(STATE_DIR / "state.json")))
STATE_LOCK_FILE = Path(
    os.environ.get("AWGUI_STATE_LOCK_FILE", str(STATE_DIR / "state.lock"))
)
ENV_FILE = Path(os.environ.get("AWGUI_ENV_FILE", "/etc/awgui.env"))
HOST = os.environ.get("AWGUI_HOST", "127.0.0.1")
PORT = int(os.environ.get("AWGUI_PORT", "8080"))
ADMIN_USER = os.environ.get("AWGUI_ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("AWGUI_ADMIN_PASSWORD", "")
SECRET_KEY = os.environ.get("AWGUI_SECRET_KEY", "")
SSH_BIN = os.environ.get("AWGUI_SSH_BIN", "ssh")
SYSTEMCTL_BIN = os.environ.get("AWGUI_SYSTEMCTL_BIN", "/usr/bin/systemctl")
MANAGE_TIMEOUT = int(os.environ.get("AWGUI_MANAGE_TIMEOUT", "900"))
MAX_UPLOAD_BYTES = int(os.environ.get("AWGUI_MAX_UPLOAD_BYTES", str(64 * 1024 * 1024)))
LOCAL_MANAGE = "/root/awg/manage_amneziawg.sh"
LOCAL_AWG_DIR = "/root/awg"
LOCAL_SERVER_CONF = "/etc/amnezia/amneziawg/awg0.conf"
CARRIERS = [
    "beeline_msk",
    "yota_msk",
    "tele2_msk",
    "tele2_krasnoyarsk",
    "tattelecom",
    "megafon_regions",
    "tmobile_us",
]
