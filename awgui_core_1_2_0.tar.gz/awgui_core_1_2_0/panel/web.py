from __future__ import annotations

import hmac
import io
import re
import secrets
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from functools import wraps
from typing import Any, Callable, TypeVar
from urllib.parse import urlsplit

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

from . import cascade, config, state
from .envfile import update_env_file
from .manager import AWGManager, Result, make_ssh_server, valid_names

F = TypeVar("F", bound=Callable)


def _manager(server_id: str | None = None) -> AWGManager:
    sid = server_id or str(session.get("server_id") or "local")
    server = state.get_server(sid) or state.get_server("local")
    if server is None:
        raise RuntimeError("В конфигурации AWGUI отсутствует локальный сервер")
    return AWGManager(server)


def _split_names(value: str) -> list[str]:
    return [x for x in value.replace(",", " ").split() if x]


def _clean(value: str, label: str) -> str:
    value = (value or "").strip()
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"Недопустимое значение: {label}")
    return value


def _merge_client_stats(
    clients: list[dict[str, Any]], statistics: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    stats_by_name = {
        str(item.get("name")): item
        for item in statistics
        if isinstance(item, dict) and item.get("name")
    }
    rows: list[dict[str, Any]] = []
    for client in clients:
        row = dict(client)
        stat = stats_by_name.get(str(client.get("name") or ""))
        if stat:
            row.update(stat)
        rows.append(row)
    return rows


def _safe_local_url(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urlsplit(value)
    if (
        parsed.scheme
        or parsed.netloc
        or not parsed.path.startswith("/")
        or parsed.path.startswith("//")
    ):
        return None
    return value


def _human_bytes(value: Any) -> str:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return str(value or "0")
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    amount = float(number)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.0f} {unit}" if unit == "B" else f"{amount:.2f} {unit}"
        amount /= 1024
    return f"{number} B"


def _handshake(value: Any) -> str:
    try:
        epoch = int(value)
    except (TypeError, ValueError):
        return "—" if not value else str(value)
    if epoch <= 0:
        return "—"
    age = max(0, int(time.time()) - epoch)
    if age < 60:
        return f"{age} сек. назад"
    if age < 3600:
        return f"{age // 60} мин. назад"
    if age < 86400:
        return f"{age // 3600} ч. назад"
    return f"{age // 86400} дн. назад"


def _summary_for(server: dict[str, Any]) -> dict[str, Any]:
    try:
        return AWGManager(server).summary()
    except Exception as exc:  # boundary: one dead server must not break the overview
        return {
            "server": dict(server),
            "probe": {
                "ssh_ok": False,
                "manager_present": False,
                "manager_version": "",
                "capabilities": {"commands": {}, "options": {}},
                "facts": {},
                "status": None,
                "connection_error": str(exc),
            },
            "clients": [],
            "statistics": [],
            "client_count": 0,
            "active_count": 0,
            "total_rx": 0,
            "total_tx": 0,
            "ok": False,
        }


def _all_summaries() -> list[dict[str, Any]]:
    servers = state.list_servers()
    if not servers:
        return []
    workers = min(8, len(servers))
    with ThreadPoolExecutor(
        max_workers=workers, thread_name_prefix="awgui-overview"
    ) as pool:
        return list(pool.map(_summary_for, servers))


def _valid_new_password(value: str) -> str:
    if not 12 <= len(value) <= 128:
        raise ValueError("Новый пароль должен содержать от 12 до 128 символов")
    if any(ch.isspace() or ord(ch) < 33 or ord(ch) > 126 for ch in value):
        raise ValueError(
            "Пароль должен состоять из печатных ASCII-символов без пробелов"
        )
    if any(ch in value for ch in "'\"\\"):
        raise ValueError("В пароле нельзя использовать кавычки и обратный слеш")
    return value


def create_app() -> Flask:
    if not config.ADMIN_PASSWORD or not config.SECRET_KEY:
        raise RuntimeError(
            "AWGUI_ADMIN_PASSWORD and AWGUI_SECRET_KEY must be configured"
        )
    app = Flask(__name__)
    app.secret_key = config.SECRET_KEY
    app.config.update(
        MAX_CONTENT_LENGTH=config.MAX_UPLOAD_BYTES,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
    )
    app.jinja_env.filters["human_bytes"] = _human_bytes
    app.jinja_env.filters["handshake"] = _handshake

    def login_required(fn: F) -> F:
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get("authenticated"):
                return redirect(url_for("login", next=request.path))
            return fn(*args, **kwargs)

        return wrapped  # type: ignore[return-value]

    def csrf_token() -> str:
        token = session.get("csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["csrf_token"] = token
        return token

    @app.before_request
    def csrf_check():
        if request.method == "POST" and request.endpoint != "login":
            expected = session.get("csrf_token", "")
            supplied = request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(str(expected), str(supplied)):
                abort(400, "CSRF")

    @app.after_request
    def sensitive_no_cache(response):
        if request.endpoint not in {"health"}:
            response.headers["Cache-Control"] = "no-store, max-age=0"
            response.headers["Pragma"] = "no-cache"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.context_processor
    def context() -> dict[str, Any]:
        servers = state.list_servers()
        sid = str(session.get("server_id") or "local")
        active = state.get_server(sid) or state.get_server("local")
        return {
            "version": config.APP_VERSION,
            "csrf_token": csrf_token,
            "servers": servers,
            "active_server": active,
        }

    def show_result(result: Result | None) -> dict[str, Any] | None:
        if result is None:
            return None
        return {
            "ok": result.ok,
            "rc": result.rc,
            "command": result.command,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "duration": result.duration,
        }

    @app.get("/health")
    def health():
        manager = _manager("local")
        return {
            "panel": "ok",
            "version": config.APP_VERSION,
            "local_awg_installed": manager.installed(),
        }

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            user_ok = hmac.compare_digest(
                request.form.get("username", ""), config.ADMIN_USER
            )
            pass_ok = hmac.compare_digest(
                request.form.get("password", ""), config.ADMIN_PASSWORD
            )
            if user_ok and pass_ok:
                session.clear()
                session["authenticated"] = True
                session["server_id"] = "local"
                next_url = request.args.get("next", "")
                return redirect(_safe_local_url(next_url) or url_for("dashboard"))
            flash("Неверный логин или пароль", "error")
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    @app.post("/select-server")
    @login_required
    def select_server():
        sid = request.form.get("server_id", "local")
        if not state.get_server(sid):
            abort(404)
        session["server_id"] = sid
        return redirect(
            _safe_local_url(request.form.get("next")) or url_for("dashboard")
        )

    @app.get("/")
    @login_required
    def dashboard():
        summaries = _all_summaries()
        active_id = str(session.get("server_id") or "local")
        active_summary = next(
            (item for item in summaries if item["server"].get("id") == active_id),
            summaries[0] if summaries else None,
        )
        if active_summary is None:
            abort(500, "Нет серверов в inventory")
        probe = active_summary["probe"]
        clients = _merge_client_stats(
            active_summary["clients"], active_summary["statistics"]
        )
        return render_template(
            "dashboard.html",
            overview=summaries,
            probe=probe,
            clients=clients,
            stats=active_summary["statistics"],
            error=(
                None
                if not probe.get("clients") or probe["clients"].ok
                else probe["clients"].text
            ),
        )

    @app.route("/clients", methods=["GET", "POST"])
    @login_required
    def clients():
        manager = _manager()
        result: Result | None = None
        if request.method == "POST":
            try:
                action = request.form.get("action", "")
                apply_mode = request.form.get("apply_mode", "syncconf")
                if action == "add":
                    result = manager.add(
                        _split_names(request.form.get("names", "")),
                        expires=request.form.get("expires", ""),
                        psk=bool(request.form.get("psk")),
                        apply_mode=apply_mode,
                    )
                elif action == "remove":
                    if request.form.get("confirm") != "REMOVE":
                        raise ValueError("Введите REMOVE")
                    result = manager.remove(
                        _split_names(request.form.get("names", "")),
                        apply_mode=apply_mode,
                    )
                elif action == "regen":
                    names = _split_names(request.form.get("names", ""))
                    required = "REGEN" if names else "REGEN ALL"
                    if request.form.get("confirm") != required:
                        raise ValueError(f"Для подтверждения введите {required}")
                    result = manager.regen(names, apply_mode=apply_mode)
                elif action == "modify":
                    result = manager.modify(
                        request.form.get("name", ""),
                        request.form.get("parameter", ""),
                        request.form.get("value", ""),
                        apply_mode=apply_mode,
                    )
                elif action == "list_verbose":
                    result = manager.run_manage("list", verbose=True)
                elif action == "stats_raw":
                    result = manager.run_manage("stats")
                else:
                    raise ValueError("Неизвестная операция")
            except ValueError as exc:
                flash(str(exc), "error")
        listing = manager.list_clients()
        statistics = manager.stats()
        listed_clients = (
            listing.data if listing.ok and isinstance(listing.data, list) else []
        )
        client_stats = (
            statistics.data
            if statistics.ok and isinstance(statistics.data, list)
            else []
        )
        capabilities = manager.capabilities()
        return render_template(
            "clients.html",
            installed=manager.installed(),
            capabilities=capabilities,
            clients=_merge_client_stats(listed_clients, client_stats),
            stats=client_stats,
            list_error=None if listing.ok else listing.text,
            stats_error=None if statistics.ok else statistics.text,
            result=show_result(result),
        )

    @app.get("/clients/<name>")
    @login_required
    def client_detail(name: str):
        try:
            clean = valid_names([name])[0]
            manager = _manager()
            artifacts = manager.client_artifacts(clean)
            conf_text = (
                manager.client_text(clean, "conf") if artifacts["conf"] else None
            )
            vpn_uri = (
                manager.client_text(clean, "vpnuri") if artifacts["vpnuri"] else None
            )
        except ValueError:
            abort(404)
        return render_template(
            "client_detail.html",
            name=clean,
            capabilities=manager.capabilities(),
            artifacts=artifacts,
            conf_text=conf_text,
            vpn_uri=vpn_uri,
        )

    @app.get("/clients/<name>/file/<kind>")
    @login_required
    def client_file(name: str, kind: str):
        try:
            item = _manager().client_file(name, kind)
        except ValueError:
            item = None
        if not item:
            abort(404)
        filename, data = item
        mimetypes = {
            "conf": "text/plain; charset=utf-8",
            "png": "image/png",
            "vpnuri": "text/plain; charset=utf-8",
            "vpnuri_png": "image/png",
        }
        return send_file(
            io.BytesIO(data),
            as_attachment=request.args.get("download") == "1",
            download_name=filename,
            mimetype=mimetypes.get(kind, "application/octet-stream"),
        )

    @app.get("/clients/<name>/bundle")
    @login_required
    def client_bundle(name: str):
        try:
            data = _manager().client_bundle(name)
        except ValueError:
            data = None
        if not data:
            abort(404)
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=f"{name}-bundle.tar.gz",
            mimetype="application/gzip",
        )

    def server_page(result: Result | None = None):
        manager = _manager()
        return render_template(
            "servers.html",
            manager=manager,
            probe=manager.probe(include_stats=True),
            backups=manager.backup_list(),
            result=show_result(result),
        )

    @app.get("/servers")
    @login_required
    def servers_page():
        return server_page()

    @app.post("/servers/add")
    @login_required
    def server_add():
        try:
            server = make_ssh_server(
                request.form.get("id", ""),
                _clean(request.form.get("host", ""), "host"),
                port=int(request.form.get("port", "22")),
                user=_clean(request.form.get("user", "root"), "user"),
                key_path=_clean(request.form.get("key_path", ""), "key_path"),
                name=_clean(request.form.get("name", ""), "name"),
                manage_path=_clean(
                    request.form.get("manage_path", config.LOCAL_MANAGE), "manage_path"
                ),
                awg_dir=_clean(
                    request.form.get("awg_dir", config.LOCAL_AWG_DIR), "awg_dir"
                ),
                server_conf=_clean(
                    request.form.get("server_conf", config.LOCAL_SERVER_CONF),
                    "server_conf",
                ),
            )
            state.upsert_server(server)
            flash("Сервер сохранён", "success")
        except (ValueError, TypeError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("servers_page"))

    @app.post("/servers/delete")
    @login_required
    def server_delete():
        sid = request.form.get("server_id", "")
        if request.form.get("confirm") != "DELETE" or not state.delete_server(sid):
            flash("Сервер не удалён: проверьте ID и подтверждение DELETE", "error")
        else:
            if session.get("server_id") == sid:
                session["server_id"] = "local"
            flash("Сервер удалён из панели; AWG на нём не изменён", "success")
        return redirect(url_for("servers_page"))

    @app.post("/servers/action")
    @login_required
    def server_action():
        manager = _manager()
        action = request.form.get("action", "")
        result: Result | None = None
        try:
            if action == "probe":
                result = (
                    manager.run_manage("status", timeout=60)
                    if manager.installed()
                    else Result(
                        False,
                        127,
                        manager.manage_path,
                        "",
                        f"Не найден установленный {manager.manage_path}",
                        0.0,
                    )
                )
            elif action in {"status", "check", "show", "help", "backup"}:
                result = manager.run_manage(action)
            elif action == "diagnose":
                result = manager.run_manage(
                    "diagnose", carrier=request.form.get("carrier", ""), timeout=900
                )
            elif action in {"restart", "repair-module"}:
                if request.form.get("confirm") != "RUN":
                    raise ValueError("Введите RUN")
                result = manager.run_manage(action, yes=True, timeout=1800)
            else:
                raise ValueError("Неизвестное действие")
        except ValueError as exc:
            flash(str(exc), "error")
        return server_page(result)

    @app.post("/servers/restore")
    @login_required
    def server_restore():
        manager = _manager()
        if request.form.get("confirm") != "RESTORE":
            flash("Введите RESTORE", "error")
            return server_page()
        name = request.form.get("backup", "")
        item = next((x for x in manager.backup_list() if x["name"] == name), None)
        if not item:
            flash("Бэкап не найден", "error")
            return server_page()
        return server_page(
            manager.run_manage("restore", item["path"], yes=True, timeout=1800)
        )

    @app.post("/servers/upload-backup")
    @login_required
    def server_upload_backup():
        upload = request.files.get("backup")
        if not upload or not upload.filename:
            flash("Выберите .tar.gz", "error")
        else:
            result = _manager().upload_backup(upload.filename, upload.read())
            flash(
                "Бэкап загружен" if result.ok else result.text,
                "success" if result.ok else "error",
            )
        return redirect(url_for("servers_page"))

    @app.get("/servers/backups/<name>")
    @login_required
    def backup_download(name: str):
        item = _manager().backup_file(name)
        if not item:
            abort(404)
        filename, data = item
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=filename,
            mimetype="application/gzip",
        )

    def cascade_page(result: Result | None = None):
        servers = state.list_servers()
        entry_id = request.values.get("entry_id") or str(
            session.get("cascade_entry") or "local"
        )
        exit_id = request.values.get("exit_id") or str(
            session.get("cascade_exit")
            or (servers[1]["id"] if len(servers) > 1 else "local")
        )
        link_name = request.values.get("link_name") or "ru_host"
        session["cascade_entry"], session["cascade_exit"] = entry_id, exit_id
        entry_spec, exit_spec = state.get_server(entry_id), state.get_server(exit_id)
        steps = []
        if entry_spec and exit_spec and entry_id != exit_id:
            try:
                steps = cascade.status(
                    AWGManager(entry_spec), AWGManager(exit_spec), link_name
                )
            except ValueError as exc:
                flash(str(exc), "error")
        return render_template(
            "cascade.html",
            entry_id=entry_id,
            exit_id=exit_id,
            link_name=link_name,
            steps=steps,
            result=show_result(result),
        )

    @app.route("/cascade", methods=["GET", "POST"])
    @login_required
    def cascade_view():
        if request.method == "GET":
            return cascade_page()
        entry_id, exit_id = (
            request.form.get("entry_id", ""),
            request.form.get("exit_id", ""),
        )
        link_name = request.form.get("link_name", "ru_host")
        if entry_id == exit_id:
            flash("AWG0 и AWG1 должны быть разными серверами", "error")
            return cascade_page()
        entry_spec, exit_spec = state.get_server(entry_id), state.get_server(exit_id)
        if not entry_spec or not exit_spec:
            abort(404)
        entry, exit_server = AWGManager(entry_spec), AWGManager(exit_spec)
        action = request.form.get("action", "")
        result: Result | None = None
        try:
            if action == "prerequisites":
                result = cascade.install_prerequisites(entry)
            elif action == "create_link":
                result = cascade.create_link_client(exit_server, link_name)
            elif action == "transfer_conf":
                result = cascade.transfer_link_config(entry, exit_server, link_name)
            elif action == "start_tunnel":
                result = cascade.start_link_tunnel(entry)
            elif action == "install_routing":
                result = cascade.install_routing(entry)
            elif action == "run_routing":
                if request.form.get("confirm") != "ROUTE":
                    raise ValueError("Введите ROUTE")
                result = cascade.run_routing(entry)
            elif action == "enable_service":
                if request.form.get("confirm") != "ENABLE":
                    raise ValueError("Введите ENABLE")
                result = cascade.enable_routing_service(entry)
            else:
                raise ValueError("Неизвестный шаг каскада")
        except ValueError as exc:
            flash(str(exc), "error")
        return cascade_page(result)

    @app.route("/settings", methods=["GET", "POST"])
    @login_required
    def settings_page():
        if request.method == "POST":
            action = request.form.get("action", "telegram")
            if action == "password":
                current = request.form.get("current_password", "")
                new_password = request.form.get("new_password", "")
                confirmation = request.form.get("new_password_confirm", "")
                if not hmac.compare_digest(current, config.ADMIN_PASSWORD):
                    flash("Текущий пароль неверен", "error")
                elif new_password != confirmation:
                    flash("Новые пароли не совпадают", "error")
                else:
                    try:
                        new_password = _valid_new_password(new_password)
                        new_secret = secrets.token_hex(32)
                        update_env_file(
                            config.ENV_FILE,
                            {
                                "AWGUI_ADMIN_PASSWORD": new_password,
                                "AWGUI_SECRET_KEY": new_secret,
                            },
                        )
                        config.ADMIN_PASSWORD = new_password
                        config.SECRET_KEY = new_secret
                        app.secret_key = new_secret
                        session.clear()
                        flash(
                            "Пароль изменён. Выполните вход с новым паролем.", "success"
                        )
                        return redirect(url_for("login"))
                    except (OSError, ValueError) as exc:
                        flash(f"Пароль не изменён: {exc}", "error")
            elif action == "telegram":
                try:
                    current_settings = state.telegram_settings()
                    supplied_token = _clean(request.form.get("token", ""), "token")
                    if supplied_token and any(ch.isspace() for ch in supplied_token):
                        raise ValueError("Bot token не должен содержать пробелы")
                    ids = [
                        x.strip()
                        for x in request.form.get("admin_ids", "")
                        .replace(",", " ")
                        .split()
                        if x.strip()
                    ]
                    invalid_ids = [
                        item for item in ids if not re.fullmatch(r"-?\d+", item)
                    ]
                    if invalid_ids:
                        raise ValueError(
                            "Некорректные Telegram chat ID: " + ", ".join(invalid_ids)
                        )
                    token = supplied_token or str(current_settings.get("token", ""))
                    enabled = bool(request.form.get("enabled"))
                    if enabled and (not token or not ids):
                        raise ValueError(
                            "Для включения Telegram укажите bot token и хотя бы один admin chat ID"
                        )
                    settings = {
                        "enabled": enabled,
                        "token": token,
                        "admin_ids": ids,
                        "dangerous": bool(request.form.get("dangerous")),
                    }
                    state.set_telegram(settings)
                    try:
                        restarted = subprocess.run(
                            [config.SYSTEMCTL_BIN, "restart", "awgui-bot.service"],
                            capture_output=True,
                            check=False,
                            timeout=15,
                        )
                        if restarted.returncode == 0:
                            flash("Настройки Telegram сохранены и применены", "success")
                        else:
                            flash(
                                "Настройки сохранены, но awgui-bot.service не перезапущен",
                                "error",
                            )
                    except (OSError, subprocess.TimeoutExpired):
                        flash(
                            "Настройки сохранены, но awgui-bot.service не перезапущен",
                            "error",
                        )
                except ValueError as exc:
                    flash(str(exc), "error")
            else:
                flash("Неизвестная операция настроек", "error")
        telegram_settings = state.telegram_settings()
        return render_template(
            "settings.html",
            telegram=telegram_settings,
            token_configured=bool(telegram_settings.get("token")),
            admin_user=config.ADMIN_USER,
            env_file=str(config.ENV_FILE),
        )

    return app
