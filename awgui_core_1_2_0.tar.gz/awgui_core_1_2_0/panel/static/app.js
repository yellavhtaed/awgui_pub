(() => {
  const root = document.documentElement;
  const saved = localStorage.getItem('awgui-theme') || 'system';
  root.dataset.theme = saved;
  const cycle = { system: 'dark', dark: 'light', light: 'system' };
  document.querySelector('[data-theme-toggle]')?.addEventListener('click', () => {
    const next = cycle[root.dataset.theme || 'system'];
    root.dataset.theme = next;
    localStorage.setItem('awgui-theme', next);
  });

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return;
    }
    const area = document.createElement('textarea');
    area.value = text;
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand('copy');
    area.remove();
    if (!ok) throw new Error('copy failed');
  }

  document.querySelectorAll('[data-copy-target]').forEach((button) => {
    button.addEventListener('click', async () => {
      const target = document.getElementById(button.dataset.copyTarget);
      if (!target) return;
      const original = button.textContent;
      try {
        await copyText(target.value ?? target.textContent ?? '');
        button.textContent = 'Скопировано';
      } catch (_) {
        button.textContent = 'Не удалось скопировать';
      }
      window.setTimeout(() => { button.textContent = original; }, 1800);
    });
  });

  document.querySelectorAll('[data-qr-image]').forEach((image) => {
    image.addEventListener('load', () => {
      const stage = image.closest('.qr-stage');
      const available = Math.max(1, Math.min(620, (stage?.clientWidth || 620) - 44));
      const natural = Math.max(1, image.naturalWidth);
      const scale = Math.max(1, Math.floor(available / natural));
      image.style.width = `${natural * scale}px`;
    });
  });
})();
