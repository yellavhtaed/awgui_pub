from __future__ import annotations

import fcntl
import os
import tempfile
from pathlib import Path
from typing import Mapping


def read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return values
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key:
            values[key] = value.strip().strip("\"'")
    return values


def update_env_file(path: Path, updates: Mapping[str, str]) -> None:
    """Atomically update a simple systemd EnvironmentFile without shell parsing."""
    for key, value in updates.items():
        if not key or "=" in key or any(ch.isspace() for ch in key):
            raise ValueError(f"Некорректное имя переменной: {key!r}")
        if not value or any(ch in value for ch in "\r\n\x00"):
            raise ValueError(f"Некорректное значение {key}")
        if any(ch.isspace() for ch in value) or any(ch in value for ch in "'\"\\"):
            raise ValueError(
                f"{key}: пробелы, кавычки и обратный слеш не поддерживаются"
            )

    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_name(path.name + ".lock")
    with lock_path.open("a+") as lock:
        os.chmod(lock_path, 0o600)
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        values = read_env_file(path)
        order = list(values)
        for key, value in updates.items():
            if key not in values:
                order.append(key)
            values[key] = value

        fd, tmp_name = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                for key in order:
                    handle.write(f"{key}={values[key]}\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, path)
            directory_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
