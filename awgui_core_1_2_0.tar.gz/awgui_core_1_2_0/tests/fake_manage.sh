#!/usr/bin/env bash
set -euo pipefail
AWG_DIR="/tmp/fake_awg"; JSON=0; EXPIRES=""; PSK=0; YES=0
args=()
while (($#)); do
 case "$1" in
  --conf-dir=*) AWG_DIR="${1#*=}";;
  --server-conf=*) ;;
  --json) JSON=1;;
  --expires=*) EXPIRES="${1#*=}";;
  --psk) PSK=1;;
  --yes|--no-color|--verbose|--apply-mode=*|--carrier=*) ;;
  *) args+=("$1");;
 esac
 shift
done
mkdir -p "$AWG_DIR/backups"
cmd="${args[0]:-help}"; shift_args=("${args[@]:1}")
if [[ -n "${FAKE_MANAGE_LOG:-}" ]]; then
  printf '%s\t%s\n' "$cmd" "${shift_args[*]}" >> "$FAKE_MANAGE_LOG"
fi
case "$cmd" in
 add)
  for n in "${shift_args[@]}"; do
    printf '[Interface]\nPrivateKey = fake\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = server\nEndpoint = 192.0.2.1:39743\nAllowedIPs = 0.0.0.0/0\n' > "$AWG_DIR/$n.conf"
    printf 'vpn://%s\n' "$n" > "$AWG_DIR/$n.vpnuri"
    printf 'PNG' > "$AWG_DIR/$n.png"
    printf 'VPNPNG' > "$AWG_DIR/$n.vpnuri.png"
  done
  echo "added ${shift_args[*]}";;
 remove) for n in "${shift_args[@]}"; do rm -f "$AWG_DIR/$n.conf" "$AWG_DIR/$n.png" "$AWG_DIR/$n.vpnuri" "$AWG_DIR/$n.vpnuri.png"; done; echo removed;;
 regen) echo regenerated;;
 modify) echo modified;;
 list)
  if [[ $JSON -eq 1 ]]; then
    printf '['; first=1
    for f in "$AWG_DIR"/*.conf; do [[ -e "$f" ]] || continue; n="$(basename "$f" .conf)"; [[ "$n" == awg0 ]] && continue; [[ $first -eq 1 ]] || printf ','; first=0; printf '{"name":"%s","ip":"10.0.0.2","client_ipv6":"","status":"Активен","status_code":"active"}' "$n"; done
    printf ']\n'
  else echo 'clients'; fi;;
 stats)
  if [[ $JSON -eq 1 ]]; then
    printf '['; first=1
    for f in "$AWG_DIR"/*.conf; do [[ -e "$f" ]] || continue; n="$(basename "$f" .conf)"; [[ "$n" == awg0 ]] && continue; [[ $first -eq 1 ]] || printf ','; first=0; printf '{"name":"%s","ip":"10.0.0.2","rx":1048576,"tx":2097152,"last_handshake":1893456000,"status":"Активен","status_code":"active"}' "$n"; done
    printf ']\n'
  else echo stats; fi;;
 backup) touch "$AWG_DIR/backups/awg_backup_2026-07-10_19-00-00.000.tar.gz"; echo backup;;
 restore) echo restored;;
 status|check) echo 'service active';;
 show) echo 'interface: awg0';;
 diagnose) echo 'diagnose OK';;
 restart) echo restarted;;
 repair-module) echo repaired;;
 help)
  cat <<'EOF'
Скрипт управления AmneziaWG 2.0 (v5.18.4)
Опции:
  --json --verbose --expires=ВРЕМЯ --psk --yes --carrier=NAME --apply-mode=РЕЖИМ --conf-dir=ПУТЬ --server-conf=ПУТЬ
Команды:
  add remove list stats regen modify backup restore check status diagnose show restart repair-module help
EOF
  ;;
 *) echo "unknown $cmd" >&2; exit 1;;
esac
