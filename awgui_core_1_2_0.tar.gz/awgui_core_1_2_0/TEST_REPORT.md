# AWGUI Core 1.2.0 — отчёт проверки

Дата проверки: 2026-07-10.

## Реализовано в этом проходе

- подтверждение `regen`: `REGEN` для выбранных клиентов и `REGEN ALL` для всех;
- аналогичные подтверждения в Telegram;
- inline-просмотр `.conf` и `vpn://` с копированием;
- inline-просмотр оригинальных QR без повторной генерации и размытия;
- смена пароля администратора в Web;
- единый read-only обзор всех серверов;
- версия и capabilities установленного `manage_amneziawg.sh`;
- скрытие unsupported-кнопок Web;
- live acceptance script для двух VPS и явного reboot-цикла;
- выделенный вывод логина/пароля installer-а и документация `/etc/awgui.env`;
- валидация Telegram token/admin IDs без раскрытия сохранённого token.

## Ошибки, найденные и исправленные при аудите

1. `regen` выполнялся без отдельного подтверждения.
2. Клиентские файлы только скачивались; отсутствовали inline-просмотр и копирование.
3. Ссылки на клиентские артефакты могли вести к отсутствующим файлам.
4. В Web отсутствовала смена пароля администратора.
5. Сохранённый Telegram token мог возвращаться в форму.
6. Кнопка «Статус» главного меню Telegram использовала callback без рабочего маршрута.
7. UI показывал команды manager-а без учёта фактического `help`.
8. RX/TX и handshake отображались в сыром формате.
9. Опубликованная ручная команда runtime-check зависела от текущего каталога; документация исправлена на абсолютный путь файла.
10. Telegram можно было включить без пригодного token/admin chat ID; теперь такая настройка отклоняется.

## Автоматические проверки

Пройдены:

- `python -m py_compile` для panel и live acceptance;
- `bash -n` для install/uninstall/upstream routing/test scripts;
- Ruff;
- Black formatting;
- `pip check` в чистом venv;
- `tests/install_contract.py`;
- `tests/selftest.py`;
- `tests/verify_release.py`;
- проверка всех release SHA-256;
- точные SHA-256 поставленного `CASCADE.md`, `awg-routing.sh` и unit;
- проверка CLI-аргументов, формируемых для manager v5.18.4;
- конкурентная запись state несколькими процессами;
- Web auth/session/CSRF и запрет external redirect;
- смена пароля, отказ старого пароля и вход новым;
- отсутствие Telegram token в HTML;
- отказ `regen` без точного подтверждения;
- inline и download headers клиентских файлов;
- Telegram add/remove/modify/regen и callbacks;
- каскадная обработка точных ключей `DNS` и `Table`;
- отказ каскада от non-full-tunnel конфигурации;
- запрет перезаписи отличающегося cascade unit.

## Runtime smoke

С реальными процессами Gunicorn и `panel.telegram` проверено:

- первый запуск;
- `/health`;
- реальный POST login;
- session cookie;
- открытие защищённой главной страницы;
- остановка процессов;
- повторный запуск;
- повторный успешный login.

## Точный install.sh smoke

Итоговый `install.sh` запускался из постороннего каталога. Для отсутствующего в контейнере работающего PID 1 systemd использовался systemctl-emulator, который реально запускал поставленные Gunicorn и bot процессы.

Проверено:

- `sha256sum -c` внутри installer-а;
- создание `/opt/awgui` и venv;
- установка pinned requirements и `pip check`;
- реальный `systemd-analyze verify` сгенерированных units;
- `enable --now` обоих units;
- состояния enabled/active;
- runtime login тем же паролем, который вывел installer;
- остановка и повторный запуск обоих процессов;
- повторный runtime login;
- наличие выделенного логина, пароля и пути `/etc/awgui.env` в выводе.

## Не выдаётся за проверенное

В данной среде не выполнялись:

- физический reboot VPS с настоящим systemd PID 1;
- реальная сборка и загрузка DKMS;
- настоящий Telegram Bot API;
- реальные команды `manage_amneziawg.sh` на AWG-сервере;
- реальный каскадный трафик между двумя VPS и клиентом.

Для этого включён `tools/live_acceptance.py`; его опасный reboot-режим требует явного `--confirm-reboot=REBOOT`.

## Dependency audit

`pip check` пройден. Запуск `pip-audit` был предпринят, но внешний запрос к `pypi.org` не завершился из-за временного DNS failure среды. Поэтому отсутствие известных CVE по результатам `pip-audit` не заявляется.
