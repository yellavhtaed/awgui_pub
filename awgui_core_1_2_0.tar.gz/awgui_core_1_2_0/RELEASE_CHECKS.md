# Release checks 1.2.0

## Автоматические

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/pip check
.testvenv/bin/python tests/verify_release.py
```

Проверяются Python/shell syntax, release hashes, Web login/session/CSRF, смена пароля, regen-confirmation, client artifacts, Telegram callbacks, state concurrency, manager CLI и upstream cascade snapshot.

## Установка и reboot панели

```bash
sudo ./install.sh
systemctl is-enabled awgui.service awgui-bot.service
systemctl is-active awgui.service awgui-bot.service
sudo /opt/awgui/.venv/bin/python /opt/awgui/panel/runtime_check.py /etc/awgui.env
sudo reboot
```

После reboot повторить три проверки и проверить Web/Telegram.

## С установленным bivlked

1. зафиксировать `awg show`, hash `awg0.conf` и время старта `awg-quick@awg0`;
2. установить AWGUI и убедиться, что установка панели не изменила AWG;
3. пройти add/list/stats/modify;
4. убедиться, что regen без точного подтверждения не запускается;
5. пройти подтверждённые regen/remove;
6. открыть `.conf`, `vpn://`, оба QR и bundle;
7. пройти backup/download/upload/restore;
8. повторить ключевые операции через Telegram;
9. проверить локальный и SSH-серверы.

## Две VPS и каскад

```bash
sudo /opt/awgui/.venv/bin/python \
  /opt/awgui/tools/live_acceptance.py --entry ENTRY --exit EXIT
```

Далее проверить с реальным клиентом:

1. egress IP для RU и non-RU адресов;
2. рост RETURN/MARK/NAT счётчиков;
3. reboot AWG0, AWG1 и обоих;
4. восстановление handshake и маршрутизации;
5. несколько независимых направленных пар.

Не отмечать DKMS, reboot или сетевой путь как пройденные без физического стенда.
