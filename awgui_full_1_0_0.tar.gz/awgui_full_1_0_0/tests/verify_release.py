from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

required = [
    ROOT / "panel/web.py", ROOT / "panel/telegram.py", ROOT / "panel/manager.py", ROOT / "panel/runner.py",
    ROOT / "panel/cascade.py", ROOT / "panel/state.py", ROOT / "install.sh", ROOT / "uninstall.sh",
    ROOT / "amneziawg-installer/install_amneziawg.sh",
    ROOT / "amneziawg-installer/manage_amneziawg.sh",
    ROOT / "amneziawg-installer/awg_common.sh",
    ROOT / "amneziawg-installer/awg-routing.sh",
    ROOT / "amneziawg-installer/cascade/ru.zone",
    ROOT / "amneziawg-installer/CASCADE.md",
]
for path in required:
    assert path.is_file(), path

assert (ROOT / "VERSION").read_text().strip() == "1.0.0"
assert 'SCRIPT_VERSION="5.18.4"' in (ROOT / "amneziawg-installer/manage_amneziawg.sh").read_text(errors="replace")
assert 'SCRIPT_VERSION="5.18.4"' in (ROOT / "amneziawg-installer/install_amneziawg.sh").read_text(errors="replace")

# Upstream checksums.
subprocess.run(["sha256sum", "-c", "SHA256SUMS"], cwd=ROOT / "amneziawg-installer", check=True, stdout=subprocess.DEVNULL)

# Syntax and actual CLI contract.
subprocess.run([sys.executable, "-m", "py_compile", *[str(x) for x in (ROOT / "panel").glob("*.py")]], check=True)
subprocess.run(["bash", "-n", str(ROOT / "install.sh"), str(ROOT / "uninstall.sh"), *[str(x) for x in (ROOT / "amneziawg-installer").glob("*.sh")]], check=True)
install_help = subprocess.check_output(["bash", str(ROOT / "amneziawg-installer/install_amneziawg.sh"), "--help", "--no-color"], text=True)
manage_help = subprocess.check_output(["bash", str(ROOT / "amneziawg-installer/manage_amneziawg.sh"), "--help", "--no-color"], text=True)
for flag in ["--uninstall", "--diagnostic", "--port=", "--ssh-port=", "--subnet=", "--allow-ipv6", "--disallow-ipv6", "--allow-ipv6-tunnel", "--route-all", "--route-amnezia", "--route-custom=", "--endpoint=", "--no-tweaks", "--force", "--preset=", "--jc=", "--jmin=", "--jmax="]:
    assert flag in install_help, flag
for command in ["add", "remove", "list", "stats", "regen", "modify", "backup", "restore", "check", "status", "diagnose", "show", "restart", "repair-module"]:
    assert command in manage_help, command

# No old fake architecture.
for forbidden in ["engine.py", "provisioner.py", "audit.html", "diagnostics.html"]:
    assert not any(p.name == forbidden for p in ROOT.rglob("*")), forbidden

# Critical UX and Telegram parity markers.
web = (ROOT / "panel/web.py").read_text()
bot = (ROOT / "panel/telegram.py").read_text()
for marker in ["server_add", "run_installer", "run_manage", "cascade_view", "settings_page"]:
    assert marker in web, marker
for marker in ["/addserver", "/install", "/modify", "/backups", "/backupfile", "/uploadbackup", "/restore", "/cascade_step", "servers_menu", "clients_menu"]:
    assert marker in bot, marker

# Removal and architecture contracts.
uninstall = (ROOT / "uninstall.sh").read_text()
assert "--all" in uninstall and "--keep-data" in uninstall
assert "make_ssh_server" in (ROOT / "panel/manager.py").read_text()
assert "AWGManager" in web and "AWGManager" in bot

# No BOM or CRLF in project code/scripts.
for path in list((ROOT / "panel").rglob("*")) + [ROOT / "install.sh", ROOT / "uninstall.sh"]:
    if not path.is_file() or path.suffix not in {".py", ".html", ".css", ".js", ".sh"}:
        continue
    data = path.read_bytes()
    assert not data.startswith(b"\xef\xbb\xbf"), path
    assert b"\r\n" not in data, path

# Selftest is part of the gate.
subprocess.run([sys.executable, str(ROOT / "tests/selftest.py")], check=True)
print("AWGUI full release gate OK")
