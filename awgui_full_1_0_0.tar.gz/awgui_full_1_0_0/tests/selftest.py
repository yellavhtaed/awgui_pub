from __future__ import annotations

import os
import tempfile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui-test-"))
STATE = TMP / "state"
AWG = TMP / "awg"
CONF = TMP / "awg0.conf"
MANAGE = TMP / "manage.sh"
MANAGE.write_bytes((ROOT / "tests/fake_manage.sh").read_bytes())
MANAGE.chmod(0o700)
AWG.mkdir()
CONF.write_text("[Interface]\nAddress = 172.16.17.1/24\n", encoding="utf-8")

os.environ.update({
    "AWGUI_BASE_DIR": str(ROOT),
    "AWGUI_UPSTREAM_DIR": str(ROOT / "amneziawg-installer"),
    "AWGUI_STATE_DIR": str(STATE),
    "AWGUI_STATE_FILE": str(STATE / "state.json"),
    "AWGUI_ADMIN_USER": "admin",
    "AWGUI_ADMIN_PASSWORD": "testpass",
    "AWGUI_SECRET_KEY": "test-secret",
    "AWGUI_SSH_BIN": str(ROOT / "tests/fake_ssh.sh"),
})

from panel import state
from panel.cascade import patch_awg1_config
from panel.manager import AWGManager
from panel.web import _installer_args, create_app

state.save({
    "servers": [{
        "id": "local", "name": "Local", "mode": "local", "host": "127.0.0.1", "port": 22, "user": "root", "key_path": "",
        "manage_path": str(MANAGE), "awg_dir": str(AWG), "server_conf": str(CONF), "installer_dir": str(ROOT / "amneziawg-installer"),
    }],
    "telegram": {"enabled": False, "token": "", "admin_ids": [], "dangerous": False},
    "telegram_server": {},
})

mgr = AWGManager(state.get_server("local"))
assert mgr.installed()
assert mgr.add(["phone"], expires="1d", psk=True).ok
assert mgr.list_clients().ok and mgr.list_clients().data[0]["name"] == "phone"
assert mgr.stats().ok
assert mgr.client_file("phone", "conf")
assert mgr.client_bundle("phone")
assert mgr.run_manage("backup").ok
assert mgr.backup_list()
assert mgr.modify("phone", "DNS", "1.1.1.1").ok
assert mgr.regen(["phone"]).ok


# Installer form maps the complete non-interactive surface used by web.
installer_args = _installer_args({
    "port": "51820", "ssh_port": "2222", "subnet": "10.9.9.1/24",
    "endpoint": "vpn.example.com", "jc": "3", "jmin": "10", "jmax": "40",
    "route": "custom", "custom_routes": "0.0.0.0/1,128.0.0.0/1",
    "ipv6": "allow", "ipv6_tunnel": "on", "no_tweaks": "on",
    "verbose": "on", "preset": "mobile",
})
for flag in ["--port=51820", "--ssh-port=2222", "--subnet=10.9.9.1/24", "--endpoint=vpn.example.com", "--route-custom=0.0.0.0/1,128.0.0.0/1", "--allow-ipv6", "--allow-ipv6-tunnel", "--no-tweaks", "--verbose", "--preset=mobile", "--jc=3", "--jmin=10", "--jmax=40"]:
    assert flag in installer_args, flag

patched = patch_awg1_config("[Interface]\nDNS = 1.1.1.1\nPrivateKey = x\n[Peer]\nEndpoint = 1.2.3.4:39743\n")
assert "DNS" not in patched and "Table = off" in patched

# Streaming SSH deployment test.
remote_dir = TMP / "remote-upstream"
remote = {
    "id": "remote", "name": "Remote", "mode": "ssh", "host": "fake", "port": 22, "user": "root", "key_path": "",
    "manage_path": str(TMP / "remote-manage.sh"), "awg_dir": str(TMP / "remote-awg"), "server_conf": str(TMP / "remote.conf"), "installer_dir": str(remote_dir),
}
state.upsert_server(remote)
remote_mgr = AWGManager(remote)
deploy = remote_mgr.deploy_upstream()
assert deploy.ok, deploy.text
assert (remote_dir / "install_amneziawg.sh").is_file()

app = create_app()
app.testing = True
client = app.test_client()
assert client.get("/health").status_code == 200
resp = client.post("/login", data={"username": "admin", "password": "testpass"}, follow_redirects=True)
assert resp.status_code == 200
with client.session_transaction() as sess:
    csrf = sess["csrf_token"]
for url in ["/", "/clients", "/servers", "/cascade", "/settings"]:
    response = client.get(url)
    assert response.status_code == 200, (url, response.status_code)
response = client.post("/clients", data={"csrf_token": csrf, "action": "add", "names": "tablet", "expires": "", "apply_mode": "syncconf"})
assert response.status_code == 200
assert (AWG / "tablet.conf").is_file()

# Telegram uses the same manager path and exposes the complete command surface.
from panel import telegram
state.set_telegram({"enabled": True, "token": "test", "admin_ids": ["1"], "dangerous": True})
messages = []
telegram.send = lambda chat_id, text, kb=None: messages.append((chat_id, text, kb))
telegram.handle_command("999", "/id")
assert "999" in messages[-1][1]
telegram.handle_command("1", "/server local")
telegram.handle_command("1", "/add phone2 tablet2 --expires=1d --psk")
assert (AWG / "phone2.conf").is_file() and (AWG / "tablet2.conf").is_file()
telegram.handle_command("1", "/modify phone2 DNS 9.9.9.9 --apply-mode=restart")
telegram.handle_command("1", "/list verbose")
for marker in ["/install", "/cascade", "/clients", "/backupfile", "/uploadbackup", "/addserver"]:
    assert marker in telegram.HELP, marker
assert messages

print("AWGUI full selftest OK")
