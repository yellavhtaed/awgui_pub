from __future__ import annotations

import re
import shlex
from dataclasses import dataclass
from ipaddress import ip_address

from . import config
from .manager import AWGManager, valid_names
from .runner import Result


@dataclass(slots=True)
class Step:
    key: str
    title: str
    ok: bool
    detail: str


def _endpoint_host(conf: str) -> str | None:
    match = re.search(r"^Endpoint\s*=\s*(.+)$", conf, re.MULTILINE)
    if not match:
        return None
    value = match.group(1).strip()
    if value.startswith("["):
        end = value.find("]")
        return value[1:end] if end > 0 else None
    return value.rsplit(":", 1)[0] if ":" in value else value


def patch_awg1_config(conf: str) -> str:
    lines = conf.replace("\r\n", "\n").splitlines()
    out: list[str] = []
    in_interface = False
    table_seen = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("["):
            if in_interface and not table_seen:
                out.append("Table = off")
            in_interface = stripped.lower() == "[interface]"
            table_seen = False
        if in_interface and stripped.lower().startswith("dns") and "=" in stripped:
            continue
        if in_interface and stripped.lower().startswith("table") and "=" in stripped:
            out.append("Table = off")
            table_seen = True
            continue
        out.append(line)
    if in_interface and not table_seen:
        out.append("Table = off")
    return "\n".join(out).rstrip() + "\n"


def _render_routing_script(client_subnet: str, endpoint: str) -> bytes:
    template = (config.UPSTREAM_DIR / "awg-routing.sh").read_text(encoding="utf-8")
    template = re.sub(r'^CLIENT_SUBNET="[^"]*"', f'CLIENT_SUBNET="{client_subnet}"', template, flags=re.MULTILINE)
    template = re.sub(r'^AWG1_ENDPOINT="[^"]*"', f'AWG1_ENDPOINT="{endpoint}"', template, flags=re.MULTILINE)
    template = re.sub(r'^RU_ZONE_FALLBACK_URL="[^"]*"', 'RU_ZONE_FALLBACK_URL=""', template, flags=re.MULTILINE)
    template = re.sub(r'^RU_ZONE="\$AWG_DIR(?:/cascade)?/ru\.zone"', 'RU_ZONE="$AWG_DIR/cascade/ru.zone"', template, flags=re.MULTILINE)
    return template.encode("utf-8")


def _service_unit() -> bytes:
    return b"""[Unit]\nDescription=Cascade split routing for AWG0\nAfter=awg-quick@awg0.service awg-quick@awg1.service network-online.target\nRequires=awg-quick@awg0.service awg-quick@awg1.service\nWants=network-online.target\n\n[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/root/awg/awg-routing.sh\n\n[Install]\nWantedBy=multi-user.target\n"""


def status(entry: AWGManager, exit_server: AWGManager, link_name: str = "ru_host") -> list[Step]:
    link_name = valid_names([link_name])[0]
    steps: list[Step] = []
    steps.append(Step("entry_installed", "AWG0 установлен", entry.installed(), entry.manage_path))
    steps.append(Step("exit_installed", "AWG1 установлен", exit_server.installed(), exit_server.manage_path))

    entry_subnet = entry.server_subnet()
    exit_subnet = exit_server.server_subnet()
    different = bool(entry_subnet and exit_subnet and entry_subnet != exit_subnet)
    steps.append(Step("subnets", "Подсети различаются", different, f"AWG0={entry_subnet or 'не определена'}, AWG1={exit_subnet or 'не определена'}"))

    exit_conf_path = exit_server.client_path(link_name, "conf")
    steps.append(Step("link_client", "Клиент связи на AWG1", bool(exit_conf_path), exit_conf_path or "не создан"))

    awg1_conf = entry.runner.read_file("/etc/amnezia/amneziawg/awg1.conf")
    awg1_text = awg1_conf.decode("utf-8", errors="replace") if awg1_conf else ""
    patched = bool(awg1_text and re.search(r"^Table\s*=\s*off\s*$", awg1_text, re.MULTILINE | re.IGNORECASE) and not re.search(r"^DNS\s*=", awg1_text, re.MULTILINE | re.IGNORECASE))
    steps.append(Step("awg1_conf", "awg1.conf на AWG0", patched, "Table=off, DNS удалён" if patched else "нет или не подготовлен"))

    tunnel = entry.runner.run(["systemctl", "is-active", "--quiet", "awg-quick@awg1.service"], timeout=20)
    steps.append(Step("awg1_active", "Туннель awg1 активен", tunnel.ok, "active" if tunnel.ok else "inactive"))

    handshake = entry.runner.run(["bash", "-lc", "awg show awg1 2>/dev/null | grep -i 'latest handshake' | head -1"], timeout=20)
    steps.append(Step("handshake", "Handshake AWG0 → AWG1", handshake.ok and bool(handshake.stdout.strip()), handshake.stdout.strip() or "не найден"))

    script_exists = entry.exists("/root/awg/awg-routing.sh")
    steps.append(Step("routing_script", "awg-routing.sh установлен", script_exists, "/root/awg/awg-routing.sh"))

    service_enabled = entry.runner.run(["systemctl", "is-enabled", "--quiet", "awg-routing.service"], timeout=20)
    steps.append(Step("routing_service", "Автозапуск маршрутизации", service_enabled.ok, "enabled" if service_enabled.ok else "disabled"))

    rule = entry.runner.run(["bash", "-lc", "ip rule show | grep -q 'fwmark 0x1.*lookup 100'"], timeout=20)
    table = entry.runner.run(["bash", "-lc", "ip route show table 100 | grep -q '^default dev awg1'"], timeout=20)
    ipset = entry.runner.run(["bash", "-lc", "ipset list ru 2>/dev/null | grep -q 'Number of entries: [1-9]'"], timeout=20)
    runtime_ok = rule.ok and table.ok and ipset.ok
    steps.append(Step("routing_runtime", "Маршрутизация применена", runtime_ok, f"rule={'ok' if rule.ok else 'no'}, table={'ok' if table.ok else 'no'}, ru-set={'ok' if ipset.ok else 'no'}"))
    return steps


def install_prerequisites(entry: AWGManager) -> Result:
    return entry.runner.run(["bash", "-lc", "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y curl ipset"], timeout=1800)


def create_link_client(exit_server: AWGManager, link_name: str) -> Result:
    return exit_server.add([valid_names([link_name])[0]])


def transfer_link_config(entry: AWGManager, exit_server: AWGManager, link_name: str) -> Result:
    clean = valid_names([link_name])[0]
    item = exit_server.client_file(clean, "conf")
    if not item:
        return Result(False, 2, "transfer awg1.conf", "", "Конфиг клиента связи не найден на AWG1", 0.0)
    _, data = item
    patched = patch_awg1_config(data.decode("utf-8", errors="strict"))
    return entry.runner.write_file("/etc/amnezia/amneziawg/awg1.conf", patched.encode("utf-8"), mode=0o600)


def start_link_tunnel(entry: AWGManager) -> Result:
    return entry.runner.run(["systemctl", "enable", "--now", "awg-quick@awg1.service"], timeout=180)


def install_routing(entry: AWGManager) -> Result:
    subnet = entry.server_subnet()
    conf = entry.runner.read_file("/etc/amnezia/amneziawg/awg1.conf")
    if not subnet or not conf:
        return Result(False, 2, "install awg-routing.sh", "", "Не определены подсеть AWG0 или awg1.conf", 0.0)
    endpoint = _endpoint_host(conf.decode("utf-8", errors="replace"))
    if not endpoint:
        return Result(False, 2, "install awg-routing.sh", "", "Endpoint AWG1 не найден в awg1.conf", 0.0)
    try:
        ip_address(endpoint)
    except ValueError:
        # FQDN is accepted by the upstream installer, but the cascade routing script uses ip route get.
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", endpoint):
            return Result(False, 2, "install awg-routing.sh", "", "Некорректный Endpoint AWG1", 0.0)
    script = _render_routing_script(subnet, endpoint)
    zone = (config.UPSTREAM_DIR / "cascade" / "ru.zone").read_bytes()
    first = entry.runner.write_file("/root/awg/awg-routing.sh", script, mode=0o700)
    if not first.ok:
        return first
    second = entry.runner.write_file("/root/awg/cascade/ru.zone", zone, mode=0o600)
    if not second.ok:
        return second
    second.command = "install awg-routing.sh + bundled ru.zone"
    return second


def run_routing(entry: AWGManager) -> Result:
    return entry.runner.run(["bash", "/root/awg/awg-routing.sh"], timeout=900)


def enable_routing_service(entry: AWGManager) -> Result:
    written = entry.runner.write_file("/etc/systemd/system/awg-routing.service", _service_unit(), mode=0o644)
    if not written.ok:
        return written
    return entry.runner.run(["bash", "-lc", "systemctl daemon-reload && systemctl enable awg-quick@awg1.service awg-routing.service && systemctl restart awg-routing.service"], timeout=300)


def remove_cascade(entry: AWGManager) -> Result:
    subnet = entry.server_subnet() or "0.0.0.0/0"
    script = f"""
set -e
systemctl disable --now awg-routing.service awg-quick@awg1.service 2>/dev/null || true
rm -f /etc/systemd/system/awg-routing.service /etc/amnezia/amneziawg/awg1.conf /root/awg/awg-routing.sh
ip rule del fwmark 0x1 table 100 2>/dev/null || true
ip route flush table 100 2>/dev/null || true
iptables -t mangle -D PREROUTING -i awg0 -s {shlex.quote(subnet)} -m set --match-set ru dst -j RETURN 2>/dev/null || true
iptables -t mangle -D PREROUTING -i awg0 -s {shlex.quote(subnet)} -j MARK --set-mark 0x1 2>/dev/null || true
iptables -t nat -D POSTROUTING -s {shlex.quote(subnet)} -o awg1 -j MASQUERADE 2>/dev/null || true
ipset destroy ru 2>/dev/null || true
systemctl daemon-reload
"""
    return entry.runner.run(["bash", "-lc", script], timeout=180)
