from __future__ import annotations

import json
import os
import tempfile
import threading
from copy import deepcopy
from typing import Any

from . import config

_LOCK = threading.RLock()

_DEFAULT = {
    "servers": [
        {
            "id": "local",
            "name": "Local",
            "mode": "local",
            "host": "127.0.0.1",
            "port": 22,
            "user": "root",
            "key_path": "",
            "manage_path": config.LOCAL_MANAGE,
            "awg_dir": config.LOCAL_AWG_DIR,
            "server_conf": config.LOCAL_SERVER_CONF,
            "installer_dir": str(config.UPSTREAM_DIR),
        }
    ],
    "telegram": {
        "enabled": False,
        "token": "",
        "admin_ids": [],
        "dangerous": False,
    },
    "telegram_server": {},
}


def _normalize(data: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(_DEFAULT)
    if isinstance(data.get("servers"), list):
        servers = [s for s in data["servers"] if isinstance(s, dict) and s.get("id")]
        if not any(s.get("id") == "local" for s in servers):
            servers.insert(0, deepcopy(_DEFAULT["servers"][0]))
        out["servers"] = servers
    if isinstance(data.get("telegram"), dict):
        out["telegram"].update(data["telegram"])
    if isinstance(data.get("telegram_server"), dict):
        out["telegram_server"] = data["telegram_server"]
    return out


def load() -> dict[str, Any]:
    with _LOCK:
        try:
            data = json.loads(config.STATE_FILE.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("state root must be object")
            return _normalize(data)
        except FileNotFoundError:
            return deepcopy(_DEFAULT)
        except Exception:
            return deepcopy(_DEFAULT)


def save(data: dict[str, Any]) -> None:
    normalized = _normalize(data)
    with _LOCK:
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(prefix="state.", suffix=".tmp", dir=config.STATE_DIR)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
                json.dump(normalized, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(tmp_name, 0o600)
            os.replace(tmp_name, config.STATE_FILE)
        finally:
            try:
                os.unlink(tmp_name)
            except FileNotFoundError:
                pass


def list_servers() -> list[dict[str, Any]]:
    return load()["servers"]


def get_server(server_id: str) -> dict[str, Any] | None:
    return next((dict(s) for s in list_servers() if s.get("id") == server_id), None)


def upsert_server(server: dict[str, Any]) -> None:
    data = load()
    existing = next((i for i, item in enumerate(data["servers"]) if item.get("id") == server["id"]), None)
    if existing is None:
        data["servers"].append(server)
    else:
        data["servers"][existing] = server
    save(data)


def delete_server(server_id: str) -> bool:
    if server_id == "local":
        return False
    data = load()
    before = len(data["servers"])
    data["servers"] = [s for s in data["servers"] if s.get("id") != server_id]
    save(data)
    return len(data["servers"]) != before


def telegram_settings() -> dict[str, Any]:
    return dict(load()["telegram"])


def set_telegram(settings: dict[str, Any]) -> None:
    data = load()
    data["telegram"] = settings
    save(data)


def telegram_server(chat_id: str) -> str:
    data = load()
    sid = str(data["telegram_server"].get(str(chat_id), "local"))
    return sid if get_server(sid) else "local"


def set_telegram_server(chat_id: str, server_id: str) -> None:
    if not get_server(server_id):
        raise KeyError(server_id)
    data = load()
    data["telegram_server"][str(chat_id)] = server_id
    save(data)
