from __future__ import annotations

import io
import os
import shlex
import subprocess
import tarfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from . import config


@dataclass(slots=True)
class Result:
    ok: bool
    rc: int
    command: str
    stdout: str
    stderr: str
    duration: float
    data: object | None = None

    @property
    def text(self) -> str:
        return "\n".join(x for x in (self.stdout.rstrip(), self.stderr.rstrip()) if x).strip()


def display(argv: Sequence[str]) -> str:
    return " ".join(shlex.quote(str(x)) for x in argv)


class Runner:
    def __init__(self, server: dict):
        self.server = server

    @property
    def remote(self) -> bool:
        return self.server.get("mode") == "ssh"

    def _ssh_prefix(self) -> list[str]:
        target = f"{self.server.get('user', 'root')}@{self.server['host']}"
        args = [
            config.SSH_BIN,
            "-p", str(int(self.server.get("port", 22))),
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=12",
            "-o", "ServerAliveInterval=15",
            "-o", "ServerAliveCountMax=2",
            "-o", "StrictHostKeyChecking=accept-new",
        ]
        key = str(self.server.get("key_path") or "").strip()
        if key:
            args += ["-i", key]
        args.append(target)
        return args

    def run(self, argv: Sequence[str], *, timeout: int = 120, input_bytes: bytes | None = None) -> Result:
        started = time.monotonic()
        if self.remote:
            prefix = self._ssh_prefix()
            cmd = prefix + [shlex.join([str(x) for x in argv])]
            shown = display(prefix + ["<remote-command>"])
        else:
            cmd = [str(x) for x in argv]
            shown = display(cmd)
        try:
            completed = subprocess.run(
                cmd,
                input=input_bytes,
                capture_output=True,
                timeout=timeout,
                check=False,
                env={**os.environ, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"},
            )
            return Result(
                completed.returncode == 0,
                completed.returncode,
                shown,
                completed.stdout.decode("utf-8", errors="replace"),
                completed.stderr.decode("utf-8", errors="replace"),
                time.monotonic() - started,
            )
        except subprocess.TimeoutExpired as exc:
            out = exc.stdout.decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else str(exc.stdout or "")
            err = exc.stderr.decode("utf-8", errors="replace") if isinstance(exc.stderr, bytes) else str(exc.stderr or "")
            return Result(False, 124, shown, out, (err + "\nTimeout").strip(), time.monotonic() - started)
        except OSError as exc:
            return Result(False, 127, shown, "", str(exc), time.monotonic() - started)

    def read_file(self, path: str, *, max_bytes: int = 64 * 1024 * 1024) -> bytes | None:
        if self.remote:
            # Binary files require a direct subprocess; decoding through Result would corrupt PNG/tar data.
            cmd = self._ssh_prefix() + [f"test -f {shlex.quote(path)} && cat -- {shlex.quote(path)}"]
            try:
                completed = subprocess.run(cmd, capture_output=True, timeout=90, check=False)
                if completed.returncode != 0 or len(completed.stdout) > max_bytes:
                    return None
                return completed.stdout
            except Exception:
                return None
        p = Path(path)
        if not p.is_file() or p.stat().st_size > max_bytes:
            return None
        return p.read_bytes()

    def write_file(self, path: str, data: bytes, *, mode: int = 0o600) -> Result:
        parent = str(Path(path).parent)
        if self.remote:
            script = f"install -d -m 700 {shlex.quote(parent)} && install -m {mode:o} /dev/stdin {shlex.quote(path)}"
            return self.run(["bash", "-lc", script], timeout=120, input_bytes=data)
        try:
            Path(parent).mkdir(parents=True, exist_ok=True)
            Path(path).write_bytes(data)
            os.chmod(path, mode)
            return Result(True, 0, f"write {path}", "", "", 0.0)
        except OSError as exc:
            return Result(False, 1, f"write {path}", "", str(exc), 0.0)

    def deploy_directory(self, source: Path, destination: str) -> Result:
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
            for item in sorted(source.rglob("*")):
                archive.add(item, arcname=item.relative_to(source), recursive=False)
        payload = buffer.getvalue()
        script = f"rm -rf {shlex.quote(destination)} && install -d -m 700 {shlex.quote(destination)} && tar -xzf - -C {shlex.quote(destination)}"
        result = self.run(["bash", "-lc", script], timeout=180, input_bytes=payload)
        result.command = f"deploy {source.name} -> {destination} ({len(payload)} bytes)"
        return result
