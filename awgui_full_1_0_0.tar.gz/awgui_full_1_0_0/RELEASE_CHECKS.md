# Release checks

- [x] pinned core scripts v5.18.4 and SHA256
- [x] installer public flags mapped in web and Telegram
- [x] manager public commands mapped in web and Telegram
- [x] client multi-add/remove/regen/modify/list/stats
- [x] conf, QR, vpnuri, vpnuri QR and bundle
- [x] backup create/list/upload/download/restore
- [x] local + SSH server registry
- [x] SSH key validation and streaming deployment
- [x] Telegram `/id`, menus and command surface
- [x] real CASCADE.md stages and explicit routing start
- [x] authentication and CSRF
- [x] Python compile and pyflakes
- [x] bash syntax
- [x] Flask selftest and release gate
- [ ] real clean-VPS DKMS/reboot run
- [ ] real two-VPS cascade network run
