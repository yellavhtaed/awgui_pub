#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Запустите: sudo ./install.sh" >&2; exit 1; }
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TARGET="/opt/awgui"
STATE_DIR="/var/lib/awgui"
ENV_FILE="/etc/awgui.env"

cd "$SRC"
sha256sum -c amneziawg-installer/SHA256SUMS >/dev/null
for f in amneziawg-installer/*.sh; do bash -n "$f"; done
python3 -m py_compile panel/*.py

apt-get update -y
apt-get install -y python3 python3-venv python3-pip curl openssl openssh-client tar
systemctl stop awgui.service awgui-bot.service 2>/dev/null || true
rm -rf "$TARGET"
install -d -m 755 "$TARGET" "$STATE_DIR"
cp -a panel amneziawg-installer requirements.txt VERSION README.md CHANGELOG.md install.sh uninstall.sh .env.example "$TARGET/"
find "$TARGET" -type d -name __pycache__ -prune -exec rm -rf {} +
chmod 700 "$TARGET/amneziawg-installer/"*.sh
chmod 600 "$TARGET/amneziawg-installer/cascade/ru.zone"
python3 -m venv "$TARGET/.venv"
"$TARGET/.venv/bin/pip" install --disable-pip-version-check -q -r "$TARGET/requirements.txt"

if [[ ! -f "$ENV_FILE" ]]; then
  PASSWORD="$(openssl rand -hex 10)"
  SECRET="$(openssl rand -hex 32)"
  umask 077
  cat > "$ENV_FILE" <<EOF
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_ADMIN_USER=admin
AWGUI_ADMIN_PASSWORD=$PASSWORD
AWGUI_SECRET_KEY=$SECRET
AWGUI_BASE_DIR=$TARGET
AWGUI_UPSTREAM_DIR=$TARGET/amneziawg-installer
AWGUI_STATE_DIR=$STATE_DIR
EOF
  NEW_CREDENTIALS=1
fi
chmod 600 "$ENV_FILE"

cat > /etc/systemd/system/awgui.service <<EOF
[Unit]
Description=AWGUI web panel for AmneziaWG installer
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/gunicorn --workers 1 --threads 4 --timeout 7200 --bind \${AWGUI_HOST}:\${AWGUI_PORT} 'panel.web:create_app()'
Restart=on-failure
RestartSec=3
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/awgui-bot.service <<EOF
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m panel.telegram
Restart=always
RestartSec=5
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now awgui.service awgui-bot.service
HEALTH=""
for _ in $(seq 1 30); do
  HEALTH="$(curl -fsS http://127.0.0.1:8080/health 2>/dev/null || true)"
  [[ -n "$HEALTH" ]] && break
  sleep 1
done
python3 - "$HEALTH" <<'PY'
import json,sys
if len(sys.argv)<2 or not sys.argv[1]: raise SystemExit("AWGUI health endpoint недоступен")
data=json.loads(sys.argv[1]); assert data.get("panel")=="ok",data
PY

echo
echo "AWGUI установлена: http://127.0.0.1:8080"
echo "Удалённый доступ: ssh -L 8080:127.0.0.1:8080 root@SERVER_IP"
if [[ ${NEW_CREDENTIALS:-0} -eq 1 ]]; then
  echo "Логин: admin"
  echo "Пароль: $PASSWORD"
else
  echo "Учётные данные: $ENV_FILE"
fi
