#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Запустите: sudo $0 [--all|--keep-data]" >&2; exit 1; }
ALL=0
KEEP_DATA=0
for arg in "$@"; do
  case "$arg" in
    --all) ALL=1 ;;
    --keep-data) KEEP_DATA=1 ;;
    *) echo "Неизвестная опция: $arg" >&2; exit 2 ;;
  esac
done
systemctl disable --now awgui.service awgui-bot.service 2>/dev/null || true
rm -f /etc/systemd/system/awgui.service /etc/systemd/system/awgui-bot.service
systemctl daemon-reload
if [[ $ALL -eq 1 ]]; then
  if [[ -f /opt/awgui/amneziawg-installer/install_amneziawg.sh ]]; then
    bash /opt/awgui/amneziawg-installer/install_amneziawg.sh --uninstall --yes --no-color || true
  elif [[ -f /root/awgui-installer/install_amneziawg.sh ]]; then
    bash /root/awgui-installer/install_amneziawg.sh --uninstall --yes --no-color || true
  fi
fi
rm -rf /opt/awgui
if [[ $KEEP_DATA -eq 0 ]]; then
  rm -rf /var/lib/awgui
  rm -f /etc/awgui.env
fi
echo "AWGUI удалена$([[ $ALL -eq 1 ]] && echo ' вместе с локальным AWG' || true)."
