# Changelog

## 1.0.0

- проект пересобран как web/Telegram-обвязка bundled `amneziawg-installer` v5.18.4;
- web отображает полный публичный CLI install/manage scripts;
- Telegram использует тот же `AWGManager` и повторяет client/server/install/backup/multi-server/cascade операции;
- local и SSH-серверы работают через один runner;
- upstream передаётся на SSH tar-stream через stdin;
- SSH-пароли и `sshpass` отсутствуют;
- cascade реализован как последовательность из `CASCADE.md`, а не как фиктивная роль;
- `awg-routing.sh` не запускается скрыто при копировании;
- удалены отдельные Engine, Provisioner, Audit, Diagnostics и прочие внутренние сущности;
- добавлены light/dark/system theme, CSRF, auth, selftest и release gate;
- удаление панели очищает её env/state по умолчанию; `--all` дополнительно удаляет локальный AWG.
