# AWGUI Full 1.0.0

AWGUI — компактная web-панель и Telegram-бот для штатных скриптов `bivlked/amneziawg-installer` v5.18.4.

Проект не переписывает установку AmneziaWG, DKMS, firewall, sysctl, UFW, Fail2Ban, генерацию ключей, клиентов, backup и repair. Эти операции выполняют bundled shell-скрипты; panel только валидирует ввод, вызывает их локально или по SSH и показывает результат.

```text
awgui_full_1_0_0/
├── panel/                    # web + Telegram + local/SSH runner
├── amneziawg-installer/      # pinned рабочий набор v5.18.4
├── install.sh
├── uninstall.sh
└── README.md
```

В `amneziawg-installer/` лежат официальные `install_amneziawg.sh`, `manage_amneziawg.sh`, `awg_common.sh`, документация и `cascade/ru.zone`. `awg-routing.sh` извлечён из `CASCADE.md` той же версии; AWGUI при установке каскада подставляет фактическую подсеть AWG0 и endpoint AWG1 и использует bundled `ru.zone` как локальный fallback.

## Интерфейс

Пять разделов без технических псевдосущностей:

- **Обзор** — выбранный сервер, установлен ли AWG, статус, клиенты и статистика;
- **Клиенты** — `add/remove/list/stats/regen/modify` и клиентские файлы;
- **Серверы** — local/SSH, установщик, все серверные команды и backup/restore;
- **Каскад** — последовательный мастер AWG0 → AWG1 по `CASCADE.md`;
- **Настройки** — Telegram token, admin chat IDs и разрешение опасных операций.

Web и Telegram используют один класс `AWGManager`; отдельной реализации AWG-логики в боте нет.

## Полное отображение install_amneziawg.sh

Web-форма и команда Telegram `/install` поддерживают:

```text
--help --uninstall --diagnostic --verbose --no-color
--port= --ssh-port= --subnet=
--allow-ipv6 --disallow-ipv6 --allow-ipv6-tunnel
--route-all --route-amnezia --route-custom=
--endpoint= --yes --force --no-tweaks
--preset=default|mobile --jc= --jmin= --jmax=
```

В web-запуске автоматически добавляются `--yes` и `--no-color`, потому что HTTP-запрос не может отвечать на интерактивные вопросы установщика. После запрошенной установщиком перезагрузки снова откройте панель и повторите **Установить / продолжить**.

Для SSH-сервера AWGUI сначала передаёт папку `amneziawg-installer/` tar-stream через stdin в `/root/awgui-installer`, затем запускает оттуда официальный installer. Base64 в argv, `sshpass` и хранение SSH-паролей не используются.

## Полное отображение manage_amneziawg.sh

Панель вызывает:

```text
add remove list stats regen modify
backup restore check status diagnose show restart repair-module help
```

Поддерживается:

- один или несколько клиентов;
- `--expires=1h|12h|1d|7d|30d|4w`;
- `--psk`;
- `--apply-mode=syncconf|restart`;
- `list --json`, `list -v`, `stats --json` и raw stats;
- изменение `DNS`, `Endpoint`, `AllowedIPs`, `PersistentKeepalive`;
- `.conf`, обычный QR `.png`, `.vpnuri`, QR `.vpnuri.png` и общий bundle;
- `diagnose --carrier=` для Beeline, Yota, Tele2, Tattelecom, Megafon и T-Mobile US;
- создание, загрузка, скачивание и restore backup;
- status/check/show/restart/repair-module/help.

Опасные действия требуют явного подтверждения.

## Telegram

Бот работает с тем же реестром серверов и тем же `AWGManager`, что web. До добавления admin ID команда `/id` показывает chat ID.

Основные команды:

```text
/id /menu
/server [ID] /servers
/addserver ID HOST [PORT] [USER] [KEY] [NAME]
/delserver ID DELETE /deploy
/clients /list [verbose]
/add NAME [NAME2] [--expires=7d] [--psk] [--apply-mode=restart]
/remove NAME [NAME2] [--confirm=REMOVE]
/regen NAME [NAME2]|all [--apply-mode=restart]
/modify NAME PARAM VALUE [--apply-mode=restart]
/conf NAME /qr NAME /vpnuri NAME /vpnuriqr NAME /bundle NAME
/status /check /show /stats [raw] /diagnose [carrier]
/backup /backups /backupfile BACKUP
/restore BACKUP --confirm=RESTORE
```

Для загрузки backup отправьте `.tar.gz` документ с подписью `/uploadbackup`.

Установщик и обслуживание:

```text
/install [installer flags] /force [flags] /uninstall
/installer_help /installer_diagnostic
/restart /repair
```

Каскад:

```text
/cascade ENTRY EXIT [LINK]
/cascade_step ENTRY EXIT STEP [LINK]
```

Доступные STEP: `prerequisites`, `create_link`, `transfer_conf`, `start_tunnel`, `install_routing`, `run_routing`, `enable_service`, `remove`.

При смене Telegram-сервера все последующие команды выполняются именно на нём.

## Multi-server и SSH

Local-сервер существует всегда. Для remote сохраняются только:

```text
ID, name, host, port, user, SSH key path,
manage path, AWG dir, server config, installer dir
```

Пароли серверов панель не хранит. Создайте отдельный ключ для AWGUI:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
chmod 700 ~/.ssh
chmod 600 ~/.ssh/awgui_ed25519
chmod 644 ~/.ssh/awgui_ed25519.pub
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP 'echo OK'
```

Приватный ключ остаётся на машине с AWGUI, а на сервер записывается только public key. Доступ отзывается удалением этой строки из `~/.ssh/authorized_keys`.

## Каскад AWG0 → AWG1

Мастер не подменяет `CASCADE.md` переключателем роли. Он выполняет реальные этапы:

1. выбрать два разных зарегистрированных сервера;
2. проверить AWG на обоих и разные туннельные подсети;
3. установить `curl` и `ipset` на AWG0;
4. создать link-client на AWG1;
5. перенести его `.conf` на AWG0 как `/etc/amnezia/amneziawg/awg1.conf`;
6. удалить `DNS`, добавить `Table = off`;
7. включить `awg-quick@awg1` и проверить handshake;
8. установить настроенный `/root/awg/awg-routing.sh` и bundled `cascade/ru.zone`;
9. отдельно, с подтверждением `ROUTE`, запустить routing;
10. отдельно включить `awg-routing.service`;
11. проверить fwmark rule, table 100 и непустой ipset `ru`.

Копирование `awg-routing.sh` **не запускает его автоматически**. Запуск меняет `ipset`, `iptables`, `ip rule` и routes, поэтому вынесен в отдельный подтверждаемый шаг.

## Установка

Для чистой установки или замены предыдущей панели:

```bash
sudo systemctl disable --now awgui awgui-bot 2>/dev/null || true
sudo rm -rf /opt/awgui

cd ~
tar -xzf ~/Downloads/awgui_full_1_0_0.tar.gz
cd ~/awgui_full_1_0_0
sudo ./install.sh
```

Установщик создаёт `/opt/awgui`, `/var/lib/awgui`, venv и два systemd-сервиса. При первом запуске генерируются пароль администратора и Flask secret.

Открыть на самом сервере:

```text
http://127.0.0.1:8080
```

Доступ с рабочего компьютера:

```bash
ssh -L 8080:127.0.0.1:8080 root@SERVER_IP
```

После чего открыть `http://127.0.0.1:8080` локально.

## Удаление

Полностью удалить панель и её настройки, не трогая AWG:

```bash
sudo /opt/awgui/uninstall.sh
```

Удалить панель и локальный AWG вместе с локальными клиентами, ключами и конфигурацией:

```bash
sudo /opt/awgui/uninstall.sh --all
```

Сохранить `/etc/awgui.env` и `/var/lib/awgui` при удалении бинарников панели:

```bash
sudo /opt/awgui/uninstall.sh --keep-data
```

Удаление remote-сервера из реестра не изменяет его систему.

## Проверки релиза

```bash
python3 -m py_compile panel/*.py tests/*.py
bash -n install.sh uninstall.sh tests/*.sh amneziawg-installer/*.sh
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/python tests/selftest.py
.testvenv/bin/python tests/verify_release.py
```

Проверяются CLI-контракты обоих upstream-скриптов, web routes, CSRF/auth, client workflow, backups, binary-файлы, SSH streaming deploy, Telegram command surface и конфигурационная часть cascade.

## Граница проверки

В Linux-контейнере проверены Python, shell syntax, Flask/Gunicorn, fake manage, fake SSH streaming и архив. Реальная сборка DKMS, apt/UFW/Fail2Ban, перезагрузки и сетевой путь каскада из двух VPS должны проверяться на настоящих Ubuntu/VPS; релиз не заявляет эти внешние операции как физически выполненные в контейнере.
