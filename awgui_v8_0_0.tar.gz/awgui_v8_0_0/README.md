# AWGUI v8.0.0

Personal web + Telegram control layer for AmneziaWG installed by `bivlked/amneziawg-installer`.

AWGUI is intentionally not a VPN panel that reimplements AmneziaWG. The parent script `/root/awg/manage_amneziawg.sh` remains the source of truth. AWGUI calls it through one adapter and adds only the operational layer: clients, QR/config delivery, backups, diagnostics, audit, and Telegram cockpit.

## Default access

Open locally:

```text
http://127.0.0.1:8080
```

Default login:

```text
admin
```

Default password:

```text
devpass
```

Change it in `/etc/awgui.env`:

```bash
sudo tee /etc/awgui.env >/dev/null <<'EOF'
AWGUI_USER="admin"
AWGUI_PASSWORD="your-strong-password"
AWGUI_SECRET="replace-with-random-long-secret"
AWGUI_MANAGE="/root/awg/manage_amneziawg.sh"
AWGUI_AWG_DIR="/root/awg"
AWGUI_SERVER_CONF="/etc/amnezia/amneziawg/awg0.conf"
EOF
sudo chmod 600 /etc/awgui.env
sudo systemctl restart awgui
```

## Install / upgrade

Copy the archive to the server, then:

```bash
cd ~
sudo systemctl stop awgui awgui-bot 2>/dev/null || true
rm -rf ~/awgui
mkdir -p ~/awgui
tar -xzf ./awgui_v8_0_0.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui
sudo ./upgrade.sh
```

Check:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected:

```json
{"app":"AWGUI","ok":true,"version":"8.0.0"}
```

## Telegram

Open:

```text
http://127.0.0.1:8080/bot
```

Paste token and admin chat_id, enable bot, then press **Save & apply**.

Bot commands:

```text
/id
/menu
/status
/clients
/client NAME
/add NAME [7d] [psk]
/backup
/diagnose [carrier]
```

Dangerous Telegram actions are disabled by default. Enable them only for a private bot and trusted chat_id.

## Architecture

```text
Flask UI / Telegram bot
        ↓
manage_adapter.py
        ↓
/root/awg/manage_amneziawg.sh
        ↓
AmneziaWG config, clients, backup, restore, diagnose
```

SQLite is used only for AWGUI audit/history. Private VPN state stays with the parent installer.

## v8 scope

Implemented:

- single ManageAdapter gateway;
- upstream compatibility scanner;
- lifecycle-first clients page;
- temporary clients via upstream `--expires`;
- PSK via upstream `--psk`;
- client QR/conf/vpnuri/bundle delivery;
- backup center with preview/checksum/restore;
- diagnostics page tied to real parent capabilities;
- SQLite audit log;
- Telegram inline cockpit;
- release gate against old v5/v6 UI regression;
- systemd upgrade that verifies `/health` is really v8.

Not implemented deliberately:

- own key generation;
- own restore engine;
- arbitrary full config editor;
- Prometheus/Grafana;
- React/Vue frontend;
- multi-server control UI.

Multi-server is reserved for a future version, but the code keeps a local server identity so the architecture can evolve without rewriting the local model.
