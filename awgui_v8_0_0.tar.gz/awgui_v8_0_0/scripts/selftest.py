#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui_v8_selftest_"))
FAKE = ROOT / "scripts" / "fake_manage_amneziawg.sh"
os.environ["AWGUI_MANAGE"] = str(FAKE)
os.environ["AWGUI_AWG_DIR"] = str(TMP / "awg")
os.environ["AWGUI_SERVER_CONF"] = str(TMP / "etc" / "awg0.conf")
os.environ["AWGUI_STATE_DIR"] = str(TMP / "state")
os.environ["AWGUI_ENV_FILE"] = str(TMP / "awgui.env")
os.environ["AWGUI_SECRET"] = "test-secret"

import config  # noqa: E402
import manage_adapter  # noqa: E402
import parse  # noqa: E402
import store  # noqa: E402

assert config.APP_VERSION == "8.0.0"
ad = manage_adapter.ManageAdapter(config.MANAGE, config.AWG_DIR, config.SERVER_CONF)
scan = ad.scan()
assert scan["ok"], scan
assert scan["commands"]["add"] and scan["commands"]["backup"] and scan["options"]["--json"], scan
lst = ad.list_clients()
assert lst["ok"] and parse.clients_from(lst["json"])[0]["name"] == "phone", lst
add = ad.add_client("test_phone", expires="7d", psk=True)
assert add["ok"], add
assert ad.find_client_file("test_phone", "conf")
bundle = ad.create_client_bundle("test_phone")
assert bundle.exists(), bundle
b = ad.backup()
assert b["ok"], b
backups = ad.list_backups()
assert backups, backups
preview = ad.backup_preview(backups[0]["path"])
assert preview["ok"], preview
store.init_db()
store.audit("selftest", "tester", "backup", "", b)
assert store.list_audit(1)[0]["action"] == "backup"
print("AWGUI v8 selftest OK")
