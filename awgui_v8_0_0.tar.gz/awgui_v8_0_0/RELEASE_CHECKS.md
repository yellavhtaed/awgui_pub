# Release checks

Fresh unpack test:

```bash
python3 -m py_compile app.py config.py manage_adapter.py parse.py store.py telegram_bot.py scripts/selftest.py scripts/verify_release.py
python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh scripts/fake_manage_amneziawg.sh
```

Expected:

```text
AWGUI v8 selftest OK
AWGUI v8 release gate OK
```
