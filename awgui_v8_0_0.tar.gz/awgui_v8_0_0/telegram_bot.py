#!/usr/bin/env python3
from __future__ import annotations

import html
import json
import sys
import time
import traceback
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import config
import manage_adapter
import parse
import store

MAX_MSG = 3600
adapter = manage_adapter.default_adapter()


def log(msg: str) -> None:
    print(f"[awgui-bot] {msg}", flush=True)


def settings() -> Dict[str, Any]:
    return config.load_telegram_settings()


def token() -> str:
    return str(settings().get("token") or "")


def esc(x: Any) -> str:
    return html.escape(str(x or ""))


def clip(text: Any, limit: int = MAX_MSG) -> str:
    s = str(text or "")
    return s if len(s) <= limit else s[:limit] + "\n\n--- cut ---"


def api(method: str, payload: Optional[Dict[str, Any]] = None, timeout: int = 60) -> Dict[str, Any]:
    url = f"https://api.telegram.org/bot{token()}/{method}"
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def multipart_api(method: str, fields: Dict[str, Any], file_field: str, path: Path, mime: str, timeout: int = 90) -> Dict[str, Any]:
    boundary = "----awgui" + str(int(time.time() * 1000))
    body = bytearray()
    def add(s: str): body.extend(s.encode("utf-8"))
    for k, v in fields.items():
        add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n")
    add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; filename=\"{path.name}\"\r\nContent-Type: {mime}\r\n\r\n")
    body.extend(path.read_bytes())
    add(f"\r\n--{boundary}--\r\n")
    req = urllib.request.Request(f"https://api.telegram.org/bot{token()}/{method}", data=bytes(body), headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def send(chat_id: int | str, text: str, keyboard: Optional[Dict[str, Any]] = None) -> None:
    payload = {"chat_id": chat_id, "text": clip(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if keyboard:
        payload["reply_markup"] = keyboard
    api("sendMessage", payload)


def edit(chat_id: int | str, message_id: int, text: str, keyboard: Optional[Dict[str, Any]] = None) -> None:
    payload = {"chat_id": chat_id, "message_id": message_id, "text": clip(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if keyboard:
        payload["reply_markup"] = keyboard
    api("editMessageText", payload)


def answer_callback(callback_id: str, text: str = "") -> None:
    api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180]})


def send_doc(chat_id: int | str, path: Path, caption: str = "") -> None:
    multipart_api("sendDocument", {"chat_id": chat_id, "caption": caption[:900]}, "document", path, "application/octet-stream")


def send_photo(chat_id: int | str, path: Path, caption: str = "") -> None:
    multipart_api("sendPhoto", {"chat_id": chat_id, "caption": caption[:900]}, "photo", path, "image/png")


def is_admin(chat_id: Any) -> bool:
    return str(chat_id) in set(settings().get("admin_ids") or [])


def require_admin(chat_id: Any) -> bool:
    tg = settings()
    if not tg.get("admin_ids"):
        send(chat_id, f"Бот ещё не привязан. Твой chat_id: <code>{esc(chat_id)}</code>\nВставь его в AWGUI → Telegram → Save & apply.")
        return False
    if not is_admin(chat_id):
        send(chat_id, f"Access denied. Твой chat_id: <code>{esc(chat_id)}</code>")
        return False
    return True


def allow_dangerous() -> bool:
    return bool(settings().get("allow_dangerous"))


def main_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "Status", "callback_data": "m:status"}, {"text": "Clients", "callback_data": "m:clients:0"}],
        [{"text": "Add temp", "callback_data": "m:addhelp"}, {"text": "Backup", "callback_data": "m:backup"}],
        [{"text": "Diagnostics", "callback_data": "m:diag"}, {"text": "Server", "callback_data": "m:server"}],
    ]}


def server_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "show", "callback_data": "m:show"}, {"text": "check", "callback_data": "m:check"}],
        [{"text": "restart", "callback_data": "confirm:restart"}, {"text": "repair-module", "callback_data": "confirm:repair"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}


def clients() -> List[Dict[str, Any]]:
    return parse.clients_from(adapter.list_clients().get("json"))


def client_by_index(i: str) -> Tuple[Optional[Dict[str, Any]], str]:
    try:
        idx = int(i)
    except Exception:
        return None, ""
    items = clients()
    if idx < 0 or idx >= len(items):
        return None, ""
    return items[idx], parse.name(items[idx])


def clients_keyboard(page: int = 0, per_page: int = 8) -> Dict[str, Any]:
    items = clients()
    page = max(0, int(page or 0))
    start = page * per_page
    rows = []
    for idx, c in enumerate(items[start:start + per_page], start=start):
        name = parse.name(c)
        state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
        icon = "●" if state == "ONLINE" else "○"
        rows.append([{"text": f"{icon} {name[:42]}", "callback_data": f"ci:{idx}"}])
    nav = []
    if page > 0:
        nav.append({"text": "←", "callback_data": f"m:clients:{page-1}"})
    if start + per_page < len(items):
        nav.append({"text": "→", "callback_data": f"m:clients:{page+1}"})
    if nav:
        rows.append(nav)
    rows.append([{"text": "← main", "callback_data": "m:main"}])
    return {"inline_keyboard": rows}


def client_keyboard(idx: int) -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "QR", "callback_data": f"qr:{idx}"}, {"text": "conf", "callback_data": f"conf:{idx}"}, {"text": "vpnuri", "callback_data": f"vpn:{idx}"}],
        [{"text": "bundle", "callback_data": f"bundle:{idx}"}, {"text": "regen", "callback_data": f"confirm:regen:{idx}"}, {"text": "remove", "callback_data": f"confirm:remove:{idx}"}],
        [{"text": "← clients", "callback_data": "m:clients:0"}, {"text": "main", "callback_data": "m:main"}],
    ]}


def confirm_keyboard(action: str, value: str) -> Dict[str, Any]:
    return {"inline_keyboard": [[{"text": "Confirm", "callback_data": f"do:{action}:{value}"}, {"text": "Cancel", "callback_data": "m:main"}]]}


def format_status() -> str:
    s = adapter.summary()
    st = adapter.status()
    return f"<b>AWGUI v{esc(config.APP_VERSION)}</b>\nClients: <b>{s['clients_total']}</b> / online <b>{s['clients_online']}</b>\nParent status: <b>{'OK' if st.get('ok') else 'FAIL'}</b>\n<pre>{esc(clip(st.get('text') or '', 1700))}</pre>"


def format_client(c: Dict[str, Any]) -> str:
    state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
    return f"<b>{esc(parse.name(c))}</b>\nIPv4: <code>{esc(parse.ipv4(c))}</code>\nIPv6: <code>{esc(parse.ipv6(c))}</code>\nHandshake: {esc(parse.handshake(c))}\nStatus: <b>{esc(state)}</b>"


def audit(action: str, target: str, result: Dict[str, Any], chat_id: Any) -> None:
    store.audit("telegram", str(chat_id), action, target, result)


def handle_command(chat_id: Any, text: str) -> None:
    if text.startswith("/id"):
        send(chat_id, f"chat_id: <code>{esc(chat_id)}</code>")
        return
    if not require_admin(chat_id):
        return
    parts = text.split()
    cmd = parts[0].lower()
    if cmd in {"/start", "/menu", "/help"}:
        send(chat_id, "<b>AWGUI cockpit</b>\nВыбери действие.", main_keyboard())
    elif cmd == "/status":
        send(chat_id, format_status(), main_keyboard())
    elif cmd == "/clients":
        send(chat_id, "<b>Clients</b>", clients_keyboard(0))
    elif cmd == "/client" and len(parts) > 1:
        name = parts[1]
        c = next((x for x in clients() if parse.name(x) == name), None)
        send(chat_id, format_client(c) if c else "client not found", main_keyboard())
    elif cmd == "/add" and len(parts) > 1:
        expires = parts[2] if len(parts) > 2 else None
        psk = "psk" in [p.lower() for p in parts[2:]]
        result = adapter.add_client(parts[1], expires=expires if expires != "psk" else None, psk=psk)
        audit("client.add", parts[1], result, chat_id)
        send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
    elif cmd == "/backup":
        result = adapter.backup()
        audit("backup.create", "", result, chat_id)
        send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
        if result.get("ok") and settings().get("send_backup"):
            backups = adapter.list_backups()
            if backups:
                send_doc(chat_id, Path(backups[0]["path"]), "latest AWG backup")
    elif cmd == "/diagnose":
        carrier = parts[1] if len(parts) > 1 else None
        result = adapter.diagnose(carrier)
        audit("diagnose", carrier or "", result, chat_id)
        send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
    else:
        send(chat_id, "Команды: /id /menu /status /clients /client NAME /add NAME [7d] [psk] /backup /diagnose [carrier]", main_keyboard())


def handle_callback(cb: Dict[str, Any]) -> None:
    qid = cb["id"]
    msg = cb.get("message") or {}
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    data = cb.get("data") or ""
    answer_callback(qid)
    if not require_admin(chat_id):
        return
    try:
        if data == "m:main":
            edit(chat_id, message_id, "<b>AWGUI cockpit</b>", main_keyboard())
        elif data == "m:status":
            edit(chat_id, message_id, format_status(), main_keyboard())
        elif data.startswith("m:clients:"):
            edit(chat_id, message_id, "<b>Clients</b>", clients_keyboard(int(data.split(":")[-1])))
        elif data == "m:addhelp":
            edit(chat_id, message_id, "Add client:\n<code>/add NAME</code>\n<code>/add NAME 7d</code>\n<code>/add NAME 7d psk</code>", main_keyboard())
        elif data == "m:server":
            edit(chat_id, message_id, "<b>Server actions</b>", server_keyboard())
        elif data == "m:backup":
            result = adapter.backup(); audit("backup.create", "", result, chat_id)
            send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
            if result.get("ok") and settings().get("send_backup"):
                backups = adapter.list_backups()
                if backups: send_doc(chat_id, Path(backups[0]["path"]), "latest AWG backup")
        elif data == "m:diag":
            result = adapter.diagnose(); audit("diagnose", "", result, chat_id)
            send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
        elif data == "m:show":
            result = adapter.show(); send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", server_keyboard())
        elif data == "m:check":
            result = adapter.check(); audit("server.check", "awg0", result, chat_id); send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", server_keyboard())
        elif data.startswith("ci:"):
            c, name = client_by_index(data.split(":", 1)[1]); edit(chat_id, message_id, format_client(c) if c else "client not found", client_keyboard(int(data.split(':')[1])) if c else clients_keyboard(0))
        elif data.startswith("qr:"):
            c, name = client_by_index(data.split(":", 1)[1])
            p = adapter.find_client_file(name, "png") if name else None
            if p: send_photo(chat_id, p, name)
            else: send(chat_id, "PNG QR not found. Use web UI for SVG fallback.", main_keyboard())
        elif data.startswith("conf:") or data.startswith("vpn:") or data.startswith("bundle:"):
            action, idx = data.split(":", 1); c, name = client_by_index(idx)
            if not name: send(chat_id, "client not found", main_keyboard()); return
            if action == "bundle": p = adapter.create_client_bundle(name)
            else: p = adapter.find_client_file(name, "conf" if action == "conf" else "vpnuri")
            if p: send_doc(chat_id, Path(p), name)
            else: send(chat_id, "file not found", main_keyboard())
        elif data.startswith("confirm:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled in AWGUI → Telegram.", main_keyboard()); return
            _, action, *rest = data.split(":")
            value = rest[0] if rest else ""
            edit(chat_id, message_id, f"Confirm <b>{esc(action)}</b> {esc(value)}?", confirm_keyboard(action, value))
        elif data.startswith("do:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled.", main_keyboard()); return
            _, action, value = data.split(":", 2)
            if action == "restart": result = adapter.restart(); target = "awg0"
            elif action == "repair": result = adapter.repair_module(); target = "module"
            elif action == "regen": c, target = client_by_index(value); result = adapter.regen_client(target)
            elif action == "remove": c, target = client_by_index(value); result = adapter.remove_client(target)
            else: raise ValueError("bad action")
            audit(action, target, result, chat_id)
            send(chat_id, f"<pre>{esc(result.get('text'))}</pre>", main_keyboard())
    except Exception as exc:
        send(chat_id, f"<b>Error</b>\n<pre>{esc(type(exc).__name__ + ': ' + str(exc))}</pre>", main_keyboard())


def poll() -> None:
    if not token():
        log("disabled: empty token")
        return
    try:
        api("deleteWebhook", {"drop_pending_updates": False}, timeout=20)
    except Exception as exc:
        log(f"deleteWebhook failed: {exc}")
    offset = 0
    log("polling started")
    while True:
        try:
            resp = api("getUpdates", {"timeout": 45, "offset": offset, "allowed_updates": ["message", "callback_query"]}, timeout=60)
            for upd in resp.get("result", []):
                offset = max(offset, int(upd.get("update_id", 0)) + 1)
                if "message" in upd:
                    msg = upd["message"]
                    chat_id = msg.get("chat", {}).get("id")
                    text = msg.get("text") or ""
                    if text: handle_command(chat_id, text.strip())
                elif "callback_query" in upd:
                    handle_callback(upd["callback_query"])
        except KeyboardInterrupt:
            raise
        except Exception:
            traceback.print_exc()
            time.sleep(4)


if __name__ == "__main__":
    poll()
