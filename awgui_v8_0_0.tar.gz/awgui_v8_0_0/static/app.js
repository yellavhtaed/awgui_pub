document.addEventListener('submit', function (e) {
  const form = e.target;
  const msg = form && form.getAttribute && form.getAttribute('data-confirm');
  if (msg && !confirm(msg)) e.preventDefault();
});
