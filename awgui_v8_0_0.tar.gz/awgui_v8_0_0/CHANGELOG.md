# Changelog

## v8.0.0

- Rebuilt the project around `manage_adapter.py` as the only path to `manage_amneziawg.sh`.
- Added upstream compatibility scanner for commands/options/carrier support.
- Added lifecycle-first client UI with temporary clients and PSK support.
- Added client bundle zip.
- Added backup center with archive preview and SHA256.
- Added focused diagnostics page.
- Added SQLite audit log for web and Telegram actions.
- Reworked Telegram into inline cockpit with guarded destructive actions.
- Reworked visual design: calmer palette, compact cards, less neon.
- Added release gate to prevent old `/bot` CLI-first text and old version labels from shipping again.
- Added upgrade health check that verifies the actually running app reports v8.0.0.
