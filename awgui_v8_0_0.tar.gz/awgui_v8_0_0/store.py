from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import config


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def conn() -> sqlite3.Connection:
    config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init_db() -> None:
    with conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS audit (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              source TEXT NOT NULL,
              actor TEXT NOT NULL,
              action TEXT NOT NULL,
              target TEXT NOT NULL DEFAULT '',
              ok INTEGER NOT NULL,
              rc INTEGER NOT NULL DEFAULT 0,
              duration REAL NOT NULL DEFAULT 0,
              cmd TEXT NOT NULL DEFAULT '',
              text TEXT NOT NULL DEFAULT ''
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit(ts DESC)")
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS traffic_snapshots (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              ts TEXT NOT NULL,
              client TEXT NOT NULL,
              rx INTEGER,
              tx INTEGER,
              handshake TEXT,
              status TEXT,
              raw TEXT NOT NULL DEFAULT ''
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_traffic_client_ts ON traffic_snapshots(client, ts DESC)")
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS settings (
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL,
              updated_at TEXT NOT NULL
            )
            """
        )


def audit(source: str, actor: str, action: str, target: str, result: Dict[str, Any]) -> None:
    init_db()
    text = (result.get("text") or result.get("stderr") or result.get("stdout") or "")
    if len(text) > 6000:
        text = text[:6000] + "\n--- cut ---"
    with conn() as c:
        c.execute(
            """
            INSERT INTO audit(ts, source, actor, action, target, ok, rc, duration, cmd, text)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                now(), source or "web", actor or "admin", action or "unknown", target or "",
                1 if result.get("ok") else 0, int(result.get("rc") or 0), float(result.get("duration") or 0),
                str(result.get("cmd") or ""), str(text or ""),
            ),
        )


def list_audit(limit: int = 120) -> List[Dict[str, Any]]:
    init_db()
    limit = max(1, min(int(limit or 120), 500))
    with conn() as c:
        rows = c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def set_setting(key: str, value: Any) -> None:
    init_db()
    with conn() as c:
        c.execute(
            "INSERT INTO settings(key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, json.dumps(value, ensure_ascii=False), now()),
        )


def get_setting(key: str, default: Any = None) -> Any:
    init_db()
    with conn() as c:
        row = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["value"])
    except Exception:
        return row["value"]


def _to_int(value: Any) -> Optional[int]:
    if value in (None, "", "-"):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip().lower().replace(",", ".")
    # Accept raw bytes or rough human values: 12.3 KiB, 1.5 GB
    parts = text.split()
    try:
        n = float(parts[0])
    except Exception:
        digits = "".join(ch for ch in text if ch.isdigit())
        return int(digits) if digits else None
    unit = parts[1] if len(parts) > 1 else "b"
    mult = 1
    if unit.startswith("k"):
        mult = 1024
    elif unit.startswith("m"):
        mult = 1024 ** 2
    elif unit.startswith("g"):
        mult = 1024 ** 3
    elif unit.startswith("t"):
        mult = 1024 ** 4
    return int(n * mult)


def record_stats_snapshot(clients: Iterable[Dict[str, Any]]) -> int:
    init_db()
    ts = now()
    count = 0
    with conn() as c:
        for item in clients:
            if not isinstance(item, dict):
                continue
            name = item.get("name") or item.get("client") or item.get("client_name") or item.get("Name")
            if not name:
                continue
            rx = _to_int(item.get("rx") or item.get("received") or item.get("transfer_rx"))
            tx = _to_int(item.get("tx") or item.get("sent") or item.get("transfer_tx"))
            handshake = str(item.get("latest_handshake") or item.get("last_handshake") or item.get("handshake") or "")
            status = str(item.get("status") or item.get("state") or "")
            c.execute(
                "INSERT INTO traffic_snapshots(ts, client, rx, tx, handshake, status, raw) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (ts, str(name), rx, tx, handshake, status, json.dumps(item, ensure_ascii=False)),
            )
            count += 1
    return count


def latest_traffic(limit: int = 80) -> List[Dict[str, Any]]:
    init_db()
    with conn() as c:
        rows = c.execute("SELECT * FROM traffic_snapshots ORDER BY id DESC LIMIT ?", (max(1, min(limit, 500)),)).fetchall()
    return [dict(r) for r in rows]
