#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import subprocess
import urllib.request
from datetime import timedelta
from pathlib import Path
from typing import Any, Dict

from flask import Flask, Response, jsonify, redirect, render_template, request, send_file, session, url_for

import config
import manage_adapter
import parse
import store

app = Flask(__name__)
app.secret_key = config.SECRET
app.permanent_session_lifetime = timedelta(hours=12)
adapter = manage_adapter.default_adapter()
store.init_db()


@app.context_processor
def globals_for_templates():
    return {
        "app_name": config.APP_NAME,
        "app_version": config.APP_VERSION,
        "app_tagline": config.APP_TAGLINE,
        "server_name": config.SERVER_NAME,
        "parse": parse,
        "online_window": config.ONLINE_WINDOW_SECONDS,
    }


def logged_in() -> bool:
    return session.get("auth") is True


def wants_json() -> bool:
    return request.path.startswith("/api/") or "application/json" in (request.headers.get("Accept") or "")


@app.before_request
def auth_guard():
    if request.endpoint == "static" or request.path in {"/health", "/login"}:
        return None
    if logged_in():
        return None
    if wants_json():
        return jsonify({"ok": False, "error": "auth required"}), 401
    return redirect(url_for("login", next=request.path))


def actor() -> str:
    return str(session.get("user") or "admin")


def audit(action: str, target: str, result: Dict[str, Any], source: str = "web") -> Dict[str, Any]:
    store.audit(source, actor(), action, target, result)
    return result


def notice(text: str):
    session["notice"] = text


def error(text: str):
    session["error"] = text


def pop_flash() -> Dict[str, str]:
    return {"notice": session.pop("notice", ""), "error": session.pop("error", "")}


def systemctl(*args: str, timeout: int = 12) -> Dict[str, Any]:
    cmd = ["systemctl", *args]
    if not shutil.which("systemctl"):
        return manage_adapter.make_result(cmd, 127, "", "systemctl not found")
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return manage_adapter.make_result(cmd, p.returncode, p.stdout.strip(), p.stderr.strip())
    except Exception as exc:
        return manage_adapter.make_result(cmd, 1, "", f"{type(exc).__name__}: {exc}")


def control_bot_service(enabled: bool) -> Dict[str, Any]:
    if enabled:
        return {"enable": systemctl("enable", "awgui-bot.service"), "restart": systemctl("restart", "awgui-bot.service")}
    return {"stop": systemctl("stop", "awgui-bot.service"), "disable": systemctl("disable", "awgui-bot.service")}


def bot_service_status() -> Dict[str, Any]:
    return adapter.systemctl_state("awgui-bot.service")


def telegram_get_me(token_value: str) -> Dict[str, Any]:
    token_value = config.validate_bot_token(token_value, required=True)
    url = f"https://api.telegram.org/bot{token_value}/getMe"
    try:
        with urllib.request.urlopen(url, timeout=12) as r:
            payload = json.loads(r.read().decode("utf-8"))
        if not payload.get("ok"):
            return {"ok": False, "error": payload.get("description") or "Telegram returned ok=false"}
        return {"ok": True, "bot": payload.get("result") or {}}
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


@app.get("/login")
def login():
    if logged_in():
        return redirect(url_for("dashboard"))
    return render_template("login.html", user=config.USER, error="")


@app.post("/login")
def login_post():
    if request.form.get("username", "") == config.USER and request.form.get("password", "") == config.PASSWORD:
        session.clear()
        session.permanent = True
        session["auth"] = True
        session["user"] = config.USER
        return redirect(request.args.get("next") or url_for("dashboard"))
    return render_template("login.html", user=request.form.get("username", ""), error="Неверный логин или пароль"), 401


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
def dashboard():
    summary = adapter.summary()
    status = adapter.status()
    doctor = adapter.doctor()
    return render_template("dashboard.html", summary=summary, status=status, doctor=doctor, last=adapter.read_last(), audit_rows=store.list_audit(8), **pop_flash())


@app.get("/clients")
def clients_page():
    list_result = adapter.list_clients()
    stats_result = adapter.stats()
    clients = parse.clients_from(list_result.get("json"))
    return render_template("clients.html", clients=clients, list_result=list_result, stats_result=stats_result, **pop_flash())


@app.post("/clients/add")
def client_add():
    name = request.form.get("name", "").strip()
    try:
        result = adapter.add_client(name, expires=request.form.get("expires", "").strip() or None, psk=bool(request.form.get("psk")))
        audit("client.add", name, result)
        if result.get("ok"):
            notice(f"Клиент {name} создан")
            return redirect(url_for("client_detail", name=name))
        error(result.get("text") or "add failed")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("clients_page"))


@app.get("/clients/<name>")
def client_detail(name):
    list_result = adapter.list_clients()
    clients = parse.clients_from(list_result.get("json"))
    client = next((c for c in clients if parse.name(c) == name), None)
    return render_template(
        "client.html",
        name=name,
        client=client,
        inventory=adapter.file_inventory(name),
        conf_text=adapter.read_client_text(name, "conf"),
        vpnuri_text=adapter.read_client_text(name, "vpnuri"),
        **pop_flash(),
    )


@app.post("/clients/<name>/remove")
def client_remove(name):
    try:
        result = adapter.remove_client(name)
        audit("client.remove", name, result)
        if result.get("ok"):
            notice(f"Клиент {name} удалён")
            return redirect(url_for("clients_page"))
        error(result.get("text") or "remove failed")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.post("/clients/<name>/regen")
def client_regen(name):
    try:
        result = adapter.regen_client(name)
        audit("client.regen", name, result)
        notice("Файлы клиента перегенерированы" if result.get("ok") else result.get("text", "regen failed"))
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.post("/clients/<name>/modify")
def client_modify(name):
    try:
        result = adapter.modify_client(name, request.form.get("param", ""), request.form.get("value", ""))
        audit("client.modify", f"{name}:{request.form.get('param','')}", result)
        notice("Параметр изменён" if result.get("ok") else result.get("text", "modify failed"))
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("client_detail", name=name))


@app.get("/clients/<name>/download/<kind>")
def client_download(name, kind):
    if kind not in {"conf", "vpnuri"}:
        return Response("bad kind", status=400)
    p = adapter.find_client_file(name, kind)
    if not p:
        return Response(f"{kind} not found", status=404)
    return send_file(p, mimetype="text/plain", as_attachment=True, download_name=f"{name}.{kind}")


@app.get("/clients/<name>/bundle.zip")
def client_bundle(name):
    try:
        p = adapter.create_client_bundle(name)
        return send_file(p, mimetype="application/zip", as_attachment=True, download_name=f"{name}_awgui_bundle.zip")
    except Exception as exc:
        return Response(f"{type(exc).__name__}: {exc}", status=404)


@app.get("/clients/<name>/qr")
def client_qr(name):
    png = adapter.find_client_file(name, "png")
    if png:
        return send_file(png, mimetype="image/png", as_attachment=False, download_name=f"{name}.png")
    source_name, source = adapter.qr_payload(name, request.args.get("source", "vpnuri"))
    if not source:
        return Response("QR source not found", status=404)
    try:
        p = subprocess.run(["qrencode", "-t", "SVG", "-m", "2"], input=source, text=True, capture_output=True, timeout=30)
    except FileNotFoundError:
        return Response(manage_adapter.error_svg("qrencode not installed", "sudo apt install -y qrencode"), mimetype="image/svg+xml", status=503)
    if p.returncode != 0:
        return Response(manage_adapter.error_svg("QR failed", p.stderr[:160]), mimetype="image/svg+xml", status=500)
    return Response(p.stdout, mimetype="image/svg+xml", headers={"X-QR-Source": source_name or "unknown"})


@app.get("/backups")
def backups_page():
    selected = request.args.get("preview", "").strip()
    preview = None
    if selected:
        p = adapter.find_backup(selected)
        preview = adapter.backup_preview(p) if p else {"ok": False, "error": "backup not found", "items": []}
    return render_template("backups.html", backups=adapter.list_backups(), selected=selected, preview=preview, **pop_flash())


@app.post("/backups/create")
def backup_create():
    result = adapter.backup()
    audit("backup.create", "", result)
    notice("Backup создан" if result.get("ok") else result.get("text", "backup failed"))
    return redirect(url_for("backups_page"))


@app.post("/backups/<name>/restore")
def backup_restore(name):
    p = adapter.find_backup(name)
    if not p:
        error("Backup не найден")
    else:
        try:
            result = adapter.restore(str(p))
            audit("backup.restore", name, result)
            notice("Restore выполнен" if result.get("ok") else result.get("text", "restore failed"))
        except Exception as exc:
            error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("backups_page", preview=name))


@app.get("/backups/<name>/download")
def backup_download(name):
    p = adapter.find_backup(name)
    if not p:
        return Response("backup not found", status=404)
    return send_file(p, mimetype="application/gzip", as_attachment=True, download_name=p.name)


@app.get("/diagnostics")
def diagnostics_page():
    carrier = request.args.get("carrier", "").strip() or None
    diag_result = None
    if carrier:
        diag_result = adapter.diagnose(carrier)
        audit("diagnose", carrier, diag_result)
    return render_template("diagnostics.html", doctor=adapter.doctor(), carriers=config.CARRIERS, selected_carrier=carrier or "", diag_result=diag_result, **pop_flash())


@app.post("/server/action")
def server_action():
    action = request.form.get("action", "")
    try:
        if action == "check":
            result = adapter.check()
        elif action == "restart":
            result = adapter.restart()
        elif action == "repair-module":
            result = adapter.repair_module()
        else:
            raise ValueError("unknown server action")
        audit(f"server.{action}", "awg0", result)
        notice(f"{action}: {'OK' if result.get('ok') else 'FAIL'}")
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(request.referrer or url_for("dashboard"))


@app.get("/audit")
def audit_page():
    return render_template("audit.html", rows=store.list_audit(160), **pop_flash())


@app.get("/logs")
def logs_page():
    return render_template("logs.html", log_text=adapter.tail_log(800), **pop_flash())


@app.get("/bot")
def bot_page():
    return render_template("bot.html", tg=config.load_telegram_settings(), service=bot_service_status(), token_check=session.pop("token_check", None), service_action=session.pop("service_action", None), **pop_flash())


@app.post("/bot/save")
def bot_save():
    try:
        tg = config.save_telegram_settings(
            enabled=bool(request.form.get("enabled")),
            token_value=request.form.get("token", ""),
            admin_ids_value=request.form.get("admin_ids", ""),
            send_backup=bool(request.form.get("send_backup")),
            allow_dangerous=bool(request.form.get("allow_dangerous")),
        )
        session["service_action"] = control_bot_service(bool(tg["enabled"]))
        notice("Telegram настройки сохранены")
        if tg["enabled"]:
            session["token_check"] = telegram_get_me(str(tg["token"]))
    except Exception as exc:
        error(f"{type(exc).__name__}: {exc}")
    return redirect(url_for("bot_page"))


@app.post("/bot/test")
def bot_test():
    token = request.form.get("token", "").strip() or str(config.load_telegram_settings().get("token") or "")
    session["token_check"] = telegram_get_me(token)
    return redirect(url_for("bot_page"))


@app.post("/bot/restart")
def bot_restart():
    session["service_action"] = control_bot_service(True)
    notice("awgui-bot перезапущен")
    return redirect(url_for("bot_page"))


@app.get("/api/version")
def api_version():
    return jsonify({"app": config.APP_NAME, "version": config.APP_VERSION, "server": config.SERVER_ID})


@app.get("/api/summary")
def api_summary():
    return jsonify(adapter.summary())


@app.get("/api/clients")
def api_clients():
    r = adapter.list_clients()
    return jsonify({"ok": r.get("ok"), "clients": parse.clients_from(r.get("json")), "raw": r})


@app.get("/api/stats")
def api_stats():
    r = adapter.stats()
    clients = parse.clients_from(r.get("json"))
    if clients:
        store.record_stats_snapshot(clients)
    return jsonify({"ok": r.get("ok"), "clients": clients, "raw": r})


@app.get("/api/doctor")
def api_doctor():
    return jsonify(adapter.doctor())


@app.get("/api/audit")
def api_audit():
    return jsonify({"ok": True, "rows": store.list_audit(200)})


@app.get("/api/bot")
def api_bot():
    tg = config.load_telegram_settings()
    return jsonify({"ok": True, "telegram": {k: v for k, v in tg.items() if k != "token"}, "service": bot_service_status()})


@app.get("/health")
def health():
    return jsonify({"app": config.APP_NAME, "ok": True, "version": config.APP_VERSION})


if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT)
