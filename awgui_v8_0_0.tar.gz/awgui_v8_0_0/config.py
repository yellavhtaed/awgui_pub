from __future__ import annotations

import os
import re
import secrets
import tempfile
from pathlib import Path
from typing import Dict, List

APP_NAME = "AWGUI"
APP_VERSION = Path(__file__).with_name("VERSION").read_text(encoding="utf-8").strip()
APP_TAGLINE = "AmneziaWG control layer"

ROOT = Path(__file__).resolve().parent
ENV_FILE = Path(os.getenv("AWGUI_ENV_FILE", "/etc/awgui.env"))
STATE_DIR = Path(os.getenv("AWGUI_STATE_DIR", "/var/lib/awgui"))
FALLBACK_STATE_DIR = ROOT / ".state"


def _state_dir() -> Path:
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        return STATE_DIR
    except Exception:
        FALLBACK_STATE_DIR.mkdir(parents=True, exist_ok=True)
        return FALLBACK_STATE_DIR

DATA_DIR = _state_dir()
DB_PATH = Path(os.getenv("AWGUI_DB", str(DATA_DIR / "awgui.db")))
LOG_FILE = Path(os.getenv("AWGUI_LOG", str(DATA_DIR / "awgui.log")))
LAST_FILE = Path(os.getenv("AWGUI_LAST", str(DATA_DIR / "last_action.json")))

HOST = os.getenv("AWGUI_HOST", "127.0.0.1")
PORT = int(os.getenv("AWGUI_PORT", "8080"))
USER = os.getenv("AWGUI_USER", "admin")
PASSWORD = os.getenv("AWGUI_PASSWORD", "devpass")
SECRET = os.getenv("AWGUI_SECRET", "") or secrets.token_hex(32)

MANAGE = Path(os.getenv("AWGUI_MANAGE", "/root/awg/manage_amneziawg.sh"))
AWG_DIR = Path(os.getenv("AWGUI_AWG_DIR", "/root/awg"))
SERVER_CONF = Path(os.getenv("AWGUI_SERVER_CONF", "/etc/amnezia/amneziawg/awg0.conf"))
SERVER_ID = os.getenv("AWGUI_SERVER_ID", "local")
SERVER_NAME = os.getenv("AWGUI_SERVER_NAME", "Local AWG")
ONLINE_WINDOW_SECONDS = int(os.getenv("AWGUI_ONLINE_WINDOW_SECONDS", "180"))
DEFAULT_TIMEOUT = int(os.getenv("AWGUI_DEFAULT_TIMEOUT", "45"))

CARRIERS = [
    "beeline_msk",
    "yota_msk",
    "tele2_msk",
    "tele2_krasnoyarsk",
    "tattelecom",
    "megafon_regions",
    "tmobile_us",
]

TOKEN_RE = re.compile(r"^[0-9]{5,20}:[A-Za-z0-9_-]{20,}$")
ADMIN_ID_RE = re.compile(r"^-?[0-9]{5,20}$")


def bool_from_env(value, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on", "enabled"}


def parse_env_file(path: Path = ENV_FILE) -> Dict[str, str]:
    data: Dict[str, str] = {}
    try:
        for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if k:
                data[k] = v
    except FileNotFoundError:
        pass
    return data


def merged_env() -> Dict[str, str]:
    data = parse_env_file()
    data.update({k: v for k, v in os.environ.items() if k.startswith("AWGUI_")})
    return data


def write_env_values(updates: Dict[str, str], path: Path = ENV_FILE) -> Dict[str, str]:
    data = parse_env_file(path)
    data.update({k: str(v) for k, v in updates.items()})
    lines = ["# AWGUI runtime config. Edited by AWGUI UI."]
    for key in sorted(data):
        value = data[key]
        safe = str(value).replace("\\", "\\\\").replace('"', '\\"')
        lines.append(f'{key}="{safe}"')
    text = "\n".join(lines) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    finally:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except Exception:
            pass
    return data


def parse_admin_ids(value: str) -> List[str]:
    if not value:
        return []
    out: List[str] = []
    for item in re.split(r"[\s,;]+", str(value).strip()):
        if not item:
            continue
        if ADMIN_ID_RE.match(item):
            out.append(item)
    return sorted(set(out), key=out.index)


def validate_admin_ids(value: str) -> List[str]:
    raw = [x for x in re.split(r"[\s,;]+", str(value or "").strip()) if x]
    bad = [x for x in raw if not ADMIN_ID_RE.match(x)]
    if bad:
        raise ValueError("bad Telegram admin chat_id: " + ", ".join(bad[:3]))
    return sorted(set(raw), key=raw.index)


def validate_bot_token(value: str, *, required: bool = False) -> str:
    token = str(value or "").strip()
    if not token:
        if required:
            raise ValueError("Telegram token is required when bot is enabled")
        return ""
    if not TOKEN_RE.match(token):
        raise ValueError("bad Telegram bot token format")
    return token


def mask_token(value: str) -> str:
    token = str(value or "")
    if not token:
        return ""
    if ":" not in token:
        return token[:4] + "…"
    a, b = token.split(":", 1)
    return f"{a}:…{b[-4:]}"


def load_telegram_settings() -> Dict[str, object]:
    data = merged_env()
    token = data.get("AWGUI_TG_BOT_TOKEN", "").strip()
    admins = parse_admin_ids(data.get("AWGUI_TG_ADMIN_IDS", ""))
    send_backup = bool_from_env(data.get("AWGUI_TG_SEND_BACKUP", "1"), True)
    allow_dangerous = bool_from_env(data.get("AWGUI_TG_ALLOW_DANGEROUS", "0"), False)
    return {
        "enabled": bool(token),
        "token": token,
        "token_set": bool(token),
        "token_masked": mask_token(token),
        "admin_ids": admins,
        "send_backup": send_backup,
        "allow_dangerous": allow_dangerous,
        "env_file": str(ENV_FILE),
    }


def save_telegram_settings(*, enabled: bool, token_value: str, admin_ids_value: str, send_backup: bool, allow_dangerous: bool) -> Dict[str, object]:
    existing = parse_env_file().get("AWGUI_TG_BOT_TOKEN", "").strip()
    token_value = str(token_value or "").strip()
    if token_value in {"", "********", "KEEP", "keep"} and existing:
        token_value = existing
    token = validate_bot_token(token_value, required=bool(enabled))
    admins = validate_admin_ids(admin_ids_value)
    data = write_env_values({
        "AWGUI_TG_BOT_TOKEN": token if enabled else "",
        "AWGUI_TG_ADMIN_IDS": ",".join(admins),
        "AWGUI_TG_SEND_BACKUP": "1" if send_backup else "0",
        "AWGUI_TG_ALLOW_DANGEROUS": "1" if allow_dangerous else "0",
    })
    os.environ["AWGUI_TG_BOT_TOKEN"] = data.get("AWGUI_TG_BOT_TOKEN", "")
    os.environ["AWGUI_TG_ADMIN_IDS"] = data.get("AWGUI_TG_ADMIN_IDS", "")
    os.environ["AWGUI_TG_SEND_BACKUP"] = data.get("AWGUI_TG_SEND_BACKUP", "1")
    os.environ["AWGUI_TG_ALLOW_DANGEROUS"] = data.get("AWGUI_TG_ALLOW_DANGEROUS", "0")
    return load_telegram_settings()
