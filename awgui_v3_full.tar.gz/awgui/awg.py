import json
import os
import re
import shlex
import subprocess
import time
from datetime import datetime
from pathlib import Path

import config

CLIENT_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,63}$")
SAFE_PARAM_RE = re.compile(r"^[A-Za-z0-9_.:@/+=,-]{1,240}$")
EXP_RE = re.compile(r"^[0-9]+[mhdw]?$")

ALLOWED_TOOLS = {
    "list",
    "stats",
    "status",
    "show",
    "check",
    "backup",
    "restore",
    "restart",
    "diagnose",
    "repair-module",
}


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def valid_client_name(value):
    return bool(CLIENT_NAME_RE.match(value or ""))


def valid_safe_value(value):
    return bool(SAFE_PARAM_RE.match(value or ""))


def json_default(obj):
    if isinstance(obj, Path):
        return str(obj)
    return str(obj)


def result(cmd, rc, stdout="", stderr="", parsed=None, started=None):
    stdout = stdout or ""
    stderr = stderr or ""
    text = (stdout + ("\n" if stdout and stderr else "") + stderr).strip()
    return {
        "time": now_iso(),
        "ok": rc == 0,
        "rc": rc,
        "cmd": shlex.join([str(x) for x in cmd]) if isinstance(cmd, (list, tuple)) else str(cmd),
        "stdout": stdout,
        "stderr": stderr,
        "text": text,
        "json": parsed,
        "duration": round(time.time() - started, 2) if started else 0,
    }


def parse_json_tolerant(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass

    chunks = []
    oi, oj = text.find("{"), text.rfind("}")
    ai, aj = text.find("["), text.rfind("]")
    if oi != -1 and oj != -1 and oj > oi:
        chunks.append(text[oi:oj + 1])
    if ai != -1 and aj != -1 and aj > ai:
        chunks.append(text[ai:aj + 1])

    for chunk in chunks:
        try:
            return json.loads(chunk)
        except Exception:
            continue
    return None


def append_log(entry):
    try:
        config.LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with config.LOG_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False, default=json_default) + "\n")
    except Exception:
        pass


def write_last(entry):
    try:
        config.LAST_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.LAST_FILE.write_text(
            json.dumps(entry, ensure_ascii=False, indent=2, default=json_default),
            encoding="utf-8",
        )
    except Exception:
        pass


def save_action(entry):
    write_last(entry)
    append_log(entry)
    return entry


def read_last():
    try:
        return json.loads(config.LAST_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def tail_log(lines=400):
    try:
        data = config.LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(data[-lines:])
    except Exception:
        return ""


def run_manage(*args, json_mode=False, timeout=None, save=True):
    timeout = timeout or config.DEFAULT_TIMEOUT
    started = time.time()
    cmd = ["bash", str(config.MANAGE), "--no-color"]
    if json_mode:
        cmd.append("--json")
    cmd.extend([str(x) for x in args if x is not None and str(x) != ""])

    if not config.MANAGE.exists() or not config.MANAGE.is_file():
        entry = result(cmd, 127, stderr=f"manage script not found: {config.MANAGE}", started=started)
        return save_action(entry) if save else entry

    env = os.environ.copy()
    env.setdefault("LC_ALL", "C.UTF-8")
    env.setdefault("LANG", "C.UTF-8")
    cwd = str(config.AWG_DIR if config.AWG_DIR.exists() else Path("/tmp"))

    try:
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        stdout = proc.stdout.strip()
        stderr = proc.stderr.strip()
        parsed = parse_json_tolerant(stdout) if json_mode else None
        entry = result(cmd, proc.returncode, stdout=stdout, stderr=stderr, parsed=parsed, started=started)
    except subprocess.TimeoutExpired as exc:
        entry = result(
            cmd,
            124,
            stdout=(exc.stdout or "") if isinstance(exc.stdout, str) else "",
            stderr=(exc.stderr or "Timeout") if isinstance(exc.stderr, str) else "Timeout",
            started=started,
        )
    except Exception as exc:
        entry = result(cmd, 1, stderr=f"{type(exc).__name__}: {exc}", started=started)

    return save_action(entry) if save else entry


# Read-only commands

def list_clients():
    return run_manage("list", json_mode=True, save=False)


def stats():
    return run_manage("stats", json_mode=True, save=False)


def status():
    return run_manage("status", save=False)


def show():
    return run_manage("show", save=True)


def check():
    return run_manage("check", save=True)


# Client actions

def add_client(name, expires=None, psk=False):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name: use A-Z a-z 0-9 _ - up to 63 chars")

    args = []
    if expires:
        expires = expires.strip()
        if not EXP_RE.match(expires):
            raise ValueError("bad expires: use 1d / 7d / 30d / 12h / 60m")
        args.append(f"--expires={expires}")
    if psk:
        args.append("--psk")
    args += ["--yes", "add", name]
    return run_manage(*args, timeout=300, save=True)


def remove_client(name):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    return run_manage("--yes", "remove", name, timeout=300, save=True)


def regen_client(name):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    return run_manage("regen", name, timeout=300, save=True)


def modify_client(name, param, value):
    name = (name or "").strip()
    param = (param or "").strip()
    value = (value or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    if not valid_safe_value(param):
        raise ValueError("bad param")
    if not value:
        raise ValueError("empty value")
    return run_manage("modify", name, param, value, timeout=300, save=True)


# Server actions

def backup():
    return run_manage("backup", timeout=300, save=True)


def restore(backup_path):
    backup_path = (backup_path or "").strip()
    if not backup_path:
        raise ValueError("backup path required")
    path = Path(backup_path)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"backup file not found: {backup_path}")
    return run_manage("--yes", "restore", str(path), timeout=600, save=True)


def restart():
    return run_manage("--yes", "restart", timeout=300, save=True)


def repair_module():
    return run_manage("repair-module", timeout=600, save=True)


def diagnose(carrier=None):
    carrier = (carrier or "").strip()
    args = []
    if carrier:
        if not valid_safe_value(carrier):
            raise ValueError("bad carrier")
        args.append(f"--carrier={carrier}")
    args.append("diagnose")
    return run_manage(*args, timeout=300, save=True)


def run_tool(action, carrier=None, backup_path=None, backup_name=None):
    action = (action or "").strip()
    if action not in ALLOWED_TOOLS:
        raise ValueError(f"unknown action: {action}")
    if action == "list":
        return run_manage("list", json_mode=True, save=True)
    if action == "stats":
        return run_manage("stats", json_mode=True, save=True)
    if action == "status":
        return run_manage("status", save=True)
    if action == "show":
        return show()
    if action == "check":
        return check()
    if action == "backup":
        return backup()
    if action == "restore":
        if backup_name and not backup_path:
            path = find_backup_by_name(backup_name)
            backup_path = str(path) if path else ""
        return restore(backup_path)
    if action == "restart":
        return restart()
    if action == "repair-module":
        return repair_module()
    if action == "diagnose":
        return diagnose(carrier)
    raise ValueError(f"unknown action: {action}")


# Client files

def find_client_file(name, suffix):
    name = (name or "").strip()
    if not valid_client_name(name):
        return None
    suffix = suffix.lstrip(".")
    candidates = [
        config.AWG_DIR / f"{name}.{suffix}",
        config.AWG_DIR / "clients" / f"{name}.{suffix}",
        config.AWG_DIR / "configs" / f"{name}.{suffix}",
        config.AWG_DIR / "client_configs" / f"{name}.{suffix}",
        config.AWG_DIR / "peer_configs" / f"{name}.{suffix}",
        config.AWG_DIR / "output" / f"{name}.{suffix}",
    ]
    for path in candidates:
        if path.exists() and path.is_file():
            return path
    try:
        for path in config.AWG_DIR.rglob(f"{name}.{suffix}"):
            if path.is_file():
                return path
    except Exception:
        pass
    return None


def read_client_text(name, suffix):
    path = find_client_file(name, suffix)
    if not path:
        return None
    return path.read_text(encoding="utf-8", errors="replace")


def file_inventory(name):
    return {
        "conf": str(find_client_file(name, "conf") or ""),
        "vpnuri": str(find_client_file(name, "vpnuri") or ""),
        "png": str(find_client_file(name, "png") or ""),
    }


# Backups

def human_size(num):
    try:
        num = float(num)
    except Exception:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"


def list_backups():
    seen = set()
    items = []
    for root in config.BACKUP_DIRS:
        if not root.exists() or not root.is_dir():
            continue
        for pattern in ("*.tar.gz", "*.tgz", "*.zip", "*.bak"):
            for path in root.glob(pattern):
                try:
                    real = path.resolve()
                    if real in seen or not real.is_file():
                        continue
                    seen.add(real)
                    st = real.stat()
                    items.append({
                        "name": real.name,
                        "path": str(real),
                        "size": st.st_size,
                        "size_h": human_size(st.st_size),
                        "mtime": st.st_mtime,
                        "mtime_h": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    })
                except Exception:
                    continue
    items.sort(key=lambda x: x["mtime"], reverse=True)
    return items


def find_backup_by_name(name):
    name = (name or "").strip()
    if "/" in name or "\\" in name or name.startswith("."):
        return None
    for item in list_backups():
        if item["name"] == name:
            return Path(item["path"])
    return None


# Self-check

def self_check():
    return {
        "version": config.VERSION,
        "manage": str(config.MANAGE),
        "manage_exists": config.MANAGE.exists(),
        "awg_dir": str(config.AWG_DIR),
        "awg_dir_exists": config.AWG_DIR.exists(),
        "log_file": str(config.LOG_FILE),
        "last_file": str(config.LAST_FILE),
        "running_as_root": os.geteuid() == 0,
        "uid": os.geteuid(),
    }
