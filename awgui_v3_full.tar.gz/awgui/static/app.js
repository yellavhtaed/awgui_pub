function copyBlock(id) {
  const el = document.getElementById(id);
  if (!el) return;
  navigator.clipboard.writeText(el.innerText || el.textContent || "");
}

window.copyBlock = copyBlock;
