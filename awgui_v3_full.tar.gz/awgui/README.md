# AWGUI v3

Лёгкая локальная Flask-панель поверх `/root/awg/manage_amneziawg.sh`.

Нет Docker, нет базы, нет второго VPN-движка.

## Запуск вручную

```bash
cd ~/awgui
sudo ./run.sh
```

Открыть:

```text
http://127.0.0.1:8080/?token=dev
```

## Установка systemd

```bash
cd ~/awgui
sudo ./install.sh
```

## Проверка

```bash
curl http://127.0.0.1:8080/health
curl 'http://127.0.0.1:8080/api/self-check?token=dev'
```

## Возможности

- Dashboard
- Clients
- Client detail
- QR / conf / vpnuri
- add / remove / regen / modify
- tools: list, stats, status, show, check, backup, restore, restart, diagnose, repair-module
- backups list / download / restore
- logs
- localhost-only
- token auth
- allowlist команд
