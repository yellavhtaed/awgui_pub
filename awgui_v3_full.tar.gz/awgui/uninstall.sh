#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "run as root"; exit 1; }
systemctl disable --now awgui.service 2>/dev/null || true
rm -f /etc/systemd/system/awgui.service
systemctl daemon-reload
