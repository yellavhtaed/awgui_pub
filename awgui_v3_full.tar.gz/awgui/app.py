#!/usr/bin/env python3
import json
import os
import subprocess

from flask import Flask, Response, jsonify, redirect, render_template, request, send_file, url_for

import awg
import config
import parse

app = Flask(__name__)
app.secret_key = os.getenv("AWGUI_SECRET", "dev-change-me")


def want_json():
    return request.args.get("format") == "json" or "application/json" in (request.headers.get("Accept") or "")


@app.context_processor
def inject_globals():
    return {
        "app_name": config.APP_NAME,
        "version": config.VERSION,
        "token": config.TOKEN,
        "parse": parse,
        "self_check": awg.self_check(),
    }


def authorized():
    return request.values.get("token") == config.TOKEN


@app.before_request
def auth_guard():
    if request.endpoint == "static" or request.path == "/health":
        return None
    if not authorized():
        return Response("Forbidden. Use ?token=dev or set AWGUI_TOKEN.", status=403)
    return None


def go(endpoint, **kwargs):
    kwargs.setdefault("token", config.TOKEN)
    return redirect(url_for(endpoint, **kwargs))


def save_exception(exc):
    entry = {
        "time": awg.now_iso(),
        "ok": False,
        "rc": 1,
        "cmd": "internal",
        "stdout": "",
        "stderr": f"{type(exc).__name__}: {exc}",
        "text": f"{type(exc).__name__}: {exc}",
        "json": None,
        "duration": 0,
    }
    awg.save_action(entry)
    return entry


@app.get("/")
def dashboard():
    list_result = awg.list_clients()
    stats_result = awg.stats()
    status_result = awg.status()
    clients = parse.clients_from(list_result["json"])
    last = awg.read_last()
    return render_template(
        "dashboard.html",
        clients=clients,
        list_result=list_result,
        stats_result=stats_result,
        status_result=status_result,
        service_state=parse.service_state(status_result["text"]),
        backups=awg.list_backups(),
        last=last,
    )


@app.get("/clients")
def clients():
    list_result = awg.list_clients()
    clients_data = parse.clients_from(list_result["json"])
    return render_template(
        "clients.html",
        clients=clients_data,
        list_result=list_result,
        stats_result=awg.stats(),
        last=awg.read_last(),
    )


@app.get("/clients/<name>")
def client_detail(name):
    list_result = awg.list_clients()
    clients_data = parse.clients_from(list_result["json"])
    client = next((item for item in clients_data if parse.name(item) == name), None)
    return render_template(
        "client.html",
        name=name,
        client=client,
        inventory=awg.file_inventory(name),
        conf_text=awg.read_client_text(name, "conf") or "",
        vpnuri_text=awg.read_client_text(name, "vpnuri") or "",
        list_result=list_result,
        stats_result=awg.stats(),
        last=awg.read_last(),
    )


@app.post("/clients/add")
def client_add():
    try:
        awg.add_client(
            request.form.get("name", "").strip(),
            expires=request.form.get("expires", "").strip() or None,
            psk=bool(request.form.get("psk")),
        )
    except Exception as exc:
        save_exception(exc)
    return go("clients")


@app.post("/clients/remove")
def client_remove():
    name = request.form.get("name", "").strip()
    try:
        awg.remove_client(name)
    except Exception as exc:
        save_exception(exc)
    return go("clients")


@app.post("/clients/regen")
def client_regen():
    name = request.form.get("name", "").strip()
    try:
        awg.regen_client(name)
    except Exception as exc:
        save_exception(exc)
    return go("client_detail", name=name) if name else go("clients")


@app.post("/clients/modify")
def client_modify():
    name = request.form.get("name", "").strip()
    try:
        awg.modify_client(
            name,
            request.form.get("param", "").strip(),
            request.form.get("value", "").strip(),
        )
    except Exception as exc:
        save_exception(exc)
    return go("client_detail", name=name) if name else go("clients")


@app.get("/clients/<name>/conf")
def client_conf(name):
    path = awg.find_client_file(name, "conf")
    if not path:
        return Response("config not found", status=404)
    return send_file(path, mimetype="text/plain", as_attachment=False, download_name=f"{name}.conf")


@app.get("/clients/<name>/vpnuri")
def client_vpnuri(name):
    path = awg.find_client_file(name, "vpnuri")
    if not path:
        return Response("vpnuri not found", status=404)
    return send_file(path, mimetype="text/plain", as_attachment=False, download_name=f"{name}.vpnuri")


@app.get("/clients/<name>/qr")
def client_qr(name):
    png = awg.find_client_file(name, "png")
    if png:
        return send_file(png, mimetype="image/png", as_attachment=False, download_name=f"{name}.png")

    source = awg.read_client_text(name, "vpnuri") or awg.read_client_text(name, "conf")
    if not source:
        return Response("QR source not found", status=404)

    try:
        proc = subprocess.run(["qrencode", "-t", "SVG"], input=source, text=True, capture_output=True, timeout=20)
        if proc.returncode == 0 and proc.stdout.strip():
            return Response(proc.stdout, mimetype="image/svg+xml")
    except Exception:
        pass
    return Response(source, mimetype="text/plain")


@app.get("/clients/<name>/inventory")
def client_inventory(name):
    return jsonify(awg.file_inventory(name))


@app.get("/tools")
def tools():
    return render_template(
        "tools.html",
        carriers=config.CARRIERS,
        backups=awg.list_backups(),
        status_result=awg.status(),
        stats_result=awg.stats(),
        last=awg.read_last(),
    )


@app.post("/tools/run")
def tools_run():
    try:
        awg.run_tool(
            request.form.get("action", "").strip(),
            carrier=request.form.get("carrier", "").strip() or None,
            backup_path=request.form.get("backup_path", "").strip() or None,
            backup_name=request.form.get("backup_name", "").strip() or None,
        )
    except Exception as exc:
        save_exception(exc)
    return go("tools")


@app.get("/backups/<name>/download")
def backup_download(name):
    path = awg.find_backup_by_name(name)
    if not path:
        return Response("backup not found", status=404)
    return send_file(path, mimetype="application/octet-stream", as_attachment=True, download_name=path.name)


@app.get("/logs")
def logs():
    return render_template("logs.html", log_text=awg.tail_log(500), last=awg.read_last())


# API
@app.get("/api/self-check")
def api_self_check():
    return jsonify(awg.self_check())


@app.get("/api/clients")
def api_clients():
    return jsonify(awg.list_clients())


@app.get("/api/status")
def api_status():
    return jsonify(awg.status())


@app.get("/api/stats")
def api_stats():
    return jsonify(awg.stats())


@app.get("/api/backups")
def api_backups():
    return jsonify(awg.list_backups())


@app.get("/api/last")
def api_last():
    return jsonify(awg.read_last() or {})


@app.get("/api/logs")
def api_logs():
    return Response(awg.tail_log(500), mimetype="text/plain")


@app.get("/health")
def health():
    return jsonify({"ok": True, "app": config.APP_NAME, "version": config.VERSION})


if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Run as root: sudo ./run.sh")
        raise SystemExit(1)
    if not config.MANAGE.exists():
        print(f"Not found: {config.MANAGE}")
        raise SystemExit(1)
    app.run(host=config.HOST, port=config.PORT, debug=False)
