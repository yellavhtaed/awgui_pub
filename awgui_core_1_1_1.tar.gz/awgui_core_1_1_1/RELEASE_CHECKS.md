# Release checks 1.1.1

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/python tests/verify_release.py
```

Перед выпуском на реальных серверах дополнительно проверить:

1. существующую установку bivlked до и после установки панели;
2. local и SSH server status;
3. полный цикл add/list/stats/modify/regen/remove;
4. backup/download/upload/restore;
5. restart и repair-module с подтверждением;
6. Telegram parity;
7. две VPS для AWG0 → AWG1 по `CASCADE.md`;
8. реальный клиентский трафик RU и non-RU;
9. reboot AWG0, reboot AWG1 и восстановление каскада;
10. несколько независимых каскадных пар.

Не отмечать DKMS/reboot/сетевой путь как пройденные без физического стенда.
