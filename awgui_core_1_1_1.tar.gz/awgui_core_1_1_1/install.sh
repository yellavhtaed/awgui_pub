#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Запустите: sudo $0" >&2; exit 1; }

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="/opt/awgui"
STAGE="/opt/.awgui-stage.$$"
ROLLBACK="/opt/.awgui-rollback.$$"
STATE_DIR="/var/lib/awgui"
ENV_FILE="/etc/awgui.env"
WEB_UNIT="/etc/systemd/system/awgui.service"
BOT_UNIT="/etc/systemd/system/awgui-bot.service"
NEW_CREDENTIALS=0
NEW_ENV=0
OLD_TARGET=0
INSTALL_FINISHED=0
TRANSACTION_STARTED=0

for command in python3 openssl systemctl; do
  command -v "$command" >/dev/null 2>&1 || {
    echo "Не найдена обязательная команда: $command" >&2
    exit 1
  }
done

WEB_WAS_ENABLED=0
BOT_WAS_ENABLED=0
WEB_WAS_ACTIVE=0
BOT_WAS_ACTIVE=0
systemctl is-enabled --quiet awgui.service 2>/dev/null && WEB_WAS_ENABLED=1 || true
systemctl is-enabled --quiet awgui-bot.service 2>/dev/null && BOT_WAS_ENABLED=1 || true
systemctl is-active --quiet awgui.service 2>/dev/null && WEB_WAS_ACTIVE=1 || true
systemctl is-active --quiet awgui-bot.service 2>/dev/null && BOT_WAS_ACTIVE=1 || true

cleanup() {
  rm -rf "$STAGE"
  if [[ $INSTALL_FINISHED -eq 1 ]]; then
    rm -rf "$ROLLBACK"
  fi
}

show_failure_logs() {
  echo >&2
  echo "--- awgui.service ---" >&2
  systemctl --no-pager --full status awgui.service 2>&1 | tail -n 40 >&2 || true
  echo >&2
  echo "--- journalctl -u awgui.service ---" >&2
  journalctl --no-pager -u awgui.service -n 80 2>&1 >&2 || true
}

restore_previous() {
  set +e
  systemctl disable --now awgui.service awgui-bot.service >/dev/null 2>&1 || true
  rm -rf "$TARGET"

  if [[ $OLD_TARGET -eq 1 && -d "$ROLLBACK/app" ]]; then
    mv "$ROLLBACK/app" "$TARGET"
    [[ -f "$ROLLBACK/awgui.service" ]] && cp -a "$ROLLBACK/awgui.service" "$WEB_UNIT"
    [[ -f "$ROLLBACK/awgui-bot.service" ]] && cp -a "$ROLLBACK/awgui-bot.service" "$BOT_UNIT"
  else
    rm -f "$WEB_UNIT" "$BOT_UNIT"
  fi

  if [[ $NEW_ENV -eq 1 ]]; then
    rm -f "$ENV_FILE"
  fi

  systemctl daemon-reload >/dev/null 2>&1 || true
  if [[ $OLD_TARGET -eq 1 ]]; then
    [[ $WEB_WAS_ENABLED -eq 1 ]] && systemctl enable awgui.service >/dev/null 2>&1 || true
    [[ $BOT_WAS_ENABLED -eq 1 ]] && systemctl enable awgui-bot.service >/dev/null 2>&1 || true
    [[ $WEB_WAS_ACTIVE -eq 1 ]] && systemctl start awgui.service >/dev/null 2>&1 || true
    [[ $BOT_WAS_ACTIVE -eq 1 ]] && systemctl start awgui-bot.service >/dev/null 2>&1 || true
  fi
  rm -rf "$ROLLBACK"
  set -e
}

on_error() {
  local rc=$?
  local line=${1:-unknown}
  trap - ERR
  echo "Ошибка установки AWGUI в строке $line." >&2
  if [[ $TRANSACTION_STARTED -eq 1 ]]; then
    show_failure_logs
    restore_previous
    if [[ $OLD_TARGET -eq 1 ]]; then
      echo "Установка отменена; предыдущая рабочая версия восстановлена." >&2
    else
      echo "Установка отменена; неполная новая установка удалена." >&2
    fi
  fi
  exit "$rc"
}

trap 'on_error $LINENO' ERR
trap cleanup EXIT

install -d -m 700 "$STATE_DIR"
rm -rf "$STAGE" "$ROLLBACK"
install -d -m 755 "$STAGE" "$ROLLBACK"
cp -a "$SOURCE_DIR"/. "$STAGE"/
find "$STAGE" -type d -name __pycache__ -prune -exec rm -rf {} +
chmod 700 "$STAGE/install.sh" "$STAGE/uninstall.sh" "$STAGE/vendor/bivlked/awg-routing.sh"
python3 -m py_compile "$STAGE"/panel/*.py

if [[ ! -f "$ENV_FILE" ]]; then
  PASSWORD="$(openssl rand -hex 10)"
  SECRET="$(openssl rand -hex 32)"
  umask 077
  cat > "$ENV_FILE" <<EOF_ENV
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_ADMIN_USER=admin
AWGUI_ADMIN_PASSWORD=$PASSWORD
AWGUI_SECRET_KEY=$SECRET
AWGUI_BASE_DIR=$TARGET
AWGUI_VENDOR_DIR=$TARGET/vendor/bivlked
AWGUI_STATE_DIR=$STATE_DIR
EOF_ENV
  NEW_CREDENTIALS=1
  NEW_ENV=1
fi
chmod 600 "$ENV_FILE"

if [[ -d "$TARGET" ]]; then
  cp -a "$TARGET" "$ROLLBACK/app"
  [[ -f "$WEB_UNIT" ]] && cp -a "$WEB_UNIT" "$ROLLBACK/awgui.service"
  [[ -f "$BOT_UNIT" ]] && cp -a "$BOT_UNIT" "$ROLLBACK/awgui-bot.service"
  OLD_TARGET=1
fi

TRANSACTION_STARTED=1
systemctl disable --now awgui.service awgui-bot.service 2>/dev/null || true
rm -rf "$TARGET"

# Виртуальное окружение создаётся только после помещения приложения по
# окончательному пути. Иначе console scripts содержат shebang на удалённый
# staging-каталог и systemd не может запустить gunicorn.
mv "$STAGE" "$TARGET"
python3 -m venv "$TARGET/.venv"
"$TARGET/.venv/bin/python" -m pip install --disable-pip-version-check --no-input -r "$TARGET/requirements.txt"
"$TARGET/.venv/bin/python" -m pip check
AWGUI_BASE_DIR="$TARGET" AWGUI_STATE_DIR="$STATE_DIR" \
  "$TARGET/.venv/bin/python" -m py_compile "$TARGET"/panel/*.py

cat > "$WEB_UNIT" <<EOF_UNIT
[Unit]
Description=AWGUI web panel for installed AmneziaWG
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m gunicorn --workers 1 --threads 4 --timeout 1800 --bind \${AWGUI_HOST}:\${AWGUI_PORT} 'panel.web:create_app()'
Restart=on-failure
RestartSec=3
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF_UNIT

cat > "$BOT_UNIT" <<EOF_UNIT
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m panel.telegram
Restart=always
RestartSec=5
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF_UNIT

systemctl daemon-reload
systemctl enable --now awgui.service awgui-bot.service
systemctl is-active --quiet awgui.service

# Проверка использует настройки bind из /etc/awgui.env и стандартную библиотеку
# Python. Наличие curl и установленной AmneziaWG для установки панели не требуется.
python3 - "$ENV_FILE" <<'PY'
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

settings = {}
for raw in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    line = raw.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, value = line.split("=", 1)
    settings[key.strip()] = value.strip().strip('"').strip("'")

host = settings.get("AWGUI_HOST", "127.0.0.1")
port = int(settings.get("AWGUI_PORT", "8080"))
if host in {"0.0.0.0", "::", "[::]"}:
    host = "127.0.0.1" if host == "0.0.0.0" else "::1"
url_host = f"[{host}]" if ":" in host and not host.startswith("[") else host
url = f"http://{url_host}:{port}/health"
deadline = time.monotonic() + 30
last_error = "нет ответа"
while time.monotonic() < deadline:
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            data = json.load(response)
        if data.get("panel") == "ok":
            raise SystemExit(0)
        last_error = f"неожиданный ответ: {data!r}"
    except (OSError, ValueError, urllib.error.URLError) as exc:
        last_error = str(exc)
    time.sleep(1)
print(f"Health-check {url} не пройден: {last_error}", file=sys.stderr)
raise SystemExit(1)
PY

INSTALL_FINISHED=1
rm -rf "$ROLLBACK"
trap - ERR

DISPLAY_HOST="$(awk -F= '$1=="AWGUI_HOST"{print substr($0,index($0,"=")+1); exit}' "$ENV_FILE")"
DISPLAY_PORT="$(awk -F= '$1=="AWGUI_PORT"{print substr($0,index($0,"=")+1); exit}' "$ENV_FILE")"
DISPLAY_HOST="${DISPLAY_HOST:-127.0.0.1}"
DISPLAY_PORT="${DISPLAY_PORT:-8080}"

echo
echo "AWGUI установлена: http://${DISPLAY_HOST}:${DISPLAY_PORT}"
echo "Удалённый доступ: ssh -L ${DISPLAY_PORT}:127.0.0.1:${DISPLAY_PORT} root@SERVER_IP"
if [[ $NEW_CREDENTIALS -eq 1 ]]; then
  echo "Логин: admin"
  echo "Пароль: $PASSWORD"
else
  echo "Учётные данные сохранены в $ENV_FILE"
fi
