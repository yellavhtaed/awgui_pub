from pathlib import Path

root = Path(__file__).resolve().parents[1]
script = (root / "install.sh").read_text(encoding="utf-8")

move = script.index('mv "$STAGE" "$TARGET"')
venv = script.index('python3 -m venv "$TARGET/.venv"')
assert move < venv, "venv must be created only at its final path"
assert 'python3 -m venv "$STAGE/.venv"' not in script
assert 'ExecStart=$TARGET/.venv/bin/python -m gunicorn' in script
assert 'curl -fsS' not in script
assert 'local_awg_installed' not in script
assert 'AWGUI_HOST' in script and 'AWGUI_PORT' in script
print("AWGUI installer contract OK")
