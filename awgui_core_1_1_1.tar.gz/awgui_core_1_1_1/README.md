# AWGUI Core 1.1.1

AWGUI — компактная Web-панель и Telegram-бот для централизованного управления несколькими серверами AmneziaWG, установленными через `bivlked/amneziawg-installer`.

## Принцип работы

AWGUI не устанавливает, не обновляет и не удаляет AmneziaWG. На каждом управляемом сервере должен уже находиться рабочий:

```text
/root/awg/manage_amneziawg.sh
```

Панель локально или по SSH вызывает именно этот скрипт. Она не генерирует ключи, не редактирует `awg0.conf`, не распределяет адреса клиентов и не дублирует логику bivlked.

Один экземпляр AWGUI управляет любым количеством зарегистрированных серверов. На удалённые VPS агент или копия панели не устанавливаются.

## Функции

### Серверы

- local и SSH-серверы;
- SSH-аутентификация по ключу;
- произвольный SSH-порт и путь к `manage_amneziawg.sh`;
- проверка manager, AWG binary, модуля, `awg0`, systemd, ядра и DKMS;
- выбор активного сервера независимо в Web и Telegram.

### Полный интерфейс `manage_amneziawg.sh`

```text
add remove list stats regen modify
backup restore check status diagnose show restart repair-module help
```

Поддерживаются:

- несколько клиентов за операцию;
- `--expires=1h|12h|1d|7d|30d|4w`;
- `--psk`;
- `--apply-mode=syncconf|restart`;
- JSON list/stats;
- изменение `DNS`, `Endpoint`, `AllowedIPs`, `PersistentKeepalive`;
- `.conf`, QR, `.vpnuri`, vpn URI QR и общий архив клиента;
- carrier-профили диагностики;
- создание, загрузка, скачивание и восстановление backup.

### Каскад

Раздел «Каскад» оркестрирует официальный сценарий `CASCADE.md` для пары AWG0 → AWG1:

1. проверка двух установленных manager;
2. проверка разных подсетей;
3. установка `curl` и `ipset` на AWG0;
4. создание link-client на AWG1 через `manage_amneziawg.sh add`;
5. перенос его конфигурации на AWG0;
6. только документированные правки: удаление `DNS` и добавление `Table = off`;
7. отказ при отсутствии `AllowedIPs = 0.0.0.0/0` — AWGUI не переписывает это поле;
8. запуск `awg-quick@awg1`;
9. установка точного `awg-routing.sh`, извлечённого из vendored `CASCADE.md`;
10. подстановка только `CLIENT_SUBNET` и `AWG1_ENDPOINT`, как требует инструкция;
11. запуск маршрутизации и установка точного systemd unit из инструкции;
12. проверка handshake, rule, table 100, ipset, RETURN, MARK и MASQUERADE;
13. удаление каскадных объектов на AWG0 и link-client на AWG1.

Несколько независимых пар управляются из одной панели. Multi-exit, автоматический failover, балансировка и multi-hop не заявлены, так как их нет в официальном сценарии bivlked.

## Структура

```text
awgui_core_1_1_1/
├── panel/                 Web, Telegram, SSH runner и вызовы manager
├── vendor/bivlked/        точный CASCADE.md, routing script и systemd unit
├── tests/
├── install.sh             устанавливает только AWGUI
├── uninstall.sh           удаляет только AWGUI
└── requirements.txt
```

Полный `amneziawg-installer` в поставку панели не входит.

## Подготовка серверов

На каждом сервере самостоятельно установите AmneziaWG по документации bivlked. Затем подготовьте ключ на машине с AWGUI:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP \
  'test -x /root/awg/manage_amneziawg.sh && echo OK'
```

Пароли серверов AWGUI не хранит.

## Установка панели

```bash
tar -xzf awgui_core_1_1_1.tar.gz
cd awgui_core_1_1_0
sudo ./install.sh
```

Установщик панели:

- создаёт staging-каталог для исходников, затем venv сразу в окончательном `/opt/awgui`;
- проверяет Python-код до переключения;
- сохраняет `/etc/awgui.env` и `/var/lib/awgui`;
- атомарно заменяет `/opt/awgui`;
- запускает health-check;
- восстанавливает предыдущую версию при неуспешном health-check.

Панель слушает `127.0.0.1:8080`. Открыть её с рабочего компьютера:

```bash
ssh -L 8080:127.0.0.1:8080 root@PANEL_SERVER
```

Затем открыть `http://127.0.0.1:8080`.

## Удаление панели

```bash
sudo /opt/awgui/uninstall.sh
```

Сохранить настройки и реестр серверов:

```bash
sudo /opt/awgui/uninstall.sh --keep-data
```

Удаление AWGUI не вызывает installer, не удаляет `/root/awg` и не меняет AmneziaWG.

## Надёжность

- JSON-state без SQL;
- межпроцессный `flock` для Web и Telegram;
- атомарная запись state с `fsync` и предыдущей копией;
- отдельный lock изменяющих операций для каждого сервера;
- атомарная запись локальных и удалённых файлов;
- завершение всей локальной process group при timeout;
- CSRF, авторизация и блокировка внешнего `next` redirect;
- root-пароли не сохраняются;
- Web и Telegram используют один `AWGManager` и один набор операций.

## Проверка релиза

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/python tests/verify_release.py
```

Проверяются:

- Python и shell syntax;
- прямой контракт fake `manage_amneziawg.sh`;
- клиенты, файлы, backup и restore;
- Web auth и CSRF;
- отсутствие open redirect;
- конкурентные записи state из нескольких процессов;
- Telegram parity и callback удаления;
- отсутствие installer/deploy функций в панели;
- byte-for-byte совпадение routing script и unit с `CASCADE.md`;
- отказ от самовольной правки non-full-tunnel `AllowedIPs`.

Реальные DKMS, reboot и сетевой путь каскада требуют настоящих VPS с root-доступом. Автоматические тесты не подменяют эту проверку.
