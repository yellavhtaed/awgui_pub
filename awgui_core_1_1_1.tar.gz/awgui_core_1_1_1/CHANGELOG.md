# Changelog

## 1.1.1

- Исправлен критический дефект установки: venv больше не переносится из staging-каталога с невалидными shebang.
- Gunicorn запускается через `python -m gunicorn`.
- Health-check учитывает `AWGUI_HOST`/`AWGUI_PORT`, не зависит от curl и не требует установленной AmneziaWG.
- При ошибке установщик выводит `systemctl status` и журнал службы перед rollback.
- Rollback восстанавливает приложение и systemd units предыдущей версии.

## 1.1.0

- AWGUI отделена от установки AmneziaWG.
- Удалены bundled installer, его Web-формы, Telegram-команды и SSH deploy.
- Все операции AWG выполняются только установленным `manage_amneziawg.sh`.
- Добавлена системная статистика manager/AWG/module/interface/systemd/kernel/DKMS.
- Удалено поле `installer_dir` из inventory с автоматической очисткой старого state.
- Добавлен межпроцессный `flock` для state и отдельный lock изменяющих операций сервера.
- Исправлен Telegram callback удаления одного клиента.
- Исправлен внешний redirect после login.
- Timeout теперь завершает локальную process group.
- Локальная и удалённая запись файлов стала атомарной.
- `install.sh` обновляет панель через staging, health-check и rollback.
- `uninstall.sh` больше не умеет и не пытается удалять AmneziaWG.
- Каскад использует точный `awg-routing.sh` и systemd unit из `CASCADE.md`.
- AWGUI меняет в конфиге каскада только `DNS` и `Table`, а non-full-tunnel `AllowedIPs` отклоняет.
- Удаление каскада удаляет также созданный link-client на AWG1.
- Расширены автоматические тесты и release gate.

## 1.0.0

- Исходная полная сборка AWGUI.
