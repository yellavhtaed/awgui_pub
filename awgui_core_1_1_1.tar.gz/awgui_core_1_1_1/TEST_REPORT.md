# AWGUI Core 1.1.1 — test report

Дата проверки: 2026-07-10.

## Пройдено

- компиляция всех Python-модулей;
- `bash -n` для install/uninstall, fake scripts и upstream routing script;
- установка зависимостей Flask 3.1.3 и Gunicorn 26.0.0 в чистое venv;
- `pip check` без конфликтов;
- фактический вызов `help` реального `manage_amneziawg.sh` v5.18.4 из предоставленного архива;
- наличие всех поддерживаемых команд manager в реальном CLI help;
- add/list/stats/modify/regen/remove через fake manager;
- client conf/QR/vpnuri bundle;
- backup list/download/upload/restore paths;
- local и fake-SSH inventory;
- одновременная запись state шестью процессами без lost update;
- Web login, CSRF и основные маршруты;
- блокировка внешнего `next` redirect;
- Telegram add и подтверждённое удаление одного клиента;
- отсутствие installer/deploy функций в Web, Telegram и manager wrapper;
- byte-for-byte совпадение `vendor/bivlked/awg-routing.sh` с bash-блоком `CASCADE.md`;
- byte-for-byte совпадение systemd unit с ini-блоком `CASCADE.md`;
- каскадная правка только `DNS` и `Table = off`;
- сохранение `AllowedIPs` без самовольной модификации;
- отказ от non-full-tunnel конфига;
- отказ от перезаписи существующих отличающихся `awg1.conf` и `awg-routing.sh`;
- контракт установщика: venv создаётся только в окончательном пути, Gunicorn запускается через `python -m gunicorn`, health-check не зависит от curl или наличия AWG;
- изолированный installer smoke-test: чистая установка без `/root/awg` и `manage_amneziawg.sh`, запуск службы, HTTP `/health`, затем полное удаление без остаточных файлов;
- проверка итогового tar.gz после повторной распаковки в чистый каталог.

## Не могло быть физически выполнено в текущей среде

- сборка и загрузка DKMS-модуля;
- reboot физической VPS;
- systemd как PID 1;
- `CAP_NET_ADMIN`, iptables/ipset и реальный AWG-туннель;
- сетевой путь реального клиента AWG0 → AWG1 между двумя VPS;
- сценарий нескольких реальных независимых каскадных пар.

Эти пункты не заявляются как пройденные. Для них нужна отдельная VPS-матрица из README/RELEASE_CHECKS.md.
