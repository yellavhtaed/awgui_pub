# AWGUI v5.0.0

Лёгкая локальная веб-панель и Telegram-бот для управления уже установленным AmneziaWG через `/root/awg/manage_amneziawg.sh`.

AWGUI не ставит второй VPN-движок, не использует Docker, не ведёт свою базу клиентов и не трогает сетевую логику напрямую. Вся управляющая логика остаётся в `manage_amneziawg.sh`; AWGUI только приводит её в человеческий веб- и Telegram-интерфейс.

## Возможности

### Web UI

- Login/password-сессия.
- Dashboard: клиенты, online count, status, stats, `awg show`, last action.
- Clients: add/remove/regen/modify, expiry duration, expiry calendar, PSK.
- Client detail: QR для Amnezia, `.conf`, `.vpnuri`, traffic, handshake, endpoint, raw JSON.
- Copy buttons с fallback-режимом.
- Backup manager: create/list/download/restore.
- Tools: `list`, `stats`, `status`, `show`, `check`, `backup`, `restore`, `restart`, `diagnose`, `repair-module`.
- Logs: audit log действий AWGUI.
- API endpoints для статуса, клиентов, логов.

### Telegram Bot

Дублирует базовые действия панели:

- `/id` — получить chat_id.
- `/status` — статус сервера.
- `/clients` — список клиентов.
- `/client NAME` — карточка клиента + inline-кнопки QR/conf/vpnuri/regen.
- `/add NAME [7d] [psk]` — добавить клиента.
- `/remove NAME` — удалить клиента.
- `/regen NAME` — перегенерировать клиента.
- `/conf NAME` — прислать `.conf`.
- `/vpnuri NAME` — прислать `.vpnuri`.
- `/qr NAME` — прислать QR-код для Amnezia.
- `/backup` — создать backup и прислать файл.
- `/backups` — список backup-файлов.
- `/show`, `/stats`, `/check`, `/diagnose [carrier]`.
- `/restart`, `/repair` — опасные действия, можно отключить через env.

## Установка вручную

```bash
cd ~
rm -rf ~/awgui
# распакуй архив так, чтобы получилась папка ~/awgui
cd ~/awgui

sudo apt update
sudo apt install -y python3 python3-venv python3-pip qrencode

python3 -m py_compile app.py awg.py config.py parse.py telegram_bot.py
sudo ./run.sh
```

Открыть:

```text
http://127.0.0.1:8080
```

Логин:

```text
admin
```

Пароль:

```text
devpass
```

## Установка как systemd-сервис

Если ручной запуск нормальный:

```bash
cd ~/awgui
sudo ./install.sh
```

Управление:

```bash
sudo systemctl status awgui --no-pager
sudo journalctl -u awgui -f
sudo systemctl restart awgui
```

## Настройка Telegram-бота

1. Открой в Telegram `@BotFather`.
2. Создай бота командой `/newbot`.
3. Скопируй token.
4. Напиши своему новому боту `/id`.
5. На сервере запусти:

```bash
cd ~/awgui
sudo ./setup_telegram.sh
```

6. Вставь token и chat_id.
7. Проверь сервис:

```bash
sudo systemctl status awgui-bot --no-pager
sudo journalctl -u awgui-bot -f
```

Ручной запуск бота без systemd:

```bash
cd ~/awgui
sudo ./run_bot.sh
```

## Конфиг

Основной env-файл после `install.sh`:

```text
/etc/awgui.env
```

Пример:

```env
AWGUI_USER=admin
AWGUI_PASSWORD=devpass
AWGUI_SECRET=change-me
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_MANAGE=/root/awg/manage_amneziawg.sh
AWGUI_AWG_DIR=/root/awg

AWGUI_TG_BOT_TOKEN=123456:telegram-token
AWGUI_TG_ADMIN_IDS=123456789
AWGUI_TG_SEND_BACKUP=1
AWGUI_TG_ALLOW_DANGEROUS=1
```

После изменения env:

```bash
sudo systemctl restart awgui
sudo systemctl restart awgui-bot
```

## Безопасность

По умолчанию web UI слушает только `127.0.0.1:8080`. Не выставляй Flask напрямую в интернет. Для VPS нужен reverse proxy + HTTPS + basic auth / firewall.

Бот выполняет команды только для chat_id из `AWGUI_TG_ADMIN_IDS`. Пока admin list пустой, бот отвечает только на `/id` и инструкцию настройки.

AWGUI не выполняет произвольный shell: только allowlist вызовов `manage_amneziawg.sh`.

## Диагностика

Проверка Python-файлов:

```bash
cd ~/awgui
python3 -m py_compile app.py awg.py config.py parse.py telegram_bot.py
```

Web:

```bash
sudo ./run.sh
curl http://127.0.0.1:8080/health
```

Bot:

```bash
sudo ./run_bot.sh
```

Systemd:

```bash
sudo systemctl status awgui --no-pager
sudo systemctl status awgui-bot --no-pager
sudo journalctl -u awgui -n 100 --no-pager
sudo journalctl -u awgui-bot -n 100 --no-pager
```

## Что AWGUI не делает

- Не заменяет `manage_amneziawg.sh`.
- Не ставит Docker.
- Не создаёт вторую VPN-систему рядом.
- Не переписывает iptables/UFW напрямую.
- Не обещает корректный online/traffic, если сам manage-скрипт не отдаёт handshake/traffic в JSON.

## Структура

```text
awgui/
  app.py              # Flask routes
  awg.py              # safe adapter around manage_amneziawg.sh
  telegram_bot.py     # Telegram long-polling bot
  config.py           # env/config
  parse.py            # normalization helpers
  run.sh              # foreground web start
  run_bot.sh          # foreground bot start
  install.sh          # systemd services
  setup_telegram.sh   # interactive bot setup
  templates/
  static/
```
