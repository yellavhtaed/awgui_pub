from datetime import datetime, timezone
import re


def clients_from(payload):
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        for key in ("clients", "items", "data", "peers", "result"):
            value = payload.get(key)
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
    return []


def first(client, keys, default="-"):
    if not isinstance(client, dict):
        return default
    for key in keys:
        value = client.get(key)
        if value not in (None, "", [], {}):
            return value
    return default


def name(client):
    return first(client, ["name", "client", "client_name", "clientName", "Name"], "?")


def ipv4(client):
    return first(client, ["client_ip", "ipv4", "ip", "address", "allowed_ip", "allowed_ips"], "-")


def ipv6(client):
    return first(client, ["client_ipv6", "ipv6"], "-")


def traffic(client):
    return first(client, ["transfer", "traffic", "rx_tx", "usage", "rxTx", "total_transfer"], "-")


def rx(client):
    return first(client, ["rx", "received", "transfer_rx", "receive", "download"], "-")


def tx(client):
    return first(client, ["tx", "sent", "transfer_tx", "transmit", "upload"], "-")


def endpoint(client):
    return first(client, ["endpoint", "remote", "peer_endpoint", "latest_endpoint"], "-")


def expires(client):
    return first(client, ["expires", "expire", "expires_at", "expiration", "valid_until"], "-")


def handshake(client):
    return first(client, ["latest_handshake", "last_handshake", "handshake", "latestHandshake", "last_seen"], "-")


def normalize_handshake_ts(value):
    if value in (None, "", "-"):
        return None

    if isinstance(value, (int, float)):
        # seconds or milliseconds
        if value > 10_000_000_000:
            value = value / 1000
        return float(value)

    text = str(value).strip()
    if not text or text == "-":
        return None

    if text.isdigit():
        number = float(text)
        if number > 10_000_000_000:
            number = number / 1000
        return number

    low = text.lower()
    if "never" in low or "нет" in low:
        return None

    # common: "2 minutes ago", "17 seconds ago", "1 hour ago"
    m = re.search(r"(\d+)\s*(second|sec|s|minute|min|m|hour|h|day|d)", low)
    if m and "ago" in low:
        n = int(m.group(1))
        unit = m.group(2)
        mult = 1
        if unit.startswith("min") or unit == "m":
            mult = 60
        elif unit.startswith("hour") or unit == "h":
            mult = 3600
        elif unit.startswith("day") or unit == "d":
            mult = 86400
        return datetime.now(timezone.utc).timestamp() - n * mult

    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M:%S%z",
        "%d.%m.%Y %H:%M:%S",
    ):
        try:
            dt = datetime.strptime(text.replace("Z", "+0000"), fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception:
            pass

    return None


def online_state(client, window_seconds=180):
    ts = normalize_handshake_ts(handshake(client))
    if not ts:
        explicit = str(first(client, ["online", "is_online", "active", "connected"], "")).lower()
        if explicit in ("true", "1", "yes", "online", "active", "connected"):
            return "ONLINE"
        if explicit in ("false", "0", "no", "offline", "inactive"):
            return "OFFLINE"
        return "UNKNOWN"

    age = datetime.now(timezone.utc).timestamp() - ts
    if age <= window_seconds:
        return "ONLINE"
    return "OFFLINE"


def service_state(text):
    text = (text or "").lower()
    if any(x in text for x in ("failed", "inactive", "dead", "error", "not running")):
        return "FAIL"
    if any(x in text for x in ("active", "running", "ok", "listening")):
        return "OK"
    return "UNKNOWN"


def short(text, limit=7000):
    text = text or ""
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\n--- cut ---"
