#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/install.sh"
  exit 1
fi

if [[ ! -f /root/awg/manage_amneziawg.sh ]]; then
  echo "ERROR: /root/awg/manage_amneziawg.sh not found"
  exit 1
fi

apt update
apt install -y python3 python3-venv python3-pip qrencode curl

rm -rf "$ROOT/.venv"
python3 -m venv "$ROOT/.venv"
"$ROOT/.venv/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
"$ROOT/.venv/bin/pip" install -q --upgrade pip
"$ROOT/.venv/bin/pip" install -q -r "$ROOT/requirements.txt"

if [[ ! -f /etc/awgui.env ]]; then
  cat > /etc/awgui.env <<EOF
AWGUI_USER=admin
AWGUI_PASSWORD=devpass
AWGUI_SECRET=$(openssl rand -hex 24 2>/dev/null || date +%s%N)
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_MANAGE=/root/awg/manage_amneziawg.sh
AWGUI_AWG_DIR=/root/awg
AWGUI_TG_BOT_TOKEN=
AWGUI_TG_ADMIN_IDS=
AWGUI_TG_SEND_BACKUP=1
AWGUI_TG_ALLOW_DANGEROUS=1
EOF
  chmod 600 /etc/awgui.env
fi

cat > /etc/systemd/system/awgui.service <<EOF
[Unit]
Description=AWGUI local AmneziaWG panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$ROOT
EnvironmentFile=/etc/awgui.env
ExecStart=$ROOT/.venv/bin/python $ROOT/app.py
Restart=on-failure
RestartSec=2
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/awgui-bot.service <<EOF
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$ROOT
EnvironmentFile=/etc/awgui.env
ExecStart=$ROOT/.venv/bin/python $ROOT/telegram_bot.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now awgui.service
systemctl enable awgui-bot.service >/dev/null 2>&1 || true
if grep -q '^AWGUI_TG_BOT_TOKEN=.' /etc/awgui.env; then
  systemctl restart awgui-bot.service || true
fi

echo
printf 'OK: AWGUI installed\nURL: http://127.0.0.1:8080\nLogin: admin\nPassword: devpass\n'
echo
printf 'Telegram bot setup:\n  cd %s && sudo ./setup_telegram.sh\n' "$ROOT"
echo
systemctl status awgui --no-pager || true
