#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/run_bot.sh"
  exit 1
fi

if [[ -f /etc/awgui.env ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/awgui.env
  set +a
fi

if [[ ! -d .venv || ! -x .venv/bin/python || ! -x .venv/bin/pip ]]; then
  rm -rf .venv
  python3 -m venv .venv
fi

.venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1 || true
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt

exec .venv/bin/python telegram_bot.py
