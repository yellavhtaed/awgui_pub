(function () {
  function toast(message) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 1600);
  }

  async function copyText(text) {
    if (!text) return false;
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (_) { ok = false; }
      document.body.removeChild(ta);
      return ok;
    }
  }

  document.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-copy]');
    if (!btn) return;
    const selector = btn.getAttribute('data-copy');
    const target = document.querySelector(selector);
    const ok = await copyText(target ? target.innerText : '');
    toast(ok ? 'Copied' : 'Copy failed');
  });

  document.querySelectorAll('[data-preset-expire]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const days = parseInt(btn.getAttribute('data-preset-expire'), 10);
      const form = btn.closest('form');
      const dateInput = form ? form.querySelector('input[name="expires_date"]') : null;
      const textInput = form ? form.querySelector('input[name="expires"]') : null;
      const d = new Date();
      d.setDate(d.getDate() + days);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      if (dateInput) dateInput.value = `${yyyy}-${mm}-${dd}`;
      if (textInput) textInput.value = `${days}d`;
    });
  });

  async function refreshBlocks() {
    const blocks = document.querySelectorAll('[data-autorefresh]');
    for (const block of blocks) {
      try {
        const url = block.getAttribute('data-autorefresh');
        const field = block.getAttribute('data-field') || 'text';
        const r = await fetch(url, {headers: {'Accept': 'application/json'}});
        if (!r.ok) continue;
        const data = await r.json();
        block.innerText = data[field] || JSON.stringify(data, null, 2);
      } catch (_) {}
    }
  }

  if (document.querySelector('[data-autorefresh]')) {
    setInterval(refreshBlocks, 5000);
  }
})();
