#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ -f /etc/awgui.env ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/awgui.env
  set +a
fi

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/run.sh"
  exit 1
fi

if [[ ! -f /root/awg/manage_amneziawg.sh ]]; then
  echo "ERROR: /root/awg/manage_amneziawg.sh not found"
  exit 1
fi

if [[ ! -x "$(command -v python3)" ]]; then
  echo "ERROR: python3 not found"
  exit 1
fi

if [[ ! -d .venv || ! -x .venv/bin/python || ! -x .venv/bin/pip ]]; then
  rm -rf .venv
  python3 -m venv .venv
fi

.venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1 || true
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt

if ! command -v qrencode >/dev/null 2>&1; then
  echo "WARN: qrencode not found. Install: sudo apt install -y qrencode"
fi

export AWGUI_USER="${AWGUI_USER:-admin}"
export AWGUI_PASSWORD="${AWGUI_PASSWORD:-devpass}"
export AWGUI_SECRET="${AWGUI_SECRET:-local-dev-secret-change-me}"

exec .venv/bin/python app.py
