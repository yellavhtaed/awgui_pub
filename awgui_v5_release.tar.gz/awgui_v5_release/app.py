#!/usr/bin/env python3
import json
import os
import subprocess
from datetime import timedelta

from flask import Flask, Response, jsonify, redirect, render_template, request, send_file, session, url_for

import awg
import config
import parse

app = Flask(__name__)
app.secret_key = config.SECRET
app.permanent_session_lifetime = timedelta(hours=12)


@app.context_processor
def inject_globals():
    return {
        "app_name": config.APP_NAME,
        "app_version": config.APP_VERSION,
        "parse": parse,
        "self_check": awg.self_check(),
    }


def is_logged_in():
    return session.get("auth") is True


def wants_json():
    return request.path.startswith("/api/") or "application/json" in (request.headers.get("Accept") or "")


@app.before_request
def auth_guard():
    if request.endpoint == "static" or request.path in ("/health", "/login"):
        return None
    if is_logged_in():
        return None
    if wants_json():
        return jsonify({"ok": False, "error": "auth required"}), 401
    return redirect(url_for("login", next=request.path))


@app.get("/login")
def login():
    if is_logged_in():
        return redirect(url_for("dashboard"))
    return render_template("login.html", error="", user=config.USER)


@app.post("/login")
def login_post():
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    if username == config.USER and password == config.PASSWORD:
        session.clear()
        session.permanent = True
        session["auth"] = True
        session["user"] = username
        return redirect(request.args.get("next") or url_for("dashboard"))
    return render_template("login.html", error="Неверный логин или пароль", user=username), 401


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def go(endpoint: str, **values):
    return redirect(url_for(endpoint, **values))


def save_exception(exc):
    result = {
        "time": awg.now_iso(),
        "ok": False,
        "rc": 1,
        "cmd": "internal",
        "stdout": "",
        "stderr": f"{type(exc).__name__}: {exc}",
        "text": f"{type(exc).__name__}: {exc}",
        "json": None,
        "duration": 0,
    }
    awg.save_action(result)
    return result


# pages

@app.get("/")
def dashboard():
    list_result = awg.list_clients()
    stats_result = awg.stats()
    status_result = awg.status()
    show_result = awg.show(save=False)
    clients = parse.clients_from(list_result["json"])
    online = sum(1 for c in clients if parse.online_state(c, config.ONLINE_WINDOW_SECONDS) == "ONLINE")
    return render_template(
        "dashboard.html",
        clients=clients,
        online=online,
        list_result=list_result,
        stats_result=stats_result,
        status_result=status_result,
        show_result=show_result,
        service_state=parse.service_state(status_result["text"]),
        last=awg.read_last(),
    )


@app.get("/clients")
def clients():
    list_result = awg.list_clients()
    stats_result = awg.stats()
    clients_data = parse.clients_from(list_result["json"])
    return render_template(
        "clients.html",
        clients=clients_data,
        list_result=list_result,
        stats_result=stats_result,
        last=awg.read_last(),
        online_window=config.ONLINE_WINDOW_SECONDS,
    )


@app.get("/clients/<name>")
def client_detail(name):
    list_result = awg.list_clients()
    clients_data = parse.clients_from(list_result["json"])
    client = next((item for item in clients_data if parse.name(item) == name), None)
    inventory = awg.file_inventory(name)
    conf_text = awg.read_client_text(name, "conf") or ""
    vpnuri_text = awg.read_client_text(name, "vpnuri") or ""
    qr_source, qr_text = awg.qr_payload(name, request.args.get("source", "vpnuri"))
    return render_template(
        "client.html",
        name=name,
        client=client,
        inventory=inventory,
        conf_text=conf_text,
        vpnuri_text=vpnuri_text,
        qr_source=qr_source or "none",
        qr_text=qr_text or "",
        last=awg.read_last(),
        online_window=config.ONLINE_WINDOW_SECONDS,
    )


@app.get("/tools")
def tools():
    return render_template(
        "tools.html",
        carriers=config.CARRIERS,
        backups=awg.list_backups(),
        status_result=awg.status(),
        stats_result=awg.stats(),
        last=awg.read_last(),
    )


@app.get("/logs")
def logs():
    return render_template("logs.html", log_text=awg.tail_log(500), last=awg.read_last())


@app.get("/bot")
def bot_page():
    return render_template(
        "bot.html",
        tg_enabled=bool(config.TG_BOT_TOKEN),
        tg_admins=config.TG_ADMIN_IDS,
        tg_send_backup=config.TG_SEND_BACKUP,
        tg_allow_dangerous=config.TG_ALLOW_DANGEROUS,
        last=awg.read_last(),
    )


# client actions

@app.post("/clients/add")
def client_add():
    try:
        expires = awg.expires_from_form(
            expires_text=request.form.get("expires", ""),
            expires_date=request.form.get("expires_date", ""),
        )
        result = awg.add_client(
            request.form.get("name", "").strip(),
            expires=expires,
            psk=bool(request.form.get("psk")),
        )
        name = request.form.get("name", "").strip()
        if result.get("ok") and name:
            return go("client_detail", name=name)
    except Exception as exc:
        save_exception(exc)
    return go("clients")


@app.post("/clients/remove")
def client_remove():
    try:
        awg.remove_client(request.form.get("name", "").strip())
    except Exception as exc:
        save_exception(exc)
    return go("clients")


@app.post("/clients/regen")
def client_regen():
    name = request.form.get("name", "").strip()
    try:
        awg.regen_client(name)
    except Exception as exc:
        save_exception(exc)
    return go("client_detail", name=name) if name else go("clients")


@app.post("/clients/modify")
def client_modify():
    name = request.form.get("name", "").strip()
    try:
        awg.modify_client(
            name,
            request.form.get("param", "").strip(),
            request.form.get("value", "").strip(),
        )
    except Exception as exc:
        save_exception(exc)
    return go("client_detail", name=name) if name else go("clients")


# files

@app.get("/clients/<name>/conf")
def client_conf(name):
    path = awg.find_client_file(name, "conf")
    if not path:
        return Response("config not found", status=404)
    return send_file(path, mimetype="text/plain", as_attachment=False, download_name=f"{name}.conf")


@app.get("/clients/<name>/vpnuri")
def client_vpnuri(name):
    path = awg.find_client_file(name, "vpnuri")
    if not path:
        return Response("vpnuri not found", status=404)
    return send_file(path, mimetype="text/plain", as_attachment=False, download_name=f"{name}.vpnuri")


@app.get("/clients/<name>/download/<kind>")
def client_download(name, kind):
    if kind not in ("conf", "vpnuri"):
        return Response("bad kind", status=400)
    path = awg.find_client_file(name, kind)
    if not path:
        return Response(f"{kind} not found", status=404)
    return send_file(path, mimetype="text/plain", as_attachment=True, download_name=f"{name}.{kind}")


@app.get("/clients/<name>/qr")
def client_qr(name):
    preferred = request.args.get("source", "vpnuri")
    if preferred == "png":
        png = awg.find_client_file(name, "png")
        if png:
            return send_file(png, mimetype="image/png", as_attachment=False, download_name=f"{name}.png")
        preferred = "vpnuri"

    source_name, source = awg.qr_payload(name, preferred)
    if not source:
        return Response("QR source not found", status=404)

    proc = subprocess.run(["qrencode", "-t", "SVG", "-m", "2"], input=source, text=True, capture_output=True)
    if proc.returncode != 0:
        return Response(source, mimetype="text/plain")
    return Response(proc.stdout, mimetype="image/svg+xml", headers={"X-QR-Source": source_name or "unknown"})


@app.get("/clients/<name>/inventory")
def client_inventory(name):
    return jsonify(awg.file_inventory(name))


# tools

@app.post("/tools/run")
def tools_run():
    try:
        backup_path = request.form.get("backup_path", "").strip()
        backup_name = request.form.get("backup_name", "").strip()
        if backup_name and not backup_path:
            backup_file = awg.find_backup_by_name(backup_name)
            if backup_file:
                backup_path = str(backup_file)
        awg.run_tool(
            request.form.get("action", "").strip(),
            carrier=request.form.get("carrier", "").strip() or None,
            backup_path=backup_path or None,
        )
    except Exception as exc:
        save_exception(exc)
    return go("tools")


@app.get("/backups/<name>/download")
def backup_download(name):
    path = awg.find_backup_by_name(name)
    if not path:
        return Response("backup not found", status=404)
    return send_file(path, mimetype="application/gzip", as_attachment=True, download_name=path.name)


# API

@app.get("/api/self-check")
def api_self_check():
    return jsonify(awg.self_check())


@app.get("/api/clients")
def api_clients():
    result = awg.list_clients()
    clients_data = parse.clients_from(result["json"])
    return jsonify({"ok": result["ok"], "clients": clients_data, "raw": result})


@app.get("/api/status")
def api_status():
    result = awg.status()
    return jsonify(result)


@app.get("/api/stats")
def api_stats():
    result = awg.stats()
    return jsonify(result)


@app.get("/api/show")
def api_show():
    return jsonify(awg.show(save=False))


@app.get("/api/last")
def api_last():
    return jsonify(awg.read_last() or {})


@app.get("/api/logs")
def api_logs():
    return Response(awg.tail_log(500), mimetype="text/plain")


@app.get("/api/bot")
def api_bot_status():
    return jsonify({
        "enabled": bool(config.TG_BOT_TOKEN),
        "admin_ids": config.TG_ADMIN_IDS,
        "send_backup": config.TG_SEND_BACKUP,
        "allow_dangerous": config.TG_ALLOW_DANGEROUS,
    })


@app.get("/health")
def health():
    return jsonify({"ok": True, "app": config.APP_NAME, "version": config.APP_VERSION})


if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Run as root: sudo ./run.sh")
        raise SystemExit(1)
    if not config.MANAGE.exists():
        print(f"Not found: {config.MANAGE}")
        raise SystemExit(1)
    app.run(host=config.HOST, port=config.PORT, debug=False)
