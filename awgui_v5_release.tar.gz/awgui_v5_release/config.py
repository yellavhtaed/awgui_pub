from pathlib import Path
import os

APP_NAME = "AWGUI"
APP_VERSION = "5.0.0"

MANAGE = Path(os.getenv("AWGUI_MANAGE", "/root/awg/manage_amneziawg.sh"))
AWG_DIR = Path(os.getenv("AWGUI_AWG_DIR", "/root/awg"))

HOST = os.getenv("AWGUI_HOST", "127.0.0.1")
PORT = int(os.getenv("AWGUI_PORT", "8080"))

USER = os.getenv("AWGUI_USER", "admin")
PASSWORD = os.getenv("AWGUI_PASSWORD", "devpass")
SECRET = os.getenv("AWGUI_SECRET", "change-this-local-secret")

LOG_FILE = Path(os.getenv("AWGUI_LOG", str(AWG_DIR / "awgui.log")))
LAST_FILE = Path(os.getenv("AWGUI_LAST", str(AWG_DIR / "awgui-last.json")))

DEFAULT_TIMEOUT = int(os.getenv("AWGUI_TIMEOUT", "240"))
ONLINE_WINDOW_SECONDS = int(os.getenv("AWGUI_ONLINE_WINDOW", "180"))

CARRIERS = [
    "beeline_msk",
    "yota_msk",
    "tele2_msk",
    "tele2_krasnoyarsk",
    "tattelecom",
    "megafon_regions",
    "tmobile_us",
]

# Telegram bot
TG_BOT_TOKEN = os.getenv("AWGUI_TG_BOT_TOKEN", "").strip()
TG_ADMIN_IDS = [x.strip() for x in os.getenv("AWGUI_TG_ADMIN_IDS", "").replace(";", ",").split(",") if x.strip()]
TG_POLL_TIMEOUT = int(os.getenv("AWGUI_TG_POLL_TIMEOUT", "25"))
TG_ONLINE_WINDOW_SECONDS = int(os.getenv("AWGUI_TG_ONLINE_WINDOW", str(ONLINE_WINDOW_SECONDS)))
TG_SEND_BACKUP = os.getenv("AWGUI_TG_SEND_BACKUP", "1").lower() in ("1", "true", "yes", "on")
TG_ALLOW_DANGEROUS = os.getenv("AWGUI_TG_ALLOW_DANGEROUS", "1").lower() in ("1", "true", "yes", "on")
