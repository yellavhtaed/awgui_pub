import json
import os
import re
import shlex
import subprocess
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import config

CLIENT_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,63}$")
SAFE_PARAM_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,80}$")

ALLOWED_DIRECT_ACTIONS = {
    "list",
    "stats",
    "status",
    "show",
    "check",
    "backup",
    "restart",
    "diagnose",
    "repair-module",
}


def now_iso():
    return datetime.now().isoformat(timespec="seconds")


def valid_client_name(name: str) -> bool:
    return bool(CLIENT_NAME_RE.match(name or ""))


def valid_param(value: str) -> bool:
    return bool(SAFE_PARAM_RE.match(value or ""))


def ensure_manage_exists():
    if not config.MANAGE.exists() or not config.MANAGE.is_file():
        raise FileNotFoundError(f"manage script not found: {config.MANAGE}")


def parse_json_tolerant(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except Exception:
        pass

    candidates = []
    first_obj, last_obj = text.find("{"), text.rfind("}")
    if first_obj != -1 and last_obj != -1 and last_obj > first_obj:
        candidates.append(text[first_obj:last_obj + 1])
    first_arr, last_arr = text.find("["), text.rfind("]")
    if first_arr != -1 and last_arr != -1 and last_arr > first_arr:
        candidates.append(text[first_arr:last_arr + 1])

    for chunk in candidates:
        try:
            return json.loads(chunk)
        except Exception:
            continue
    return None


def make_result(*, cmd, rc, stdout="", stderr="", parsed=None, started=None):
    stdout = stdout or ""
    stderr = stderr or ""
    text = (stdout + ("\n" if stdout and stderr else "") + stderr).strip()
    return {
        "time": now_iso(),
        "ok": rc == 0,
        "rc": rc,
        "cmd": shlex.join([str(x) for x in cmd]) if isinstance(cmd, (list, tuple)) else str(cmd),
        "stdout": stdout,
        "stderr": stderr,
        "text": text,
        "json": parsed,
        "duration": round(time.time() - started, 2) if started else 0,
    }


def write_last(result):
    try:
        config.LAST_FILE.parent.mkdir(parents=True, exist_ok=True)
        config.LAST_FILE.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def read_last():
    try:
        return json.loads(config.LAST_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None


def append_log(result):
    try:
        config.LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with config.LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(result, ensure_ascii=False) + "\n")
    except Exception:
        pass


def tail_log(lines=400):
    try:
        data = config.LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(data[-lines:])
    except Exception:
        return ""


def save_action(result):
    write_last(result)
    append_log(result)
    return result


def run_manage(*args, json_mode=False, timeout=None, save=True):
    timeout = timeout or config.DEFAULT_TIMEOUT
    started = time.time()
    cmd = ["bash", str(config.MANAGE), "--no-color"]
    if json_mode:
        cmd.append("--json")
    cmd += [str(x) for x in args if x is not None and str(x) != ""]

    try:
        ensure_manage_exists()
        env = os.environ.copy()
        env.setdefault("LC_ALL", "C.UTF-8")
        env.setdefault("LANG", "C.UTF-8")
        cwd = str(config.AWG_DIR if config.AWG_DIR.exists() else Path("/tmp"))
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        stdout, stderr = proc.stdout.strip(), proc.stderr.strip()
        parsed = parse_json_tolerant(stdout) if json_mode else None
        result = make_result(cmd=cmd, rc=proc.returncode, stdout=stdout, stderr=stderr, parsed=parsed, started=started)
    except subprocess.TimeoutExpired as e:
        result = make_result(
            cmd=cmd,
            rc=124,
            stdout=(e.stdout or "").strip() if isinstance(e.stdout, str) else "",
            stderr=(e.stderr or "Timeout").strip() if isinstance(e.stderr, str) else "Timeout",
            parsed=None,
            started=started,
        )
    except Exception as e:
        result = make_result(cmd=cmd, rc=1, stdout="", stderr=f"{type(e).__name__}: {e}", parsed=None, started=started)

    if save:
        save_action(result)
    return result


# read-only

def list_clients():
    return run_manage("list", json_mode=True, save=False)


def stats():
    return run_manage("stats", json_mode=True, save=False)


def status():
    return run_manage("status", save=False)


def show(save=True):
    return run_manage("show", save=save)


def check():
    return run_manage("check", save=True)


# expiry helpers

def expires_from_form(expires_text=None, expires_date=None):
    expires_text = (expires_text or "").strip()
    expires_date = (expires_date or "").strip()

    if expires_text:
        if not re.match(r"^[0-9]+[dhm]?$", expires_text):
            raise ValueError("bad expires format: use 1d / 7d / 30d / 12h")
        return expires_text

    if expires_date:
        try:
            target = datetime.strptime(expires_date, "%Y-%m-%d").date()
        except Exception:
            raise ValueError("bad expires date")
        today = datetime.now().date()
        days = (target - today).days
        if days <= 0:
            raise ValueError("expires date must be in the future")
        return f"{days}d"

    return None


# client actions

def add_client(name, expires=None, psk=False):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name: use A-Z a-z 0-9 _ - up to 63 chars")

    args = []
    if expires:
        expires = expires.strip()
        if not re.match(r"^[0-9]+[dhm]?$", expires):
            raise ValueError("bad expires format: use 1d / 7d / 30d / 12h")
        args.append(f"--expires={expires}")
    if psk:
        args.append("--psk")
    args += ["--yes", "add", name]
    return run_manage(*args, timeout=300, save=True)


def remove_client(name):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    return run_manage("--yes", "remove", name, timeout=300, save=True)


def regen_client(name):
    name = (name or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    return run_manage("regen", name, timeout=300, save=True)


def modify_client(name, param, value):
    name = (name or "").strip()
    param = (param or "").strip()
    value = (value or "").strip()
    if not valid_client_name(name):
        raise ValueError("bad client name")
    if not valid_param(param):
        raise ValueError("bad param")
    if not value:
        raise ValueError("empty value")
    return run_manage("modify", name, param, value, timeout=300, save=True)


# server actions

def backup():
    return run_manage("backup", timeout=300, save=True)


def restore(backup_path):
    backup_path = (backup_path or "").strip()
    if not backup_path:
        raise ValueError("backup path required")
    p = Path(backup_path)
    if not p.exists() or not p.is_file():
        raise FileNotFoundError(f"backup file not found: {backup_path}")
    return run_manage("--yes", "restore", str(p), timeout=600, save=True)


def restart():
    return run_manage("--yes", "restart", timeout=300, save=True)


def repair_module():
    return run_manage("repair-module", timeout=600, save=True)


def diagnose(carrier=None):
    carrier = (carrier or "").strip()
    args = []
    if carrier:
        if not valid_param(carrier):
            raise ValueError("bad carrier")
        args.append(f"--carrier={carrier}")
    args.append("diagnose")
    return run_manage(*args, timeout=300, save=True)


def run_tool(action, *, carrier=None, backup_path=None):
    action = (action or "").strip()
    if action not in ALLOWED_DIRECT_ACTIONS and action != "restore":
        raise ValueError(f"unknown action: {action}")
    if action == "list":
        return run_manage("list", json_mode=True, save=True)
    if action == "stats":
        return run_manage("stats", json_mode=True, save=True)
    if action == "status":
        return run_manage("status", save=True)
    if action == "show":
        return show(save=True)
    if action == "check":
        return check()
    if action == "backup":
        return backup()
    if action == "restore":
        return restore(backup_path)
    if action == "restart":
        return restart()
    if action == "repair-module":
        return repair_module()
    if action == "diagnose":
        return diagnose(carrier)
    raise ValueError(f"unknown action: {action}")


# client files

def find_client_file(name, suffix):
    name = (name or "").strip()
    if not valid_client_name(name):
        return None
    suffix = suffix.lstrip(".")
    candidates = [
        config.AWG_DIR / f"{name}.{suffix}",
        config.AWG_DIR / "clients" / f"{name}.{suffix}",
        config.AWG_DIR / "configs" / f"{name}.{suffix}",
        config.AWG_DIR / "client_configs" / f"{name}.{suffix}",
        config.AWG_DIR / "peer_configs" / f"{name}.{suffix}",
        config.AWG_DIR / "output" / f"{name}.{suffix}",
    ]
    for path in candidates:
        if path.exists() and path.is_file():
            return path
    try:
        for path in config.AWG_DIR.rglob(f"{name}.{suffix}"):
            if path.is_file():
                return path
    except Exception:
        pass
    return None


def read_client_text(name, suffix):
    path = find_client_file(name, suffix)
    if not path:
        return None
    return path.read_text(encoding="utf-8", errors="replace")


def qr_payload(name, preferred="vpnuri"):
    preferred = preferred if preferred in ("vpnuri", "conf") else "vpnuri"
    order = [preferred, "conf" if preferred == "vpnuri" else "vpnuri"]
    for suffix in order:
        text = read_client_text(name, suffix)
        if text:
            return suffix, text.strip()
    return None, None


def file_inventory(name):
    return {
        "conf": str(find_client_file(name, "conf") or ""),
        "vpnuri": str(find_client_file(name, "vpnuri") or ""),
        "png": str(find_client_file(name, "png") or ""),
    }


# backups

def human_size(num):
    try:
        num = float(num)
    except Exception:
        return "-"
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024:
            return f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} TB"


def backup_roots():
    return [config.AWG_DIR / "backups", config.AWG_DIR / "backup", config.AWG_DIR]


def list_backups():
    seen = set()
    items = []
    for root in backup_roots():
        if not root.exists() or not root.is_dir():
            continue
        for pattern in ("*.tar.gz", "*.tgz", "*.zip"):
            for path in root.glob(pattern):
                try:
                    real = path.resolve()
                    if real in seen or not real.is_file():
                        continue
                    seen.add(real)
                    st = real.stat()
                    items.append({
                        "name": real.name,
                        "path": str(real),
                        "size": st.st_size,
                        "size_h": human_size(st.st_size),
                        "mtime": st.st_mtime,
                        "mtime_h": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    })
                except Exception:
                    continue
    items.sort(key=lambda x: x["mtime"], reverse=True)
    return items


def find_backup_by_name(name):
    name = (name or "").strip()
    if "/" in name or "\\" in name or name.startswith("."):
        return None
    for item in list_backups():
        if item["name"] == name:
            return Path(item["path"])
    return None


# diagnostics

def self_check():
    return {
        "version": config.APP_VERSION,
        "manage": str(config.MANAGE),
        "manage_exists": config.MANAGE.exists(),
        "awg_dir": str(config.AWG_DIR),
        "awg_dir_exists": config.AWG_DIR.exists(),
        "log_file": str(config.LOG_FILE),
        "last_file": str(config.LAST_FILE),
        "running_as_root": os.geteuid() == 0,
        "host": config.HOST,
        "port": config.PORT,
    }
