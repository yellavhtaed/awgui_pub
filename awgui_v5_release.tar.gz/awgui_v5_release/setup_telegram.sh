#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo ./setup_telegram.sh"
  exit 1
fi

ENV_FILE="/etc/awgui.env"
touch "$ENV_FILE"
chmod 600 "$ENV_FILE"

read -rp "Telegram bot token from @BotFather: " BOT_TOKEN
read -rp "Telegram admin chat_id(s), comma-separated: " ADMIN_IDS
read -rp "Allow dangerous commands /remove /restart /repair? [y/N]: " DANGER

ALLOW=0
case "${DANGER,,}" in
  y|yes|1|true) ALLOW=1 ;;
esac

python3 - <<PY
from pathlib import Path
path = Path('$ENV_FILE')
vals = {}
for line in path.read_text().splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        k, v = line.split('=', 1)
        vals[k.strip()] = v.strip()
vals['AWGUI_TG_BOT_TOKEN'] = '''$BOT_TOKEN'''
vals['AWGUI_TG_ADMIN_IDS'] = '''$ADMIN_IDS'''
vals['AWGUI_TG_SEND_BACKUP'] = '1'
vals['AWGUI_TG_ALLOW_DANGEROUS'] = str($ALLOW)
base = []
for k in ['AWGUI_USER','AWGUI_PASSWORD','AWGUI_SECRET','AWGUI_HOST','AWGUI_PORT','AWGUI_MANAGE','AWGUI_AWG_DIR']:
    if k in vals:
        base.append(f'{k}={vals[k]}')
for k in ['AWGUI_TG_BOT_TOKEN','AWGUI_TG_ADMIN_IDS','AWGUI_TG_SEND_BACKUP','AWGUI_TG_ALLOW_DANGEROUS']:
    base.append(f'{k}={vals[k]}')
path.write_text('\n'.join(base) + '\n')
PY

systemctl daemon-reload || true
systemctl restart awgui-bot 2>/dev/null || true

echo
echo "OK. Test bot: send /status or /clients"
echo "Logs: sudo journalctl -u awgui-bot -f"
