from __future__ import annotations

import base64
import io
import json
import os
import shlex
import shutil
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import config
import manage_adapter

VENDOR_ROOT = config.ROOT / "engine" / "vendor" / config.ENGINE_VENDOR_DIRNAME
MANIFEST = VENDOR_ROOT / "MANIFEST.json"
REMOTE_ROOT = config.ENGINE_REMOTE_ROOT
REMOTE_DIR = f"{REMOTE_ROOT}/{config.ENGINE_VERSION}"
REQUIRED_FILES = [
    "install_amneziawg.sh",
    "awgui_engine_apply.sh",
    "README.md",
    "LICENSE.upstream",
    "cascade/README.md",
]


def sha256(path: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_manifest() -> Dict[str, Any]:
    try:
        return json.loads(MANIFEST.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}"}


def verify_bundled_engine() -> Dict[str, Any]:
    manifest = load_manifest()
    files: List[Dict[str, Any]] = []
    ok = True
    for rel in REQUIRED_FILES:
        p = VENDOR_ROOT / rel
        present = p.exists() and p.is_file()
        item = {"path": rel, "present": present, "sha256": sha256(p) if present else "", "size": p.stat().st_size if present else 0}
        files.append(item)
        ok = ok and present
    return {
        "ok": bool(ok),
        "offline_ready": False,
        "mode": "pinned-vendored-engine-launcher",
        "engine_version": config.ENGINE_VERSION,
        "upstream_version": config.ENGINE_UPSTREAM_VERSION,
        "vendor_name": config.ENGINE_VENDOR_NAME,
        "vendor_root": str(VENDOR_ROOT),
        "remote_dir": REMOTE_DIR,
        "raw_base": config.ENGINE_RAW_BASE,
        "manifest": manifest,
        "files": files,
        "note": "v8.4 ships a pinned AWGUI engine launcher/manifest. It installs the exact upstream v5.18.4 engine from the pinned tag; full offline vendoring is the next hardening step once the complete upstream scripts are imported into the package.",
    }


def _tar_vendor_bytes() -> bytes:
    bio = io.BytesIO()
    with tarfile.open(fileobj=bio, mode="w:gz") as t:
        for p in VENDOR_ROOT.rglob("*"):
            if p.is_file():
                t.add(p, arcname=str(Path(config.ENGINE_VERSION) / p.relative_to(VENDOR_ROOT)))
    return bio.getvalue()


def deploy_bundled_engine(adapter: manage_adapter.ManageAdapter, timeout: int = 120) -> Dict[str, Any]:
    """Copy AWGUI's pinned engine launcher to local/remote server.

    This deliberately does not replace a working manage script by itself. It only
    places the AWGUI engine under /root/awg/.awgui-engine/<version>/ and writes a
    marker. Installing/upgrading live scripts is a separate confirmed action.
    """
    ver = verify_bundled_engine()
    if not ver.get("ok"):
        return manage_adapter.make_result(["awgui-engine", "verify"], 2, "", "bundled engine incomplete")
    started = time.time()
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        data = base64.b64encode(_tar_vendor_bytes()).decode("ascii")
        script = f"""
set -Eeuo pipefail
install -d -m 700 {shlex.quote(REMOTE_ROOT)}
base64 -d > /tmp/awgui_engine.tgz <<'AWGUI_ENGINE_B64'
{data}
AWGUI_ENGINE_B64
tar -xzf /tmp/awgui_engine.tgz -C {shlex.quote(REMOTE_ROOT)}
rm -f /tmp/awgui_engine.tgz
chmod 700 {shlex.quote(REMOTE_DIR)}/*.sh 2>/dev/null || true
printf '%s\n' {shlex.quote(config.ENGINE_VERSION)} > /root/awg/.awgui-engine-version
printf 'AWGUI engine deployed: %s\n' {shlex.quote(config.ENGINE_VERSION)}
""".strip()
        return adapter.shell(script, timeout=timeout)
    # local
    try:
        target = Path(REMOTE_DIR)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(VENDOR_ROOT, target)
        for sh in target.glob("*.sh"):
            sh.chmod(0o700)
        Path("/root/awg").mkdir(parents=True, exist_ok=True)
        Path("/root/awg/.awgui-engine-version").write_text(config.ENGINE_VERSION + "\n", encoding="utf-8")
        return manage_adapter.make_result(["awgui-engine", "deploy", str(target)], 0, f"AWGUI engine deployed: {config.ENGINE_VERSION}", "", started)
    except Exception as exc:
        return manage_adapter.make_result(["awgui-engine", "deploy", REMOTE_DIR], 1, "", f"{type(exc).__name__}: {exc}", started)


def server_engine_status(adapter: manage_adapter.ManageAdapter) -> Dict[str, Any]:
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        script = f"""
set -u
printf 'installed_marker=%s\n' "$(cat /root/awg/.awgui-engine-version 2>/dev/null || true)"
printf 'engine_dir=%s\n' "{REMOTE_DIR}"
[ -d {shlex.quote(REMOTE_DIR)} ] && printf 'engine_deployed=1\n' || printf 'engine_deployed=0\n'
[ -x {shlex.quote(REMOTE_DIR + '/awgui_engine_apply.sh')} ] && printf 'engine_apply=1\n' || printf 'engine_apply=0\n'
if [ -f {shlex.quote(str(adapter.manage))} ]; then grep -m1 -E 'SCRIPT_VERSION="?[0-9.]+' {shlex.quote(str(adapter.manage))} 2>/dev/null | sed 's/^/manage_version_line=/'; else printf 'manage_version_line=missing\n'; fi
""".strip()
        r = adapter.shell(script, timeout=25, save_last=False)
        data: Dict[str, str] = {}
        for line in str(r.get("stdout") or "").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                data[k] = v
        return {"ok": bool(r.get("ok")), "server": "ssh", "data": data, "raw": r, "bundled": verify_bundled_engine()}
    scan = adapter.scan()
    marker = ""
    try:
        marker = Path("/root/awg/.awgui-engine-version").read_text(encoding="utf-8").strip()
    except Exception:
        pass
    return {
        "ok": True,
        "server": "local",
        "data": {
            "installed_marker": marker,
            "engine_dir": REMOTE_DIR,
            "engine_deployed": "1" if Path(REMOTE_DIR).is_dir() else "0",
            "engine_apply": "1" if (Path(REMOTE_DIR) / "awgui_engine_apply.sh").exists() else "0",
            "manage_version_line": scan.get("script_version", "unknown"),
        },
        "scan": scan,
        "bundled": verify_bundled_engine(),
    }


def apply_bundled_engine(adapter: manage_adapter.ManageAdapter, timeout: int = 300) -> Dict[str, Any]:
    """Run the deployed engine apply script on selected server.

    This refreshes /root/awg/manage_amneziawg.sh and awg_common.sh from the pinned
    upstream v5.18.4 tag. It is intentionally separated from deploy and must be
    called from a confirmed UI action.
    """
    dep = deploy_bundled_engine(adapter)
    if not dep.get("ok"):
        return dep
    if isinstance(adapter, manage_adapter.SSHManageAdapter):
        return adapter.shell(f"bash {shlex.quote(REMOTE_DIR + '/awgui_engine_apply.sh')}", timeout=timeout)
    try:
        p = Path(REMOTE_DIR) / "awgui_engine_apply.sh"
        if not p.exists():
            return manage_adapter.make_result(["bash", str(p)], 127, "", "engine apply script not found")
        import subprocess
        proc = subprocess.run(["bash", str(p)], text=True, capture_output=True, timeout=timeout)
        return manage_adapter.make_result(["bash", str(p)], proc.returncode, proc.stdout.strip(), proc.stderr.strip())
    except Exception as exc:
        return manage_adapter.make_result(["awgui-engine", "apply"], 1, "", f"{type(exc).__name__}: {exc}")
