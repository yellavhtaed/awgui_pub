#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION="$(cat "$APP_DIR/VERSION")"
HOST="${AWGUI_HOST:-127.0.0.1}"
PORT="${AWGUI_PORT:-8080}"

if [[ $EUID -ne 0 ]]; then
  echo "Run as root: sudo ./upgrade.sh" >&2
  exit 1
fi

cd "$APP_DIR"
python3 -m venv .venv
.venv/bin/python -m pip install -q --upgrade pip
.venv/bin/python -m pip install -q -r requirements.txt
.venv/bin/python scripts/selftest.py
.venv/bin/python scripts/verify_release.py

systemctl stop awgui awgui-bot 2>/dev/null || true

cat >/etc/systemd/system/awgui.service <<EOF
[Unit]
Description=AWGUI v${VERSION} web control layer
After=network.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=-/etc/awgui.env
ExecStart=${APP_DIR}/run.sh
Restart=on-failure
RestartSec=3
User=root

[Install]
WantedBy=multi-user.target
EOF

cat >/etc/systemd/system/awgui-bot.service <<EOF
[Unit]
Description=AWGUI v${VERSION} Telegram cockpit
After=network.target awgui.service

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
EnvironmentFile=-/etc/awgui.env
ExecStart=${APP_DIR}/run_bot.sh
Restart=on-failure
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable awgui >/dev/null
systemctl restart awgui

for i in {1..30}; do
  if curl -fsS "http://${HOST}:${PORT}/health" 2>/dev/null | grep -q "\"version\":\"${VERSION}\""; then
    echo "AWGUI ${VERSION} is running at http://${HOST}:${PORT}"
    exit 0
  fi
  sleep 1
done

echo "AWGUI did not report version ${VERSION}. Diagnostics:" >&2
systemctl status awgui --no-pager >&2 || true
journalctl -u awgui -n 80 --no-pager >&2 || true
exit 1
