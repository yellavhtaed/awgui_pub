# Changelog

## v8.4.0 — Autonomous Engine Pivot

### Added

- AWGUI engine slot: `5.18.4-awgui1` targeting upstream `bivlked/amneziawg-installer` `v5.18.4`.
- `engine.py` with engine verification, deploy, apply and selected-server status.
- `/engine` UI page.
- Pinned engine launcher files under `engine/vendor/bivlked_5_18_4/`.
- Engine status block inside diagnostics.
- `/api/version` now includes engine version.

### Changed

- Provisioner now deploys AWGUI's pinned engine slot before remote bootstrap.
- Provisioner no longer follows an unpinned `main` installer URL by default.
- Default installer URL moved to the pinned `v5.18.4` tag.
- Release gate now checks engine files and engine routes.

### Intentionally not changed

- DKMS / apt / UFW / sysctl / routing logic is not rewritten.
- No Debian bootstrap in AWGUI UI yet.
- No Telegram provisioning/engine upgrade yet.
- No offline full upstream mirror yet; v8.4 prepares the layout and uses a pinned engine launcher.
