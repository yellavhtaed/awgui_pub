#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp(prefix="awgui_v8_4_gate_"))
os.environ["AWGUI_MANAGE"] = str(ROOT / "scripts" / "fake_manage_amneziawg.sh")
os.environ["AWGUI_AWG_DIR"] = str(TMP / "awg")
os.environ["AWGUI_SERVER_CONF"] = str(TMP / "etc" / "awg0.conf")
os.environ["AWGUI_STATE_DIR"] = str(TMP / "state")
os.environ["AWGUI_ENV_FILE"] = str(TMP / "awgui.env")
os.environ["AWGUI_SECRET"] = "test-secret"

import config  # noqa: E402
assert config.APP_VERSION == "8.4.0", config.APP_VERSION
assert config.ENGINE_VERSION == "5.18.4-awgui1"
for rel in (ROOT / "templates").glob("*.html"):
    text = rel.read_text(encoding="utf-8")
    forbidden = [
        "На сервере запусти cd ~/awgui",
        "AmneziaWG Control · v5.0.0",
        "v5.0.0",
        "Mode\nlocalhost only",
        "Update center",
    ]
    for bad in forbidden:
        if bad in text:
            raise SystemExit(f"forbidden legacy text in {rel.name}: {bad}")
required = [
    "manage_adapter.py", "store.py", "i18n.py", "telegram_bot.py", "engine.py",
    "engine/vendor/bivlked_5_18_4/MANIFEST.json",
    "engine/vendor/bivlked_5_18_4/awgui_engine_apply.sh",
    "engine/vendor/bivlked_5_18_4/install_amneziawg.sh",
    "templates/bot.html", "templates/diagnostics.html", "templates/traffic.html", "templates/expiry.html", "templates/servers.html", "templates/provisioner.html", "templates/engine.html",
]
for item in required:
    if not (ROOT / item).exists():
        raise SystemExit(f"missing {item}")
text = (ROOT / "manage_adapter.py").read_text(encoding="utf-8")
for needle in ("class SSHManageAdapter", "def adapter_for_server", "StrictHostKeyChecking=accept-new", "No-agent SSH adapter"):
    if needle not in text:
        raise SystemExit(f"missing SSH adapter marker: {needle}")
app_text = (ROOT / "app.py").read_text(encoding="utf-8")
for needle in ("/servers", "current_adapter", "current_server_id", "server_select", "/provisioner", "provisioner_bootstrap", "/engine", "engine_apply"):
    if needle not in app_text:
        raise SystemExit(f"missing web multi-server/provisioner/engine marker: {needle}")
eng_text = (ROOT / "engine.py").read_text(encoding="utf-8")
for needle in ("verify_bundled_engine", "deploy_bundled_engine", "apply_bundled_engine" , "pinned-vendored-engine-launcher"):
    if needle not in eng_text:
        raise SystemExit(f"missing engine marker: {needle}")
prov_text = (ROOT / "provisioner.py").read_text(encoding="utf-8")
for needle in ("Ubuntu 24.04", "PROVISIONER_PREFLIGHT", "engine.deploy_bundled_engine", "ready_to_bootstrap"):
    if needle not in prov_text:
        raise SystemExit(f"missing provisioner marker: {needle}")
print("AWGUI v8.4 release gate OK")
