#!/usr/bin/env python3
from __future__ import annotations

import html
import json
import sys
import tempfile
import time
import traceback
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import config
import manage_adapter
import parse
import store

MAX_MSG = 3900
DOC_THRESHOLD = 3000
ADD_DURATIONS = ["1h", "12h", "1d", "7d", "30d", "4w"]



def tg_server_id(chat_id: Any = None) -> str:
    if chat_id is not None:
        sid = store.get_setting(f"telegram_server:{chat_id}", config.SERVER_ID)
        if store.get_server(str(sid)):
            return str(sid)
    return config.SERVER_ID


def tg_server(chat_id: Any = None) -> Dict[str, Any]:
    return store.get_server(tg_server_id(chat_id)) or store.get_server(config.SERVER_ID) or {"id": config.SERVER_ID, "name": config.SERVER_NAME, "mode": "local"}


def tg_adapter(chat_id: Any = None) -> manage_adapter.ManageAdapter:
    return manage_adapter.adapter_for_server(tg_server(chat_id))


class AdapterProxy:
    def __getattr__(self, name: str):
        # Fallback for legacy command paths before chat_id is known.
        return getattr(tg_adapter(None), name)


adapter = AdapterProxy()
_pending_add: Dict[str, Dict[str, Any]] = {}


class TelegramError(RuntimeError):
    def __init__(self, method: str, status: int, description: str, raw: str = "") -> None:
        super().__init__(f"Telegram {method} failed: {status} {description}")
        self.method = method
        self.status = status
        self.description = description
        self.raw = raw


def log(msg: str) -> None:
    print(f"[awgui-bot] {msg}", flush=True)


def settings() -> Dict[str, Any]:
    return config.load_telegram_settings()


def token() -> str:
    return str(settings().get("token") or "")


def esc(x: Any) -> str:
    return html.escape(str(x or ""), quote=False)


def clip(text: Any, limit: int = MAX_MSG) -> str:
    s = str(text or "")
    return s if len(s) <= limit else s[:limit] + "\n\n--- cut ---"


def _http_error_text(exc: urllib.error.HTTPError) -> str:
    try:
        raw = exc.read().decode("utf-8", errors="replace")
    except Exception:
        raw = ""
    if raw:
        try:
            payload = json.loads(raw)
            return str(payload.get("description") or raw)
        except Exception:
            return raw
    return str(exc.reason or exc)


def api(method: str, payload: Optional[Dict[str, Any]] = None, timeout: int = 60) -> Dict[str, Any]:
    url = f"https://api.telegram.org/bot{token()}/{method}"
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", errors="replace")
        out = json.loads(body or "{}")
        if not out.get("ok", True):
            raise TelegramError(method, 200, str(out.get("description") or "ok=false"), body)
        return out
    except urllib.error.HTTPError as exc:
        desc = _http_error_text(exc)
        raise TelegramError(method, int(exc.code or 0), desc) from exc


def multipart_api(method: str, fields: Dict[str, Any], file_field: str, path: Path, mime: str, timeout: int = 90) -> Dict[str, Any]:
    boundary = "----awgui" + str(int(time.time() * 1000))
    body = bytearray()

    def add(s: str) -> None:
        body.extend(s.encode("utf-8"))

    for k, v in fields.items():
        add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n")
    add(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{file_field}\"; filename=\"{path.name}\"\r\nContent-Type: {mime}\r\n\r\n")
    body.extend(path.read_bytes())
    add(f"\r\n--{boundary}--\r\n")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token()}/{method}",
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        desc = _http_error_text(exc)
        raise TelegramError(method, int(exc.code or 0), desc) from exc


def _text_payload(chat_id: int | str, text: str, keyboard: Optional[Dict[str, Any]], html_mode: bool) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "chat_id": chat_id,
        "text": clip(text),
        "disable_web_page_preview": True,
    }
    if html_mode:
        payload["parse_mode"] = "HTML"
    if keyboard:
        payload["reply_markup"] = keyboard
    return payload


def send(chat_id: int | str, text: str, keyboard: Optional[Dict[str, Any]] = None, html_mode: bool = True) -> bool:
    try:
        api("sendMessage", _text_payload(chat_id, text, keyboard, html_mode))
        return True
    except TelegramError as exc:
        log(f"sendMessage failed: {exc.status} {exc.description}")
        if html_mode:
            try:
                api("sendMessage", _text_payload(chat_id, _strip_html_for_fallback(text), keyboard, False))
                return True
            except TelegramError as retry_exc:
                log(f"sendMessage plain fallback failed: {retry_exc.status} {retry_exc.description}")
        return False


def edit(chat_id: int | str, message_id: int, text: str, keyboard: Optional[Dict[str, Any]] = None, html_mode: bool = True) -> bool:
    payload = _text_payload(chat_id, text, keyboard, html_mode)
    payload["message_id"] = message_id
    try:
        api("editMessageText", payload)
        return True
    except TelegramError as exc:
        desc = exc.description.lower()
        if "message is not modified" in desc:
            return True
        log(f"editMessageText failed: {exc.status} {exc.description}; falling back to sendMessage")
        return send(chat_id, text, keyboard, html_mode=html_mode)


def answer_callback(callback_id: str, text: str = "") -> bool:
    try:
        api("answerCallbackQuery", {"callback_query_id": callback_id, "text": text[:180]}, timeout=15)
        return True
    except TelegramError as exc:
        log(f"answerCallbackQuery failed: {exc.status} {exc.description}")
        return False


def send_doc(chat_id: int | str, path: Path, caption: str = "") -> bool:
    try:
        multipart_api("sendDocument", {"chat_id": chat_id, "caption": caption[:900]}, "document", path, "application/octet-stream")
        return True
    except Exception as exc:
        log(f"sendDocument failed for {path}: {type(exc).__name__}: {exc}")
        return False


def send_photo(chat_id: int | str, path: Path, caption: str = "") -> bool:
    try:
        multipart_api("sendPhoto", {"chat_id": chat_id, "caption": caption[:900]}, "photo", path, "image/png")
        return True
    except Exception as exc:
        log(f"sendPhoto failed for {path}: {type(exc).__name__}: {exc}")
        return False


def _strip_html_for_fallback(text: str) -> str:
    return str(text or "").replace("<b>", "").replace("</b>", "").replace("<code>", "").replace("</code>", "").replace("<pre>", "").replace("</pre>", "")


def send_output(chat_id: Any, title: str, result_or_text: Any, keyboard: Optional[Dict[str, Any]] = None, *, force_doc: bool = False) -> None:
    if isinstance(result_or_text, dict):
        ok = bool(result_or_text.get("ok"))
        text = str(result_or_text.get("text") or result_or_text.get("stdout") or result_or_text.get("stderr") or "")
        icon = "✅" if ok else "⚠️"
        header = f"{icon} {title}"
    else:
        text = str(result_or_text or "")
        header = title
    if force_doc or len(text) > DOC_THRESHOLD:
        tmp_path: Optional[Path] = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".txt", prefix="awgui_", delete=False) as f:
                f.write(text)
                tmp_path = Path(f.name)
            if send_doc(chat_id, tmp_path, header):
                send(chat_id, f"<b>{esc(header)}</b>\nВывод отправлен файлом: <code>{esc(tmp_path.name)}</code>", keyboard)
                return
        finally:
            if tmp_path:
                try:
                    tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass
    send(chat_id, f"<b>{esc(header)}</b>\n<pre>{esc(text)}</pre>", keyboard)


def is_admin(chat_id: Any) -> bool:
    return str(chat_id) in set(settings().get("admin_ids") or [])


def require_admin(chat_id: Any) -> bool:
    tg = settings()
    if not tg.get("admin_ids"):
        send(chat_id, f"Бот ещё не привязан. Твой chat_id: <code>{esc(chat_id)}</code>\nВставь его в AWGUI → Telegram → Save & apply.")
        return False
    if not is_admin(chat_id):
        send(chat_id, f"Access denied. Твой chat_id: <code>{esc(chat_id)}</code>")
        return False
    return True


def allow_dangerous() -> bool:
    return bool(settings().get("allow_dangerous"))


# Keyboards

def main_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "🟢 Status", "callback_data": "m:status"}, {"text": "👥 Clients", "callback_data": "m:clients:0"}],
        [{"text": "➕ Add client", "callback_data": "m:add"}, {"text": "⏳ Temporary", "callback_data": "m:addtemp"}],
        [{"text": "💾 Backup", "callback_data": "m:backupmenu"}, {"text": "🩺 Diagnostics", "callback_data": "m:diag"}],
        [{"text": "🌐 Servers", "callback_data": "m:servers"}, {"text": "🖥 Server actions", "callback_data": "m:server"}],
        [{"text": "❔ Help", "callback_data": "m:help"}],
    ]}


def add_keyboard(temporary_only: bool = False) -> Dict[str, Any]:
    rows: List[List[Dict[str, str]]] = []
    if not temporary_only:
        rows.append([{"text": "♾ Permanent", "callback_data": "add:perm"}])
    rows += [
        [{"text": "1h", "callback_data": "add:exp:1h"}, {"text": "12h", "callback_data": "add:exp:12h"}, {"text": "1d", "callback_data": "add:exp:1d"}],
        [{"text": "7d", "callback_data": "add:exp:7d"}, {"text": "30d", "callback_data": "add:exp:30d"}, {"text": "4w", "callback_data": "add:exp:4w"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]
    return {"inline_keyboard": rows}


def add_psk_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "PSK off", "callback_data": "addpsk:0"}, {"text": "PSK on", "callback_data": "addpsk:1"}],
        [{"text": "Cancel", "callback_data": "m:main"}],
    ]}


def backup_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "💾 Create backup", "callback_data": "backup:create"}],
        [{"text": "📦 Send latest", "callback_data": "backup:latest"}, {"text": "📋 List", "callback_data": "backup:list"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}



def servers_keyboard(chat_id: Any = None) -> Dict[str, Any]:
    rows: List[List[Dict[str, str]]] = []
    active = tg_server_id(chat_id)
    for s in store.list_servers(include_disabled=False)[:12]:
        icon = "✓" if s.get("id") == active else ""
        mode = "ssh" if s.get("mode") == "ssh" else "local"
        rows.append([{"text": f"{icon} {s.get('name') or s.get('id')} · {mode}", "callback_data": f"srv:{s.get('id')}"}])
    rows.append([{"text": "← main", "callback_data": "m:main"}])
    return {"inline_keyboard": rows}


def send_backup_doc(chat_id: Any, backup_name: str = "") -> bool:
    backups = tg_adapter(chat_id).list_backups()
    if not backups:
        send(chat_id, "No backups found.", backup_keyboard())
        return False
    name = backup_name or backups[0]["name"]
    filename, data = tg_adapter(chat_id).backup_bytes(name)
    if not data:
        send(chat_id, "Backup file not readable.", backup_keyboard())
        return False
    tmp_path: Optional[Path] = None
    try:
        with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name), prefix="awgui_backup_", delete=False) as f:
            f.write(data)
            tmp_path = Path(f.name)
        return send_doc(chat_id, tmp_path, f"latest AWG backup · {tg_server_id(chat_id)}")
    finally:
        if tmp_path:
            try:
                tmp_path.unlink(missing_ok=True)
            except Exception:
                pass

def server_keyboard() -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "📋 show", "callback_data": "m:show"}, {"text": "✅ check", "callback_data": "m:check"}],
        [{"text": "🔄 restart", "callback_data": "confirm:restart"}, {"text": "🛠 repair-module", "callback_data": "confirm:repair"}],
        [{"text": "← main", "callback_data": "m:main"}],
    ]}


def clients(chat_id: Any = None) -> List[Dict[str, Any]]:
    return parse.clients_from(tg_adapter(chat_id).list_clients().get("json"))


def client_by_index(i: str, chat_id: Any = None) -> Tuple[Optional[Dict[str, Any]], str]:
    try:
        idx = int(i)
    except Exception:
        return None, ""
    items = clients(chat_id)
    if idx < 0 or idx >= len(items):
        return None, ""
    return items[idx], parse.name(items[idx])


def clients_keyboard(page: int = 0, per_page: int = 7, chat_id: Any = None) -> Dict[str, Any]:
    items = clients(chat_id)
    page = max(0, int(page or 0))
    start = page * per_page
    rows: List[List[Dict[str, str]]] = []
    for idx, c in enumerate(items[start:start + per_page], start=start):
        name = parse.name(c)
        state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
        icon = "🟢" if state == "ONLINE" else "⚪"
        rows.append([{"text": f"{icon} {name[:38]}", "callback_data": f"ci:{idx}"}])
    nav = []
    if page > 0:
        nav.append({"text": "← prev", "callback_data": f"m:clients:{page-1}"})
    if start + per_page < len(items):
        nav.append({"text": "next →", "callback_data": f"m:clients:{page+1}"})
    if nav:
        rows.append(nav)
    rows.append([{"text": "➕ add", "callback_data": "m:add"}, {"text": "← main", "callback_data": "m:main"}])
    return {"inline_keyboard": rows}


def client_keyboard(idx: int) -> Dict[str, Any]:
    return {"inline_keyboard": [
        [{"text": "🧾 QR", "callback_data": f"qr:{idx}"}, {"text": "📄 conf", "callback_data": f"conf:{idx}"}, {"text": "🔗 vpnuri", "callback_data": f"vpn:{idx}"}],
        [{"text": "📦 bundle", "callback_data": f"bundle:{idx}"}, {"text": "♻️ regen", "callback_data": f"confirm:regen:{idx}"}, {"text": "🗑 remove", "callback_data": f"confirm:remove:{idx}"}],
        [{"text": "← clients", "callback_data": "m:clients:0"}, {"text": "main", "callback_data": "m:main"}],
    ]}


def confirm_keyboard(action: str, value: str) -> Dict[str, Any]:
    return {"inline_keyboard": [[
        {"text": f"Confirm {action}", "callback_data": f"do:{action}:{value}"},
        {"text": "Cancel", "callback_data": "m:main"},
    ]]}


# Formatting

def format_main(chat_id: Any = None) -> str:
    ad = tg_adapter(chat_id)
    srv = tg_server(chat_id)
    s = ad.summary()
    st = ad.status()
    state = "online" if st.get("ok") else "attention needed"
    return (
        f"<b>AWGUI cockpit</b> · <code>{esc(config.SERVER_ID)}</code>\n"
        f"Server: <b>{esc(config.SERVER_NAME)}</b>\n"
        f"AWG: <b>{esc(state)}</b>\n"
        f"Clients: <b>{s['clients_total']}</b> total / <b>{s['clients_online']}</b> online\n\n"
        "Выбери действие:"
    )


def format_status(chat_id: Any = None) -> str:
    ad = tg_adapter(chat_id)
    srv = tg_server(chat_id)
    s = ad.summary()
    st = ad.status()
    return (
        f"<b>Status</b> · AWGUI <code>{esc(config.APP_VERSION)}</code>\n"
        f"Server: <code>{esc(config.SERVER_ID)}</code> · {esc(config.SERVER_NAME)}\n"
        f"Clients: <b>{s['clients_total']}</b> total / <b>{s['clients_online']}</b> online\n"
        f"Parent: <b>{'OK' if st.get('ok') else 'FAIL'}</b>\n"
        f"<pre>{esc(clip(st.get('text') or '', 1500))}</pre>"
    )


def format_client(c: Dict[str, Any]) -> str:
    state = parse.online_state(c, config.ONLINE_WINDOW_SECONDS)
    icon = "🟢" if state == "ONLINE" else "⚪"
    return (
        f"{icon} <b>{esc(parse.name(c))}</b>\n"
        f"IPv4: <code>{esc(parse.ipv4(c))}</code>\n"
        f"IPv6: <code>{esc(parse.ipv6(c))}</code>\n"
        f"Handshake: {esc(parse.handshake(c))}\n"
        f"Status: <b>{esc(state)}</b>"
    )


def help_text() -> str:
    return (
        "<b>AWGUI Telegram cockpit</b>\n"
        "Основной режим — кнопки через <code>/menu</code>.\n\n"
        "Команды остаются как быстрый fallback:\n"
        "<code>/id</code> · показать chat_id\n"
        "<code>/status</code> · статус сервера\n"
        "<code>/clients</code> · список клиентов\n"
        "<code>/add NAME [7d] [psk]</code> · быстрый add\n"
        "<code>/backup</code> · создать backup\n"
        "<code>/diagnose [carrier]</code> · диагностика"
    )


def audit(action: str, target: str, result: Dict[str, Any], chat_id: Any) -> None:
    store.audit("telegram", str(chat_id), action, target, result, server_id=tg_server_id(chat_id))


def start_add_flow(chat_id: Any, message_id: int, expires: Optional[str]) -> None:
    _pending_add[str(chat_id)] = {"expires": expires, "psk": False, "step": "psk", "ts": time.time()}
    label = "permanent" if not expires else f"temporary {expires}"
    edit(chat_id, message_id, f"<b>Add {esc(label)} client</b>\nВыбери PSK режим.", add_psk_keyboard())


def set_add_psk(chat_id: Any, message_id: int, psk: bool) -> None:
    state = _pending_add.setdefault(str(chat_id), {"expires": None})
    state["psk"] = psk
    state["step"] = "name"
    state["ts"] = time.time()
    expires = state.get("expires")
    label = "permanent" if not expires else f"temporary {expires}"
    psk_label = "ON" if psk else "OFF"
    edit(chat_id, message_id, f"<b>Add {esc(label)} client</b>\nPSK: <b>{psk_label}</b>\n\nТеперь отправь имя клиента одним сообщением.\nНапример: <code>iphone_lamanper</code>", {"inline_keyboard": [[{"text": "Cancel", "callback_data": "m:main"}]]})


def handle_pending_add(chat_id: Any, text: str) -> bool:
    state = _pending_add.get(str(chat_id))
    if not state or state.get("step") != "name" or text.startswith("/"):
        return False
    name = text.strip().split()[0]
    _pending_add.pop(str(chat_id), None)
    result = tg_adapter(chat_id).add_client(name, expires=state.get("expires"), psk=bool(state.get("psk")))
    audit("client.add", name, result, chat_id)
    send_output(chat_id, f"Add client {name}", result, main_keyboard())
    try:
        items = clients(chat_id)
        idx = next((i for i, c in enumerate(items) if parse.name(c) == name), None)
        if idx is not None:
            send(chat_id, format_client(items[idx]), client_keyboard(idx))
    except Exception as exc:
        log(f"post-add client card failed: {exc}")
    return True


def handle_command(chat_id: Any, text: str) -> None:
    if text.startswith("/id"):
        send(chat_id, f"chat_id: <code>{esc(chat_id)}</code>")
        return
    if not require_admin(chat_id):
        return
    if handle_pending_add(chat_id, text):
        return
    parts = text.split()
    cmd = parts[0].lower() if parts else ""
    if cmd in {"/start", "/menu", "/help"}:
        send(chat_id, format_main(chat_id) if cmd != "/help" else help_text(), main_keyboard())
    elif cmd == "/status":
        send(chat_id, format_status(chat_id), main_keyboard())
    elif cmd == "/clients":
        send(chat_id, "<b>Clients</b>", clients_keyboard(0, chat_id=chat_id))
    elif cmd == "/client" and len(parts) > 1:
        name = parts[1]
        c = next((x for x in clients(chat_id) if parse.name(x) == name), None)
        send(chat_id, format_client(c) if c else "client not found", main_keyboard())
    elif cmd == "/add" and len(parts) > 1:
        expires = parts[2] if len(parts) > 2 and parts[2] != "psk" else None
        psk = "psk" in [p.lower() for p in parts[2:]]
        result = tg_adapter(chat_id).add_client(parts[1], expires=expires, psk=psk)
        audit("client.add", parts[1], result, chat_id)
        send_output(chat_id, f"Add client {parts[1]}", result, main_keyboard())
    elif cmd == "/backup":
        result = tg_adapter(chat_id).backup()
        audit("backup.create", "", result, chat_id)
        send_output(chat_id, "Backup", result, main_keyboard())
        if result.get("ok") and settings().get("send_backup"):
            send_backup_doc(chat_id)
    elif cmd == "/diagnose":
        carrier = parts[1] if len(parts) > 1 else None
        result = tg_adapter(chat_id).diagnose(carrier)
        audit("diagnose", carrier or "", result, chat_id)
        send_output(chat_id, "Diagnostics", result, main_keyboard())
    elif cmd == "/cancel":
        _pending_add.pop(str(chat_id), None)
        send(chat_id, "Cancelled.", main_keyboard())
    else:
        send(chat_id, help_text(), main_keyboard())


def handle_callback(cb: Dict[str, Any]) -> None:
    qid = cb.get("id", "")
    msg = cb.get("message") or {}
    chat_id = msg.get("chat", {}).get("id")
    message_id = msg.get("message_id")
    data = cb.get("data") or ""
    answer_callback(qid)
    if not require_admin(chat_id):
        return
    try:
        if data == "m:main":
            _pending_add.pop(str(chat_id), None)
            edit(chat_id, message_id, format_main(chat_id), main_keyboard())
        elif data == "m:help":
            edit(chat_id, message_id, help_text(), main_keyboard())
        elif data == "m:status":
            edit(chat_id, message_id, format_status(chat_id), main_keyboard())
        elif data == "m:servers":
            edit(chat_id, message_id, "<b>Servers</b>\nВыбери активный сервер для Telegram-действий.", servers_keyboard(chat_id))
        elif data.startswith("srv:"):
            sid = data.split(":", 1)[1]
            if store.get_server(sid):
                store.set_setting(f"telegram_server:{chat_id}", sid)
                edit(chat_id, message_id, format_main(chat_id), main_keyboard())
            else:
                send(chat_id, "server not found", main_keyboard())
        elif data.startswith("m:clients:"):
            edit(chat_id, message_id, "<b>Clients</b>", clients_keyboard(int(data.split(":")[-1]), chat_id=chat_id))
        elif data == "m:add":
            edit(chat_id, message_id, "<b>Add client</b>\nВыбери срок действия.", add_keyboard(False))
        elif data == "m:addtemp":
            edit(chat_id, message_id, "<b>Add temporary client</b>\nВыбери срок действия.", add_keyboard(True))
        elif data == "m:server":
            edit(chat_id, message_id, "<b>Server actions</b>", server_keyboard())
        elif data == "m:backupmenu":
            edit(chat_id, message_id, "<b>Backup center</b>", backup_keyboard())
        elif data == "m:diag":
            result = tg_adapter(chat_id).diagnose()
            audit("diagnose", "", result, chat_id)
            send_output(chat_id, "Diagnostics", result, main_keyboard())
        elif data == "m:show":
            result = tg_adapter(chat_id).show()
            audit("server.show", "awg0", result, chat_id)
            send_output(chat_id, "Server show", result, server_keyboard(), force_doc=len(str(result.get("text") or "")) > DOC_THRESHOLD)
        elif data == "m:check":
            result = tg_adapter(chat_id).check()
            audit("server.check", "awg0", result, chat_id)
            send_output(chat_id, "Server check", result, server_keyboard())
        elif data.startswith("add:perm"):
            start_add_flow(chat_id, message_id, None)
        elif data.startswith("add:exp:"):
            duration = data.split(":", 2)[2]
            if duration not in ADD_DURATIONS:
                send(chat_id, "Unsupported duration.", main_keyboard())
            else:
                start_add_flow(chat_id, message_id, duration)
        elif data.startswith("addpsk:"):
            set_add_psk(chat_id, message_id, data.endswith(":1"))
        elif data == "backup:create":
            result = tg_adapter(chat_id).backup()
            audit("backup.create", "", result, chat_id)
            send_output(chat_id, "Backup", result, backup_keyboard())
            if result.get("ok") and settings().get("send_backup"):
                send_backup_doc(chat_id)
        elif data == "backup:latest":
            if send_backup_doc(chat_id):
                send(chat_id, "Latest backup sent.", backup_keyboard())
        elif data == "backup:list":
            backups = tg_adapter(chat_id).list_backups()[:8]
            if not backups:
                send(chat_id, "No backups found.", backup_keyboard())
            else:
                lines = [f"{i+1}. {esc(b['name'])} · {esc(b.get('size_h') or b.get('size') or '')}" for i, b in enumerate(backups)]
                send(chat_id, "<b>Backups</b>\n" + "\n".join(lines), backup_keyboard())
        elif data.startswith("ci:"):
            idx = int(data.split(":", 1)[1])
            c, _name = client_by_index(str(idx), chat_id)
            edit(chat_id, message_id, format_client(c) if c else "client not found", client_keyboard(idx) if c else clients_keyboard(0))
        elif data.startswith("qr:"):
            c, name = client_by_index(data.split(":", 1)[1], chat_id)
            filename, data_bytes = tg_adapter(chat_id).read_client_bytes(name, "png") if name else (None, None)
            if data_bytes:
                tmp_path = None
                try:
                    with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name + ".png"), prefix="awgui_qr_", delete=False) as f:
                        f.write(data_bytes); tmp_path = Path(f.name)
                    send_photo(chat_id, tmp_path, name)
                finally:
                    if tmp_path:
                        tmp_path.unlink(missing_ok=True)
            else:
                send(chat_id, "PNG QR not found. Use web UI for SVG fallback.", main_keyboard())
        elif data.startswith("conf:") or data.startswith("vpn:") or data.startswith("bundle:"):
            action, idx = data.split(":", 1)
            c, name = client_by_index(idx, chat_id)
            if not name:
                send(chat_id, "client not found", main_keyboard())
                return
            if action == "bundle":
                p = tg_adapter(chat_id).create_client_bundle(name)
            else:
                filename, data_bytes = tg_adapter(chat_id).read_client_bytes(name, "conf" if action == "conf" else "vpnuri")
                p = None
                if data_bytes:
                    with tempfile.NamedTemporaryFile("wb", suffix="_" + (filename or name), prefix="awgui_client_", delete=False) as f:
                        f.write(data_bytes); p = Path(f.name)
            if p:
                try:
                    send_doc(chat_id, Path(p), name)
                finally:
                    if str(p).startswith(tempfile.gettempdir()):
                        Path(p).unlink(missing_ok=True)
            else:
                send(chat_id, "file not found", main_keyboard())
        elif data.startswith("confirm:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled in AWGUI → Telegram.", main_keyboard())
                return
            _, action, *rest = data.split(":")
            value = rest[0] if rest else ""
            edit(chat_id, message_id, f"Confirm <b>{esc(action)}</b> {esc(value)}?", confirm_keyboard(action, value))
        elif data.startswith("do:"):
            if not allow_dangerous():
                send(chat_id, "Dangerous Telegram actions are disabled.", main_keyboard())
                return
            _, action, value = data.split(":", 2)
            if action == "restart":
                result = tg_adapter(chat_id).restart(); target = "awg0"
            elif action == "repair":
                result = tg_adapter(chat_id).repair_module(); target = "module"
            elif action == "regen":
                _c, target = client_by_index(value, chat_id); result = tg_adapter(chat_id).regen_client(target)
            elif action == "remove":
                _c, target = client_by_index(value, chat_id); result = tg_adapter(chat_id).remove_client(target)
            else:
                raise ValueError("bad action")
            audit(action, target, result, chat_id)
            send_output(chat_id, action, result, main_keyboard())
        else:
            send(chat_id, "Unknown action.", main_keyboard())
    except Exception as exc:
        log(f"callback failed data={data!r}: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        send(chat_id, "⚠️ Telegram action failed. Команда не скрыта: подробности в journalctl -u awgui-bot.", main_keyboard())


def poll() -> None:
    if not token():
        log("disabled: empty token")
        return
    try:
        api("deleteWebhook", {"drop_pending_updates": False}, timeout=20)
    except Exception as exc:
        log(f"deleteWebhook failed: {exc}")
    offset = 0
    log("polling started")
    while True:
        try:
            resp = api("getUpdates", {"timeout": 45, "offset": offset, "allowed_updates": ["message", "callback_query"]}, timeout=60)
            for upd in resp.get("result", []):
                offset = max(offset, int(upd.get("update_id", 0)) + 1)
                if "message" in upd:
                    msg = upd["message"]
                    chat_id = msg.get("chat", {}).get("id")
                    text = msg.get("text") or ""
                    if text:
                        handle_command(chat_id, text.strip())
                elif "callback_query" in upd:
                    handle_callback(upd["callback_query"])
        except KeyboardInterrupt:
            raise
        except Exception:
            traceback.print_exc()
            time.sleep(4)


if __name__ == "__main__":
    poll()
