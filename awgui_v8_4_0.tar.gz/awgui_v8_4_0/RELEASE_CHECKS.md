# AWGUI v8.4.0 release checks

Fresh package checks:

```bash
python3 -m py_compile app.py config.py manage_adapter.py parse.py store.py i18n.py engine.py telegram_bot.py provisioner.py scripts/selftest.py scripts/verify_release.py
bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh scripts/fake_manage_amneziawg.sh scripts/fake_ssh.sh engine/vendor/bivlked_5_18_4/install_amneziawg.sh engine/vendor/bivlked_5_18_4/awgui_engine_apply.sh
python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
```

Expected:

```text
AWGUI v8.4 selftest OK
AWGUI v8.4 release gate OK
```

Runtime smoke:

```text
/health       200, version 8.4.0
/             200
/clients      200
/servers      200
/engine       200
/provisioner  200
/traffic      200
/expiry       200
/backups      200
/diagnostics  200
/audit        200
/bot          200
/logs         200
/api/version  200
/api/summary  200
/api/clients  200
/api/stats    200
/api/doctor   200
/api/audit    200
/api/bot      200
```
