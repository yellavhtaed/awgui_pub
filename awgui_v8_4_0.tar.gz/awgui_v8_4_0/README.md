# AWGUI v8.4.0 — Autonomous Engine Pivot

AWGUI is moving from a runtime dependency on an unknown externally installed parent script to an AWGUI-controlled AWG engine slot.

The low-level AWG logic remains shell-native: DKMS, apt, firewall, sysctl, UFW, Fail2Ban, kernel headers, routing and parent manager behavior are not rewritten in Python. AWGUI provides web/Telegram/SSH orchestration, audit, traffic history and server registry.

## Engine model

v8.4 ships:

- AWGUI engine metadata: `5.18.4-awgui1`.
- Pinned upstream target: `bivlked/amneziawg-installer` `v5.18.4`.
- Engine manifest and SHA256 of packaged engine-launcher files.
- Engine page in UI: `/engine`.
- Deploy engine slot to selected local/SSH server.
- Apply pinned engine to selected server with explicit `ENGINE` confirmation.
- Provisioner now deploys the AWGUI engine slot before bootstrap.

Current package mode is **pinned engine launcher**, not a full offline mirror yet. That means the engine slot installs the exact upstream v5.18.4 scripts from the pinned tag instead of following `main`. The directory layout is already ready for a full offline import of upstream scripts and `cascade/ru.zone`.

## What changed from v8.3

- Added `engine.py`.
- Added `templates/engine.html`.
- Added `engine/vendor/bivlked_5_18_4/`.
- Provisioner no longer downloads an unpinned parent installer from `main`.
- Provisioner deploys AWGUI's pinned engine slot first.
- Diagnostics shows engine status for the selected server.
- `/api/version` includes engine version.
- Release gate checks engine files and old-UI regressions.

## Installation / upgrade

```bash
cd ~

sudo systemctl stop awgui awgui-bot 2>/dev/null || true

rm -rf ~/awgui
mkdir -p ~/awgui

tar -xzf ~/Downloads/awgui_v8_4_0.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui

sudo ./upgrade.sh
```

Check:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected:

```json
{"app":"AWGUI","ok":true,"version":"8.4.0"}
```

Open:

```text
http://127.0.0.1:8080
```

Default login:

```text
admin / devpass
```

## Engine page

Open:

```text
http://127.0.0.1:8080/engine
```

Actions:

- **Deploy engine slot** — copies AWGUI engine files to `/root/awg/.awgui-engine/5.18.4-awgui1/` on the selected server.
- **Apply bundled engine** — after typing `ENGINE`, refreshes `/root/awg/install_amneziawg.sh`, `/root/awg/manage_amneziawg.sh`, `/root/awg/awg_common.sh` and cascade docs/assets from the pinned upstream v5.18.4 tag, then verifies `manage --json list`.

## Provisioner

v8.4 Provisioner remains strict:

- SSH target only;
- Ubuntu 24.04 LTS;
- root or passwordless sudo;
- no agents;
- no Docker;
- no Python rewrite of AWG/DKMS install;
- destructive bootstrap remains web-only.

Flow:

```text
/servers      → add SSH target
/provisioner  → run preflight
/provisioner  → type BOOTSTRAP and bootstrap
```

## Telegram

Telegram keeps functional parity for normal operations: server switch, clients, temporary clients, backups, diagnostics and server actions. Engine/provisioner destructive flows remain web-only for now.

## Roadmap

- v8.5 — Cascade & Routing Resilience UI.
- v8.6 — Obfuscation & Resilience profiles.
- v8.7 — Travel packs / fallback bundles.

## Design doctrine

- KISS.
- One server registry.
- One adapter layer.
- One engine slot.
- Web and Telegram call the same operational model.
- No agents, no Docker, no cluster layer.
- No custom replacement for parent AWG low-level scripts.
