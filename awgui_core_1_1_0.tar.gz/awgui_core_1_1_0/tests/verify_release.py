from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

required = [
    ROOT / "panel/web.py", ROOT / "panel/telegram.py", ROOT / "panel/manager.py", ROOT / "panel/runner.py",
    ROOT / "panel/cascade.py", ROOT / "panel/state.py", ROOT / "install.sh", ROOT / "uninstall.sh",
    ROOT / "vendor/bivlked/awg-routing.sh", ROOT / "vendor/bivlked/awg-routing.service",
    ROOT / "vendor/bivlked/CASCADE.md",
]
for path in required:
    assert path.is_file(), path

assert (ROOT / "VERSION").read_text().strip() == "1.1.0"
assert not (ROOT / "amneziawg-installer").exists()

# The vendored routing script must be byte-for-byte the script embedded in CASCADE.md.
text = (ROOT / "vendor/bivlked/CASCADE.md").read_text(encoding="utf-8")
sub = text[text.index("## Шаг 4."):]
i = sub.index("```bash") + len("```bash")
j = sub.index("```", i)
embedded = sub[i:j].strip() + "\n"
assert embedded == (ROOT / "vendor/bivlked/awg-routing.sh").read_text(encoding="utf-8")
assert "RU_ZONE_FALLBACK_URL=\"https://raw.githubusercontent.com/bivlked/amneziawg-installer/main/cascade/ru.zone\"" in embedded

sub = text[text.index("## Шаг 5."):]
i = sub.index("```ini") + len("```ini")
j = sub.index("```", i)
unit = sub[i:j].strip() + "\n"
assert unit == (ROOT / "vendor/bivlked/awg-routing.service").read_text(encoding="utf-8")

subprocess.run([sys.executable, "-m", "py_compile", *[str(x) for x in (ROOT / "panel").glob("*.py")]], check=True)
subprocess.run(["bash", "-n", str(ROOT / "install.sh"), str(ROOT / "uninstall.sh"), str(ROOT / "vendor/bivlked/awg-routing.sh"), *[str(x) for x in (ROOT / "tests").glob("*.sh")]], check=True)

manager = (ROOT / "panel/manager.py").read_text()
web = (ROOT / "panel/web.py").read_text()
bot = (ROOT / "panel/telegram.py").read_text()
for forbidden in ["run_installer", "deploy_upstream", "validate_installer_args", "INSTALL_TIMEOUT", "installer_dir"]:
    assert forbidden not in manager + web + bot, forbidden
for marker in ["manage_amneziawg.sh", "run_manage", "AWGManager"]:
    assert marker in manager, marker
for marker in ["server_add", "run_manage", "cascade_view", "settings_page"]:
    assert marker in web, marker
for marker in ["/addserver", "/modify", "/backups", "/backupfile", "/uploadbackup", "/restore", "/cascade_step"]:
    assert marker in bot, marker

uninstall = (ROOT / "uninstall.sh").read_text()
assert "install_amneziawg" not in uninstall and "--all" not in uninstall

for path in list((ROOT / "panel").rglob("*")) + [ROOT / "install.sh", ROOT / "uninstall.sh"]:
    if not path.is_file() or path.suffix not in {".py", ".html", ".css", ".js", ".sh"}:
        continue
    data = path.read_bytes()
    assert not data.startswith(b"\xef\xbb\xbf"), path
    assert b"\r\n" not in data, path

subprocess.run([sys.executable, str(ROOT / "tests/selftest.py")], check=True)
print("AWGUI Core release gate OK")
