#!/usr/bin/env bash
set -euo pipefail
AWG_DIR="/tmp/fake_awg"; JSON=0; EXPIRES=""; PSK=0; YES=0
args=()
while (($#)); do
 case "$1" in
  --conf-dir=*) AWG_DIR="${1#*=}";;
  --server-conf=*) ;;
  --json) JSON=1;;
  --expires=*) EXPIRES="${1#*=}";;
  --psk) PSK=1;;
  --yes|--no-color|--verbose|--apply-mode=*|--carrier=*) ;;
  *) args+=("$1");;
 esac
 shift
done
mkdir -p "$AWG_DIR/backups"
cmd="${args[0]:-help}"; shift_args=("${args[@]:1}")
case "$cmd" in
 add)
  for n in "${shift_args[@]}"; do printf '[Interface]\nPrivateKey = fake\n' > "$AWG_DIR/$n.conf"; printf 'vpn://%s\n' "$n" > "$AWG_DIR/$n.vpnuri"; printf 'PNG' > "$AWG_DIR/$n.png"; done
  echo "added ${shift_args[*]}";;
 remove) for n in "${shift_args[@]}"; do rm -f "$AWG_DIR/$n."*; done; echo removed;;
 regen) echo regenerated;;
 modify) echo modified;;
 list)
  if [[ $JSON -eq 1 ]]; then
    printf '['; first=1
    for f in "$AWG_DIR"/*.conf; do [[ -e "$f" ]] || continue; n="$(basename "$f" .conf)"; [[ "$n" == awg0 ]] && continue; [[ $first -eq 1 ]] || printf ','; first=0; printf '{"name":"%s","client_ip":"10.0.0.2","status":"active"}' "$n"; done
    printf ']\n'
  else echo 'clients'; fi;;
 stats) [[ $JSON -eq 1 ]] && echo '[{"name":"phone","rx":"1 MB","tx":"2 MB"}]' || echo stats;;
 backup) touch "$AWG_DIR/backups/backup-test.tar.gz"; echo backup;;
 restore) echo restored;;
 status|check) echo 'service active';;
 show) echo 'interface: awg0';;
 diagnose) echo 'diagnose OK';;
 restart) echo restarted;;
 repair-module) echo repaired;;
 help) echo 'add remove list stats regen modify backup restore check status diagnose show restart repair-module --json --expires --psk --carrier --apply-mode --yes';;
 *) echo "unknown $cmd" >&2; exit 1;;
esac
