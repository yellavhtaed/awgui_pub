#!/usr/bin/env bash
set -Eeuo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Запустите: sudo $0" >&2; exit 1; }

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="/opt/awgui"
STAGE="/opt/.awgui-stage.$$"
BACKUP="/opt/.awgui-rollback.$$"
STATE_DIR="/var/lib/awgui"
ENV_FILE="/etc/awgui.env"
NEW_CREDENTIALS=0

cleanup() { rm -rf "$STAGE"; }
trap cleanup EXIT

install -d -m 700 "$STATE_DIR"
rm -rf "$STAGE"
install -d -m 755 "$STAGE"
cp -a "$SOURCE_DIR"/. "$STAGE"/
find "$STAGE" -type d -name __pycache__ -prune -exec rm -rf {} +
chmod 700 "$STAGE/install.sh" "$STAGE/uninstall.sh" "$STAGE/vendor/bivlked/awg-routing.sh"
python3 -m venv "$STAGE/.venv"
"$STAGE/.venv/bin/pip" install --disable-pip-version-check -q -r "$STAGE/requirements.txt"
AWGUI_BASE_DIR="$STAGE" AWGUI_STATE_DIR="$STATE_DIR" "$STAGE/.venv/bin/python" -m py_compile "$STAGE"/panel/*.py

if [[ ! -f "$ENV_FILE" ]]; then
  PASSWORD="$(openssl rand -hex 10)"
  SECRET="$(openssl rand -hex 32)"
  umask 077
  cat > "$ENV_FILE" <<EOF
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_ADMIN_USER=admin
AWGUI_ADMIN_PASSWORD=$PASSWORD
AWGUI_SECRET_KEY=$SECRET
AWGUI_BASE_DIR=$TARGET
AWGUI_VENDOR_DIR=$TARGET/vendor/bivlked
AWGUI_STATE_DIR=$STATE_DIR
EOF
  NEW_CREDENTIALS=1
fi
chmod 600 "$ENV_FILE"

cat > /etc/systemd/system/awgui.service <<EOF
[Unit]
Description=AWGUI web panel for installed AmneziaWG
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/gunicorn --workers 1 --threads 4 --timeout 1800 --bind \${AWGUI_HOST}:\${AWGUI_PORT} 'panel.web:create_app()'
Restart=on-failure
RestartSec=3
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/awgui-bot.service <<EOF
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m panel.telegram
Restart=always
RestartSec=5
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

systemctl disable --now awgui.service awgui-bot.service 2>/dev/null || true
rm -rf "$BACKUP"
if [[ -d "$TARGET" ]]; then mv "$TARGET" "$BACKUP"; fi
mv "$STAGE" "$TARGET"
trap - EXIT
systemctl daemon-reload
systemctl enable --now awgui.service awgui-bot.service

HEALTH=""
for _ in $(seq 1 30); do
  HEALTH="$(curl -fsS http://127.0.0.1:8080/health 2>/dev/null || true)"
  [[ -n "$HEALTH" ]] && break
  sleep 1
done
if ! python3 - "$HEALTH" <<'PY'
import json,sys
if len(sys.argv)<2 or not sys.argv[1]: raise SystemExit(1)
data=json.loads(sys.argv[1]); assert data.get("panel")=="ok",data
PY
then
  systemctl disable --now awgui.service awgui-bot.service 2>/dev/null || true
  rm -rf "$TARGET"
  if [[ -d "$BACKUP" ]]; then mv "$BACKUP" "$TARGET"; systemctl enable --now awgui.service awgui-bot.service || true; fi
  echo "AWGUI health-check не пройден; предыдущая версия восстановлена" >&2
  exit 1
fi
rm -rf "$BACKUP"

echo
echo "AWGUI установлена: http://127.0.0.1:8080"
echo "Удалённый доступ: ssh -L 8080:127.0.0.1:8080 root@SERVER_IP"
if [[ $NEW_CREDENTIALS -eq 1 ]]; then
  echo "Логин: admin"
  echo "Пароль: $PASSWORD"
else
  echo "Учётные данные: $ENV_FILE"
fi
