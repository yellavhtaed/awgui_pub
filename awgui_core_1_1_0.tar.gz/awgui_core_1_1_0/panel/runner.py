from __future__ import annotations

import os
import shlex
import signal
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from . import config


@dataclass(slots=True)
class Result:
    ok: bool
    rc: int
    command: str
    stdout: str
    stderr: str
    duration: float
    data: object | None = None

    @property
    def text(self) -> str:
        return "\n".join(x for x in (self.stdout.rstrip(), self.stderr.rstrip()) if x).strip()


def display(argv: Sequence[str]) -> str:
    return " ".join(shlex.quote(str(x)) for x in argv)


class Runner:
    def __init__(self, server: dict):
        self.server = server

    @property
    def remote(self) -> bool:
        return self.server.get("mode") == "ssh"

    def _ssh_prefix(self) -> list[str]:
        target = f"{self.server.get('user', 'root')}@{self.server['host']}"
        args = [
            config.SSH_BIN,
            "-p", str(int(self.server.get("port", 22))),
            "-o", "BatchMode=yes",
            "-o", "ConnectTimeout=12",
            "-o", "ServerAliveInterval=15",
            "-o", "ServerAliveCountMax=2",
            "-o", "StrictHostKeyChecking=accept-new",
        ]
        key = str(self.server.get("key_path") or "").strip()
        if key:
            args += ["-i", key]
        args.append(target)
        return args

    def run(self, argv: Sequence[str], *, timeout: int = 120, input_bytes: bytes | None = None) -> Result:
        started = time.monotonic()
        if self.remote:
            prefix = self._ssh_prefix()
            cmd = prefix + [shlex.join([str(x) for x in argv])]
            shown = display(prefix + ["<remote-command>"])
        else:
            cmd = [str(x) for x in argv]
            shown = display(cmd)
        process: subprocess.Popen[bytes] | None = None
        try:
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={**os.environ, "LC_ALL": "C.UTF-8", "LANG": "C.UTF-8"},
                start_new_session=True,
            )
            stdout, stderr = process.communicate(input=input_bytes, timeout=timeout)
            return Result(
                process.returncode == 0,
                int(process.returncode or 0),
                shown,
                stdout.decode("utf-8", errors="replace"),
                stderr.decode("utf-8", errors="replace"),
                time.monotonic() - started,
            )
        except subprocess.TimeoutExpired as exc:
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                    stdout, stderr = process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    stdout, stderr = process.communicate()
                except ProcessLookupError:
                    stdout, stderr = b"", b""
            else:
                stdout, stderr = b"", b""
            old_out = exc.stdout if isinstance(exc.stdout, bytes) else b""
            old_err = exc.stderr if isinstance(exc.stderr, bytes) else b""
            return Result(
                False, 124, shown,
                (old_out + stdout).decode("utf-8", errors="replace"),
                ((old_err + stderr).decode("utf-8", errors="replace") + "\nTimeout").strip(),
                time.monotonic() - started,
            )
        except OSError as exc:
            return Result(False, 127, shown, "", str(exc), time.monotonic() - started)

    def read_file(self, path: str, *, max_bytes: int = 64 * 1024 * 1024) -> bytes | None:
        if self.remote:
            cmd = self._ssh_prefix() + [f"test -f {shlex.quote(path)} && cat -- {shlex.quote(path)}"]
            try:
                completed = subprocess.run(cmd, capture_output=True, timeout=90, check=False)
                if completed.returncode != 0 or len(completed.stdout) > max_bytes:
                    return None
                return completed.stdout
            except (OSError, subprocess.TimeoutExpired):
                return None
        p = Path(path)
        try:
            if not p.is_file() or p.stat().st_size > max_bytes:
                return None
            return p.read_bytes()
        except OSError:
            return None

    def write_file(self, path: str, data: bytes, *, mode: int = 0o600) -> Result:
        parent = str(Path(path).parent)
        if self.remote:
            script = (
                f"set -e; install -d -m 700 {shlex.quote(parent)}; "
                f"tmp=$(mktemp {shlex.quote(parent + '/.awgui.XXXXXX')}); "
                f"trap 'rm -f \"$tmp\"' EXIT; cat >\"$tmp\"; chmod {mode:o} \"$tmp\"; "
                f"mv -f \"$tmp\" {shlex.quote(path)}; trap - EXIT"
            )
            return self.run(["bash", "-lc", script], timeout=120, input_bytes=data)
        try:
            Path(parent).mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(prefix=".awgui.", dir=parent)
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.chmod(tmp, mode)
                os.replace(tmp, path)
            finally:
                try:
                    os.unlink(tmp)
                except FileNotFoundError:
                    pass
            return Result(True, 0, f"write {path}", "", "", 0.0)
        except OSError as exc:
            return Result(False, 1, f"write {path}", "", str(exc), 0.0)
