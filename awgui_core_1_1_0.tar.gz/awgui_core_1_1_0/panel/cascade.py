from __future__ import annotations

import re
import shlex
import time
from dataclasses import dataclass
from ipaddress import ip_address

from . import config
from .manager import AWGManager, valid_names
from .runner import Result


@dataclass(slots=True)
class Step:
    key: str
    title: str
    ok: bool
    detail: str


def _endpoint_host(conf: str) -> str | None:
    match = re.search(r"^Endpoint\s*=\s*(.+)$", conf, re.MULTILINE)
    if not match:
        return None
    value = match.group(1).strip()
    if value.startswith("["):
        end = value.find("]")
        return value[1:end] if end > 0 else None
    return value.rsplit(":", 1)[0] if ":" in value else value


def _is_full_tunnel(conf: str) -> bool:
    values = re.findall(r"^AllowedIPs\s*=\s*(.+)$", conf, re.MULTILINE | re.IGNORECASE)
    return any("0.0.0.0/0" in {part.strip() for part in value.split(",")} for value in values)


def patch_awg1_config(conf: str) -> str:
    """Выполняет только две правки из CASCADE.md: удаляет DNS и ставит Table=off."""
    lines = conf.replace("\r\n", "\n").splitlines()
    out: list[str] = []
    in_interface = False
    table_seen = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("["):
            if in_interface and not table_seen:
                out.append("Table = off")
            in_interface = stripped.lower() == "[interface]"
            table_seen = False
        if in_interface and stripped.lower().startswith("dns") and "=" in stripped:
            continue
        if in_interface and stripped.lower().startswith("table") and "=" in stripped:
            out.append("Table = off")
            table_seen = True
            continue
        out.append(line)
    if in_interface and not table_seen:
        out.append("Table = off")
    return "\n".join(out).rstrip() + "\n"


def _render_upstream_routing_script(client_subnet: str, endpoint: str) -> bytes:
    path = config.VENDOR_DIR / "awg-routing.sh"
    template = path.read_text(encoding="utf-8")
    # CASCADE.md требует вручную изменить только эти параметры.
    template, subnet_count = re.subn(
        r'^CLIENT_SUBNET="[^"]*"', f'CLIENT_SUBNET="{client_subnet}"', template,
        count=1, flags=re.MULTILINE,
    )
    template, endpoint_count = re.subn(
        r'^AWG1_ENDPOINT="[^"]*"', f'AWG1_ENDPOINT="{endpoint}"', template,
        count=1, flags=re.MULTILINE,
    )
    if subnet_count != 1 or endpoint_count != 1:
        raise RuntimeError("Upstream awg-routing.sh не соответствует ожидаемому CASCADE.md")
    return template.encode("utf-8")


def status(entry: AWGManager, exit_server: AWGManager, link_name: str = "ru_host") -> list[Step]:
    link_name = valid_names([link_name])[0]
    steps: list[Step] = []
    steps.append(Step("entry_manager", "manage_amneziawg.sh на AWG0", entry.installed(), entry.manage_path))
    steps.append(Step("exit_manager", "manage_amneziawg.sh на AWG1", exit_server.installed(), exit_server.manage_path))

    entry_subnet = entry.server_subnet()
    exit_subnet = exit_server.server_subnet()
    different = bool(entry_subnet and exit_subnet and entry_subnet != exit_subnet)
    steps.append(Step("subnets", "Подсети различаются", different, f"AWG0={entry_subnet or 'не определена'}, AWG1={exit_subnet or 'не определена'}"))

    exit_conf_path = exit_server.client_path(link_name, "conf")
    steps.append(Step("link_client", "Клиент связи на AWG1", bool(exit_conf_path), exit_conf_path or "не создан"))

    awg1_conf = entry.runner.read_file("/etc/amnezia/amneziawg/awg1.conf")
    awg1_text = awg1_conf.decode("utf-8", errors="replace") if awg1_conf else ""
    prepared = bool(
        awg1_text
        and re.search(r"^Table\s*=\s*off\s*$", awg1_text, re.MULTILINE | re.IGNORECASE)
        and not re.search(r"^DNS\s*=", awg1_text, re.MULTILINE | re.IGNORECASE)
    )
    steps.append(Step("awg1_conf", "awg1.conf подготовлен по CASCADE.md", prepared, "Table=off, DNS удалён" if prepared else "нет или не подготовлен"))
    steps.append(Step("full_tunnel", "AllowedIPs = 0.0.0.0/0", _is_full_tunnel(awg1_text), "требование CASCADE.md"))

    tunnel = entry.runner.run(["systemctl", "is-active", "--quiet", "awg-quick@awg1.service"], timeout=20)
    steps.append(Step("awg1_active", "Туннель awg1 активен", tunnel.ok, "active" if tunnel.ok else "inactive"))

    handshake = entry.runner.run(["bash", "-lc", "awg show awg1 latest-handshakes 2>/dev/null | awk 'NF>=2{print $2; exit}'"], timeout=20)
    try:
        epoch = int(handshake.stdout.strip())
    except ValueError:
        epoch = 0
    age = int(time.time()) - epoch if epoch else 0
    fresh = bool(epoch and 0 <= age <= 180)
    steps.append(Step("handshake", "Свежий handshake AWG0 → AWG1", fresh, f"{age} сек. назад" if epoch else "не найден"))

    script_exists = entry.exists("/root/awg/awg-routing.sh")
    steps.append(Step("routing_script", "Upstream awg-routing.sh установлен", script_exists, "/root/awg/awg-routing.sh"))

    service_enabled = entry.runner.run(["systemctl", "is-enabled", "--quiet", "awg-routing.service"], timeout=20)
    steps.append(Step("routing_service", "Автозапуск маршрутизации", service_enabled.ok, "enabled" if service_enabled.ok else "disabled"))

    subnet = entry_subnet or "0.0.0.0/0"
    checks = {
        "rule": "ip rule show | grep -Eq 'fwmark (0x)?1.*lookup 100'",
        "table": "ip route show table 100 | grep -Eq '^default dev awg1'",
        "ru-set": "ipset list ru 2>/dev/null | grep -Eq 'Number of entries: [1-9][0-9]*'",
        "return": f"iptables -t mangle -C PREROUTING -i awg0 -s {shlex.quote(subnet)} -m set --match-set ru dst -j RETURN",
        "mark": f"iptables -t mangle -C PREROUTING -i awg0 -s {shlex.quote(subnet)} -j MARK --set-mark 0x1",
        "nat": f"iptables -t nat -C POSTROUTING -s {shlex.quote(subnet)} -o awg1 -j MASQUERADE",
    }
    results = {name: entry.runner.run(["bash", "-lc", command], timeout=20).ok for name, command in checks.items()}
    runtime_ok = all(results.values())
    detail = ", ".join(f"{name}={'ok' if ok else 'no'}" for name, ok in results.items())
    steps.append(Step("routing_runtime", "Правила CASCADE.md применены", runtime_ok, detail))
    return steps


def install_prerequisites(entry: AWGManager) -> Result:
    return entry.runner.run(["bash", "-lc", "DEBIAN_FRONTEND=noninteractive apt-get update && apt-get install -y curl ipset"], timeout=1800)


def create_link_client(exit_server: AWGManager, link_name: str) -> Result:
    return exit_server.add([valid_names([link_name])[0]])


def transfer_link_config(entry: AWGManager, exit_server: AWGManager, link_name: str) -> Result:
    clean = valid_names([link_name])[0]
    item = exit_server.client_file(clean, "conf")
    if not item:
        return Result(False, 2, "transfer awg1.conf", "", "Конфиг клиента связи не найден на AWG1", 0.0)
    _, data = item
    text = data.decode("utf-8", errors="strict")
    if not _is_full_tunnel(text):
        return Result(False, 2, "transfer awg1.conf", "", "CASCADE.md требует AllowedIPs = 0.0.0.0/0; конфиг не изменён", 0.0)
    patched = patch_awg1_config(text)
    target = "/etc/amnezia/amneziawg/awg1.conf"
    existing = entry.runner.read_file(target)
    if existing is not None:
        if existing.decode("utf-8", errors="replace") == patched:
            return Result(True, 0, "transfer awg1.conf", "Файл уже соответствует CASCADE.md", "", 0.0)
        return Result(False, 2, "transfer awg1.conf", "", f"{target} уже существует и отличается; AWGUI не перезаписывает его", 0.0)
    return entry.runner.write_file(target, patched.encode("utf-8"), mode=0o600)


def start_link_tunnel(entry: AWGManager) -> Result:
    return entry.runner.run(["systemctl", "enable", "--now", "awg-quick@awg1.service"], timeout=180)


def install_routing(entry: AWGManager) -> Result:
    subnet = entry.server_subnet()
    conf = entry.runner.read_file("/etc/amnezia/amneziawg/awg1.conf")
    if not subnet or not conf:
        return Result(False, 2, "install upstream awg-routing.sh", "", "Не определены подсеть AWG0 или awg1.conf", 0.0)
    text = conf.decode("utf-8", errors="replace")
    if not _is_full_tunnel(text):
        return Result(False, 2, "install upstream awg-routing.sh", "", "AllowedIPs не соответствует CASCADE.md", 0.0)
    endpoint = _endpoint_host(text)
    if not endpoint:
        return Result(False, 2, "install upstream awg-routing.sh", "", "Endpoint AWG1 не найден", 0.0)
    try:
        ip_address(endpoint)
    except ValueError:
        if not re.fullmatch(r"[A-Za-z0-9.-]{1,253}", endpoint):
            return Result(False, 2, "install upstream awg-routing.sh", "", "Некорректный Endpoint AWG1", 0.0)
    try:
        script = _render_upstream_routing_script(subnet, endpoint)
    except (OSError, RuntimeError) as exc:
        return Result(False, 2, "install upstream awg-routing.sh", "", str(exc), 0.0)
    target = "/root/awg/awg-routing.sh"
    existing = entry.runner.read_file(target)
    if existing is not None and existing != script:
        return Result(False, 2, "install upstream awg-routing.sh", "", f"{target} уже существует и отличается; AWGUI не перезаписывает его", 0.0)
    if existing == script:
        return Result(True, 0, "install upstream awg-routing.sh", "Файл уже установлен", "", 0.0)
    return entry.runner.write_file(target, script, mode=0o700)


def run_routing(entry: AWGManager) -> Result:
    return entry.runner.run(["bash", "/root/awg/awg-routing.sh"], timeout=900)


def enable_routing_service(entry: AWGManager) -> Result:
    try:
        unit = (config.VENDOR_DIR / "awg-routing.service").read_bytes()
    except OSError as exc:
        return Result(False, 2, "install awg-routing.service", "", str(exc), 0.0)
    written = entry.runner.write_file("/etc/systemd/system/awg-routing.service", unit, mode=0o644)
    if not written.ok:
        return written
    return entry.runner.run([
        "bash", "-lc",
        "systemctl daemon-reload && systemctl enable awg-quick@awg1 awg-routing && systemctl start awg-routing",
    ], timeout=300)


def remove_cascade(entry: AWGManager, exit_server: AWGManager, link_name: str) -> Result:
    """Откатывает только объекты официальной пары и удаляет её peer через manager."""
    clean = valid_names([link_name])[0]
    subnet = entry.server_subnet() or "0.0.0.0/0"
    script = f"""
set -e
systemctl disable --now awg-routing.service awg-quick@awg1.service 2>/dev/null || true
rm -f /etc/systemd/system/awg-routing.service /etc/amnezia/amneziawg/awg1.conf /root/awg/awg-routing.sh
ip rule del fwmark 0x1 table 100 2>/dev/null || true
ip route flush table 100 2>/dev/null || true
iptables -t mangle -D PREROUTING -i awg0 -s {shlex.quote(subnet)} -m set --match-set ru dst -j RETURN 2>/dev/null || true
iptables -t mangle -D PREROUTING -i awg0 -s {shlex.quote(subnet)} -j MARK --set-mark 0x1 2>/dev/null || true
iptables -t nat -D POSTROUTING -s {shlex.quote(subnet)} -o awg1 -j MASQUERADE 2>/dev/null || true
ipset destroy ru 2>/dev/null || true
systemctl daemon-reload
"""
    local_result = entry.runner.run(["bash", "-lc", script], timeout=180)
    if not local_result.ok:
        return local_result
    peer_result = exit_server.remove([clean])
    if not peer_result.ok:
        return Result(False, peer_result.rc, "remove cascade", local_result.stdout, f"AWG0 очищен, но peer {clean} на AWG1 не удалён:\n{peer_result.text}", local_result.duration + peer_result.duration)
    return Result(True, 0, "remove cascade", "AWG0 очищен; link-client удалён на AWG1", "", local_result.duration + peer_result.duration)
