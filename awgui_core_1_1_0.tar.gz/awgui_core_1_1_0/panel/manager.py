from __future__ import annotations

import fcntl
import hashlib
import io
import json
import re
import shlex
import tarfile
from ipaddress import ip_interface
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable

from . import config
from .runner import Result, Runner

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,63}$")
_SERVER_ID_RE = re.compile(r"^[a-zA-Z0-9_.-]{1,48}$")
_ALLOWED_EXPIRES = {"", "1h", "12h", "1d", "7d", "30d", "4w"}
_ALLOWED_MODIFY = {"DNS", "Endpoint", "AllowedIPs", "PersistentKeepalive"}
_ALLOWED_APPLY = {"syncconf", "restart"}
_MUTATING_MANAGE = {"add", "remove", "regen", "modify", "backup", "restore", "restart", "repair-module"}
_ALLOWED_MANAGE = {
    "add", "remove", "list", "stats", "regen", "modify", "backup", "restore",
    "check", "status", "diagnose", "show", "restart", "repair-module", "help",
}


def valid_server_id(value: str) -> str:
    value = (value or "").strip()
    if not _SERVER_ID_RE.fullmatch(value):
        raise ValueError("ID сервера: только буквы, цифры, точка, дефис и подчёркивание")
    return value


def make_ssh_server(
    server_id: str,
    host: str,
    *,
    port: int = 22,
    user: str = "root",
    key_path: str = "",
    name: str = "",
    manage_path: str = "",
    awg_dir: str = "",
    server_conf: str = "",
) -> dict[str, Any]:
    sid = valid_server_id(server_id)
    if sid == "local":
        raise ValueError("ID local зарезервирован")
    host = host.strip()
    user = user.strip()
    key_path = key_path.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.:\-\[\]]{1,255}", host):
        raise ValueError("Некорректный host")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_-]{0,31}", user):
        raise ValueError("Некорректный SSH user")
    if not 1 <= int(port) <= 65535:
        raise ValueError("Некорректный SSH-порт")
    if key_path and not Path(key_path).is_absolute():
        raise ValueError("SSH key path должен быть абсолютным")
    paths = {
        "manage_path": manage_path or config.LOCAL_MANAGE,
        "awg_dir": awg_dir or config.LOCAL_AWG_DIR,
        "server_conf": server_conf or config.LOCAL_SERVER_CONF,
    }
    for label, value in paths.items():
        if not Path(value).is_absolute() or any(ch in value for ch in "\r\n\x00"):
            raise ValueError(f"Некорректный путь: {label}")
    display_name = (name or sid).strip()
    if not display_name or len(display_name) > 80 or any(ch in display_name for ch in "\r\n\x00"):
        raise ValueError("Некорректное имя сервера")
    return {
        "id": sid, "name": display_name, "mode": "ssh", "host": host,
        "port": int(port), "user": user, "key_path": key_path, **paths,
    }


def valid_names(values: Iterable[str], *, required: bool = True) -> list[str]:
    names = [v.strip() for v in values if v and v.strip()]
    if required and not names:
        raise ValueError("Укажите имя клиента")
    bad = [name for name in names if not _NAME_RE.fullmatch(name)]
    if bad:
        raise ValueError("Недопустимые имена: " + ", ".join(bad))
    return names


def parse_json(result: Result) -> Result:
    if not result.stdout.strip():
        result.ok = False
        result.stderr = (result.stderr + "\nПустой JSON-ответ").strip()
        return result
    try:
        result.data = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        result.ok = False
        result.stderr = (result.stderr + f"\nНекорректный JSON: {exc}").strip()
    return result


class AWGManager:
    """Тонкий вызов установленного manage_amneziawg.sh без собственной AWG-логики."""

    def __init__(self, server: dict[str, Any]):
        self.server = server
        self.runner = Runner(server)
        self.manage_path = str(server.get("manage_path") or config.LOCAL_MANAGE)
        self.awg_dir = str(server.get("awg_dir") or config.LOCAL_AWG_DIR)
        self.server_conf = str(server.get("server_conf") or config.LOCAL_SERVER_CONF)

    @contextmanager
    def _operation_lock(self):
        identity = f"{self.server.get('id','server')}|{self.server.get('host','local')}|{self.manage_path}"
        digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20]
        config.STATE_DIR.mkdir(parents=True, exist_ok=True)
        path = config.STATE_DIR / f"operation-{digest}.lock"
        with path.open("a+") as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)

    def exists(self, path: str) -> bool:
        return self.runner.run(["test", "-f", path], timeout=20).ok

    def installed(self) -> bool:
        return self.exists(self.manage_path)

    def run_manage(
        self,
        command: str,
        *args: str,
        json_output: bool = False,
        verbose: bool = False,
        expires: str = "",
        psk: bool = False,
        yes: bool = False,
        carrier: str = "",
        apply_mode: str = "syncconf",
        timeout: int | None = None,
    ) -> Result:
        if command not in _ALLOWED_MANAGE:
            return Result(False, 2, command, "", "Команда не разрешена", 0.0)
        if not self.installed():
            return Result(False, 127, self.manage_path, "", f"Не найден {self.manage_path}", 0.0)
        if expires not in _ALLOWED_EXPIRES:
            return Result(False, 2, command, "", "Недопустимый срок", 0.0)
        if apply_mode not in _ALLOWED_APPLY:
            return Result(False, 2, command, "", "Недопустимый apply-mode", 0.0)
        argv = [
            "bash", self.manage_path, "--no-color",
            f"--conf-dir={self.awg_dir}", f"--server-conf={self.server_conf}",
        ]
        if json_output:
            argv.append("--json")
        if verbose:
            argv.append("--verbose")
        if expires:
            argv.append(f"--expires={expires}")
        if psk:
            argv.append("--psk")
        if yes:
            argv.append("--yes")
        if carrier:
            if carrier not in config.CARRIERS:
                return Result(False, 2, command, "", "Неизвестный операторский профиль", 0.0)
            argv.append(f"--carrier={carrier}")
        if command in {"add", "remove", "regen", "modify"}:
            argv.append(f"--apply-mode={apply_mode}")
        argv.extend([command, *[str(x) for x in args]])
        if command in _MUTATING_MANAGE:
            with self._operation_lock():
                result = self.runner.run(argv, timeout=timeout or config.MANAGE_TIMEOUT)
        else:
            result = self.runner.run(argv, timeout=timeout or config.MANAGE_TIMEOUT)
        return parse_json(result) if json_output else result

    def probe(self) -> dict[str, Any]:
        manager_present = self.installed()
        shell = self.runner.run([
            "bash", "-lc",
            "awg_binary=$(command -v awg 2>/dev/null || true); "
            "module=$(lsmod 2>/dev/null | awk '$1==\"amneziawg\"{print $1; exit}' || true); "
            "interface=$( (ip link show awg0 >/dev/null 2>&1 && echo awg0) || true ); "
            "service=$(systemctl is-active awg-quick@awg0.service 2>/dev/null || true); "
            "kernel=$(uname -r 2>/dev/null || true); "
            "dkms=$(dkms status 2>/dev/null | grep -i amnezia | head -1 || true); "
            "printf 'awg_binary=%s\nmodule=%s\ninterface=%s\nservice=%s\nkernel=%s\ndkms=%s\n' "
            "\"$awg_binary\" \"$module\" \"$interface\" \"$service\" \"$kernel\" \"$dkms\"",
        ], timeout=30)
        facts: dict[str, str] = {}
        for line in shell.stdout.splitlines():
            key, sep, value = line.partition("=")
            if sep:
                facts[key] = value.strip()
        status = self.run_manage("status", timeout=60) if manager_present else None
        listing = self.run_manage("list", json_output=True, timeout=60) if manager_present else None
        help_result = self.run_manage("help", timeout=30) if manager_present else None
        manager_version = ""
        if help_result and help_result.ok:
            match = re.search(r"\(v([0-9]+(?:\.[0-9]+)+)\)", help_result.stdout)
            manager_version = match.group(1) if match else ""
        return {
            "installed": manager_present,
            "manager_present": manager_present,
            "manager_path": self.manage_path,
            "manager_version": manager_version,
            "status": status,
            "clients": listing,
            "help": help_result,
            "facts": facts,
            "ssh_ok": shell.rc != 255,
        }

    def list_clients(self) -> Result:
        return self.run_manage("list", json_output=True)

    def stats(self) -> Result:
        return self.run_manage("stats", json_output=True)

    def add(self, names: Iterable[str], *, expires: str = "", psk: bool = False, apply_mode: str = "syncconf") -> Result:
        return self.run_manage("add", *valid_names(names), expires=expires, psk=psk, apply_mode=apply_mode)

    def remove(self, names: Iterable[str], *, apply_mode: str = "syncconf") -> Result:
        return self.run_manage("remove", *valid_names(names), yes=True, apply_mode=apply_mode)

    def regen(self, names: Iterable[str], *, apply_mode: str = "syncconf") -> Result:
        clean = valid_names(names, required=False)
        return self.run_manage("regen", *clean, apply_mode=apply_mode)

    def modify(self, name: str, parameter: str, value: str, *, apply_mode: str = "syncconf") -> Result:
        clean = valid_names([name])[0]
        if parameter not in _ALLOWED_MODIFY:
            return Result(False, 2, "modify", "", "Недопустимый параметр", 0.0)
        value = value.strip()
        if not value or any(ch in value for ch in "\r\n\x00"):
            return Result(False, 2, "modify", "", "Недопустимое значение", 0.0)
        return self.run_manage("modify", clean, parameter, value, apply_mode=apply_mode)

    def client_path(self, name: str, kind: str) -> str | None:
        clean = valid_names([name])[0]
        suffixes = {
            "conf": [f"{clean}.conf", f"awg0-client-{clean}.conf"],
            "png": [f"{clean}.png", f"awg0-client-{clean}.png"],
            "vpnuri": [f"{clean}.vpnuri", f"awg0-client-{clean}.vpnuri"],
            "vpnuri_png": [f"{clean}.vpnuri.png", f"awg0-client-{clean}.vpnuri.png"],
        }
        if kind not in suffixes:
            return None
        for filename in suffixes[kind]:
            path = f"{self.awg_dir}/{filename}"
            if self.exists(path):
                return path
        return None

    def client_file(self, name: str, kind: str) -> tuple[str, bytes] | None:
        path = self.client_path(name, kind)
        if not path:
            return None
        data = self.runner.read_file(path)
        return (Path(path).name, data) if data is not None else None

    def client_bundle(self, name: str) -> bytes | None:
        files: list[tuple[str, bytes]] = []
        for kind in ("conf", "png", "vpnuri", "vpnuri_png"):
            item = self.client_file(name, kind)
            if item:
                files.append(item)
        if not files:
            return None
        output = io.BytesIO()
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for filename, data in files:
                info = tarfile.TarInfo(filename)
                info.size = len(data)
                info.mode = 0o600
                archive.addfile(info, io.BytesIO(data))
        return output.getvalue()

    def backup_list(self) -> list[dict[str, Any]]:
        roots = [f"{self.awg_dir}/backups", f"{self.awg_dir}/backup", self.awg_dir]
        command = "for d in " + " ".join(shlex.quote(x) for x in roots) + "; do [ -d \"$d\" ] || continue; find \"$d\" -maxdepth 1 -type f -name '*.tar.gz' -printf '%p\\t%s\\t%T@\\n'; done"
        result = self.runner.run(["bash", "-lc", command], timeout=60)
        if not result.ok:
            return []
        found: dict[str, dict[str, Any]] = {}
        for line in result.stdout.splitlines():
            parts = line.split("\t")
            if len(parts) != 3:
                continue
            path, size, mtime = parts
            try:
                item = {"name": Path(path).name, "path": path, "size": int(size), "mtime": float(mtime)}
            except ValueError:
                continue
            found[path] = item
        return sorted(found.values(), key=lambda x: x["mtime"], reverse=True)

    def backup_file(self, name: str) -> tuple[str, bytes] | None:
        if Path(name).name != name:
            return None
        item = next((x for x in self.backup_list() if x["name"] == name), None)
        if not item:
            return None
        data = self.runner.read_file(item["path"])
        return (name, data) if data is not None else None

    def upload_backup(self, filename: str, data: bytes) -> Result:
        safe = Path(filename).name
        if safe != filename or not safe.endswith(".tar.gz"):
            return Result(False, 2, "upload backup", "", "Разрешены только .tar.gz", 0.0)
        return self.runner.write_file(f"{self.awg_dir}/backups/{safe}", data, mode=0o600)

    def server_subnet(self) -> str | None:
        data = self.runner.read_file(self.server_conf)
        if not data:
            return None
        text = data.decode("utf-8", errors="replace")
        match = re.search(r"^Address\s*=\s*([0-9.]+/\d+)", text, re.MULTILINE)
        if not match:
            return None
        try:
            return str(ip_interface(match.group(1)).network)
        except ValueError:
            return None
