from __future__ import annotations

import fcntl
import json
import os
import tempfile
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable, Iterator, TypeVar

from . import config

T = TypeVar("T")

_DEFAULT = {
    "servers": [
        {
            "id": "local",
            "name": "Local",
            "mode": "local",
            "host": "127.0.0.1",
            "port": 22,
            "user": "root",
            "key_path": "",
            "manage_path": config.LOCAL_MANAGE,
            "awg_dir": config.LOCAL_AWG_DIR,
            "server_conf": config.LOCAL_SERVER_CONF,
        }
    ],
    "telegram": {"enabled": False, "token": "", "admin_ids": [], "dangerous": False},
    "telegram_server": {},
}


def _normalize(data: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(_DEFAULT)
    if isinstance(data.get("servers"), list):
        servers = [dict(s) for s in data["servers"] if isinstance(s, dict) and s.get("id")]
        for server in servers:
            server.pop("installer_dir", None)
        if not any(s.get("id") == "local" for s in servers):
            servers.insert(0, deepcopy(_DEFAULT["servers"][0]))
        out["servers"] = servers
    if isinstance(data.get("telegram"), dict):
        out["telegram"].update(data["telegram"])
    if isinstance(data.get("telegram_server"), dict):
        out["telegram_server"] = dict(data["telegram_server"])
    return out


@contextmanager
def _file_lock(*, exclusive: bool) -> Iterator[None]:
    config.STATE_DIR.mkdir(parents=True, exist_ok=True)
    with config.STATE_LOCK_FILE.open("a+") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def _load_unlocked() -> dict[str, Any]:
    try:
        data = json.loads(config.STATE_FILE.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return deepcopy(_DEFAULT)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise RuntimeError(f"Не удалось прочитать state {config.STATE_FILE}: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError(f"Некорректный state {config.STATE_FILE}: корень должен быть объектом")
    return _normalize(data)


def _save_unlocked(data: dict[str, Any]) -> None:
    normalized = _normalize(data)
    config.STATE_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="state.", suffix=".tmp", dir=config.STATE_DIR)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(normalized, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_name, 0o600)
        if config.STATE_FILE.exists():
            previous = config.STATE_FILE.with_suffix(".json.prev")
            try:
                previous.write_bytes(config.STATE_FILE.read_bytes())
                os.chmod(previous, 0o600)
            except OSError:
                pass
        os.replace(tmp_name, config.STATE_FILE)
        directory_fd = os.open(config.STATE_DIR, os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


def load() -> dict[str, Any]:
    with _file_lock(exclusive=False):
        return _load_unlocked()


def save(data: dict[str, Any]) -> None:
    with _file_lock(exclusive=True):
        _save_unlocked(data)


def update(mutator: Callable[[dict[str, Any]], T]) -> T:
    with _file_lock(exclusive=True):
        data = _load_unlocked()
        result = mutator(data)
        _save_unlocked(data)
        return result


def list_servers() -> list[dict[str, Any]]:
    return [dict(s) for s in load()["servers"]]


def get_server(server_id: str) -> dict[str, Any] | None:
    return next((dict(s) for s in list_servers() if s.get("id") == server_id), None)


def upsert_server(server: dict[str, Any]) -> None:
    def mutate(data: dict[str, Any]) -> None:
        existing = next((i for i, item in enumerate(data["servers"]) if item.get("id") == server["id"]), None)
        if existing is None:
            data["servers"].append(dict(server))
        else:
            data["servers"][existing] = dict(server)
    update(mutate)


def delete_server(server_id: str) -> bool:
    if server_id == "local":
        return False
    def mutate(data: dict[str, Any]) -> bool:
        before = len(data["servers"])
        data["servers"] = [s for s in data["servers"] if s.get("id") != server_id]
        for chat_id, selected in list(data["telegram_server"].items()):
            if selected == server_id:
                data["telegram_server"][chat_id] = "local"
        return len(data["servers"]) != before
    return update(mutate)


def telegram_settings() -> dict[str, Any]:
    return dict(load()["telegram"])


def set_telegram(settings: dict[str, Any]) -> None:
    update(lambda data: data.__setitem__("telegram", dict(settings)))


def telegram_server(chat_id: str) -> str:
    data = load()
    sid = str(data["telegram_server"].get(str(chat_id), "local"))
    return sid if any(s.get("id") == sid for s in data["servers"]) else "local"


def set_telegram_server(chat_id: str, server_id: str) -> None:
    def mutate(data: dict[str, Any]) -> None:
        if not any(s.get("id") == server_id for s in data["servers"]):
            raise KeyError(server_id)
        data["telegram_server"][str(chat_id)] = server_id
    update(mutate)
