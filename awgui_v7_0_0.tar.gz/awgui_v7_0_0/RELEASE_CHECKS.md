# AWGUI v7.0.0 release checks

Fresh-unpack checks performed before packaging:

```bash
python3 -m py_compile app.py awg.py config.py parse.py telegram_bot.py scripts/selftest.py scripts/verify_release.py
python3 -m venv .testvenv
.testvenv/bin/pip install -q -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh
```

Expected:

```text
AWGUI selftest OK
AWGUI release gate OK: 7.0.0 UI is new
```

Runtime guard:

```bash
curl -s http://127.0.0.1:8080/health
```

Expected version:

```text
7.0.0
```

The release gate fails if `/bot` contains old CLI-first text such as:

```text
На сервере запусти
cd ~/awgui && sudo ./setup_telegram.sh
Service commands
```
