#!/usr/bin/env python3
import html
import json
import os
import shlex
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.parse
import urllib.request
from pathlib import Path

import awg
import config
import parse

API_BASE = "https://api.telegram.org/bot{token}/{method}"
MAX_MESSAGE = 3600


def log(msg):
    print(f"[awgui-bot] {msg}", flush=True)


def token():
    return config.TG_BOT_TOKEN


def enabled():
    return bool(config.TG_BOT_TOKEN)


def api(method, payload=None, timeout=60):
    url = API_BASE.format(token=token(), method=method)
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def multipart_api(method, fields, file_field, path, mime="application/octet-stream", timeout=90):
    boundary = "----awgui" + str(int(time.time() * 1000))
    body = bytearray()

    def add(s):
        body.extend(s.encode("utf-8"))

    for key, value in fields.items():
        add(f"--{boundary}\r\n")
        add(f'Content-Disposition: form-data; name="{key}"\r\n\r\n')
        add(str(value))
        add("\r\n")

    filename = Path(path).name
    add(f"--{boundary}\r\n")
    add(f'Content-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\n')
    add(f"Content-Type: {mime}\r\n\r\n")
    body.extend(Path(path).read_bytes())
    add("\r\n")
    add(f"--{boundary}--\r\n")

    url = API_BASE.format(token=token(), method=method)
    req = urllib.request.Request(
        url,
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def is_admin(chat_id):
    return str(chat_id) in set(config.TG_ADMIN_IDS)


def esc(text):
    return html.escape(str(text or ""))


def clip(text, limit=MAX_MESSAGE):
    text = str(text or "")
    if len(text) <= limit:
        return text
    return text[:limit] + "\n\n--- cut ---"


def send_message(chat_id, text, keyboard=None):
    payload = {
        "chat_id": chat_id,
        "text": clip(text),
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if keyboard:
        payload["reply_markup"] = keyboard
    return api("sendMessage", payload)


def send_plain(chat_id, text):
    return send_message(chat_id, f"<pre>{esc(clip(text))}</pre>")


def send_doc(chat_id, path, caption=""):
    return multipart_api(
        "sendDocument",
        {"chat_id": chat_id, "caption": caption[:900]},
        "document",
        path,
        "application/octet-stream",
    )


def send_photo(chat_id, path, caption=""):
    return multipart_api(
        "sendPhoto",
        {"chat_id": chat_id, "caption": caption[:900]},
        "photo",
        path,
        "image/png",
    )


def main_keyboard():
    return {
        "inline_keyboard": [
            [
                {"text": "📊 Status", "callback_data": "menu:status"},
                {"text": "👥 Clients", "callback_data": "menu:clients:0"},
            ],
            [
                {"text": "💾 Backup", "callback_data": "menu:backup"},
                {"text": "🧪 Diagnostics", "callback_data": "menu:doctor"},
            ],
            [
                {"text": "🧰 Server", "callback_data": "menu:server"},
                {"text": "❔ Help", "callback_data": "menu:help"},
            ],
        ]
    }


def server_keyboard():
    return {
        "inline_keyboard": [
            [
                {"text": "show", "callback_data": "menu:show"},
                {"text": "stats", "callback_data": "menu:stats"},
                {"text": "check", "callback_data": "menu:check"},
            ],
            [
                {"text": "backups", "callback_data": "menu:backups"},
                {"text": "diagnose", "callback_data": "menu:diagnose"},
            ],
            [{"text": "← Main", "callback_data": "menu:main"}],
        ]
    }


def clients_keyboard(page=0, per_page=8):
    items = clients_list()
    page = max(int(page or 0), 0)
    start = page * per_page
    rows = []
    for idx, c in enumerate(items[start:start + per_page], start=start):
        n = parse.name(c)
        st = parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS)
        icon = "🟢" if st == "ONLINE" else "🔴" if st == "OFFLINE" else "⚪"
        rows.append([{"text": f"{icon} {n[:34]}", "callback_data": f"client_i:{idx}"}])
    nav = []
    if page > 0:
        nav.append({"text": "← Prev", "callback_data": f"menu:clients:{page-1}"})
    if start + per_page < len(items):
        nav.append({"text": "Next →", "callback_data": f"menu:clients:{page+1}"})
    if nav:
        rows.append(nav)
    rows.append([{"text": "← Main", "callback_data": "menu:main"}])
    return {"inline_keyboard": rows}


def keyboard_for_client_index(idx):
    return {
        "inline_keyboard": [
            [
                {"text": "QR", "callback_data": f"qri:{idx}"},
                {"text": "conf", "callback_data": f"confi:{idx}"},
                {"text": "vpnuri", "callback_data": f"vpnurii:{idx}"},
            ],
            [
                {"text": "regen", "callback_data": f"regeni:{idx}"},
                {"text": "clients", "callback_data": "menu:clients:0"},
                {"text": "main", "callback_data": "menu:main"},
            ],
        ]
    }


def keyboard_for_client(name):
    # Backward-compatible keyboard for /client NAME. Short callback names keep Telegram's 64-byte limit safer.
    if len(str(name)) > 56:
        return main_keyboard()
    return {
        "inline_keyboard": [
            [
                {"text": "QR", "callback_data": f"q:{name}"},
                {"text": "conf", "callback_data": f"c:{name}"},
                {"text": "vpnuri", "callback_data": f"u:{name}"},
            ],
            [
                {"text": "regen", "callback_data": f"r:{name}"},
                {"text": "main", "callback_data": "menu:main"},
            ],
        ]
    }


def client_by_index(idx):
    try:
        i = int(idx)
    except Exception:
        return None, None
    items = clients_list()
    if i < 0 or i >= len(items):
        return None, None
    return items[i], parse.name(items[i])


def require_admin(chat_id):
    if not config.TG_ADMIN_IDS:
        send_message(
            chat_id,
            "Бот ещё не привязан к admin chat_id. Отправь <b>/id</b>, затем вставь chat_id на странице <code>/bot</code> в AWGUI и нажми Save.",
        )
        return False
    if not is_admin(chat_id):
        send_message(chat_id, f"Access denied. Твой chat_id: <code>{chat_id}</code>")
        return False
    return True


def clients_list():
    result = awg.list_clients()
    return parse.clients_from(result.get("json"))


def find_client(name):
    for item in clients_list():
        if parse.name(item) == name:
            return item
    return None


def format_client(c):
    if not c:
        return "client not found"
    state = parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS)
    return "\n".join([
        f"<b>{esc(parse.name(c))}</b>",
        f"State: <b>{esc(state)}</b>",
        f"IPv4: <code>{esc(parse.ipv4(c))}</code>",
        f"IPv6: <code>{esc(parse.ipv6(c))}</code>",
        f"Traffic: <code>{esc(parse.traffic(c))}</code>",
        f"Handshake: <code>{esc(parse.handshake(c))}</code>",
        f"Endpoint: <code>{esc(parse.endpoint(c))}</code>",
        f"Expires: <code>{esc(parse.expires(c))}</code>",
    ])


def latest_backup_path():
    backups = awg.list_backups()
    if not backups:
        return None
    return Path(backups[0]["path"])


def send_client_conf(chat_id, name):
    path = awg.find_client_file(name, "conf")
    if path:
        return send_doc(chat_id, path, caption=f"{name}.conf")
    text = awg.read_client_text(name, "conf")
    if text:
        return send_plain(chat_id, text)
    send_message(chat_id, "config not found")


def send_client_vpnuri(chat_id, name):
    text = awg.read_client_text(name, "vpnuri")
    if text:
        return send_plain(chat_id, text)
    send_message(chat_id, "vpnuri not found")


def send_client_qr(chat_id, name):
    png = awg.find_client_file(name, "png")
    if png:
        return send_photo(chat_id, png, caption=f"QR: {name}")
    source_name, source = awg.qr_payload(name, "vpnuri")
    if not source:
        send_message(chat_id, "QR source not found")
        return
    with tempfile.NamedTemporaryFile(prefix=f"awgui_{name}_", suffix=".png", delete=False) as tmp:
        tmp_path = Path(tmp.name)
    try:
        try:
            proc = subprocess.run(["qrencode", "-o", str(tmp_path), "-m", "2"], input=source, text=True, capture_output=True, timeout=30)
        except FileNotFoundError:
            send_message(chat_id, "qrencode is not installed. Run: sudo apt install -y qrencode")
            send_plain(chat_id, source)
            return
        if proc.returncode != 0:
            send_message(chat_id, "QR generation failed; sending raw payload instead")
            send_plain(chat_id, source)
            return
        send_photo(chat_id, tmp_path, caption=f"QR {source_name}: {name}")
    finally:
        try:
            tmp_path.unlink()
        except Exception:
            pass


def handle_command(chat_id, text):
    parts = shlex.split(text)
    cmd = parts[0].split("@", 1)[0].lower() if parts else ""
    args = parts[1:]

    if cmd == "/id":
        send_message(chat_id, f"Твой chat_id: <code>{chat_id}</code>")
        return

    if cmd in ("/start", "/help"):
        if config.TG_ADMIN_IDS and is_admin(chat_id):
            send_message(chat_id, help_text(), main_keyboard())
        else:
            send_message(chat_id, help_text())
        return

    if cmd == "/menu":
        if require_admin(chat_id):
            send_message(chat_id, "<b>AWGUI V7</b>\nВыбери действие:", main_keyboard())
        return

    if not require_admin(chat_id):
        return

    if cmd in ("/doctor", "/diagnostics"):
        d = awg.doctor()
        lines = [f"AWGUI doctor: {d.get('version')}"]
        for c in d.get("checks", []):
            mark = "OK" if c.get("ok") else c.get("level", "CHECK").upper()
            lines.append(f"{mark}: {c.get('label')} — {c.get('detail')}")
        send_plain(chat_id, "\n".join(lines))
        return

    if cmd == "/status":
        status = awg.status()
        clients = clients_list()
        online = sum(1 for c in clients if parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS) == "ONLINE")
        send_message(chat_id, f"<b>AWGUI status</b>\nClients: <b>{len(clients)}</b>\nOnline: <b>{online}</b>\n\n<pre>{esc(clip(status.get('text')))}</pre>")
        return

    if cmd == "/clients":
        items = clients_list()
        if not items:
            send_message(chat_id, "No clients")
            return
        lines = []
        for c in items[:80]:
            n = parse.name(c)
            st = parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS)
            lines.append(f"{n} · {st} · {parse.traffic(c)}")
        send_plain(chat_id, "\n".join(lines))
        return

    if cmd == "/client":
        if not args:
            send_message(chat_id, "Usage: /client NAME")
            return
        name = args[0]
        send_message(chat_id, format_client(find_client(name)), keyboard_for_client(name))
        return

    if cmd == "/add":
        if len(args) < 1:
            send_message(chat_id, "Usage: /add NAME [7d] [psk]")
            return
        name = args[0]
        expires = None
        psk = False
        for x in args[1:]:
            if x.lower() == "psk":
                psk = True
            else:
                expires = x
        result = awg.add_client(name, expires=expires, psk=psk)
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("ok"):
            send_client_qr(chat_id, name)
        return

    if cmd == "/remove":
        if not config.TG_ALLOW_DANGEROUS:
            send_message(chat_id, "Dangerous commands are disabled: AWGUI_TG_ALLOW_DANGEROUS=0")
            return
        if not args:
            send_message(chat_id, "Usage: /remove NAME")
            return
        result = awg.remove_client(args[0])
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    if cmd == "/regen":
        if not args:
            send_message(chat_id, "Usage: /regen NAME")
            return
        result = awg.regen_client(args[0])
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("ok"):
            send_client_qr(chat_id, args[0])
        return

    if cmd == "/conf":
        if not args:
            send_message(chat_id, "Usage: /conf NAME")
            return
        send_client_conf(chat_id, args[0])
        return

    if cmd == "/vpnuri":
        if not args:
            send_message(chat_id, "Usage: /vpnuri NAME")
            return
        send_client_vpnuri(chat_id, args[0])
        return

    if cmd == "/qr":
        if not args:
            send_message(chat_id, "Usage: /qr NAME")
            return
        send_client_qr(chat_id, args[0])
        return

    if cmd == "/backup":
        result = awg.backup()
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        path = latest_backup_path()
        if config.TG_SEND_BACKUP and path:
            send_doc(chat_id, path, caption=f"AWGUI backup: {path.name}")
        return

    if cmd == "/backups":
        backups = awg.list_backups()
        if not backups:
            send_message(chat_id, "No backups")
            return
        lines = [f"{b['name']} · {b['size_h']} · {b['mtime_h']}" for b in backups[:30]]
        send_plain(chat_id, "\n".join(lines))
        return

    if cmd in ("/show", "/stats", "/check"):
        result = getattr(awg, "stats")() if cmd == "/stats" else (awg.show() if cmd == "/show" else awg.check())
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    if cmd == "/diagnose":
        result = awg.diagnose(args[0] if args else None)
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    if cmd == "/restart":
        if not config.TG_ALLOW_DANGEROUS:
            send_message(chat_id, "Dangerous commands are disabled: AWGUI_TG_ALLOW_DANGEROUS=0")
            return
        result = awg.restart()
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    if cmd in ("/repair", "/repair_module"):
        if not config.TG_ALLOW_DANGEROUS:
            send_message(chat_id, "Dangerous commands are disabled: AWGUI_TG_ALLOW_DANGEROUS=0")
            return
        result = awg.repair_module()
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    send_message(chat_id, "Unknown command. Use /help")


def handle_callback(query):
    chat_id = query.get("message", {}).get("chat", {}).get("id")
    data = query.get("data") or ""
    cq_id = query.get("id")
    try:
        api("answerCallbackQuery", {"callback_query_id": cq_id})
    except Exception:
        pass
    if not chat_id or not require_admin(chat_id):
        return

    if data == "menu:main":
        send_message(chat_id, "<b>AWGUI V7</b>\nГлавное меню", main_keyboard())
        return
    if data == "menu:help":
        send_message(chat_id, help_text(), main_keyboard())
        return
    if data == "menu:server":
        send_message(chat_id, "<b>Server actions</b>", server_keyboard())
        return
    if data.startswith("menu:clients:"):
        page = data.rsplit(":", 1)[-1]
        items = clients_list()
        online = sum(1 for c in items if parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS) == "ONLINE")
        send_message(chat_id, f"<b>Clients</b>\nTotal: <b>{len(items)}</b>\nOnline: <b>{online}</b>", clients_keyboard(page))
        return
    if data == "menu:status":
        status = awg.status()
        items = clients_list()
        online = sum(1 for c in items if parse.online_state(c, config.TG_ONLINE_WINDOW_SECONDS) == "ONLINE")
        send_message(chat_id, f"<b>AWGUI status</b>\nVersion: <b>{esc(config.APP_VERSION)}</b>\nClients: <b>{len(items)}</b>\nOnline: <b>{online}</b>\n\n<pre>{esc(clip(status.get('text')))}</pre>", main_keyboard())
        return
    if data == "menu:backup":
        result = awg.backup()
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        path = latest_backup_path()
        if config.TG_SEND_BACKUP and path:
            send_doc(chat_id, path, caption=f"AWGUI backup: {path.name}")
        send_message(chat_id, "Backup action completed.", main_keyboard())
        return
    if data == "menu:backups":
        backups = awg.list_backups()
        if not backups:
            send_message(chat_id, "No backups", server_keyboard())
            return
        lines = [f"{b['name']} · {b['size_h']} · {b['mtime_h']}" for b in backups[:30]]
        send_plain(chat_id, "\n".join(lines))
        return
    if data in ("menu:doctor", "menu:diagnose"):
        if data == "menu:diagnose":
            result = awg.diagnose(None)
            send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
            return
        d = awg.doctor()
        lines = [f"AWGUI doctor: {d.get('version')}"]
        for c in d.get("checks", []):
            mark = "OK" if c.get("ok") else c.get("level", "CHECK").upper()
            lines.append(f"{mark}: {c.get('label')} — {c.get('detail')}")
        send_plain(chat_id, "\n".join(lines))
        return
    if data in ("menu:show", "menu:stats", "menu:check"):
        result = awg.stats() if data == "menu:stats" else (awg.show() if data == "menu:show" else awg.check())
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        return

    if data.startswith("client_i:"):
        client, name = client_by_index(data.split(":", 1)[1])
        if not client:
            send_message(chat_id, "client not found", clients_keyboard(0))
            return
        send_message(chat_id, format_client(client), keyboard_for_client_index(data.split(":", 1)[1]))
        return

    for prefix, sender in (("qri:", send_client_qr), ("confi:", send_client_conf), ("vpnurii:", send_client_vpnuri)):
        if data.startswith(prefix):
            _, name = client_by_index(data.split(":", 1)[1])
            if name:
                sender(chat_id, name)
            else:
                send_message(chat_id, "client not found")
            return
    if data.startswith("regeni:"):
        _, name = client_by_index(data.split(":", 1)[1])
        if not name:
            send_message(chat_id, "client not found")
            return
        result = awg.regen_client(name)
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("ok"):
            send_client_qr(chat_id, name)
        return

    # Backward-compatible callbacks from command keyboards.
    if ":" not in data:
        return
    action, name = data.split(":", 1)
    if action in ("qr", "q"):
        send_client_qr(chat_id, name)
    elif action in ("conf", "c"):
        send_client_conf(chat_id, name)
    elif action in ("vpnuri", "u"):
        send_client_vpnuri(chat_id, name)
    elif action in ("regen", "r"):
        result = awg.regen_client(name)
        send_plain(chat_id, result.get("text") or json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("ok"):
            send_client_qr(chat_id, name)


def help_text():
    return """
<b>AWGUI Telegram Bot</b>
Настройка: AWGUI → Telegram Bot → token/chat_id → Save.

<b>Safe/info</b>
/id — показать chat_id
/menu — кнопочное меню V7
/status — статус сервера
/clients — список клиентов
/client NAME — карточка клиента
/show — awg show
/stats — stats
/check — check
/doctor — AWGUI doctor
/diagnose [carrier] — diagnose
/backups — список backup-файлов

<b>Client actions</b>
/add NAME [7d] [psk] — добавить клиента
/regen NAME — перегенерировать
/conf NAME — прислать .conf
/vpnuri NAME — прислать vpnuri
/qr NAME — прислать QR для Amnezia
/remove NAME — удалить клиента

<b>Server actions</b>
/backup — создать backup и прислать файл
/restart — restart AmneziaWG
/repair — repair-module
""".strip()


def handle_update(update):
    if "callback_query" in update:
        handle_callback(update["callback_query"])
        return
    msg = update.get("message") or update.get("edited_message") or {}
    chat_id = msg.get("chat", {}).get("id")
    text = msg.get("text") or ""
    if not chat_id or not text.startswith("/"):
        return
    try:
        handle_command(chat_id, text)
    except Exception as exc:
        err = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
        log(err)
        try:
            send_message(chat_id, f"<b>Error</b>\n<pre>{esc(clip(err))}</pre>")
        except Exception:
            pass


def run_loop():
    if not enabled():
        log("disabled: set token on the AWGUI /bot page or in AWGUI_TG_BOT_TOKEN")
        return 0
    try:
        me = api("getMe", timeout=15).get("result", {})
        username = me.get("username") or me.get("first_name") or "bot"
        log(f"authorized as @{username}" if me.get("username") else f"authorized as {username}")
    except Exception as exc:
        log(f"token check failed: {type(exc).__name__}: {exc}")
    try:
        api("deleteWebhook", {"drop_pending_updates": False}, timeout=15)
    except Exception as exc:
        log(f"deleteWebhook warning: {type(exc).__name__}: {exc}")
    log("starting long polling")
    offset = None
    while True:
        try:
            payload = {"timeout": config.TG_POLL_TIMEOUT, "allowed_updates": ["message", "edited_message", "callback_query"]}
            if offset is not None:
                payload["offset"] = offset
            result = api("getUpdates", payload, timeout=config.TG_POLL_TIMEOUT + 10)
            for update in result.get("result", []):
                offset = update["update_id"] + 1
                handle_update(update)
        except KeyboardInterrupt:
            log("stopped")
            return 0
        except Exception as exc:
            log(f"poll error: {type(exc).__name__}: {exc}")
            time.sleep(5)


if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Run as root: sudo ./run_bot.sh")
        sys.exit(1)
    sys.exit(run_loop())
