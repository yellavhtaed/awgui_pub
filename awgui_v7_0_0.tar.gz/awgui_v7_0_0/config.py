from pathlib import Path
import os
import re

APP_NAME = "AWGUI"
APP_VERSION = "7.0.0"

ENV_FILE = Path(os.getenv("AWGUI_ENV_FILE", "/etc/awgui.env"))

MANAGE = Path(os.getenv("AWGUI_MANAGE", "/root/awg/manage_amneziawg.sh"))
AWG_DIR = Path(os.getenv("AWGUI_AWG_DIR", "/root/awg"))

HOST = os.getenv("AWGUI_HOST", "127.0.0.1")
PORT = int(os.getenv("AWGUI_PORT", "8080"))

USER = os.getenv("AWGUI_USER", "admin")
PASSWORD = os.getenv("AWGUI_PASSWORD", "devpass")
SECRET = os.getenv("AWGUI_SECRET", "change-this-local-secret")

LOG_FILE = Path(os.getenv("AWGUI_LOG", str(AWG_DIR / "awgui.log")))
LAST_FILE = Path(os.getenv("AWGUI_LAST", str(AWG_DIR / "awgui-last.json")))

DEFAULT_TIMEOUT = int(os.getenv("AWGUI_TIMEOUT", "240"))
ONLINE_WINDOW_SECONDS = int(os.getenv("AWGUI_ONLINE_WINDOW", "180"))

CARRIERS = [
    "beeline_msk",
    "yota_msk",
    "tele2_msk",
    "tele2_krasnoyarsk",
    "tattelecom",
    "megafon_regions",
    "tmobile_us",
]

# Telegram bot
TG_BOT_TOKEN = os.getenv("AWGUI_TG_BOT_TOKEN", "").strip()
TG_ADMIN_IDS = []
TG_POLL_TIMEOUT = int(os.getenv("AWGUI_TG_POLL_TIMEOUT", "25"))
TG_ONLINE_WINDOW_SECONDS = int(os.getenv("AWGUI_TG_ONLINE_WINDOW", str(ONLINE_WINDOW_SECONDS)))
TG_SEND_BACKUP = False
TG_ALLOW_DANGEROUS = False

TG_KEYS = {
    "AWGUI_TG_BOT_TOKEN",
    "AWGUI_TG_ADMIN_IDS",
    "AWGUI_TG_SEND_BACKUP",
    "AWGUI_TG_ALLOW_DANGEROUS",
}

ENV_ORDER = [
    "AWGUI_USER",
    "AWGUI_PASSWORD",
    "AWGUI_SECRET",
    "AWGUI_HOST",
    "AWGUI_PORT",
    "AWGUI_MANAGE",
    "AWGUI_AWG_DIR",
    "AWGUI_LOG",
    "AWGUI_LAST",
    "AWGUI_TIMEOUT",
    "AWGUI_ONLINE_WINDOW",
    "AWGUI_TG_BOT_TOKEN",
    "AWGUI_TG_ADMIN_IDS",
    "AWGUI_TG_SEND_BACKUP",
    "AWGUI_TG_ALLOW_DANGEROUS",
    "AWGUI_TG_POLL_TIMEOUT",
    "AWGUI_TG_ONLINE_WINDOW",
]


def bool_from_env(value, default=False):
    if value is None:
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on", "y")


def parse_admin_ids(value):
    return [x.strip() for x in str(value or "").replace(";", ",").split(",") if x.strip()]


def validate_admin_ids(value):
    ids = parse_admin_ids(value)
    bad = [x for x in ids if not re.match(r"^-?\d{3,32}$", x)]
    if bad:
        raise ValueError("bad Telegram admin id(s): " + ", ".join(bad))
    return ids


def validate_bot_token(value, *, required=False):
    token = str(value or "").strip()
    if not token:
        if required:
            raise ValueError("Telegram token required when bot is enabled")
        return ""
    # BotFather tokens are normally digits:secret. Keep validation permissive enough for future format changes.
    if not re.match(r"^\d{5,20}:[A-Za-z0-9_-]{20,120}$", token):
        raise ValueError("bad Telegram token format")
    return token


def read_env_file(path=None):
    path = Path(path or ENV_FILE)
    data = {}
    if not path.exists():
        return data
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        data[key] = value
    return data


def merged_env():
    data = read_env_file()
    defaults = {
        "AWGUI_USER": USER,
        "AWGUI_PASSWORD": PASSWORD,
        "AWGUI_SECRET": SECRET,
        "AWGUI_HOST": HOST,
        "AWGUI_PORT": str(PORT),
        "AWGUI_MANAGE": str(MANAGE),
        "AWGUI_AWG_DIR": str(AWG_DIR),
        "AWGUI_TG_BOT_TOKEN": os.getenv("AWGUI_TG_BOT_TOKEN", TG_BOT_TOKEN),
        "AWGUI_TG_ADMIN_IDS": os.getenv("AWGUI_TG_ADMIN_IDS", ",".join(TG_ADMIN_IDS)),
        "AWGUI_TG_SEND_BACKUP": os.getenv("AWGUI_TG_SEND_BACKUP", "1"),
        "AWGUI_TG_ALLOW_DANGEROUS": os.getenv("AWGUI_TG_ALLOW_DANGEROUS", "0"),
    }
    for key, value in defaults.items():
        data.setdefault(key, str(value))
    return data


def quote_env_value(value):
    value = str(value or "")
    # systemd EnvironmentFile accepts plain KEY=value. Values used here are intentionally restricted.
    if re.match(r"^[A-Za-z0-9_./:@,+=-]*$", value):
        return value
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def write_env_values(updates, path=None):
    path = Path(path or ENV_FILE)
    data = merged_env()
    data.update({k: str(v) for k, v in updates.items()})
    lines = []
    written = set()
    for key in ENV_ORDER:
        if key in data and data[key] != "":
            lines.append(f"{key}={quote_env_value(data[key])}")
            written.add(key)
        elif key in TG_KEYS:
            lines.append(f"{key}=")
            written.add(key)
    for key in sorted(k for k in data.keys() if k not in written):
        if data[key] != "":
            lines.append(f"{key}={quote_env_value(data[key])}")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
    tmp.chmod(0o600)
    tmp.replace(path)
    try:
        path.chmod(0o600)
    except Exception:
        pass
    return data


def apply_telegram_runtime(token_value, admin_ids_value, send_backup_value, allow_dangerous_value):
    global TG_BOT_TOKEN, TG_ADMIN_IDS, TG_SEND_BACKUP, TG_ALLOW_DANGEROUS
    TG_BOT_TOKEN = str(token_value or "").strip()
    TG_ADMIN_IDS = validate_admin_ids(admin_ids_value)
    TG_SEND_BACKUP = bool_from_env(send_backup_value)
    TG_ALLOW_DANGEROUS = bool_from_env(allow_dangerous_value)
    os.environ["AWGUI_TG_BOT_TOKEN"] = TG_BOT_TOKEN
    os.environ["AWGUI_TG_ADMIN_IDS"] = ",".join(TG_ADMIN_IDS)
    os.environ["AWGUI_TG_SEND_BACKUP"] = "1" if TG_SEND_BACKUP else "0"
    os.environ["AWGUI_TG_ALLOW_DANGEROUS"] = "1" if TG_ALLOW_DANGEROUS else "0"


def load_telegram_settings():
    data = merged_env()
    token_value = data.get("AWGUI_TG_BOT_TOKEN", "").strip()
    admin_ids = validate_admin_ids(data.get("AWGUI_TG_ADMIN_IDS", ""))
    send_backup = bool_from_env(data.get("AWGUI_TG_SEND_BACKUP", "1"), True)
    allow_dangerous = bool_from_env(data.get("AWGUI_TG_ALLOW_DANGEROUS", "0"), False)
    apply_telegram_runtime(token_value, ",".join(admin_ids), send_backup, allow_dangerous)
    return {
        "token_set": bool(token_value),
        "token_masked": mask_token(token_value),
        "admin_ids": admin_ids,
        "send_backup": send_backup,
        "allow_dangerous": allow_dangerous,
        "env_file": str(ENV_FILE),
    }


def save_telegram_settings(*, enabled, token_value, admin_ids_value, send_backup, allow_dangerous):
    enabled = bool_from_env(enabled)
    existing = merged_env().get("AWGUI_TG_BOT_TOKEN", "").strip()
    token_value = str(token_value or "").strip()
    if token_value in ("", "********", "keep", "KEEP") and existing:
        token_value = existing
    token_value = validate_bot_token(token_value, required=enabled)
    admin_ids = validate_admin_ids(admin_ids_value)
    updates = {
        "AWGUI_TG_BOT_TOKEN": token_value if enabled else "",
        "AWGUI_TG_ADMIN_IDS": ",".join(admin_ids),
        "AWGUI_TG_SEND_BACKUP": "1" if bool_from_env(send_backup) else "0",
        "AWGUI_TG_ALLOW_DANGEROUS": "1" if bool_from_env(allow_dangerous) else "0",
    }
    data = write_env_values(updates)
    apply_telegram_runtime(
        data.get("AWGUI_TG_BOT_TOKEN", ""),
        data.get("AWGUI_TG_ADMIN_IDS", ""),
        data.get("AWGUI_TG_SEND_BACKUP", "1"),
        data.get("AWGUI_TG_ALLOW_DANGEROUS", "0"),
    )
    return load_telegram_settings()


def mask_token(token_value):
    token_value = str(token_value or "")
    if not token_value:
        return ""
    if ":" not in token_value:
        return token_value[:4] + "…"
    bot_id, secret = token_value.split(":", 1)
    tail = secret[-4:] if len(secret) >= 4 else secret
    return f"{bot_id}:…{tail}"


# initialize runtime telegram values from environment/file if present
try:
    load_telegram_settings()
except Exception:
    # Never fail app import because of a malformed optional bot config.
    TG_ADMIN_IDS = parse_admin_ids(os.getenv("AWGUI_TG_ADMIN_IDS", ""))
    TG_SEND_BACKUP = bool_from_env(os.getenv("AWGUI_TG_SEND_BACKUP", "1"), True)
    TG_ALLOW_DANGEROUS = bool_from_env(os.getenv("AWGUI_TG_ALLOW_DANGEROUS", "0"), False)
