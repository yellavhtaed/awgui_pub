#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo ./setup_telegram.sh"
  exit 1
fi

ENV_FILE="${AWGUI_ENV_FILE:-/etc/awgui.env}"
touch "$ENV_FILE"
chmod 600 "$ENV_FILE"

echo "Fallback Telegram setup. Normal path: open AWGUI /bot page and save token/chat_id there."
echo
read -rp "Telegram bot token from @BotFather: " BOT_TOKEN
read -rp "Telegram admin chat_id(s), comma-separated: " ADMIN_IDS
read -rp "Enable bot now? [Y/n]: " ENABLED
read -rp "Send backup file after /backup? [Y/n]: " SEND_BACKUP
read -rp "Allow dangerous commands /remove /restart /repair? [y/N]: " DANGER

is_true() {
  case "${1,,}" in y|yes|1|true|on|"") return 0 ;; *) return 1 ;; esac
}
is_danger_true() {
  case "${1,,}" in y|yes|1|true|on) return 0 ;; *) return 1 ;; esac
}

ENABLED_VAL=1; is_true "$ENABLED" || ENABLED_VAL=0
SEND_BACKUP_VAL=1; is_true "$SEND_BACKUP" || SEND_BACKUP_VAL=0
ALLOW=0; is_danger_true "$DANGER" && ALLOW=1

python3 - "$ENV_FILE" "$BOT_TOKEN" "$ADMIN_IDS" "$ENABLED_VAL" "$SEND_BACKUP_VAL" "$ALLOW" <<'PY'
import sys
from pathlib import Path

env_file, token, admin_ids, enabled, send_backup, allow = sys.argv[1:]
path = Path(env_file)
vals = {}
for line in path.read_text(encoding='utf-8', errors='replace').splitlines():
    if '=' in line and not line.lstrip().startswith('#'):
        k, v = line.split('=', 1)
        vals[k.strip()] = v.strip().strip('"').strip("'")
vals.setdefault('AWGUI_USER', 'admin')
vals.setdefault('AWGUI_PASSWORD', 'devpass')
vals.setdefault('AWGUI_SECRET', 'change-me')
vals.setdefault('AWGUI_HOST', '127.0.0.1')
vals.setdefault('AWGUI_PORT', '8080')
vals.setdefault('AWGUI_MANAGE', '/root/awg/manage_amneziawg.sh')
vals.setdefault('AWGUI_AWG_DIR', '/root/awg')
vals['AWGUI_TG_BOT_TOKEN'] = token if enabled == '1' else ''
vals['AWGUI_TG_ADMIN_IDS'] = admin_ids
vals['AWGUI_TG_SEND_BACKUP'] = '1' if send_backup == '1' else '0'
vals['AWGUI_TG_ALLOW_DANGEROUS'] = '1' if allow == '1' else '0'
order = ['AWGUI_USER','AWGUI_PASSWORD','AWGUI_SECRET','AWGUI_HOST','AWGUI_PORT','AWGUI_MANAGE','AWGUI_AWG_DIR','AWGUI_TG_BOT_TOKEN','AWGUI_TG_ADMIN_IDS','AWGUI_TG_SEND_BACKUP','AWGUI_TG_ALLOW_DANGEROUS']
lines = [f'{k}={vals.get(k, "")}' for k in order]
path.write_text('\n'.join(lines) + '\n', encoding='utf-8')
path.chmod(0o600)
PY

systemctl daemon-reload || true
if [[ "$ENABLED_VAL" == "1" ]]; then
  systemctl enable awgui-bot >/dev/null 2>&1 || true
  systemctl restart awgui-bot 2>/dev/null || true
else
  systemctl stop awgui-bot 2>/dev/null || true
fi

echo
echo "OK. Test bot: send /status or /clients"
echo "Logs: sudo journalctl -u awgui-bot -f"
