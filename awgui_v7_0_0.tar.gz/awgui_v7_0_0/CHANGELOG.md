# Changelog

## v7.0.0

Новая базовая ветка AWGUI.

### Added

- Telegram inline keyboard menu via `/menu`.
- Button flows for status, clients, client card, QR, config, vpnuri, backup, diagnostics and server actions.
- `/diagnostics` page with doctor checks.
- `/api/doctor` and `/api/summary`.
- `/backups` page with backup create/list/download/preview/restore.
- `/clients/<name>/bundle.zip` endpoint.
- Client card button for bundle zip.
- V7 dashboard hero block.
- Release gate checks for v7.

### Changed

- Telegram bot page now describes v7 UI-first flow and button menu.
- `upgrade.sh` runs release gate before writing/running systemd units.
- `install.sh` delegates to `upgrade.sh`.

### Fixed

- Prevents stale v5/v6 Telegram setup text from passing release verification.
- Keeps `/health` and `/api/version` as explicit runtime version checks.
