#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if [[ -f /etc/awgui.env ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/awgui.env
  set +a
fi

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/run.sh"
  exit 1
fi

MANAGE_SCRIPT="${AWGUI_MANAGE:-/root/awg/manage_amneziawg.sh}"
if [[ ! -f "$MANAGE_SCRIPT" ]]; then
  echo "ERROR: $MANAGE_SCRIPT not found"
  exit 1
fi

if [[ ! -x "$(command -v python3)" ]]; then
  echo "ERROR: python3 not found"
  exit 1
fi

if [[ ! -d .venv || ! -x .venv/bin/python || ! -x .venv/bin/pip ]]; then
  rm -rf .venv
  python3 -m venv .venv
fi

.venv/bin/python -m ensurepip --upgrade >/dev/null 2>&1 || true
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt

if ! command -v qrencode >/dev/null 2>&1; then
  if command -v apt >/dev/null 2>&1; then
    echo "INFO: qrencode not found; installing it"
    apt update
    apt install -y qrencode
  else
    echo "WARN: qrencode not found. QR will show a readable error SVG."
  fi
fi

export AWGUI_USER="${AWGUI_USER:-admin}"
export AWGUI_PASSWORD="${AWGUI_PASSWORD:-devpass}"
export AWGUI_SECRET="${AWGUI_SECRET:-local-dev-secret-change-me}"

exec .venv/bin/python app.py
