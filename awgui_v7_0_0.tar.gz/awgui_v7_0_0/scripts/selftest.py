#!/usr/bin/env python3
import os
import stat
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

with tempfile.TemporaryDirectory(prefix="awgui-selftest-") as td:
    td = Path(td)
    awg_dir = td / "awg"
    awg_dir.mkdir()
    (awg_dir / "alice.conf").write_text("[Interface]\nPrivateKey = test\n", encoding="utf-8")
    (awg_dir / "alice.vpnuri").write_text("awg://alice-test", encoding="utf-8")
    (awg_dir / "backups").mkdir()
    (awg_dir / "backups" / "awg_backup_test.tar.gz").write_bytes(b"test")

    manage = td / "manage_amneziawg.sh"
    manage.write_text(r'''#!/usr/bin/env bash
json=0
args=()
for a in "$@"; do
  case "$a" in --json) json=1;; --no-color|--yes) ;; *) args+=("$a");; esac
done
cmd=""
for a in "${args[@]}"; do
  case "$a" in list|stats|status|show|check|backup|restart|diagnose|repair-module|add|remove|regen|modify|restore) cmd="$a";; esac
done
case "$cmd" in
  list)
    if [[ "$json" == "1" ]]; then
      echo '[{"name":"alice","client_ip":"10.8.0.2","client_ipv6":"fd00::2","latest_handshake":1700000000,"transfer":"1 MiB / 2 MiB"}]'
    else
      echo alice
    fi
    ;;
  stats)
    if [[ "$json" == "1" ]]; then echo '{"total_rx":"1 MiB","total_tx":"2 MiB"}'; else echo stats; fi
    ;;
  status) echo 'active running ok' ;;
  show) echo 'interface: awg0' ;;
  check) echo 'check ok' ;;
  backup) echo 'backup ok' ;;
  add|remove|regen|modify|restore|restart|diagnose|repair-module) echo "$cmd ok" ;;
  *) echo "unknown command" ;;
esac
''', encoding="utf-8")
    manage.chmod(manage.stat().st_mode | stat.S_IEXEC)

    os.environ["AWGUI_MANAGE"] = str(manage)
    os.environ["AWGUI_AWG_DIR"] = str(awg_dir)
    os.environ["AWGUI_USER"] = "admin"
    os.environ["AWGUI_PASSWORD"] = "devpass"
    os.environ["AWGUI_SECRET"] = "selftest-secret"
    os.environ["AWGUI_ENV_FILE"] = str(td / "awgui.env")

    import app as awgui_app
    awgui_app.telegram_get_me = lambda token_value: {"ok": True, "bot": {"id": 123, "username": "awgui_selftest_bot"}}
    awgui_app.control_bot_service = lambda enabled: {"mock": {"enabled": bool(enabled)}}
    awgui_app.bot_service_status = lambda: {"active": "mock-active", "enabled": "mock-enabled", "active_ok": True, "enabled_ok": True}
    app = awgui_app.app

    client = app.test_client()

    for path in ("/", "/clients", "/tools", "/backups", "/diagnostics", "/logs", "/bot"):
        r = client.get(path)
        assert r.status_code in (302, 401), (path, r.status_code)

    r = client.post("/login", data={"username": "admin", "password": "devpass"})
    assert r.status_code in (302, 303), r.status_code

    ok_pages = [
        "/", "/clients", "/clients/alice", "/tools", "/backups", "/diagnostics", "/logs", "/bot",
        "/api/self-check", "/api/clients", "/api/status", "/api/stats",
        "/api/show", "/api/last", "/api/logs", "/api/bot", "/api/doctor", "/api/summary", "/api/version", "/health",
        "/clients/alice/conf", "/clients/alice/vpnuri", "/clients/alice/inventory", "/clients/alice/bundle.zip",
    ]
    for path in ok_pages:
        r = client.get(path)
        assert r.status_code == 200, (path, r.status_code, r.data[:200])

    bot_page = client.get("/bot").data.decode("utf-8", errors="replace")
    assert "Save &amp; apply" in bot_page, bot_page[:500]
    assert 'action="/bot/save"' in bot_page, bot_page[:500]
    assert "На сервере запусти" not in bot_page
    assert "setup_telegram.sh" not in bot_page
    assert "v7.0.0" in client.get("/").data.decode("utf-8", errors="replace")
    assert client.get("/health").json["version"] == "7.0.0"

    qr = client.get("/clients/alice/qr")
    assert qr.status_code in (200, 500, 503), ("qr", qr.status_code, qr.data[:200])

    posts = [
        ("/bot/save", {"enabled": "1", "token": "123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ_ab", "admin_ids": "123456789", "send_backup": "1"}),
        ("/bot/restart", {}),
        ("/bot/test-token", {}),
        ("/clients/add", {"name": "bob", "expires": "7d"}),
        ("/clients/regen", {"name": "alice"}),
        ("/clients/remove", {"name": "alice"}),
        ("/clients/modify", {"name": "alice", "param": "mtu", "value": "1280"}),
        ("/tools/run", {"action": "check"}),
        ("/tools/run", {"action": "diagnose", "carrier": "beeline_msk"}),
        ("/tools/run", {"action": "backup"}),
    ]
    for url, data in posts:
        r = client.post(url, data=data)
        assert r.status_code in (302, 303), (url, r.status_code, r.data[:200])

print("AWGUI selftest OK")
