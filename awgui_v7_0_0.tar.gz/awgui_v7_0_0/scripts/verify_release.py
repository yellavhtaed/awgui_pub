#!/usr/bin/env python3
"""Release gate for AWGUI package. Fails if stale Telegram UI leaks back in."""
import os
import stat
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

EXPECTED_VERSION = "7.0.0"
FORBIDDEN = [
    "На сервере запусти",
    "cd ~/awgui && sudo ./setup_telegram.sh",
    "Service commands",
]
REQUIRED = [
    "Save &amp; apply",
    "Bot settings",
    "Admin chat_id",
    "Включить Telegram-бота",
    "action=\"/bot/save\"",
]

with tempfile.TemporaryDirectory(prefix="awgui-release-gate-") as td:
    td = Path(td)
    awg_dir = td / "awg"
    awg_dir.mkdir()
    (awg_dir / "alice.conf").write_text("[Interface]\nPrivateKey = test\n", encoding="utf-8")
    (awg_dir / "alice.vpnuri").write_text("awg://alice-test", encoding="utf-8")
    manage = td / "manage_amneziawg.sh"
    manage.write_text("#!/usr/bin/env bash\ncase \"$*\" in *list*) echo '[{\"name\":\"alice\"}]';; *stats*) echo '{}';; *) echo ok;; esac\n", encoding="utf-8")
    manage.chmod(manage.stat().st_mode | stat.S_IEXEC)

    os.environ.update({
        "AWGUI_MANAGE": str(manage),
        "AWGUI_AWG_DIR": str(awg_dir),
        "AWGUI_USER": "admin",
        "AWGUI_PASSWORD": "devpass",
        "AWGUI_SECRET": "verify-release-secret",
        "AWGUI_ENV_FILE": str(td / "awgui.env"),
    })

    import app as awgui_app
    awgui_app.bot_service_status = lambda: {"active": "mock-active", "enabled": "mock-enabled", "active_ok": True, "enabled_ok": True}
    app = awgui_app.app
    client = app.test_client()
    login = client.post("/login", data={"username": "admin", "password": "devpass"})
    assert login.status_code in (302, 303), login.status_code

    html = client.get("/bot").data.decode("utf-8", errors="replace")
    index = client.get("/").data.decode("utf-8", errors="replace")
    health = client.get("/health").json
    api_version = client.get("/api/version").json
    doctor = client.get("/api/doctor").json
    backups_html = client.get("/backups").data.decode("utf-8", errors="replace")
    diagnostics_html = client.get("/diagnostics").data.decode("utf-8", errors="replace")

    assert doctor["version"] == EXPECTED_VERSION, doctor
    assert "Backups" in backups_html
    assert "Diagnostics" in diagnostics_html

    assert health["version"] == EXPECTED_VERSION, health
    assert api_version["version"] == EXPECTED_VERSION, api_version
    assert f"v{EXPECTED_VERSION}" in index, index[:500]
    for text in REQUIRED:
        assert text in html, f"missing {text!r}"
    for text in FORBIDDEN:
        assert text not in html, f"forbidden stale text leaked: {text!r}"

print("AWGUI release gate OK: 7.0.0 UI is new")
