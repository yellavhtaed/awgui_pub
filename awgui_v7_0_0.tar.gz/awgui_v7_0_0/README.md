# AWGUI v7.0.0

Локальная web-панель для `manage_amneziawg.sh` + Telegram-бот с кнопочным меню.  
V7 — это новая базовая ветка, не косметический hotfix v6.

## Что нового в v7

- **Telegram inline menu**: `/menu` открывает кнопки Status / Clients / Backup / Diagnostics / Server.
- **Telegram больше не требует обязательного `setup_telegram.sh`**: token и chat_id вводятся на странице `/bot`.
- **Diagnostics doctor**: страница `/diagnostics` проверяет версию, systemd, env, manage-скрипт, `qrencode`, Telegram и отсутствие старого CLI-first текста.
- **Backups center**: отдельная страница `/backups` для создания, скачивания, preview и restore backup-файлов.
- **Client bundle zip**: на карточке клиента доступен zip с `.conf`, `.vpnuri`, `.png` и README-инвентарём.
- **Release gate**: `scripts/verify_release.py` падает, если в `/bot` снова возвращается старый текст `На сервере запусти...`.
- **Upgrade guard**: `upgrade.sh` после установки проверяет, что `/health` реально отдаёт `7.0.0`.

## Установка / обновление

Рекомендуемый чистый переход на v7:

```bash
cd ~
sudo systemctl stop awgui awgui-bot 2>/dev/null || true
rm -rf ~/awgui
mkdir -p ~/awgui
tar -xzf ~/Downloads/awgui_v7_0_0.tar.gz -C ~/awgui --strip-components=1
cd ~/awgui
sudo ./upgrade.sh
```

Панель:

```text
http://127.0.0.1:8080
```

Логин по умолчанию:

```text
admin
```

Пароль по умолчанию:

```text
devpass
```

После первого запуска лучше сменить `AWGUI_PASSWORD` в `/etc/awgui.env` и перезапустить сервис.

## Проверка, что поднялась именно v7

```bash
curl -s http://127.0.0.1:8080/health
curl -s http://127.0.0.1:8080/api/version
```

Ожидаемо:

```json
{"app":"AWGUI","ok":true,"version":"7.0.0"}
```

Если в UI снова видно `v5.0.0` или старую Telegram-страницу, значит порт `8080` обслуживает старый systemd unit или другая директория:

```bash
sudo systemctl cat awgui
sudo systemctl status awgui --no-pager
sudo journalctl -u awgui -n 100 --no-pager
```

## Telegram Bot

Открыть:

```text
http://127.0.0.1:8080/bot
```

Сценарий:

1. Создать бота в `@BotFather` через `/newbot`.
2. Вставить token на странице `/bot`.
3. Включить чекбокс **Включить Telegram-бота**.
4. Нажать **Save & apply**.
5. Написать боту `/id`.
6. Вставить chat_id на странице `/bot`.
7. Нажать **Save & apply** ещё раз.
8. В Telegram написать `/menu`.

Команды:

```text
/id
/help
/menu
/status
/clients
/client NAME
/add NAME [7d] [psk]
/regen NAME
/conf NAME
/vpnuri NAME
/qr NAME
/remove NAME
/backup
/backups
/doctor
/diagnose [carrier]
/show
/stats
/check
/restart
/repair
```

`/remove`, `/restart`, `/repair` работают только если в UI включён переключатель dangerous commands.

## Основные страницы

- `/` — dashboard.
- `/clients` — клиенты, online-state, QR, config, vpnuri.
- `/clients/NAME` — карточка клиента.
- `/clients/NAME/bundle.zip` — zip-бандл клиента.
- `/tools` — прямые allowlist server actions.
- `/backups` — backup/preview/restore/download.
- `/diagnostics` — doctor/checks.
- `/bot` — Telegram settings.
- `/logs` — журнал действий AWGUI.

## Systemd

```bash
sudo systemctl status awgui --no-pager
sudo systemctl status awgui-bot --no-pager
sudo journalctl -u awgui -f
sudo journalctl -u awgui-bot -f
```

Перезапуск:

```bash
sudo systemctl restart awgui
sudo systemctl restart awgui-bot
```

## Локальная проверка релиза

```bash
cd ~/awgui
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/python scripts/selftest.py
.testvenv/bin/python scripts/verify_release.py
bash -n run.sh run_bot.sh install.sh upgrade.sh setup_telegram.sh
```

Ожидаемо:

```text
AWGUI selftest OK
AWGUI release gate OK: 7.0.0 UI is new
```

## Безопасность

- Web UI слушает `127.0.0.1:8080` по умолчанию.
- Произвольного shell из панели нет: только allowlist операций.
- Telegram token хранится в `/etc/awgui.env`, файл создаётся с правами `600`.
- Token в UI показывается только masked.
- Dangerous Telegram-команды выключены по умолчанию.

## Что осталось на следующие minor-релизы v7.x

- traffic history с SQLite и графиками;
- role-based users вместо одного admin/devpass;
- полноценный config diff/rollback;
- multi-server profiles;
- restore dry-run перед реальным restore;
- firewall/profile editor для AmneziaWG;
- notification rules: клиент online/offline, истечение, превышение трафика.
