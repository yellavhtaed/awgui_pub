#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
VERSION="$(cat "$ROOT/VERSION" 2>/dev/null || python3 - <<'PY'
import config
print(config.APP_VERSION)
PY
)"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: run as root: sudo $ROOT/upgrade.sh"
  exit 1
fi

echo "== AWGUI upgrade: $VERSION =="

if [[ -f /etc/awgui.env ]]; then
  set -a
  # shellcheck disable=SC1091
  source /etc/awgui.env
  set +a
fi

MANAGE_SCRIPT="${AWGUI_MANAGE:-/root/awg/manage_amneziawg.sh}"
if [[ ! -f "$MANAGE_SCRIPT" ]]; then
  echo "ERROR: manage script not found: $MANAGE_SCRIPT"
  echo "Set AWGUI_MANAGE in /etc/awgui.env or export AWGUI_MANAGE=/path/to/manage_amneziawg.sh"
  exit 1
fi

if command -v systemctl >/dev/null 2>&1; then
  systemctl stop awgui.service awgui-bot.service >/dev/null 2>&1 || true
fi

if command -v apt >/dev/null 2>&1; then
  apt update
  apt install -y python3 python3-venv python3-pip qrencode curl
fi

rm -rf "$ROOT/.venv"
python3 -m venv "$ROOT/.venv"
"$ROOT/.venv/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
"$ROOT/.venv/bin/pip" install -q --upgrade pip
"$ROOT/.venv/bin/pip" install -q -r "$ROOT/requirements.txt"
"$ROOT/.venv/bin/python" "$ROOT/scripts/verify_release.py"

if [[ ! -f /etc/awgui.env ]]; then
  cat > /etc/awgui.env <<ENVEOF
AWGUI_USER=admin
AWGUI_PASSWORD=devpass
AWGUI_SECRET=$(openssl rand -hex 24 2>/dev/null || date +%s%N)
AWGUI_HOST=127.0.0.1
AWGUI_PORT=8080
AWGUI_MANAGE=$MANAGE_SCRIPT
AWGUI_AWG_DIR=${AWGUI_AWG_DIR:-/root/awg}
AWGUI_LOG=${AWGUI_LOG:-${AWGUI_AWG_DIR:-/root/awg}/awgui.log}
AWGUI_LAST=${AWGUI_LAST:-${AWGUI_AWG_DIR:-/root/awg}/awgui-last.json}
AWGUI_TG_BOT_TOKEN=
AWGUI_TG_ADMIN_IDS=
AWGUI_TG_SEND_BACKUP=1
AWGUI_TG_ALLOW_DANGEROUS=0
ENVEOF
  chmod 600 /etc/awgui.env
fi

cat > /etc/systemd/system/awgui.service <<SERVICEEOF
[Unit]
Description=AWGUI local AmneziaWG panel
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$ROOT
EnvironmentFile=/etc/awgui.env
ExecStart=$ROOT/.venv/bin/python $ROOT/app.py
Restart=on-failure
RestartSec=2
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
SERVICEEOF

cat > /etc/systemd/system/awgui-bot.service <<SERVICEEOF
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$ROOT
EnvironmentFile=/etc/awgui.env
ExecStart=$ROOT/.venv/bin/python $ROOT/telegram_bot.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=false
PrivateTmp=true

[Install]
WantedBy=multi-user.target
SERVICEEOF

systemctl daemon-reload
systemctl enable --now awgui.service
if grep -q '^AWGUI_TG_BOT_TOKEN=.' /etc/awgui.env; then
  systemctl enable --now awgui-bot.service || true
else
  systemctl disable --now awgui-bot.service >/dev/null 2>&1 || true
fi

ok=0
for i in 1 2 3 4 5; do
  if curl -fsS http://127.0.0.1:8080/health | grep -q "$VERSION"; then
    ok=1
    break
  fi
  sleep 1
done

if [[ "$ok" != "1" ]]; then
  echo "ERROR: AWGUI started, but /health did not report $VERSION"
  echo "Debug:"
  systemctl status awgui --no-pager || true
  journalctl -u awgui -n 80 --no-pager || true
  exit 1
fi

echo "OK: AWGUI is running version $VERSION"
echo "Open: http://127.0.0.1:8080"
echo "Telegram UI: http://127.0.0.1:8080/bot"
echo "Health: $(curl -fsS http://127.0.0.1:8080/health)"
