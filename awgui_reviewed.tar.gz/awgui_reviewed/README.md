# AWGUI Core 1.1.3

AWGUI — компактная Web-панель и Telegram-бот для централизованного управления несколькими серверами AmneziaWG, установленными через `bivlked/amneziawg-installer`.

## Граница ответственности

AWGUI не устанавливает, не обновляет и не удаляет AmneziaWG. На каждом управляемом сервере должен быть установлен рабочий:

```text
/root/awg/manage_amneziawg.sh
```

Все изменения клиентов и обслуживание AWG панель делегирует этому скрипту. AWGUI не генерирует ключи, не распределяет адреса, не редактирует `awg0.conf` и не воспроизводит внутреннюю логику manager-а.

На удалённые серверы AWGUI не устанавливается: один центральный экземпляр работает локально или выполняет команды по SSH-ключу.

## Возможности

### Несколько серверов

- локальный сервер и произвольное количество SSH-серверов;
- отдельные host, port, user, SSH key и пути bivlked для каждого сервера;
- проверка подключения, manager, AWG binary, модуля, `awg0`, systemd, ядра и DKMS;
- независимый выбор активного сервера в Web и Telegram.

### Функции `manage_amneziawg.sh`

```text
add remove list stats regen modify
backup restore check status diagnose show restart repair-module help
```

Web и Telegram используют один и тот же Python-вызов установленного manager-а. Поддерживаются пакетные операции, сроки действия, PSK, `syncconf|restart`, JSON list/stats, клиентские файлы, carrier-диагностика и backup/restore.

### Каскад AWG0 → AWG1

Раздел «Каскад» автоматизирует шаги официального `CASCADE.md`:

1. проверяет manager и разные подсети двух серверов;
2. ставит `curl` и `ipset` на AWG0;
3. создаёт link-client на AWG1 через `manage_amneziawg.sh add`;
4. копирует клиентский конфиг на AWG0 как `awg1.conf`;
5. удаляет только ключ `DNS` и добавляет `Table = off`;
6. отклоняет конфиг без `AllowedIPs = 0.0.0.0/0`, не исправляя его самостоятельно;
7. запускает `awg-quick@awg1`;
8. устанавливает точный upstream `awg-routing.sh`, меняя только `CLIENT_SUBNET` и `AWG1_ENDPOINT`;
9. отдельно запускает точный upstream `awg-routing.sh`;
10. устанавливает точный upstream systemd unit и выполняет только документированные `daemon-reload`/`enable`;
11. показывает handshake и состояние правил, описанных upstream.

Панель не реализует multi-exit, балансировку, автоматический failover или multi-hop: этих сценариев нет в поставленном upstream `CASCADE.md`. Удаление каскада намеренно не автоматизировано, потому что официальный документ не определяет безопасную процедуру владения и отката уже существующих сетевых объектов.

## Подготовка удалённого сервера

AmneziaWG устанавливается отдельно по документации bivlked. Затем на сервере панели настраивается ключ:

```bash
ssh-keygen -t ed25519 -a 100 -f ~/.ssh/awgui_ed25519 -C awgui
ssh-copy-id -i ~/.ssh/awgui_ed25519.pub -p 22 root@SERVER_IP
ssh -i ~/.ssh/awgui_ed25519 -p 22 -o BatchMode=yes root@SERVER_IP \
  'test -x /root/awg/manage_amneziawg.sh && echo OK'
```

Пароли удалённых серверов AWGUI не хранит.

## Установка панели

```bash
tar -xzf awgui_reviewed.tar.gz
cd awgui_reviewed
sudo ./install.sh
```

`install.sh` не принимает параметры. Он:

- проверяет контрольные суммы поставки, Python, venv и доступность systemd;
- сохраняет существующие `/etc/awgui.env`, state и предыдущую версию приложения;
- создаёт venv только в окончательном `/opt/awgui`;
- проверяет systemd units;
- включает и запускает `awgui.service` и `awgui-bot.service`;
- выполняет `/health`, реальный вход и открытие защищённой страницы;
- восстанавливает прежние файлы и состояние служб при любой ошибке.

После успешной установки выводятся фактические логин и пароль. При повторной установке используются и снова выводятся существующие данные из `/etc/awgui.env`.

По умолчанию панель слушает только `127.0.0.1:8080`. Для доступа с рабочего компьютера:

```bash
ssh -L 8080:127.0.0.1:8080 root@PANEL_SERVER
```

Откройте `http://127.0.0.1:8080`.

## Автозапуск

Обе службы имеют `WantedBy=multi-user.target`; установщик выполняет и проверяет `systemctl enable --now`.

```bash
systemctl is-enabled awgui.service awgui-bot.service
systemctl is-active awgui.service awgui-bot.service
```

Ожидается `enabled` и `active` для обеих служб. Физический reboot необходимо подтвердить на целевой машине.

## Удаление панели

```bash
sudo /opt/awgui/uninstall.sh
```

Сохранить `/etc/awgui.env` и `/var/lib/awgui`:

```bash
sudo /opt/awgui/uninstall.sh --keep-data
```

Удаление не вызывает installer, не удаляет `/root/awg` и не меняет AmneziaWG.

## Данные и безопасность

- state хранится в JSON, без SQL;
- межпроцессный `flock` защищает Web и Telegram от потерянных обновлений;
- записи выполняются через временный файл, `fsync` и `replace`;
- изменяющие manager-команды сериализуются по фактическому SSH endpoint;
- удалённая атомарная запись не меняет права уже существующих системных каталогов;
- SSH работает в `BatchMode=yes` по ключам;
- Web защищён сессией и CSRF и по умолчанию доступен только на loopback;
- Telegram token и inventory хранятся в state с правами `0600`.

## Проверка исходников

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/pip check
.testvenv/bin/python tests/verify_release.py
```

Автоматические проверки не заменяют физические испытания DKMS, reboot и сетевого пути между VPS.
