# Release checks 1.1.3

## Автоматические

```bash
python3 -m venv .testvenv
.testvenv/bin/pip install -r requirements.txt
.testvenv/bin/pip check
.testvenv/bin/python tests/verify_release.py
```

## На целевом сервере

```bash
sudo ./install.sh
systemctl is-enabled awgui.service awgui-bot.service
systemctl is-active awgui.service awgui-bot.service
sudo /opt/awgui/.venv/bin/python -m panel.runtime_check /etc/awgui.env
sudo reboot
```

После reboot повторить три последние проверки и проверить Web/Telegram.

## С установленным bivlked

1. зафиксировать состояние AWG до установки панели;
2. установить AWGUI и убедиться, что `awg0` не перезапускался и конфиг не изменился;
3. пройти add/list/stats/modify/regen/remove;
4. пройти backup/download/upload/restore;
5. проверить local и SSH серверы;
6. проверить Telegram теми же операциями;
7. проверить, что загрузка файла на SSH-сервер не меняет права существующего родительского каталога.

## Каскад

Только на отдельном стенде AWG0 + AWG1 + реальный клиент:

1. пройти все шаги официального `CASCADE.md` через панель;
2. проверить handshake и реальный RU/non-RU путь;
3. перезагрузить AWG0, затем AWG1, затем оба;
4. проверить восстановление маршрутизации и счётчики правил;
5. повторить для нескольких независимых пар.

Не отмечать DKMS, reboot или сетевой путь как пройденные без физического стенда.
