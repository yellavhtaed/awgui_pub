#!/usr/bin/env bash
set -Eeuo pipefail

[[ ${EUID:-$(id -u)} -eq 0 ]] || {
  echo "Запустите установку от root: sudo $0" >&2
  exit 1
}

if [[ $# -ne 0 ]]; then
  echo "install.sh не принимает параметры" >&2
  exit 2
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="/opt/awgui"
STAGE="/opt/.awgui-stage.$$"
ROLLBACK="/opt/.awgui-rollback.$$"
STATE_DIR="/var/lib/awgui"
ENV_FILE="/etc/awgui.env"
WEB_UNIT="/etc/systemd/system/awgui.service"
BOT_UNIT="/etc/systemd/system/awgui-bot.service"

TRANSACTION_STARTED=0
INSTALL_FINISHED=0
ERROR_HANDLED=0
OLD_TARGET=0
ENV_EXISTED=0
WEB_UNIT_EXISTED=0
BOT_UNIT_EXISTED=0
WEB_WAS_ENABLED=0
BOT_WAS_ENABLED=0
WEB_WAS_ACTIVE=0
BOT_WAS_ACTIVE=0

for command in python3 openssl sha256sum systemctl; do
  command -v "$command" >/dev/null 2>&1 || {
    echo "Не найдена обязательная команда: $command" >&2
    exit 1
  }
done

systemctl show-environment >/dev/null 2>&1 || {
  echo "systemd недоступен: AWGUI требует сервер с работающим systemd" >&2
  exit 1
}

if [[ ! -f "$SOURCE_DIR/SHA256SUMS" ]]; then
  echo "Не найден $SOURCE_DIR/SHA256SUMS" >&2
  exit 1
fi
(
  cd "$SOURCE_DIR"
  sha256sum -c SHA256SUMS >/dev/null
) || {
  echo "Проверка целостности файлов AWGUI не пройдена" >&2
  exit 1
}

systemctl is-enabled --quiet awgui.service 2>/dev/null && WEB_WAS_ENABLED=1 || true
systemctl is-enabled --quiet awgui-bot.service 2>/dev/null && BOT_WAS_ENABLED=1 || true
systemctl is-active --quiet awgui.service 2>/dev/null && WEB_WAS_ACTIVE=1 || true
systemctl is-active --quiet awgui-bot.service 2>/dev/null && BOT_WAS_ACTIVE=1 || true
[[ -d "$TARGET" ]] && OLD_TARGET=1
[[ -f "$ENV_FILE" ]] && ENV_EXISTED=1
[[ -f "$WEB_UNIT" ]] && WEB_UNIT_EXISTED=1
[[ -f "$BOT_UNIT" ]] && BOT_UNIT_EXISTED=1

cleanup() {
  rm -rf "$STAGE"
  if [[ $INSTALL_FINISHED -eq 1 || $TRANSACTION_STARTED -eq 0 ]]; then
    rm -rf "$ROLLBACK"
  fi
}

show_failure_logs() {
  echo >&2
  echo "--- awgui.service ---" >&2
  systemctl --no-pager --full status awgui.service 2>&1 | tail -n 50 >&2 || true
  echo >&2
  echo "--- awgui-bot.service ---" >&2
  systemctl --no-pager --full status awgui-bot.service 2>&1 | tail -n 30 >&2 || true
  if command -v journalctl >/dev/null 2>&1; then
    echo >&2
    echo "--- journalctl -u awgui.service ---" >&2
    journalctl --no-pager -u awgui.service -n 80 2>&1 >&2 || true
  fi
}

restore_previous() {
  set +e
  systemctl disable --now awgui.service awgui-bot.service >/dev/null 2>&1 || true
  rm -rf "$TARGET"
  rm -f "$WEB_UNIT" "$BOT_UNIT"

  if [[ $OLD_TARGET -eq 1 && -d "$ROLLBACK/app" ]]; then
    mv "$ROLLBACK/app" "$TARGET"
  fi
  if [[ $WEB_UNIT_EXISTED -eq 1 && -f "$ROLLBACK/awgui.service" ]]; then
    cp -a "$ROLLBACK/awgui.service" "$WEB_UNIT"
  fi
  if [[ $BOT_UNIT_EXISTED -eq 1 && -f "$ROLLBACK/awgui-bot.service" ]]; then
    cp -a "$ROLLBACK/awgui-bot.service" "$BOT_UNIT"
  fi
  if [[ $ENV_EXISTED -eq 1 && -f "$ROLLBACK/awgui.env" ]]; then
    cp -a "$ROLLBACK/awgui.env" "$ENV_FILE"
  elif [[ $ENV_EXISTED -eq 0 ]]; then
    rm -f "$ENV_FILE"
  fi

  systemctl daemon-reload >/dev/null 2>&1 || true
  [[ $WEB_WAS_ENABLED -eq 1 ]] && systemctl enable awgui.service >/dev/null 2>&1 || true
  [[ $BOT_WAS_ENABLED -eq 1 ]] && systemctl enable awgui-bot.service >/dev/null 2>&1 || true
  [[ $WEB_WAS_ACTIVE -eq 1 ]] && systemctl start awgui.service >/dev/null 2>&1 || true
  [[ $BOT_WAS_ACTIVE -eq 1 ]] && systemctl start awgui-bot.service >/dev/null 2>&1 || true
  rm -rf "$ROLLBACK"
  set -e
}

on_error() {
  local rc=$?
  local line=${1:-unknown}
  trap - ERR
  set +e
  if [[ $ERROR_HANDLED -eq 1 ]]; then
    exit "$rc"
  fi
  ERROR_HANDLED=1
  echo "Ошибка установки AWGUI в строке $line" >&2
  if [[ $TRANSACTION_STARTED -eq 1 ]]; then
    show_failure_logs
    restore_previous
    if [[ $OLD_TARGET -eq 1 ]]; then
      echo "Предыдущая версия AWGUI восстановлена" >&2
    else
      echo "Неполная установка AWGUI удалена" >&2
    fi
  fi
  exit "$rc"
}

on_signal() {
  local signal=$1
  trap - ERR INT TERM HUP
  echo "Установка AWGUI прервана сигналом $signal" >&2
  if [[ $TRANSACTION_STARTED -eq 1 ]]; then
    restore_previous
    echo "Предыдущее состояние AWGUI восстановлено" >&2
  fi
  exit 130
}

trap 'on_error $LINENO' ERR
trap 'on_signal INT' INT
trap 'on_signal TERM' TERM
trap 'on_signal HUP' HUP
trap cleanup EXIT

rm -rf "$STAGE" "$ROLLBACK"
install -d -m 755 "$STAGE" "$ROLLBACK"
install -d -m 700 "$STATE_DIR"
cp -a "$SOURCE_DIR"/. "$STAGE"/
find "$STAGE" -type d -name __pycache__ -prune -exec rm -rf {} +
chmod 700 "$STAGE/install.sh" "$STAGE/uninstall.sh" "$STAGE/vendor/bivlked/awg-routing.sh"
python3 -m py_compile "$STAGE"/panel/*.py
python3 -m venv "$STAGE/.venv-preflight"
"$STAGE/.venv-preflight/bin/python" -m pip --version >/dev/null
rm -rf "$STAGE/.venv-preflight"

[[ $OLD_TARGET -eq 1 ]] && cp -a "$TARGET" "$ROLLBACK/app"
[[ $ENV_EXISTED -eq 1 ]] && cp -a "$ENV_FILE" "$ROLLBACK/awgui.env"
[[ $WEB_UNIT_EXISTED -eq 1 ]] && cp -a "$WEB_UNIT" "$ROLLBACK/awgui.service"
[[ $BOT_UNIT_EXISTED -eq 1 ]] && cp -a "$BOT_UNIT" "$ROLLBACK/awgui-bot.service"

TRANSACTION_STARTED=1
PASSWORD_FALLBACK="$(openssl rand -hex 12)"
SECRET_FALLBACK="$(openssl rand -hex 32)"
python3 - "$ENV_FILE" "$PASSWORD_FALLBACK" "$SECRET_FALLBACK" "$TARGET" "$STATE_DIR" <<'PY_ENV'
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

path = Path(sys.argv[1])
password_fallback = sys.argv[2]
secret_fallback = sys.argv[3]
target = sys.argv[4]
state_dir = sys.argv[5]

values: dict[str, str] = {}
order: list[str] = []
if path.exists():
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        if key and key not in values:
            order.append(key)
        values[key] = value.strip().strip('"\'')

values.setdefault("AWGUI_HOST", "127.0.0.1")
values.setdefault("AWGUI_PORT", "8080")
values.setdefault("AWGUI_ADMIN_USER", "admin")
values["AWGUI_ADMIN_PASSWORD"] = values.get("AWGUI_ADMIN_PASSWORD") or password_fallback
values["AWGUI_SECRET_KEY"] = values.get("AWGUI_SECRET_KEY") or secret_fallback
values["AWGUI_BASE_DIR"] = target
values["AWGUI_VENDOR_DIR"] = f"{target}/vendor/bivlked"
values["AWGUI_STATE_DIR"] = state_dir

required_order = [
    "AWGUI_HOST", "AWGUI_PORT", "AWGUI_ADMIN_USER", "AWGUI_ADMIN_PASSWORD",
    "AWGUI_SECRET_KEY", "AWGUI_BASE_DIR", "AWGUI_VENDOR_DIR", "AWGUI_STATE_DIR",
]
keys = required_order + [key for key in order if key not in required_order]
for key in required_order:
    value = values.get(key, "")
    if not value or any(ch in value for ch in "\r\n\x00"):
        raise SystemExit(f"Некорректное значение {key} в {path}")
if not values["AWGUI_PORT"].isdigit() or not (1 <= int(values["AWGUI_PORT"]) <= 65535):
    raise SystemExit(f"Некорректный AWGUI_PORT в {path}")
for key, value in values.items():
    if any(ch in value for ch in "\r\n\x00"):
        raise SystemExit(f"Некорректное значение {key} в {path}")
    if any(ch.isspace() for ch in value):
        raise SystemExit(f"Пробелы в {key} не поддерживаются форматом systemd EnvironmentFile")

path.parent.mkdir(parents=True, exist_ok=True)
fd, tmp = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
try:
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
        for key in keys:
            if key in values:
                handle.write(f"{key}={values[key]}\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)
finally:
    try:
        os.unlink(tmp)
    except FileNotFoundError:
        pass
PY_ENV
chmod 600 "$ENV_FILE"

systemctl disable --now awgui.service awgui-bot.service 2>/dev/null || true
python3 - "$ENV_FILE" <<'PY_PORT'
from __future__ import annotations

import socket
import sys
from pathlib import Path

values: dict[str, str] = {}
for raw in Path(sys.argv[1]).read_text(encoding="utf-8").splitlines():
    line = raw.strip()
    if not line or line.startswith("#") or "=" not in line:
        continue
    key, value = line.split("=", 1)
    values[key.strip()] = value.strip().strip("\"'")
host = values.get("AWGUI_HOST", "127.0.0.1").strip("[]")
port = int(values.get("AWGUI_PORT", "8080"))
family = socket.AF_INET6 if ":" in host else socket.AF_INET
address = (host, port, 0, 0) if family == socket.AF_INET6 else (host, port)
with socket.socket(family, socket.SOCK_STREAM) as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind(address)
    except OSError as exc:
        raise SystemExit(f"Порт AWGUI {host}:{port} недоступен: {exc}") from exc
PY_PORT
rm -rf "$TARGET"
mv "$STAGE" "$TARGET"

python3 -m venv "$TARGET/.venv"
"$TARGET/.venv/bin/python" -m pip install --disable-pip-version-check --no-input -r "$TARGET/requirements.txt"
"$TARGET/.venv/bin/python" -m pip check
"$TARGET/.venv/bin/python" -m py_compile "$TARGET"/panel/*.py

cat > "$WEB_UNIT" <<EOF_UNIT
[Unit]
Description=AWGUI web panel for installed AmneziaWG
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m gunicorn --workers 1 --threads 4 --timeout 1800 --bind \${AWGUI_HOST}:\${AWGUI_PORT} 'panel.web:create_app()'
Restart=on-failure
RestartSec=3
UMask=0077
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF_UNIT

cat > "$BOT_UNIT" <<EOF_UNIT
[Unit]
Description=AWGUI Telegram bot
After=network-online.target awgui.service
Wants=network-online.target awgui.service

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET
EnvironmentFile=$ENV_FILE
ExecStart=$TARGET/.venv/bin/python -m panel.telegram
Restart=always
RestartSec=5
UMask=0077
PrivateTmp=true
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF_UNIT

if command -v systemd-analyze >/dev/null 2>&1; then
  systemd-analyze verify "$WEB_UNIT" "$BOT_UNIT"
fi
systemctl daemon-reload
systemctl enable --now awgui.service awgui-bot.service
systemctl is-enabled --quiet awgui.service
systemctl is-enabled --quiet awgui-bot.service
systemctl is-active --quiet awgui.service
systemctl is-active --quiet awgui-bot.service
cd "$TARGET"
"$TARGET/.venv/bin/python" -m panel.runtime_check "$ENV_FILE"

INSTALL_FINISHED=1
rm -rf "$ROLLBACK"
trap - ERR

read_env_value() {
  local key=$1
  awk -F= -v key="$key" '$1==key {print substr($0,index($0,"=")+1); exit}' "$ENV_FILE"
}

DISPLAY_HOST="$(read_env_value AWGUI_HOST)"
DISPLAY_PORT="$(read_env_value AWGUI_PORT)"
DISPLAY_USER="$(read_env_value AWGUI_ADMIN_USER)"
DISPLAY_PASSWORD="$(read_env_value AWGUI_ADMIN_PASSWORD)"

echo
echo "AWGUI установлена"
echo "Адрес на сервере: http://${DISPLAY_HOST}:${DISPLAY_PORT}"
echo "SSH-туннель: ssh -L ${DISPLAY_PORT}:127.0.0.1:${DISPLAY_PORT} root@SERVER_IP"
echo "Логин: ${DISPLAY_USER}"
echo "Пароль: ${DISPLAY_PASSWORD}"
echo "Службы awgui.service и awgui-bot.service включены в автозапуск"
