#!/usr/bin/env bash
set -euo pipefail
while (($#)); do
 case "$1" in
  -p|-i|-o) shift 2;;
  --) shift; break;;
  -*) shift;;
  *) shift; break;; # destination
 esac
done
cmd="${1:-}"
exec bash -lc "$cmd"
