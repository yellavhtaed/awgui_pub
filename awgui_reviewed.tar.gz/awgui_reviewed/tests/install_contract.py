from pathlib import Path

root = Path(__file__).resolve().parents[1]
install = (root / "install.sh").read_text(encoding="utf-8")
uninstall = (root / "uninstall.sh").read_text(encoding="utf-8")

assert "install.sh не принимает параметры" in install
assert "reset-password" not in install
assert "--reset-admin" not in install
assert "sha256sum -c SHA256SUMS" in install
assert "systemctl show-environment" in install
assert 'python3 -m venv "$STAGE/.venv-preflight"' in install
assert 'python3 -m venv "$TARGET/.venv"' in install
assert 'python3 -m venv "$STAGE/.venv"' not in install
assert "ExecStart=$TARGET/.venv/bin/python -m gunicorn" in install
assert "panel.runtime_check" in install
assert 'cd "$TARGET"' in install
assert "Порт AWGUI" in install
assert "systemd-analyze verify" in install
assert "systemctl enable --now awgui.service awgui-bot.service" in install
assert install.count("WantedBy=multi-user.target") == 2
assert "systemctl is-enabled --quiet awgui.service" in install
assert "systemctl is-enabled --quiet awgui-bot.service" in install
assert "systemctl is-active --quiet awgui.service" in install
assert "systemctl is-active --quiet awgui-bot.service" in install
assert 'cp -a "$ENV_FILE" "$ROLLBACK/awgui.env"' in install
assert 'cp -a "$ROLLBACK/awgui.env" "$ENV_FILE"' in install
assert 'echo "Пароль: ${DISPLAY_PASSWORD}"' in install
assert "install_amneziawg" not in install
assert "/root/awg" not in install
assert "install_amneziawg" not in uninstall
assert "rm -rf /root/awg" not in uninstall
print("AWGUI installer contract OK")
