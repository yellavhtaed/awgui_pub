# ruff: noqa: E402
from __future__ import annotations

import hashlib
import multiprocessing
import os
import stat
import tempfile
import time
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
TMP_CTX = tempfile.TemporaryDirectory(prefix="awgui-selftest-")
TMP = Path(TMP_CTX.name)
STATE = TMP / "state"
AWG = TMP / "awg"
CONF = TMP / "awg0.conf"
MANAGE = ROOT / "tests/fake_manage.sh"
AWG.mkdir()
CONF.write_text("[Interface]\nAddress = 172.16.17.1/24\n", encoding="utf-8")

os.environ.update(
    {
        "AWGUI_BASE_DIR": str(ROOT),
        "AWGUI_VENDOR_DIR": str(ROOT / "vendor/bivlked"),
        "AWGUI_STATE_DIR": str(STATE),
        "AWGUI_STATE_FILE": str(STATE / "state.json"),
        "AWGUI_STATE_LOCK_FILE": str(STATE / "state.lock"),
        "AWGUI_ADMIN_USER": "admin",
        "AWGUI_ADMIN_PASSWORD": "testpass",
        "AWGUI_SECRET_KEY": "test-secret",
        "AWGUI_SSH_BIN": str(ROOT / "tests/fake_ssh.sh"),
    }
)

from panel import state, telegram
from panel.cascade import (
    _render_upstream_routing_script,
    enable_routing_service,
    install_routing,
    patch_awg1_config,
    start_link_tunnel,
    transfer_link_config,
)
from panel.manager import AWGManager, make_ssh_server
from panel.runner import Result, Runner
from panel.runtime_check import read_env
from panel.web import create_app

LOCAL = {
    "id": "local",
    "name": "Local",
    "mode": "local",
    "host": "127.0.0.1",
    "port": 22,
    "user": "root",
    "key_path": "",
    "manage_path": str(MANAGE),
    "awg_dir": str(AWG),
    "server_conf": str(CONF),
}
state.save(
    {
        "servers": [LOCAL],
        "telegram": {
            "enabled": False,
            "token": "",
            "admin_ids": [],
            "dangerous": False,
        },
        "telegram_server": {},
    }
)

# Direct delegation to the installed manage_amneziawg.sh command surface.
mgr = AWGManager(state.get_server("local"))
assert mgr.installed()
assert mgr.add(["phone"], expires="1d", psk=True).ok
listing = mgr.list_clients()
assert listing.ok and listing.data[0]["name"] == "phone"
assert mgr.stats().ok
assert mgr.client_file("phone", "conf")
assert mgr.client_bundle("phone")
assert mgr.run_manage("backup").ok
assert mgr.backup_list()
assert not mgr.upload_backup("random.tar.gz", b"x").ok
upload_name = "awg_backup_2026-07-10_19-01-00.000.tar.gz"
assert mgr.upload_backup(upload_name, b"x").ok
assert not mgr.upload_backup(upload_name, b"replacement").ok
assert mgr.modify("phone", "DNS", "1.1.1.1").ok
assert mgr.regen(["phone"]).ok
assert not mgr.run_manage("not-a-command").ok


# Wrapper builds the documented v5.18.4 CLI and delegates without AWG logic.
class CaptureRunner:
    remote = False

    def __init__(self):
        self.calls: list[list[str]] = []

    def run(self, argv, **kwargs):
        call = [str(x) for x in argv]
        self.calls.append(call)
        return Result(
            True, 0, " ".join(call), "[]\n" if "--json" in call else "ok\n", "", 0.0
        )

    def read_file(self, path, **kwargs):
        return None

    def write_file(self, path, data, **kwargs):
        return Result(True, 0, f"write {path}", "", "", 0.0)


captured = CaptureRunner()
wrapped = AWGManager(LOCAL)
wrapped.runner = captured
assert wrapped.add(["one", "two"], expires="7d", psk=True, apply_mode="restart").ok
assert captured.calls[-1] == [
    "bash",
    str(MANAGE),
    "--no-color",
    f"--conf-dir={AWG}",
    f"--server-conf={CONF}",
    "--expires=7d",
    "--psk",
    "--apply-mode=restart",
    "add",
    "one",
    "two",
]
assert wrapped.run_manage("diagnose", carrier="tele2_msk").ok
assert "--carrier=tele2_msk" in captured.calls[-1]
assert wrapped.run_manage("restore", "/tmp/backup.tar.gz", yes=True).ok
assert "--yes" in captured.calls[-1] and captured.calls[-1][-2:] == [
    "restore",
    "/tmp/backup.tar.gz",
]

# Server inventory is agentless and stores no installer state.
remote = make_ssh_server(
    "remote",
    "fake",
    key_path="/tmp/key",
    manage_path=str(MANAGE),
    awg_dir=str(AWG),
    server_conf=str(CONF),
)
assert "installer_dir" not in remote
try:
    make_ssh_server("bad-path", "fake", key_path="/tmp/key\tbad")
except ValueError:
    pass
else:
    raise AssertionError("control character accepted in SSH key path")
state.upsert_server(remote)
assert state.get_server("remote")["manage_path"] == str(MANAGE)


# State update is process-safe: independent writers do not overwrite one another.
def add_server(index: int) -> None:
    from panel import state as child_state

    child_state.upsert_server(
        make_ssh_server(
            f"s{index}",
            "fake",
            manage_path=str(MANAGE),
            awg_dir=str(AWG),
            server_conf=str(CONF),
        )
    )


processes = [multiprocessing.Process(target=add_server, args=(i,)) for i in range(8)]
for process in processes:
    process.start()
for process in processes:
    process.join(10)
    assert process.exitcode == 0
ids = {item["id"] for item in state.list_servers()}
assert {f"s{i}" for i in range(8)} <= ids

# CASCADE.md config transformation: only exact DNS and Table keys are changed.
source_conf = """[Interface]
DNS = 1.1.1.1
DNSFoo = keep-me
Table = 123
TableExtra = keep-me-too
PrivateKey = x
[Peer]
PublicKey = y
Endpoint = 1.2.3.4:39743
AllowedIPs = 0.0.0.0/0
"""
patched = patch_awg1_config(source_conf)
assert "DNS =" not in patched
assert "DNSFoo = keep-me" in patched
assert patched.count("Table = off") == 1
assert "TableExtra = keep-me-too" in patched
assert "AllowedIPs = 0.0.0.0/0" in patched
for malformed in (
    "",
    "[Peer]\nAllowedIPs=0.0.0.0/0\n",
    "[Interface]\nPrivateKey=x\n",
    "[Interface]\nPrivateKey=x\n[Peer]\nAllowedIPs=0.0.0.0/0\n[Peer]\nAllowedIPs=10.0.0.0/8\n",
):
    try:
        patch_awg1_config(malformed)
    except ValueError:
        pass
    else:
        raise AssertionError("malformed cascade config accepted")

rendered = _render_upstream_routing_script("172.16.17.0/24", "1.2.3.4")
assert (
    hashlib.sha256(rendered).hexdigest()
    != hashlib.sha256((ROOT / "vendor/bivlked/awg-routing.sh").read_bytes()).hexdigest()
)
rendered_text = rendered.decode()
assert 'CLIENT_SUBNET="172.16.17.0/24"' in rendered_text
assert 'AWG1_ENDPOINT="1.2.3.4"' in rendered_text
assert (
    'RU_ZONE_FALLBACK_URL="https://raw.githubusercontent.com/bivlked/amneziawg-installer/v5.18.4/cascade/ru.zone"'
    in rendered_text
)


class MemoryRunner:
    def __init__(self, files: dict[str, bytes] | None = None):
        self.files = dict(files or {})
        self.commands: list[list[str]] = []

    def read_file(self, path: str, **kwargs):
        return self.files.get(path)

    def write_file(self, path: str, data: bytes, *, mode: int = 0o600):
        self.files[path] = data
        return Result(True, 0, f"write {path}", "", "", 0.0)

    def run(self, argv, **kwargs):
        self.commands.append(list(argv))
        return Result(True, 0, " ".join(argv), "", "", 0.0)


class DummyManager:
    def __init__(
        self, *, conf: bytes | None = None, subnet: str | None = "172.16.17.0/24"
    ):
        files = {"/etc/amnezia/amneziawg/awg1.conf": conf} if conf is not None else {}
        self.runner = MemoryRunner(files)
        self._subnet = subnet

    def client_file(self, name: str, kind: str):
        return (f"{name}.conf", source_conf.encode())

    def server_subnet(self):
        return self._subnet


entry = DummyManager(conf=None)
exit_server = DummyManager()
result = transfer_link_config(entry, exit_server, "link")
assert result.ok
written = entry.runner.files["/etc/amnezia/amneziawg/awg1.conf"].decode()
assert "DNS =" not in written and "Table = off" in written

bad_exit = DummyManager()
bad_exit.client_file = lambda name, kind: (
    "link.conf",
    b"[Interface]\nPrivateKey=x\n[Peer]\nAllowedIPs=10.0.0.0/8\n",
)
assert not transfer_link_config(DummyManager(conf=None), bad_exit, "link").ok

start_entry = DummyManager()
assert start_link_tunnel(start_entry).ok
assert start_entry.runner.commands[-1] == ["systemctl", "start", "awg-quick@awg1"]

routing_entry = DummyManager(conf=source_conf.encode())
assert install_routing(routing_entry).ok
assert routing_entry.runner.files["/root/awg/awg-routing.sh"] == rendered

hostname_conf = source_conf.replace("1.2.3.4:39743", "exit.example:39743")
assert not install_routing(DummyManager(conf=hostname_conf.encode())).ok

conflicting_unit = DummyManager(conf=source_conf.encode())
conflicting_unit.runner.files["/etc/systemd/system/awg-routing.service"] = b"custom\n"
assert not enable_routing_service(conflicting_unit).ok
assert (
    conflicting_unit.runner.files["/etc/systemd/system/awg-routing.service"]
    == b"custom\n"
)

assert enable_routing_service(routing_entry).ok
assert (
    routing_entry.runner.files["/etc/systemd/system/awg-routing.service"]
    == (ROOT / "vendor/bivlked/awg-routing.service").read_bytes()
)
assert (
    "systemctl enable awg-quick@awg1 awg-routing"
    in routing_entry.runner.commands[-1][-1]
)
assert "systemctl start awg-routing" not in routing_entry.runner.commands[-1][-1]

# Remote writes never chmod an existing parent directory (notably /etc/systemd/system).
remote_runner = Runner(remote)
existing_parent = TMP / "existing-parent"
existing_parent.mkdir(mode=0o755)
os.chmod(existing_parent, 0o755)
assert remote_runner.write_file(
    str(existing_parent / "unit.service"), b"unit\n", mode=0o644
).ok
assert stat.S_IMODE(existing_parent.stat().st_mode) == 0o755
assert stat.S_IMODE((existing_parent / "unit.service").stat().st_mode) == 0o644

# Remote command timeout is enforced on the remote side as well as locally.
started = time.monotonic()
timeout_result = remote_runner.run(["bash", "-lc", "sleep 3"], timeout=1)
assert not timeout_result.ok and timeout_result.rc == 124
assert time.monotonic() - started < 5
large = TMP / "large.bin"
large.write_bytes(b"x" * 1024)
assert remote_runner.read_file(str(large), max_bytes=32) is None

# Environment parser reads the credentials used by systemd/runtime checks.
env_file = TMP / "awgui.env"
env_file.write_text(
    "AWGUI_ADMIN_USER=admin\nAWGUI_ADMIN_PASSWORD=testpass\n", encoding="utf-8"
)
assert read_env(env_file)["AWGUI_ADMIN_PASSWORD"] == "testpass"

# Web authentication, session, CSRF and safe redirects.
app = create_app()
app.testing = True
client = app.test_client()
assert client.get("/health").status_code == 200
assert client.get("/").status_code == 302
wrong = client.post("/login", data={"username": "admin", "password": "wrong"})
assert wrong.status_code == 200 and "Неверный логин или пароль" in wrong.get_data(
    as_text=True
)
external = client.post(
    "/login?next=https://evil.example/x",
    data={"username": "admin", "password": "testpass"},
)
assert (
    external.status_code == 302 and "evil.example" not in external.headers["Location"]
)
client = app.test_client()
response = client.post(
    "/login", data={"username": "admin", "password": "testpass"}, follow_redirects=True
)
assert response.status_code == 200
with client.session_transaction() as sess:
    csrf = sess["csrf_token"]
assert (
    client.post("/clients", data={"action": "add", "names": "bad"}).status_code == 400
)
for url in ["/", "/clients", "/servers", "/cascade", "/settings"]:
    assert client.get(url).status_code == 200
select = client.post(
    "/select-server",
    data={"csrf_token": csrf, "server_id": "local"},
    headers={"Referer": "https://evil.example/steal"},
)
assert select.status_code == 302 and "evil.example" not in select.headers["Location"]
response = client.post(
    "/clients",
    data={
        "csrf_token": csrf,
        "action": "add",
        "names": "tablet",
        "expires": "",
        "apply_mode": "syncconf",
    },
)
assert response.status_code == 200 and (AWG / "tablet.conf").is_file()
assert b"1 MB" in response.data and b"2 MB" in response.data
assert client.get("/clients/tablet/file/conf").status_code == 200
assert client.get("/clients/tablet/bundle").status_code == 200
assert (
    client.post(
        "/clients",
        data={
            "csrf_token": csrf,
            "action": "modify",
            "name": "tablet",
            "parameter": "DNS",
            "value": "9.9.9.9",
            "apply_mode": "syncconf",
        },
    ).status_code
    == 200
)
assert (
    client.post(
        "/clients",
        data={
            "csrf_token": csrf,
            "action": "regen",
            "names": "tablet",
            "apply_mode": "syncconf",
        },
    ).status_code
    == 200
)
assert (
    client.post(
        "/servers/action", data={"csrf_token": csrf, "action": "backup"}
    ).status_code
    == 200
)
backup_name = mgr.backup_list()[0]["name"]
assert client.get(f"/servers/backups/{backup_name}").status_code == 200
assert (
    client.post(
        "/servers/restore",
        data={
            "csrf_token": csrf,
            "backup": backup_name,
            "confirm": "RESTORE",
        },
    ).status_code
    == 200
)
assert (
    client.post(
        "/servers/add",
        data={
            "csrf_token": csrf,
            "id": "web-remote",
            "name": "Web remote",
            "host": "fake",
            "port": "22",
            "user": "root",
            "key_path": "/tmp/key",
            "manage_path": str(MANAGE),
            "awg_dir": str(AWG),
            "server_conf": str(CONF),
        },
    ).status_code
    == 302
)
assert state.get_server("web-remote") is not None
assert (
    client.post(
        "/servers/delete",
        data={
            "csrf_token": csrf,
            "server_id": "web-remote",
            "confirm": "DELETE",
        },
    ).status_code
    == 302
)
assert state.get_server("web-remote") is None
assert (
    client.post(
        "/clients",
        data={
            "csrf_token": csrf,
            "action": "remove",
            "names": "tablet",
            "confirm": "REMOVE",
            "apply_mode": "syncconf",
        },
    ).status_code
    == 200
)
assert not (AWG / "tablet.conf").exists()

# Telegram parity; callback remains valid after bot process memory is cleared.
state.set_telegram(
    {"enabled": True, "token": "test", "admin_ids": ["1"], "dangerous": True}
)
messages: list[tuple] = []
telegram.send = lambda chat_id, text, kb=None: messages.append((chat_id, text, kb))
telegram.answer = lambda callback_id, text="": None
telegram.handle_command("1", "/add phone2 --expires=1d --psk")
assert (AWG / "phone2.conf").is_file()
telegram.handle_command("1", "/remove phone2")
callback = messages[-1][2]["inline_keyboard"][0][0]["callback_data"]
telegram.CALLBACK_NAMES.clear()
telegram.handle_callback(
    {"id": "1", "data": callback, "message": {"chat": {"id": "1"}}}
)
assert not (AWG / "phone2.conf").exists()
telegram.handle_command("1", "/add tgclient")
telegram.handle_command("1", "/modify tgclient DNS 1.1.1.1")
telegram.handle_command("1", "/regen tgclient")
telegram.handle_command("1", "/status")
telegram.handle_command("1", "/stats")
telegram.handle_command("1", "/backup")
telegram.handle_command("1", "/addserver tg-remote fake 22 root /tmp/key TG")
assert state.get_server("tg-remote") is not None
telegram.handle_command("1", "/delserver tg-remote DELETE")
assert state.get_server("tg-remote") is None
messages.clear()
telegram.handle_command("1", "/cascade local local")
assert any("разными" in text for _, text, _ in messages)
for marker in ["/cascade", "/clients", "/backupfile", "/uploadbackup", "/addserver"]:
    assert marker in telegram.HELP
for forbidden in ["/install", "/deploy", "/uninstall"]:
    assert forbidden not in telegram.HELP

print("AWGUI selftest OK")
