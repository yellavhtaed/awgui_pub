from __future__ import annotations

import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
assert VERSION == "1.1.3"

required = [
    ROOT / "panel/web.py",
    ROOT / "panel/telegram.py",
    ROOT / "panel/manager.py",
    ROOT / "panel/runner.py",
    ROOT / "panel/cascade.py",
    ROOT / "panel/state.py",
    ROOT / "panel/runtime_check.py",
    ROOT / "install.sh",
    ROOT / "uninstall.sh",
    ROOT / "vendor/bivlked/CASCADE.md",
    ROOT / "vendor/bivlked/awg-routing.sh",
    ROOT / "vendor/bivlked/awg-routing.service",
    ROOT / "vendor/bivlked/LICENSE",
    ROOT / "vendor/bivlked/SOURCE",
    ROOT / "README.md",
    ROOT / "requirements.txt",
]
for path in required:
    assert path.is_file(), path
assert not (ROOT / "reset-password.sh").exists()
assert not (ROOT / "amneziawg-installer").exists()


# Pinned snapshot of the official upstream CASCADE.md, not a self-generated reference.
def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert (
    sha(ROOT / "vendor/bivlked/CASCADE.md")
    == "f4178ef1c85d67741e23f8006e64fdd7a62ec0cb654347e75d88b83337920d90"
)
assert (
    sha(ROOT / "vendor/bivlked/awg-routing.sh")
    == "bfade62bdc1b2f2441f58645bec891a2e1df8aec9b026a9dce5bcd5e63b87c2c"
)
assert (
    sha(ROOT / "vendor/bivlked/awg-routing.service")
    == "8898a5c8f61a951dc67c3e2bec1cd59b625ab33110236caad77fd466fc45bb87"
)

text = (ROOT / "vendor/bivlked/CASCADE.md").read_text(encoding="utf-8")
sub = text[text.index("## Шаг 4.") :]
i = sub.index("```bash") + len("```bash")
j = sub.index("```", i)
embedded = sub[i:j].strip() + "\n"
assert embedded == (ROOT / "vendor/bivlked/awg-routing.sh").read_text(encoding="utf-8")
assert (
    'RU_ZONE_FALLBACK_URL="https://raw.githubusercontent.com/bivlked/amneziawg-installer/v5.18.4/cascade/ru.zone"'
    in embedded
)
sub = text[text.index("## Шаг 5.") :]
i = sub.index("```ini") + len("```ini")
j = sub.index("```", i)
unit = sub[i:j].strip() + "\n"
assert unit == (ROOT / "vendor/bivlked/awg-routing.service").read_text(encoding="utf-8")

subprocess.run(
    [
        sys.executable,
        "-m",
        "py_compile",
        *[str(x) for x in (ROOT / "panel").glob("*.py")],
    ],
    check=True,
)
subprocess.run(
    [
        "bash",
        "-n",
        str(ROOT / "install.sh"),
        str(ROOT / "uninstall.sh"),
        str(ROOT / "vendor/bivlked/awg-routing.sh"),
        *[str(x) for x in (ROOT / "tests").glob("*.sh")],
    ],
    check=True,
)

combined = "\n".join(
    (ROOT / path).read_text(encoding="utf-8")
    for path in [
        "panel/manager.py",
        "panel/web.py",
        "panel/telegram.py",
        "install.sh",
        "uninstall.sh",
    ]
)
for forbidden in [
    "run_installer",
    "deploy_upstream",
    "validate_installer_args",
    "INSTALL_TIMEOUT",
    "reset-password",
]:
    assert forbidden not in combined, forbidden
for marker in ["manage_amneziawg.sh", "run_manage", "AWGManager"]:
    assert marker in (ROOT / "panel/manager.py").read_text(encoding="utf-8"), marker
assert "remove_cascade" not in (ROOT / "panel/cascade.py").read_text(encoding="utf-8")

for path in list((ROOT / "panel").rglob("*")) + [
    ROOT / "install.sh",
    ROOT / "uninstall.sh",
]:
    if not path.is_file() or path.suffix not in {".py", ".html", ".css", ".js", ".sh"}:
        continue
    data = path.read_bytes()
    assert not data.startswith(b"\xef\xbb\xbf"), path
    assert b"\r\n" not in data, path

readme = (ROOT / "README.md").read_text(encoding="utf-8")
for stale in ["reset-password", "--reset-admin", "удаление каскадных объектов"]:
    assert stale not in readme, stale

subprocess.run([sys.executable, str(ROOT / "tests/install_contract.py")], check=True)
subprocess.run([sys.executable, str(ROOT / "tests/selftest.py")], check=True)
print("AWGUI release gate OK")
