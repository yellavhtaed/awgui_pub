(() => {
  const root = document.documentElement;
  const saved = localStorage.getItem('awgui-theme') || 'system';
  root.dataset.theme = saved;
  const cycle = { system: 'dark', dark: 'light', light: 'system' };
  document.querySelector('[data-theme-toggle]')?.addEventListener('click', () => {
    const next = cycle[root.dataset.theme || 'system'];
    root.dataset.theme = next;
    localStorage.setItem('awgui-theme', next);
  });
})();
