#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import html
import json
import re
import shlex
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from . import cascade, config, state
from .manager import AWGManager, make_ssh_server

MAX_TEXT = 3900
PENDING: dict[str, dict[str, Any]] = {}
CALLBACK_NAMES: dict[str, str] = {}


def log(message: str) -> None:
    print(f"[awgui-bot] {message}", flush=True)


def settings() -> dict[str, Any]:
    return state.telegram_settings()


def api(
    method: str, payload: dict[str, Any] | None = None, timeout: int = 60
) -> dict[str, Any]:
    token = settings().get("token") or ""
    request = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/{method}",
        data=json.dumps(payload or {}, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read().decode("utf-8", errors="replace")
        data = json.loads(body or "{}")
        if not data.get("ok"):
            raise RuntimeError(str(data.get("description") or "Telegram API error"))
        return data
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
            detail = json.loads(body).get("description", body)
        except Exception:
            detail = str(exc)
        raise RuntimeError(f"Telegram {method}: {detail}") from exc


def multipart(
    method: str, chat_id: str, path: Path, field: str, caption: str = ""
) -> None:
    boundary = f"----awgui{time.time_ns()}"
    chunks: list[bytes] = []
    for key, value in {"chat_id": chat_id, "caption": caption[:900]}.items():
        chunks.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode()
        )
    chunks.append(
        f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{path.name}"\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()
    )
    chunks.append(path.read_bytes())
    chunks.append(f"\r\n--{boundary}--\r\n".encode())
    token = settings().get("token") or ""
    request = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/{method}",
        data=b"".join(chunks),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            data = json.loads(response.read().decode("utf-8", errors="replace"))
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read().decode("utf-8", errors="replace")
            detail = json.loads(body).get("description", body)
        except Exception:
            detail = f"HTTP {exc.code}"
        raise RuntimeError(f"Telegram {method}: {detail}") from exc
    if not data.get("ok"):
        raise RuntimeError(
            f"Telegram {method}: {data.get('description') or 'upload error'}"
        )


def send_bytes(chat_id: str, filename: str, data: bytes, caption: str = "") -> None:
    with tempfile.TemporaryDirectory(prefix="awgui-tg-") as directory:
        path = Path(directory) / Path(filename).name
        path.write_bytes(data)
        multipart("sendDocument", chat_id, path, "document", caption or path.name)


def download_telegram_file(
    file_id: str, max_bytes: int = config.MAX_UPLOAD_BYTES
) -> bytes:
    info = api("getFile", {"file_id": file_id}, timeout=30).get("result", {})
    file_path = str(info.get("file_path") or "")
    if not file_path:
        raise RuntimeError("Telegram не вернул file_path")
    token = settings().get("token") or ""
    try:
        with urllib.request.urlopen(
            f"https://api.telegram.org/file/bot{token}/{file_path}", timeout=120
        ) as response:
            data = response.read(max_bytes + 1)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Telegram file download: HTTP {exc.code}") from exc
    if len(data) > max_bytes:
        raise ValueError("Файл превышает допустимый размер")
    return data


def _option(args: list[str], prefix: str, default: str = "") -> str:
    return next(
        (item.split("=", 1)[1] for item in args if item.startswith(prefix + "=")),
        default,
    )


def _plain_args(args: list[str]) -> list[str]:
    return [item for item in args if not item.startswith("--")]


def esc(value: Any) -> str:
    return html.escape(str(value or ""), quote=False)


def name_token(name: str) -> str:
    token = hashlib.sha256(name.encode("utf-8")).hexdigest()[:16]
    if len(CALLBACK_NAMES) >= 2048:
        CALLBACK_NAMES.clear()
    CALLBACK_NAMES[token] = name
    return token


def token_name(chat_id: str, token: str) -> str | None:
    cached = CALLBACK_NAMES.get(token)
    if cached:
        return cached
    result = manager(chat_id).list_clients()
    if result.ok and isinstance(result.data, list):
        for item in result.data:
            name = str(item.get("name") or "")
            if name and hashlib.sha256(name.encode("utf-8")).hexdigest()[:16] == token:
                CALLBACK_NAMES[token] = name
                return name
    return None


def keyboard(rows: list[list[tuple[str, str]]]) -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [{"text": title, "callback_data": data} for title, data in row]
            for row in rows
        ]
    }


def send(chat_id: str, text: str, kb: dict[str, Any] | None = None) -> None:
    payload: dict[str, Any] = {
        "chat_id": chat_id,
        "text": text[:MAX_TEXT],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if kb:
        payload["reply_markup"] = kb
    try:
        api("sendMessage", payload)
    except Exception as exc:
        log(str(exc))
        payload.pop("parse_mode", None)
        payload["text"] = (
            text.replace("<b>", "")
            .replace("</b>", "")
            .replace("<code>", "")
            .replace("</code>", "")
            .replace("<pre>", "")
            .replace("</pre>", "")[:MAX_TEXT]
        )
        try:
            api("sendMessage", payload)
        except Exception as retry:
            log(str(retry))


def answer(callback_id: str, text: str = "") -> None:
    try:
        api(
            "answerCallbackQuery",
            {"callback_query_id": callback_id, "text": text[:180]},
            timeout=15,
        )
    except Exception as exc:
        log(str(exc))


def send_result(chat_id: str, title: str, result) -> None:
    text = result.text or "Команда завершена без вывода"
    icon = "✅" if result.ok else "⚠️"
    if len(text) > 3000:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", suffix=".txt", delete=False
        ) as handle:
            handle.write(text)
            path = Path(handle.name)
        try:
            multipart("sendDocument", chat_id, path, "document", f"{icon} {title}")
        except Exception as exc:
            log(str(exc))
            send(chat_id, f"{icon} <b>{esc(title)}</b>\n<pre>{esc(text[:3000])}</pre>")
        finally:
            path.unlink(missing_ok=True)
    else:
        send(chat_id, f"{icon} <b>{esc(title)}</b>\n<pre>{esc(text)}</pre>")


def is_admin(chat_id: str) -> bool:
    return chat_id in {str(x) for x in settings().get("admin_ids", [])}


def require_admin(chat_id: str) -> bool:
    if is_admin(chat_id):
        return True
    send(chat_id, f"Доступ запрещён. chat_id: <code>{esc(chat_id)}</code>")
    return False


def active_server(chat_id: str) -> dict[str, Any]:
    return (
        state.get_server(state.telegram_server(chat_id))
        or state.get_server("local")
        or {}
    )


def manager(chat_id: str) -> AWGManager:
    return AWGManager(active_server(chat_id))


def main_menu(chat_id: str) -> None:
    server = active_server(chat_id)
    mgr = AWGManager(server)
    probe = mgr.probe()
    count = 0
    if (
        probe["clients"]
        and probe["clients"].ok
        and isinstance(probe["clients"].data, list)
    ):
        count = len(probe["clients"].data)
    text = f"<b>AWGUI · {esc(server.get('name'))}</b>\nAWG: {'установлен' if probe['installed'] else 'не установлен'} · клиентов: {count}"
    send(
        chat_id,
        text,
        keyboard(
            [
                [("📊 Статус", "status"), ("👥 Клиенты", "clients")],
                [("➕ Добавить", "add"), ("🛠 Сервер", "maintenance")],
                [("🌐 Серверы", "servers"), ("🔀 Каскад", "cascade")],
                [("❓ Помощь", "help")],
            ]
        ),
    )


def clients_menu(chat_id: str) -> None:
    result = manager(chat_id).list_clients()
    if not result.ok or not isinstance(result.data, list):
        send_result(chat_id, "Клиенты", result)
        return
    lines = [f"<b>Клиенты · {esc(active_server(chat_id).get('name'))}</b>"]
    rows: list[list[tuple[str, str]]] = []
    for item in result.data[:30]:
        name = str(item.get("name") or "")
        lines.append(
            f"• <code>{esc(name)}</code> — {esc(item.get('status') or item.get('status_code') or '—')}"
        )
        rows.append([(name, f"client:{name_token(name)}")])
    rows.append([("➕ Добавить", "add"), ("⬅️ Меню", "menu")])
    send(chat_id, "\n".join(lines), keyboard(rows))


def client_menu(chat_id: str, name: str) -> None:
    token = name_token(name)
    send(
        chat_id,
        f"<b>Клиент:</b> <code>{esc(name)}</code>",
        keyboard(
            [
                [("QR", f"file:png:{token}"), ("conf", f"file:conf:{token}")],
                [
                    ("vpn://", f"file:vpnuri:{token}"),
                    ("vpn QR", f"file:vpnuri_png:{token}"),
                ],
                [("bundle", f"bundle:{token}"), ("regen", f"regen:{token}")],
                [("удалить", f"removeask:{token}"), ("⬅️ Клиенты", "clients")],
            ]
        ),
    )


def server_menu(chat_id: str) -> None:
    send(
        chat_id,
        f"<b>Сервер · {esc(active_server(chat_id).get('name'))}</b>",
        keyboard(
            [
                [
                    ("status", "cmd:status"),
                    ("check", "cmd:check"),
                    ("show", "cmd:show"),
                ],
                [
                    ("stats", "cmd:stats"),
                    ("backup", "cmd:backup"),
                    ("diagnose", "diagnose"),
                ],
                [("restart", "restartask"), ("repair", "repairask")],
                [("⬅️ Меню", "menu")],
            ]
        ),
    )


def servers_menu(chat_id: str) -> None:
    current = state.telegram_server(chat_id)
    rows = [
        [(("✓ " if s["id"] == current else "") + str(s["name"]), f"setsrv:{s['id']}")]
        for s in state.list_servers()
    ]
    rows.append([("⬅️ Меню", "menu")])
    send(chat_id, "<b>Выберите сервер</b>", keyboard(rows))


def cascade_menu(chat_id: str) -> None:
    send(
        chat_id,
        "<b>Каскад</b>\nПолный мастер находится в web-панели. В Telegram доступны статус и отдельные шаги командой <code>/cascade ENTRY EXIT [LINK]</code>.",
        keyboard(
            [
                [("Список серверов", "servers"), ("⬅️ Меню", "menu")],
            ]
        ),
    )


def send_client_file(chat_id: str, name: str, kind: str) -> None:
    item = manager(chat_id).client_file(name, kind)
    if not item:
        send(chat_id, "Файл не найден")
        return
    filename, data = item
    with tempfile.TemporaryDirectory(prefix="awgui-tg-") as directory:
        path = Path(directory) / filename
        path.write_bytes(data)
        try:
            is_image = kind in {"png", "vpnuri_png"}
            multipart(
                "sendPhoto" if is_image else "sendDocument",
                chat_id,
                path,
                "photo" if is_image else "document",
                name,
            )
        except Exception as exc:
            send(chat_id, f"Ошибка отправки: {esc(exc)}")


def handle_callback(callback: dict[str, Any]) -> None:
    data = str(callback.get("data") or "")
    chat_id = str(callback.get("message", {}).get("chat", {}).get("id", ""))
    if not chat_id or not require_admin(chat_id):
        return
    answer(str(callback.get("id") or ""))
    mgr = manager(chat_id)
    if data in {"menu", "start"}:
        main_menu(chat_id)
    elif data == "clients":
        clients_menu(chat_id)
    elif data.startswith("client:"):
        name = token_name(chat_id, data.split(":", 1)[1])
        if name:
            client_menu(chat_id, name)
        else:
            send(chat_id, "Кнопка устарела. Откройте список клиентов заново.")
    elif data == "add":
        PENDING[chat_id] = {"type": "add"}
        send(chat_id, "Отправьте: <code>имя [1h|12h|1d|7d|30d|4w] [psk]</code>")
    elif data.startswith("file:"):
        _, kind, token = data.split(":", 2)
        name = token_name(chat_id, token)
        if name:
            send_client_file(chat_id, name, kind)
        else:
            send(chat_id, "Кнопка устарела. Откройте клиента заново.")
    elif data.startswith("bundle:"):
        name = token_name(chat_id, data.split(":", 1)[1])
        if not name:
            send(chat_id, "Кнопка устарела. Откройте клиента заново.")
            return
        payload = mgr.client_bundle(name)
        if not payload:
            send(chat_id, "Файлы не найдены")
            return
        try:
            send_bytes(chat_id, f"{name}-bundle.tar.gz", payload, name)
        except Exception as exc:
            send(chat_id, f"Ошибка отправки: {esc(exc)}")
    elif data.startswith("regen:"):
        name = token_name(chat_id, data.split(":", 1)[1])
        if name:
            send_result(chat_id, "regen", mgr.regen([name]))
        else:
            send(chat_id, "Кнопка устарела. Откройте клиента заново.")
    elif data.startswith("removeask:"):
        token = data.split(":", 1)[1]
        name = token_name(chat_id, token)
        if not name:
            send(chat_id, "Кнопка устарела. Откройте клиента заново.")
            return
        send(
            chat_id,
            f"Удалить <code>{esc(name)}</code>?",
            keyboard([[("Удалить", f"remove:{token}"), ("Отмена", f"client:{token}")]]),
        )
    elif data.startswith("remove:"):
        if not settings().get("dangerous"):
            send(chat_id, "Опасные действия выключены в Settings")
            return
        name = token_name(chat_id, data.split(":", 1)[1])
        if name:
            send_result(chat_id, "remove", mgr.remove([name]))
        else:
            send(chat_id, "Кнопка устарела. Откройте клиента заново.")
    elif data == "maintenance":
        server_menu(chat_id)
    elif data.startswith("cmd:"):
        command = data.split(":", 1)[1]
        result = mgr.stats() if command == "stats" else mgr.run_manage(command)
        send_result(chat_id, command, result)
    elif data == "diagnose":
        send_result(chat_id, "diagnose", mgr.run_manage("diagnose", timeout=900))
    elif data == "restartask":
        send(
            chat_id,
            "Перезапустить AWG?",
            keyboard([[("Подтвердить", "restart"), ("Отмена", "maintenance")]]),
        )
    elif data == "restart":
        if settings().get("dangerous"):
            send_result(
                chat_id, "restart", mgr.run_manage("restart", yes=True, timeout=300)
            )
        else:
            send(chat_id, "Опасные действия выключены")
    elif data == "repairask":
        send(
            chat_id,
            "Запустить repair-module?",
            keyboard([[("Подтвердить", "repair"), ("Отмена", "maintenance")]]),
        )
    elif data == "repair":
        if settings().get("dangerous"):
            send_result(
                chat_id, "repair-module", mgr.run_manage("repair-module", timeout=1800)
            )
        else:
            send(chat_id, "Опасные действия выключены")
    elif data == "servers":
        servers_menu(chat_id)
    elif data.startswith("setsrv:"):
        state.set_telegram_server(chat_id, data.split(":", 1)[1])
        main_menu(chat_id)
    elif data == "cascade":
        cascade_menu(chat_id)
    elif data == "help":
        send(chat_id, HELP)


HELP = """<b>AWGUI Bot</b>
/id — показать chat_id (доступно до настройки)
/menu — интерактивное меню
/server [ID] — выбрать сервер · /servers — список
/addserver ID HOST [PORT] [USER] [KEY] [NAME]
/delserver ID DELETE
/clients · /list [verbose]
/add NAME [NAME2] [--expires=7d] [--psk] [--apply-mode=restart]
/remove NAME [NAME2] [--confirm=REMOVE] · /regen NAME [NAME2]|all
/modify NAME DNS|Endpoint|AllowedIPs|PersistentKeepalive VALUE [--apply-mode=restart]
/conf NAME · /qr NAME · /vpnuri NAME · /vpnuriqr NAME · /bundle NAME
/status · /check · /show · /stats [raw] · /diagnose [carrier]
/backup · /backups · /backupfile BACKUP
/uploadbackup — подпись к отправляемому .tar.gz
/restore BACKUP --confirm=RESTORE · /restart · /repair
/cascade ENTRY EXIT [LINK] — состояние
/cascade_step ENTRY EXIT STEP [LINK] --confirm=CASCADE
Шаги: prerequisites, create_link, transfer_conf, start_tunnel, install_routing, run_routing, enable_service
"""


def handle_command(chat_id: str, text: str) -> None:
    try:
        parts = shlex.split(text.strip())
    except ValueError as exc:
        send(chat_id, f"Ошибка аргументов: <code>{esc(exc)}</code>")
        return
    if not parts:
        return
    command = parts[0].split("@", 1)[0].lower()
    args = parts[1:]
    if command == "/id":
        send(chat_id, f"Ваш chat_id: <code>{esc(chat_id)}</code>")
        return
    if not require_admin(chat_id):
        return
    mgr = manager(chat_id)
    try:
        if command in {"/start", "/menu"}:
            main_menu(chat_id)
        elif command == "/server":
            if args:
                state.set_telegram_server(chat_id, args[0])
                main_menu(chat_id)
            else:
                servers_menu(chat_id)
        elif command in {"/clients", "/list"}:
            if command == "/list" and args and args[0].lower() in {"-v", "verbose"}:
                send_result(chat_id, "list -v", mgr.run_manage("list", verbose=True))
            else:
                clients_menu(chat_id)
        elif command == "/add":
            durations = {"1h", "12h", "1d", "7d", "30d", "4w"}
            expires = _option(args, "--expires") or next(
                (x for x in args if x in durations), ""
            )
            apply_mode = _option(args, "--apply-mode", "syncconf")
            psk = "psk" in args or "--psk" in args
            names = [x for x in _plain_args(args) if x not in durations and x != "psk"]
            if not names:
                send(
                    chat_id,
                    "Использование: /add NAME [NAME2] [--expires=7d] [--psk] [--apply-mode=restart]",
                )
                return
            send_result(
                chat_id,
                "add",
                mgr.add(names, expires=expires, psk=psk, apply_mode=apply_mode),
            )
        elif command == "/remove":
            confirm = _option(args, "--confirm")
            names = _plain_args(args)
            if not names:
                send(chat_id, "Использование: /remove NAME [NAME2] [--confirm=REMOVE]")
                return
            if len(names) == 1 and confirm != "REMOVE":
                send(
                    chat_id,
                    f"Удалить <code>{esc(names[0])}</code>?",
                    keyboard(
                        [
                            [
                                ("Удалить", f"remove:{name_token(names[0])}"),
                                ("Отмена", "clients"),
                            ]
                        ]
                    ),
                )
                return
            if not settings().get("dangerous") or confirm != "REMOVE":
                send(
                    chat_id,
                    "Для нескольких клиентов: включите опасные действия и добавьте --confirm=REMOVE",
                )
                return
            send_result(
                chat_id,
                "remove",
                mgr.remove(names, apply_mode=_option(args, "--apply-mode", "syncconf")),
            )
        elif command == "/regen":
            apply_mode = _option(args, "--apply-mode", "syncconf")
            names = _plain_args(args)
            send_result(
                chat_id,
                "regen",
                mgr.regen(
                    [] if not names or names == ["all"] else names,
                    apply_mode=apply_mode,
                ),
            )
        elif command in {"/conf", "/qr", "/vpnuri", "/vpnuriqr", "/bundle"}:
            if not args:
                send(chat_id, f"Использование: {command} NAME")
                return
            if command == "/bundle":
                payload = mgr.client_bundle(args[0])
                if not payload:
                    send(chat_id, "Файлы не найдены")
                    return
                try:
                    send_bytes(chat_id, f"{args[0]}-bundle.tar.gz", payload, args[0])
                except Exception as exc:
                    send(chat_id, f"Ошибка отправки: {esc(exc)}")
            else:
                send_client_file(
                    chat_id,
                    args[0],
                    {
                        "/conf": "conf",
                        "/qr": "png",
                        "/vpnuri": "vpnuri",
                        "/vpnuriqr": "vpnuri_png",
                    }[command],
                )
        elif command in {"/status", "/check", "/show", "/backup"}:
            send_result(chat_id, command[1:], mgr.run_manage(command[1:]))
        elif command == "/stats":
            send_result(
                chat_id,
                "stats",
                mgr.run_manage("stats")
                if args and args[0].lower() == "raw"
                else mgr.stats(),
            )
        elif command == "/diagnose":
            send_result(
                chat_id,
                "diagnose",
                mgr.run_manage(
                    "diagnose", carrier=args[0] if args else "", timeout=900
                ),
            )
        elif command == "/restart":
            send(
                chat_id,
                "Подтвердить restart",
                keyboard([[("Restart", "restart"), ("Отмена", "maintenance")]]),
            )
        elif command == "/repair":
            send(
                chat_id,
                "Подтвердить repair-module",
                keyboard([[("Repair", "repair"), ("Отмена", "maintenance")]]),
            )
        elif command == "/servers":
            lines = [
                f"{'✓ ' if x['id'] == state.telegram_server(chat_id) else ''}{x['id']}: {x['name']} ({x['mode']})"
                for x in state.list_servers()
            ]
            send(chat_id, "<b>Серверы</b>\n" + "\n".join(esc(x) for x in lines))
        elif command == "/addserver":
            if len(args) < 2:
                send(
                    chat_id,
                    "Использование: /addserver ID HOST [PORT] [USER] [KEY] [NAME]",
                )
                return
            sid, host = args[0], args[1]
            server = make_ssh_server(
                sid,
                host,
                port=int(args[2]) if len(args) > 2 else 22,
                user=args[3] if len(args) > 3 else "root",
                key_path=args[4] if len(args) > 4 else "",
                name=args[5] if len(args) > 5 else sid,
            )
            state.upsert_server(server)
            send(chat_id, f"Сервер <code>{esc(sid)}</code> сохранён")
        elif command == "/delserver":
            if not args:
                send(chat_id, "Использование: /delserver ID DELETE")
                return
            if not settings().get("dangerous") or len(args) < 2 or args[1] != "DELETE":
                send(
                    chat_id,
                    "Включите опасные действия и подтвердите: /delserver ID DELETE",
                )
                return
            send(
                chat_id,
                "Удалён из панели" if state.delete_server(args[0]) else "Не удалён",
            )
        elif command == "/modify":
            apply_mode = _option(args, "--apply-mode", "syncconf")
            plain = _plain_args(args)
            if len(plain) < 3:
                send(
                    chat_id,
                    "Использование: /modify NAME PARAM VALUE [--apply-mode=restart]",
                )
                return
            send_result(
                chat_id,
                "modify",
                mgr.modify(
                    plain[0], plain[1], " ".join(plain[2:]), apply_mode=apply_mode
                ),
            )
        elif command == "/backups":
            items = mgr.backup_list()
            send(
                chat_id,
                "<b>Бэкапы</b>\n"
                + (
                    "\n".join(f"• <code>{esc(x['name'])}</code>" for x in items)
                    if items
                    else "Нет"
                ),
            )
        elif command == "/backupfile":
            if not args:
                send(chat_id, "Использование: /backupfile BACKUP")
                return
            item = mgr.backup_file(args[0])
            if not item:
                send(chat_id, "Бэкап не найден")
                return
            try:
                send_bytes(chat_id, item[0], item[1], item[0])
            except Exception as exc:
                send(chat_id, f"Ошибка отправки: {esc(exc)}")
        elif command == "/restore":
            if not args:
                send(chat_id, "Использование: /restore BACKUP --confirm=RESTORE")
                return
            if (
                not settings().get("dangerous")
                or _option(args, "--confirm") != "RESTORE"
            ):
                send(chat_id, "Включите опасные действия и добавьте --confirm=RESTORE")
                return
            item = next((x for x in mgr.backup_list() if x["name"] == args[0]), None)
            if not item:
                send(chat_id, "Бэкап не найден")
                return
            send_result(
                chat_id,
                "restore",
                mgr.run_manage("restore", item["path"], yes=True, timeout=1800),
            )
        elif command == "/cascade":
            plain = _plain_args(args)
            if len(plain) < 2:
                send(chat_id, "Использование: /cascade ENTRY_ID EXIT_ID [LINK_NAME]")
                return
            if plain[0] == plain[1]:
                send(chat_id, "AWG0 и AWG1 должны быть разными серверами")
                return
            entry_spec, exit_spec = (
                state.get_server(plain[0]),
                state.get_server(plain[1]),
            )
            if not entry_spec or not exit_spec:
                send(chat_id, "Сервер не найден")
                return
            steps = cascade.status(
                AWGManager(entry_spec),
                AWGManager(exit_spec),
                plain[2] if len(plain) > 2 else "ru_host",
            )
            send(
                chat_id,
                "<b>Cascade status</b>\n"
                + "\n".join(
                    ("✅" if st.ok else "⚠️") + f" {esc(st.title)} — {esc(st.detail)}"
                    for st in steps
                ),
            )
        elif command == "/cascade_step":
            plain = _plain_args(args)
            if len(plain) < 3:
                send(
                    chat_id,
                    "Использование: /cascade_step ENTRY EXIT STEP [LINK] --confirm=CASCADE",
                )
                return
            if plain[0] == plain[1]:
                send(chat_id, "AWG0 и AWG1 должны быть разными серверами")
                return
            if (
                not settings().get("dangerous")
                or _option(args, "--confirm") != "CASCADE"
            ):
                send(chat_id, "Включите опасные действия и добавьте --confirm=CASCADE")
                return
            entry_spec, exit_spec = (
                state.get_server(plain[0]),
                state.get_server(plain[1]),
            )
            step = plain[2]
            link = plain[3] if len(plain) > 3 else "ru_host"
            if not entry_spec or not exit_spec:
                send(chat_id, "Сервер не найден")
                return
            entry, exit_mgr = AWGManager(entry_spec), AWGManager(exit_spec)
            funcs = {
                "prerequisites": lambda: cascade.install_prerequisites(entry),
                "create_link": lambda: cascade.create_link_client(exit_mgr, link),
                "transfer_conf": lambda: cascade.transfer_link_config(
                    entry, exit_mgr, link
                ),
                "start_tunnel": lambda: cascade.start_link_tunnel(entry),
                "install_routing": lambda: cascade.install_routing(entry),
                "run_routing": lambda: cascade.run_routing(entry),
                "enable_service": lambda: cascade.enable_routing_service(entry),
            }
            if step not in funcs:
                send(chat_id, "Неизвестный шаг")
                return
            send_result(chat_id, f"cascade {step}", funcs[step]())
        elif command == "/help":
            send(chat_id, HELP)
        else:
            send(chat_id, "Неизвестная команда. /help")
    except Exception as exc:
        log(f"command {command}: {type(exc).__name__}: {exc}")
        send(chat_id, f"Ошибка: <code>{esc(exc)}</code>")


def handle_document(message: dict[str, Any]) -> bool:
    document = message.get("document")
    if not isinstance(document, dict):
        return False
    chat_id = str(message.get("chat", {}).get("id", ""))
    caption = str(message.get("caption") or "").strip().split("@", 1)[0]
    if not chat_id or not require_admin(chat_id):
        return True
    if not caption.startswith("/uploadbackup"):
        send(
            chat_id,
            "Для загрузки отправьте штатный awg_backup_*.tar.gz с подписью /uploadbackup",
        )
        return True
    filename = Path(str(document.get("file_name") or "backup.tar.gz")).name
    if not re.fullmatch(r"awg_backup_[A-Za-z0-9_.-]+\.tar\.gz", filename):
        send(chat_id, "Ожидается штатный awg_backup_*.tar.gz")
        return True
    try:
        data = download_telegram_file(str(document.get("file_id") or ""))
        send_result(
            chat_id, "upload backup", manager(chat_id).upload_backup(filename, data)
        )
    except Exception as exc:
        log(f"upload backup: {type(exc).__name__}: {exc}")
        send(chat_id, f"Ошибка загрузки: <code>{esc(exc)}</code>")
    return True


def handle_message(message: dict[str, Any]) -> None:
    if handle_document(message):
        return
    chat_id = str(message.get("chat", {}).get("id", ""))
    text = str(message.get("text") or "").strip()
    if not chat_id or not text:
        return
    pending = PENDING.pop(chat_id, None)
    if pending and pending.get("type") == "add":
        handle_command(chat_id, "/add " + text)
        return
    handle_command(chat_id, text)


def main() -> None:
    offset = 0
    active_token = ""
    while True:
        cfg = settings()
        token = str(cfg.get("token") or "")
        if not cfg.get("enabled") or not token:
            active_token = ""
            time.sleep(5)
            continue
        try:
            if token != active_token:
                offset = 0
                api("deleteWebhook", {"drop_pending_updates": False}, timeout=20)
                active_token = token
            result = api(
                "getUpdates",
                {
                    "offset": offset,
                    "timeout": 30,
                    "allowed_updates": ["message", "callback_query"],
                },
                timeout=40,
            )
            for update in result.get("result", []):
                offset = max(offset, int(update.get("update_id", 0)) + 1)
                if update.get("callback_query"):
                    handle_callback(update["callback_query"])
                elif update.get("message"):
                    handle_message(update["message"])
        except Exception as exc:
            log(f"poll: {type(exc).__name__}: {exc}")
            time.sleep(5)


if __name__ == "__main__":
    main()
