from __future__ import annotations

import hmac
import io
import secrets
import subprocess
from functools import wraps
from typing import Any, Callable, TypeVar
from urllib.parse import urlsplit

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

from . import cascade, config, state
from .manager import AWGManager, Result, make_ssh_server

F = TypeVar("F", bound=Callable)


def _manager(server_id: str | None = None) -> AWGManager:
    sid = server_id or str(session.get("server_id") or "local")
    server = state.get_server(sid) or state.get_server("local")
    if server is None:
        raise RuntimeError("В конфигурации AWGUI отсутствует локальный сервер")
    return AWGManager(server)


def _split_names(value: str) -> list[str]:
    return [x for x in value.replace(",", " ").split() if x]


def _clean(value: str, label: str) -> str:
    value = (value or "").strip()
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"Недопустимое значение: {label}")
    return value


def _merge_client_stats(
    clients: list[dict[str, Any]], statistics: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    stats_by_name = {
        str(item.get("name")): item
        for item in statistics
        if isinstance(item, dict) and item.get("name")
    }
    rows: list[dict[str, Any]] = []
    for client in clients:
        row = dict(client)
        stat = stats_by_name.get(str(client.get("name") or ""))
        if stat:
            row.update(stat)
        rows.append(row)
    return rows


def _safe_local_url(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urlsplit(value)
    if (
        parsed.scheme
        or parsed.netloc
        or not parsed.path.startswith("/")
        or parsed.path.startswith("//")
    ):
        return None
    return value


def create_app() -> Flask:
    if not config.ADMIN_PASSWORD or not config.SECRET_KEY:
        raise RuntimeError(
            "AWGUI_ADMIN_PASSWORD and AWGUI_SECRET_KEY must be configured"
        )
    app = Flask(__name__)
    app.secret_key = config.SECRET_KEY
    app.config.update(
        MAX_CONTENT_LENGTH=config.MAX_UPLOAD_BYTES,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
    )

    def login_required(fn: F) -> F:
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not session.get("authenticated"):
                return redirect(url_for("login", next=request.path))
            return fn(*args, **kwargs)

        return wrapped  # type: ignore[return-value]

    def csrf_token() -> str:
        token = session.get("csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["csrf_token"] = token
        return token

    @app.before_request
    def csrf_check():
        if request.method == "POST" and request.endpoint != "login":
            expected = session.get("csrf_token", "")
            supplied = request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(str(expected), str(supplied)):
                abort(400, "CSRF")

    @app.context_processor
    def context() -> dict[str, Any]:
        servers = state.list_servers()
        sid = str(session.get("server_id") or "local")
        active = state.get_server(sid) or state.get_server("local")
        return {
            "version": config.APP_VERSION,
            "csrf_token": csrf_token,
            "servers": servers,
            "active_server": active,
        }

    def show_result(result: Result | None) -> dict[str, Any] | None:
        if result is None:
            return None
        return {
            "ok": result.ok,
            "rc": result.rc,
            "command": result.command,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "duration": result.duration,
        }

    @app.get("/health")
    def health():
        manager = _manager("local")
        return {
            "panel": "ok",
            "version": config.APP_VERSION,
            "local_awg_installed": manager.installed(),
        }

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            user_ok = hmac.compare_digest(
                request.form.get("username", ""), config.ADMIN_USER
            )
            pass_ok = hmac.compare_digest(
                request.form.get("password", ""), config.ADMIN_PASSWORD
            )
            if user_ok and pass_ok:
                session.clear()
                session["authenticated"] = True
                session["server_id"] = "local"
                next_url = request.args.get("next", "")
                return redirect(_safe_local_url(next_url) or url_for("dashboard"))
            flash("Неверный логин или пароль", "error")
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        session.clear()
        return redirect(url_for("login"))

    @app.post("/select-server")
    @login_required
    def select_server():
        sid = request.form.get("server_id", "local")
        if not state.get_server(sid):
            abort(404)
        session["server_id"] = sid
        return redirect(_safe_local_url(request.referrer) or url_for("dashboard"))

    @app.get("/")
    @login_required
    def dashboard():
        manager = _manager()
        probe = manager.probe()
        clients = (
            probe["clients"].data
            if probe["clients"]
            and probe["clients"].ok
            and isinstance(probe["clients"].data, list)
            else []
        )
        stats = manager.stats() if probe["installed"] else None
        statistics = (
            stats.data if stats and stats.ok and isinstance(stats.data, list) else []
        )
        return render_template(
            "dashboard.html",
            probe=probe,
            clients=_merge_client_stats(clients, statistics),
            stats=statistics,
            error=None
            if not probe["clients"] or probe["clients"].ok
            else probe["clients"].text,
        )

    @app.route("/clients", methods=["GET", "POST"])
    @login_required
    def clients():
        manager = _manager()
        result: Result | None = None
        if request.method == "POST":
            try:
                action = request.form.get("action", "")
                apply_mode = request.form.get("apply_mode", "syncconf")
                if action == "add":
                    result = manager.add(
                        _split_names(request.form.get("names", "")),
                        expires=request.form.get("expires", ""),
                        psk=bool(request.form.get("psk")),
                        apply_mode=apply_mode,
                    )
                elif action == "remove":
                    if request.form.get("confirm") != "REMOVE":
                        raise ValueError("Введите REMOVE")
                    result = manager.remove(
                        _split_names(request.form.get("names", "")),
                        apply_mode=apply_mode,
                    )
                elif action == "regen":
                    result = manager.regen(
                        _split_names(request.form.get("names", "")),
                        apply_mode=apply_mode,
                    )
                elif action == "modify":
                    result = manager.modify(
                        request.form.get("name", ""),
                        request.form.get("parameter", ""),
                        request.form.get("value", ""),
                        apply_mode=apply_mode,
                    )
                elif action == "list_verbose":
                    result = manager.run_manage("list", verbose=True)
                elif action == "stats_raw":
                    result = manager.run_manage("stats")
                else:
                    raise ValueError("Неизвестная операция")
            except ValueError as exc:
                flash(str(exc), "error")
        listing = manager.list_clients()
        statistics = manager.stats()
        listed_clients = (
            listing.data if listing.ok and isinstance(listing.data, list) else []
        )
        client_stats = (
            statistics.data
            if statistics.ok and isinstance(statistics.data, list)
            else []
        )
        return render_template(
            "clients.html",
            installed=manager.installed(),
            clients=_merge_client_stats(listed_clients, client_stats),
            stats=client_stats,
            list_error=None if listing.ok else listing.text,
            stats_error=None if statistics.ok else statistics.text,
            result=show_result(result),
        )

    @app.get("/clients/<name>/file/<kind>")
    @login_required
    def client_file(name: str, kind: str):
        try:
            item = _manager().client_file(name, kind)
        except ValueError:
            item = None
        if not item:
            abort(404)
        filename, data = item
        return send_file(io.BytesIO(data), as_attachment=True, download_name=filename)

    @app.get("/clients/<name>/bundle")
    @login_required
    def client_bundle(name: str):
        try:
            data = _manager().client_bundle(name)
        except ValueError:
            data = None
        if not data:
            abort(404)
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=f"{name}-bundle.tar.gz",
            mimetype="application/gzip",
        )

    def server_page(result: Result | None = None):
        manager = _manager()
        return render_template(
            "servers.html",
            manager=manager,
            probe=manager.probe(),
            backups=manager.backup_list(),
            result=show_result(result),
        )

    @app.get("/servers")
    @login_required
    def servers_page():
        return server_page()

    @app.post("/servers/add")
    @login_required
    def server_add():
        try:
            server = make_ssh_server(
                request.form.get("id", ""),
                _clean(request.form.get("host", ""), "host"),
                port=int(request.form.get("port", "22")),
                user=_clean(request.form.get("user", "root"), "user"),
                key_path=_clean(request.form.get("key_path", ""), "key_path"),
                name=_clean(request.form.get("name", ""), "name"),
                manage_path=_clean(
                    request.form.get("manage_path", config.LOCAL_MANAGE), "manage_path"
                ),
                awg_dir=_clean(
                    request.form.get("awg_dir", config.LOCAL_AWG_DIR), "awg_dir"
                ),
                server_conf=_clean(
                    request.form.get("server_conf", config.LOCAL_SERVER_CONF),
                    "server_conf",
                ),
            )
            state.upsert_server(server)
            flash("Сервер сохранён", "success")
        except (ValueError, TypeError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("servers_page"))

    @app.post("/servers/delete")
    @login_required
    def server_delete():
        sid = request.form.get("server_id", "")
        if request.form.get("confirm") != "DELETE" or not state.delete_server(sid):
            flash("Сервер не удалён: проверьте ID и подтверждение DELETE", "error")
        else:
            if session.get("server_id") == sid:
                session["server_id"] = "local"
            flash("Сервер удалён из панели; AWG на нём не изменён", "success")
        return redirect(url_for("servers_page"))

    @app.post("/servers/action")
    @login_required
    def server_action():
        manager = _manager()
        action = request.form.get("action", "")
        result: Result | None = None
        try:
            if action == "probe":
                result = (
                    manager.run_manage("status", timeout=60)
                    if manager.installed()
                    else Result(
                        False,
                        127,
                        manager.manage_path,
                        "",
                        f"Не найден установленный {manager.manage_path}",
                        0.0,
                    )
                )
            elif action in {"status", "check", "show", "help", "backup"}:
                result = manager.run_manage(action)
            elif action == "diagnose":
                result = manager.run_manage(
                    "diagnose", carrier=request.form.get("carrier", ""), timeout=900
                )
            elif action in {"restart", "repair-module"}:
                if request.form.get("confirm") != "RUN":
                    raise ValueError("Введите RUN")
                result = manager.run_manage(action, yes=True, timeout=1800)
            else:
                raise ValueError("Неизвестное действие")
        except ValueError as exc:
            flash(str(exc), "error")
        return server_page(result)

    @app.post("/servers/restore")
    @login_required
    def server_restore():
        manager = _manager()
        if request.form.get("confirm") != "RESTORE":
            flash("Введите RESTORE", "error")
            return server_page()
        name = request.form.get("backup", "")
        item = next((x for x in manager.backup_list() if x["name"] == name), None)
        if not item:
            flash("Бэкап не найден", "error")
            return server_page()
        return server_page(
            manager.run_manage("restore", item["path"], yes=True, timeout=1800)
        )

    @app.post("/servers/upload-backup")
    @login_required
    def server_upload_backup():
        upload = request.files.get("backup")
        if not upload or not upload.filename:
            flash("Выберите .tar.gz", "error")
        else:
            result = _manager().upload_backup(upload.filename, upload.read())
            flash(
                "Бэкап загружен" if result.ok else result.text,
                "success" if result.ok else "error",
            )
        return redirect(url_for("servers_page"))

    @app.get("/servers/backups/<name>")
    @login_required
    def backup_download(name: str):
        item = _manager().backup_file(name)
        if not item:
            abort(404)
        filename, data = item
        return send_file(
            io.BytesIO(data),
            as_attachment=True,
            download_name=filename,
            mimetype="application/gzip",
        )

    def cascade_page(result: Result | None = None):
        servers = state.list_servers()
        entry_id = request.values.get("entry_id") or str(
            session.get("cascade_entry") or "local"
        )
        exit_id = request.values.get("exit_id") or str(
            session.get("cascade_exit")
            or (servers[1]["id"] if len(servers) > 1 else "local")
        )
        link_name = request.values.get("link_name") or "ru_host"
        session["cascade_entry"], session["cascade_exit"] = entry_id, exit_id
        entry_spec, exit_spec = state.get_server(entry_id), state.get_server(exit_id)
        steps = []
        if entry_spec and exit_spec and entry_id != exit_id:
            try:
                steps = cascade.status(
                    AWGManager(entry_spec), AWGManager(exit_spec), link_name
                )
            except ValueError as exc:
                flash(str(exc), "error")
        return render_template(
            "cascade.html",
            entry_id=entry_id,
            exit_id=exit_id,
            link_name=link_name,
            steps=steps,
            result=show_result(result),
        )

    @app.route("/cascade", methods=["GET", "POST"])
    @login_required
    def cascade_view():
        if request.method == "GET":
            return cascade_page()
        entry_id, exit_id = (
            request.form.get("entry_id", ""),
            request.form.get("exit_id", ""),
        )
        link_name = request.form.get("link_name", "ru_host")
        if entry_id == exit_id:
            flash("AWG0 и AWG1 должны быть разными серверами", "error")
            return cascade_page()
        entry_spec, exit_spec = state.get_server(entry_id), state.get_server(exit_id)
        if not entry_spec or not exit_spec:
            abort(404)
        entry, exit_server = AWGManager(entry_spec), AWGManager(exit_spec)
        action = request.form.get("action", "")
        result: Result | None = None
        try:
            if action == "prerequisites":
                result = cascade.install_prerequisites(entry)
            elif action == "create_link":
                result = cascade.create_link_client(exit_server, link_name)
            elif action == "transfer_conf":
                result = cascade.transfer_link_config(entry, exit_server, link_name)
            elif action == "start_tunnel":
                result = cascade.start_link_tunnel(entry)
            elif action == "install_routing":
                result = cascade.install_routing(entry)
            elif action == "run_routing":
                if request.form.get("confirm") != "ROUTE":
                    raise ValueError("Введите ROUTE")
                result = cascade.run_routing(entry)
            elif action == "enable_service":
                if request.form.get("confirm") != "ENABLE":
                    raise ValueError("Введите ENABLE")
                result = cascade.enable_routing_service(entry)
            else:
                raise ValueError("Неизвестный шаг каскада")
        except ValueError as exc:
            flash(str(exc), "error")
        return cascade_page(result)

    @app.route("/settings", methods=["GET", "POST"])
    @login_required
    def settings_page():
        if request.method == "POST":
            token = _clean(request.form.get("token", ""), "token")
            ids = [
                x.strip()
                for x in request.form.get("admin_ids", "").replace(",", " ").split()
                if x.strip()
            ]
            settings = {
                "enabled": bool(request.form.get("enabled")),
                "token": token,
                "admin_ids": ids,
                "dangerous": bool(request.form.get("dangerous")),
            }
            state.set_telegram(settings)
            try:
                restarted = subprocess.run(
                    [config.SYSTEMCTL_BIN, "restart", "awgui-bot.service"],
                    capture_output=True,
                    check=False,
                    timeout=15,
                )
                if restarted.returncode == 0:
                    flash("Настройки Telegram сохранены и применены", "success")
                else:
                    flash(
                        "Настройки сохранены, но awgui-bot.service не перезапущен",
                        "error",
                    )
            except (OSError, subprocess.TimeoutExpired):
                flash(
                    "Настройки сохранены, но awgui-bot.service не перезапущен", "error"
                )
        return render_template("settings.html", telegram=state.telegram_settings())

    return app
