"""AWGUI full panel."""
